<template>
	<view
		style="position: fixed;bottom: -6rpx;left: 0;right: 0;background-color: #000000;border-top: 1px solid #FFFFFFA;z-index: 99999;padding: 12rpx 0;">
		<view style="display: flex;align-items: center;justify-content: space-between;">
			<block v-for="(v,k) in list" :key="k">
				<view style="flex:1;text-align: center;padding:6prx 0;cursor: pointer;" @click="linkTo(v)">
					<view>
						<image :src="`/static/tarbar${k}${curKey==v.key?`_act`:`` }.png`" mode="aspectFit"
							:style="$theme.setImageSize(46)"></image>
					</view>
					<view style="font-size: 12px; line-height: normal;font-family: '';"
						:style="{color:curKey==v.key?`#FFF`:`#6e6e6e`}">
						{{v.text}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: "FooterSmall",
		props: {
			// 非一级导航携带参数，用于定位当前自定义tabBar激活项
			code: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				curKey: '', // 当前一级导航KEY
				list: [{
						key: `home`,
						text: this.$lang.TABBAR_HOME,
						url: `/pages/home/index`,
					},
					{
						key: `market`,
						text: this.$lang.TABBAR_MARKET,
						url: `/pages/market/index`,
					}, {
						key: `stock`,
						text: this.$lang.TABBAR_CONTRACT,
						url: `/pages/trade/day/index?type=1&top1=1`,
					}, {
						key: `position`,
						text: this.$lang.max_ping2,
						url: `/pages/position/index`,
					}, {
						key: `assets`,
						text: this.$lang.TABBAR_ACCOUNT,
						url: `/pages/assets/index`,
					}
				]
			};
		},
		beforeMount() {
			this.curKey = this.code;
		},
		methods: {
			linkTo(val) {
				// if (this.curKey == 'stock') {
				// 	uni.navigateTo({
				// 		url: val.url
				// 	})
				// } else {
				uni.switchTab({
					// url: `/pages/${val.key}/index`
					url: val.url
				})
				// }
				this.curKey = '';
			},
		}
	}
</script>

<style>

</style>