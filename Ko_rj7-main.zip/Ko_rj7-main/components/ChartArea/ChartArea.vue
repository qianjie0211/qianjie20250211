<template>
	<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
		<canvas canvas-id="score" id="score" class="charts"></canvas>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import customUChart from '@/common/customUChart.js';
	let uChartsInstance = {};
	export default {
		name: "ChartArea",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
			}
		},
		computed: {
			chartData() {
				console.log(`??`, this.list);
				const temp = this.list.map(item => {
					return {
						name: item.name,
						value: item.extended_price
					}
				});
				return {
					series: [{
						data: temp
					}],
				}
			},
		},
		beforeMount() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			genCharts() {
				console.log(`data:`, this.chartData);
				const ctx = uni.createCanvasContext("score", this);
				uChartsInstance["score"] = new uCharts(customUChart.pieChart(ctx,
					this.chartData,
					this.cWidth,
					this.cHeight));
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>