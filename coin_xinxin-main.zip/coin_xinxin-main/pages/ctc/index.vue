<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;background-color: #FFFFFF;">
		<header class="common_header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding: 0 80rpx;text-align: center;color: #121212;">
				<view style="display: flex;align-items: center;justify-content: space-around;">
					<block v-for="(item,index) in tabs" :key="index">
						<view :style="setStyleTab(curMode==index)" @click="changeTab(index)">{{item}}</view>
					</block>
				</view>
			</view>
			<!-- @click="linkRecord()" -->
			<view class="right" >
				<!-- <image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image> -->
			</view>
		</header>

		<view style="padding:36rpx; padding-bottom: 200rpx;">
			<view style="display: flex;align-items: center;padding-bottom: 36rpx;border-bottom: 1px Solid #ccc;">
				<CustomLogo logo="" :name="$lang.CTC_USDT" :size="48" />
				<view style="font-size: 28rpx;padding-left: 40rpx;" :style="{color:$theme.LOG_VALUE}">{{$lang.CTC_USDT}}
				</view>
			</view>



			<block v-for="(item,index) in list" :key="index">
				<view style="padding: 36rpx 0;border-bottom: 1px Solid #ccc;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 32rpx;font-weight: 900;">{{item.name}}</view>
						<view style="padding:8rpx 36rpx;border-radius: 44rpx;color:#FFF;"
							:style="{backgroundColor:curMode==0?$theme.RISE:$theme.FALL}" @click="linkTo(item.id)">
							{{curMode==0?$lang.CTC_BUY:$lang.CTC_SELL}}
						</view>
					</view>
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.CTC_QTY}} {{item.shuliang}}%</view>
					<view>
						<text style="font-size: 24rpx;font-weight: 700;">{{$lang.CTC_RATE}}</text>
						<text style="font-size: 32rpx;font-weight: 900;">{{item.bili}}%</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.CTC_TIP1}}
						</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{item.jiaoyicishu}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.CTC_MIN}}
						</view>
						<!-- Sell 是USD -->
						<view :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.xiane)}} {{$lang.CTC_USDT}}
						</view>
					</view>
				</view>
			</block>




		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			CustomLogo
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curMode: 0,
				list: [],
			};
		},
		computed: {
			tabs() {
				return [
					this.$lang.COMMON_BUY,
					this.$lang.COMMON_SELL,
				]
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 跳转到买卖页面
			linkTo(id) {
				uni.navigateTo({
					// 0买，1卖
					url: this.$paths.CTC_TRADE + `?id=${id}&type=${this.curMode}`
				})
			},

			// 切换模式
			changeTab(val) {
				this.curMode = val;
				this.getList();
			},

			linkRecord() {
				uni.navigateTo({
					url: this.$paths.CTC_RECORD
				})
			},

			// 
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/app/c2clist`, {
					type: this.curMode + 1,
				});
				if (!result) return false;
				console.log(result);
				this.list = result;
			},

			setStyleTab(val) {
				return {
					borderBottom: `3px Solid ${val?'#295FFF':this.$theme.TRANSPARENT}`
				}
			},
			setStyle() {
				// this.curMode ==0?
				const _buy = this.$theme.linerGradient(90, '#295FFF', '#48DAFF');
				const _sell = this.$theme.linerGradient(90, '#FF8D29', '#FF533B');
				// const temp =

				return {
					// backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					...this.curMode == 0 ? _buy : _sell,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 32rpx;
		display: flex;
		align-items: center;

		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1;
			text-align: left;
		}
	}
</style>