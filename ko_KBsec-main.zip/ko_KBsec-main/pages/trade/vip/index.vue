<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.TRADE_VIP_TITLE}}</text>
			</view>
		</header>

		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;display: flex;align-items: center;">
					<view style="flex:0 0 6%">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex:94%;">
						<view style="display: flex;align-items: center;">
							<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
								{{item.name}}
							</view>
							<view style="margin-left: auto;">
								<view :style="setStyle()" @click="linkStockInfo(item)">
									{{$lang.BTN_BUY}}
								</view>
							</view>
						</view>
						<view style="display: flex;align-items: center;padding:0 20rpx;">
							<view style="font-size: 24rpx;padding-right:80rpx;" :style="{color:$theme.LOG_LABEL}">
								{{item.code}}
							</view>
							<view style="font-size: 28rpx;padding-right:80rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(item.current_price)}}
							</view>
							<view style="font-size: 26rpx;text-align: center;"
								:style="$theme.setStockRiseFall(item.rate_num>0)">
								{{$util.formatNumber(item.rate_num)}}
							</view>

							<view style="margin-left: auto;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.rate>0?'+':'-'}} {{($util.formatNumber(Math.abs(item.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [], // 持有列表
			}
		},
		onShow() {
			this.getList();
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkStockInfo(val) {
				uni.navigateTo({
					url: this.$CONSTANTS.STOCK_OVERVIEW + `?code=${val.code}&type=${val.project_type_id}`
				});
			},

			async getList() {
				const result = await this.$http.get('api/goods/zhangdie');
				if (!result) return false;
				console.log(result);
				this.list = result;
			},
			setStyle() {
				return {
					backgroundColor: this.$theme.PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		},
	}
</script>
<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>