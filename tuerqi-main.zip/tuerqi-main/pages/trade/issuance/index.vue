<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond :title="$lang.TRADE_ISSUANCE_TITLE" :color="$theme.SECOND"></HeaderSecond>
		

		<TabsPrimary :tabs="$lang.TRADE_DAY_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<TradeIssuanceList @action="changeTab"></TradeIssuanceList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIssuanceLog></TradeIssuanceLog>
		</template>
		<template v-else>
			<TradeIssuanceSuccessLog></TradeIssuanceSuccessLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIssuanceList from './components/TradeIssuanceList.vue';
	import TradeIssuanceLog from './components/TradeIssuanceLog.vue';
	import TradeIssuanceSuccessLog from './components/TradeIssuanceSuccessLog.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIssuanceList,
			TradeIssuanceLog,
			TradeIssuanceSuccessLog,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>

<style>
</style>