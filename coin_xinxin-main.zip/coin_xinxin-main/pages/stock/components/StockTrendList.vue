<template>
	<view style="padding-bottom: 20rpx;">
		<CustomTitle :title="$lang.STOCK_TRADE_TREND_RECENT_TITLE"></CustomTitle>

		<view style="border-radius:16rpx 16rpx 0 0;background-color: #2D54AB3A;border-bottom: 1px Solid #4b4b97;">
			<view style="display: flex;align-items: center;padding:10px;">
				<block v-for="(item,index) in $lang.STOCK_TRADE_TREND_RECENT_LABELS">
					<view :style="{flex:index==0?'20%':'26%',textAlign:index==0?'':'right',color:$theme.PRIMARY}">
						{{item}}
					</view>
				</block>
			</view>
		</view>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="display: flex;align-items: center;padding:10px;border-bottom: 1px Solid #4b4b97;background-color: #2D54AB1A;">
				<view style="flex:20%;font-size: 20rpx;" :style="{color:$theme.LOG_VALUE}">{{item.dt}}</view>
				<view :style="$theme.setStockRiseFall(item.net_vol_individual>0)" style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_individual)}}
				</view>
				<view :style="$theme.setStockRiseFall(item.net_vol_institutional>0)"
					style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_institutional)}}
				</view>
				<view :style="$theme.setStockRiseFall(item.net_vol_foreigner>0)" style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_foreigner)}}
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'StockTrendList',
		components: {
			CustomTitle
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>