/* change theme 挂在全局，方便后期做主题切换 */
const PRIMARY = '#00aa99'; //
const RISE = '#02B975'; // 涨
const FALL = '#FF315A'; // 跌		
const LABEL = '#666666'; // 列表的标题		
const ACCESS_TEXT = '#FFFFFF'; // 标题文字	
const TITLE = '#666666'; // 		
const STOCK_NAME = '#121212';
const FG = ' #AFAFAF';
const SECONDARY = '#FF8C00';
//const  LABEL= '#F7F7F7';
const TEXT = '#333333'; // D3D3D3
const TIP = '#333333';
const PLACEHOLDER = '#8E8D92'; // 输入框占位符

const SECOND = '#16E2E2';
// uni.showModal 弹层cancelColor取消按钮的样式 
const MODAL_CANCEL = '#999999';

const TRANSPARENT = 'transparent'; // 使用父级元素颜色

const LOG_LABEL = '#999999'; // 一些记录的明文颜色
const LOG_VALUE = '#C9C9C9'; // 一些记录的数据颜色

const WHITE = '#FFFFFF'; // white

const LABEL_PRIMARY = '#C9C9C9';
const LABEL_SECOND = '#A8A8A8';

const CHART_TEXT_COLOR = '#999999'; // 图表相关的字色

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? RISE : FALL,
		backgroundColor: !isbg ? '' : val ? RISE : FALL,
	}
};
// 设置input的placeholder样式
const setPlaceholder = (color = '', fontsize = '') => {
	return `color:${color == '' ? PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
};

// 设置图片尺寸（自定义size）
const setImageSize = (w = 0, h = 0) => {
	const _w = w > 0 ? w : 20;
	const _h = h > 0 ? h : _w;
	return {
		width: `${_w}rpx`,
		// 若为设置h值，则视为高=宽
		height: `${_h}rpx`,
	};
};

// 渐变设置
const linerGradient = (deg, from, to) => {
	return {
		backgroundImage: `linear-gradient(${deg}deg, ${from} ,${to})`
	}
};


// 设置页面背景,返回style对象，动态替换页面背景图
const setBGCover = (url) => {
	return {
		backgroundImage: `url(/static/${url}.png)`,
		backgroundRepeat: 'no-repeat',
		backgroundPosition: '0 0',
		backgroundSize: 'cover',
		width: '100%',
		height: '100vh',
	}
};


// 另外一种，使用渐变，动态改变background-size的值。
// val:外部设置该值，可以改变背景的size。 
const setBGSize = (val) => {
	return {
		...linerGradient(180, '#00AA98', 'transparent'),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: '0 0',
		backgroundSize: `100% ${val}`,
		width: '100%',
		minHeight: '100vh',
	}
};

// 计算设计图上带有透明度的值输出为RGBA
const RGBConvertToRGBA = (hexColor, opacity) => {
	// console.log(hexColor);
	const r = parseInt(hexColor.slice(1, 3), 16);
	const g = parseInt(hexColor.slice(3, 5), 16);
	const b = parseInt(hexColor.slice(5, 7), 16);
	const a = opacity / 100;
	return `rgba(${r},${g},${b},${a})`;
};


// 跟单详情 评分 百分比
const tradeCopyScore = (val, color, max) => {
	// const temp = RGBConvertToRGBA(FALL, 20);
	// 當前最大值為100%,
	const tempVal = val / max * 100;
	// console.log(val, max, tempVal);
	const style = {
		...linerGradient(180, color, color),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: `0 0`,
		backgroundSize: `100% 100%`,
		width: `${tempVal}%`,
		minHeight: `30rpx`,
		borderRadius: `10rpx`,
	}
	// console.log(style);
	return style;
}

// Coin Depth bg
const depathAsksBG = (val, max, dir = 'right') => {
	const temp = RGBConvertToRGBA(RISE, 20);
	// 當前最大值為100%,
	const tempVal = val / max * 100;
	// console.log(val, max, tempVal);
	const style = {
		...linerGradient(180, temp, temp),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: `right 0`,
		backgroundSize: `${tempVal}% 100%`,
		width: '100%',
		minHeight: `100%`,
	}
	return style;
}
const depathBidsBG = (val, max, dir = '0') => {
	const temp = RGBConvertToRGBA(FALL, 20);
	// 當前最大值為100%,
	const tempVal = val / max * 100;
	// console.log(val, max, tempVal);
	const style = {
		...linerGradient(180, temp, temp),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: `${dir} 0`,
		backgroundSize: `${tempVal}% 100%`,
		width: '100%',
		minHeight: `100%`,
	}
	return style;
}

// 主题，一些通用的颜色值 硬编码
export default {
	PRIMARY, //
	RISE, // 股票涨
	FALL, // 股票跌		
	LABEL, // 列表的标题		
	ACCESS_TEXT, // 标题文字	
	TITLE, // 		
	STOCK_NAME,
	FG,
	SECONDARY,
	// LABEL: '#F7F7F7',
	TEXT, // D3D3D3
	TIP,
	PLACEHOLDER, // 输入框占位符
	CHART_TEXT_COLOR,
	SECOND,
	TRANSPARENT,
	MODAL_CANCEL,
	LOG_LABEL,
	LOG_VALUE,
	WHITE,
	LABEL_PRIMARY,
	LABEL_SECOND,

	setStockRiseFall,
	setPlaceholder,
	setImageSize,
	setBGCover,
	setBGSize,
	RGBConvertToRGBA,
	tradeCopyScore,
	depathAsksBG,
	depathBidsBG,
};