<template>
	<view style="background-color: #ffffff;">
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 20px;">
			<view class="bold" style="font-size: 18px;">保有銘柄一覧</view>
			<view class="" style="width: 60%;justify-content: flex-end; display: flex; ">
				<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;height: 20px;" @click="home2()">
				</image>
			</view>
		</view>
		<view class="flex" style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#fff);height: 250px;">
		</view>
		<!-- <view
			style="background-color: #ffffff;width: 95%;border-radius: 10px;height: 150px;margin-top: -250px;position: relative;margin-left: 10px;">
			<view class="flex" style="padding: 20px;">
				<view class="flex-4">現金残高</view>
				<image src="/static/zhenyan.png" mode="widthFix" style="width: 20px;" @click="yan_show=false"
					v-if="yan_show"></image>
				<image src="/static/yanjin.png" mode="widthFix" style="width: 20px;" @click="yan_show=true"
					v-if="!yan_show"></image>
			</view>
			<view class="margin-left-20 font-size-30 bold" style="color: #030244;margin-top: -10px;" v-if="yan_show">
				{{$util.formatNumber(userInfo.totalZichan)}}</view>
			<view class="margin-left-20 font-size-30 bold" style="color: #030244;margin-top: -10px;" v-if="!yan_show">
				******</view>
			<view class="flex margin-top-20">
				<button style="width: 120px;height: 35px;background-color: #97e2dd;color: #FFF;font-size: 15px;"
					@click="handleBack()">入金</button>
				<button style="width: 120px;height: 35px;background-color: #18bfb4;color: #FFF;font-size: 15px;"
					@click="handle()">出金</button>
			</view>
		</view> -->

		<!-- <TradeInfo></TradeInfo> -->

		<view
			style="background-color: #FFF;width: 90%;margin-left: 10px; margin-top: 20px;padding:10px;border-radius: 10px;margin-top: -240px;">
			<view
				style="display: flex;align-items: center;justify-content:space-between;font-size: 16px;padding: 10px;font-weight: 700;">
				<!-- <image mode="aspectFit" src="/static/refresh.png" :style="$util.calcImageSize(30)"
					@click="handleRefresh()"> -->
				<view class="text-center padding-5 margin-left-30" style="font-size: 16px;"
					:style="{color:isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}" @click="handleChangeList(0)">
					{{$lang.STOCK_HOLD_STATUS}}
				</view>
				<view class="text-center padding-5 margin-right-30" style="font-size: 16px;"
					:style="{color:!isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}" @click="handleChangeList(1)">
					{{$lang.STOCK_SALES_HISTORY}}
				</view>
				</image>
			</view>

			<view class="line"></view>

			<view>
				<view class="flex" style="margin: 8px;">
					<view class="flex-1">現金残高</view>
					<view>{{$util.formatNumber(userInfo.totalZichan)}}</view>
				</view>
			
				<view class="flex" style="margin: 8px;">
					<view class="flex-1">購入金額合計</view>
					<view>{{$util.formatNumber(userInfo.frozen)}}</view>
				</view>
				<view class="flex" style="margin: 8px;background-color: #ebf9f9;">
					<view class="flex-1">評価損益合計</view>
					<view style="color: red;">{{$util.formatNumber(userInfo.holdYingli)}}</view>
				</view>
				<view class="flex" style="margin: 8px;background-color: #ebf9f9;">
					<view class="flex-1">損益率</view>
					<view style="color: red;">{{userInfo.huibao}}%</view>
				</view>
			</view>


			<view class="flex" style="margin-top: 30px;">
				<view class="flex-1">株式</view>
				<view class="flex-1">
					<view>残高数量</view>
					<view style="margin-top: 5px;">評価額</view>
				</view>
				<view class="flex-1">
					<view>平均取得単価</view>
					<view style="margin-top: 5px;">評価損益</view>
				</view>
				<view class="">
					<view>損益率</view>
					<view style="margin-top: 5px;">現在値</view>
				</view>
			</view>

			<view>
				<block v-for="(item,index) in list" :key="index">
					<view @tap="handleShowModal(item)"
						style="align-items: center;padding:10px 0;border-bottom: 1px solid #ccc;">

						<view class="flex" style="margin-top: 5px;">
							<view class="flex-1">{{item.goods_info.name}}</view>
							<view class="flex-1">
								<view>
									<template v-if="isHold">
										<view :style="(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber(item.order_buy.num)}}
										</view>
									</template>
									<template v-else>
										<view :style="(item.order_sell.yingkui>0)">
											{{$util.formatNumber(item.order_buy.num)}}
										</view>
									</template>
								</view>
								<view style="margin-top: 10px;">
									<template v-if="isHold">
										<view :style="(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber((isHold? item.goods_info.current_price:item.order_sell.price)*item.order_buy.num)}}
										</view>
									</template>
									<template v-else>
										<view :style="(item.order_sell.yingkui>0)">
											{{$util.formatNumber((isHold? item.goods_info.current_price:item.order_sell.price))}}
										</view>
									</template>
								</view>
							</view>
							<view class="flex-1">
								<view>
									<template v-if="isHold">
										<view :style="(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber(item.order_buy.price)}}
										</view>
									</template>
									<template v-else>
										<view :style="(item.order_sell.yingkui>0)">
											{{$util.formatNumber(item.order_buy.price)}}
										</view>
									</template>
								</view>
								<view style="margin-top: 10px;"><template v-if="isHold">
										<view :style="$util.calcStyleRiseFall(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber(item.order_buy.yingkui)}}
										</view>
									</template>
									<template v-else>
										<view :style="$util.calcStyleRiseFall(item.order_sell.yingkui>0)">
											{{$util.formatNumber(item.order_sell.yingkui)}}
										</view>
									</template>
								</view>
							</view>

							<view class="">
								<view>
									<template v-if="isHold">
										<view :style="$util.calcStyleRiseFall(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber((item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}%
										</view>
									</template>
									<template v-else>
										<view :style="$util.calcStyleRiseFall(item.order_sell.yingkui>0)">
											{{$util.formatNumber((item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}%
										</view>
									</template>
								</view>

								<view style="margin-top: 10px;">
									<template v-if="isHold">
										<view :style="(item.order_buy.float_yingkui>0)">
											{{$util.formatNumber((isHold? item.goods_info.current_price:item.order_sell.price))}}
										</view>
									</template>
									<template v-else>
										<view :style="(item.order_sell.yingkui>0)">
											{{$util.formatNumber((isHold? item.goods_info.current_price:item.order_sell.price))}}
										</view>
									</template>
								</view>
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class=" common_popup"
					style="min-height:35vh;margin:auto;background-color: #fff;border-radius: 10px;">
					<view class="popup_header" style="margin: 0;background-color: #1dc0b5;">
						<text style="text-align: center;font-size: 18px;color:#FFF;">詳細
						</text>
						<image src="/static/close.png" :style="$util.calcImageSize(20)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.STOCK_NAME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_DATETIME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.created_at}}</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.SELL_DATETIME}}</view>
							<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CURRENT_PROFIT_LOSS}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.float_yingkui:info.order_sell.float_yingkui)}}
						</view>
						<!-- <view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.LEVER}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.double}}</view> -->                      
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CODE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.TOTAL_PROFIT_LOSS_AMOUNT}}
						</view>

						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui:info.order_sell.yingkui)}}
						</view>

						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_PRICE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_NUM}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<!-- <view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.FEE_BUY_SELL}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:info.order_sell.sell_fee)}}
						</view> -->
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_TOTAL_AMOUNT}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}
						</view>
					</view>

					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_TOTAL_AMOUNT}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}
						</view>
						
					</view> -->

					<view
						style="border-radius: 0 0 20px 20px;display: flex;align-items: center;justify-content: space-around;padding-top: 20px;margin-bottom: 20px;"
						v-if="isHold">
						<view class="common_btn " style="width: 40%;background-color: #97e2dd;color: #FFF;"
							@tap="handleStockDetail(info.goods_info.number_code,info.goods_info.id)">
							{{$lang.STOCK_DETAIL}}
						</view>
						<view class="common_btn " style="width: 40%;background-color: #18bfb4;"
							@tap="handleSell(info.id)">
							{{$lang.STOCK_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	export default {
		components: {
			Header,
			TradeInfo,

		},
		data() {
			return {
				isHold: 1, // 是否是持股状态，否则为销售历史
				list: [],
				isSelf: true, // 国内，false:海外
				info: {},
				isShow: false, // 买卖弹出
				yan_show: true,
				userInfo: []
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.curPage = 1; // 从第一页重新开始
			this.list = []; // 清空所有翻页后内中数据
			this.handleRefresh()
			uni.stopPullDownRefresh()
		},
		//监听页面触底函数
		onReachBottom() {
			// 如果触底，并且当前页码<最大页码
			console.log(this.curPage, this.maxPage);
			if (!this.flag) {
				if (this.curPage < this.maxPage) {
					this.curPage++;
					console.log('page:', this.curPage);
					this.getList()
				}
				if (this.curPage >= this.maxPage) {
					return false;
				}
			}
		},
		onShow() {
			this.handleRefresh()
			this.gaint_info()
		},

		onUnload() {
			console.log('ポジションが終了しました');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('ポジションが終了しました');
			clearInterval(this.timerId);
		},
		methods: {
			handleChangeList(val) {
				this.isHold = val == 0;
				this.handleRefresh();
			},
			handleChangeLocation(val) {
				this.isSelf = val == 0;
				this.handleRefresh();
			},

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},
			home2() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/search'
				});
			},
			home() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/notification'
				});
			},
			

			handleBack() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/account/deposit'
				});
			},
			handle() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/account/withdraw'
				});
			},

			handleRefresh() {
				uni.showLoading({
					mask: true
				})
				this.curPage = 1; // 从第一页重新开始
				this.list = []; // 清空所有翻页后内中数据
				this.getList();
			},
			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							console.log(_this);
							uni.hideLoading();
							_this.confirmSell(id);
						} else if (res.cancel) {
							console.log('ユーザーはキャンセルをクリックします。');
						}
					}
				})
			},
			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		console.log('위치요청');
			// 		this.handleRefresh()
			// 		this.gaint_info()
			// 	}, 8000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// },
			// 平仓功能
			async confirmSell(id) {
				uni.showLoading({
					title: this.$lang.TIP_SELLING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.USER_SELL, {
					id
				})
				if (result.data.code == 0) {
					this.handleRefresh()
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				}
			},

			handleStockDetail(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`
				});
			},
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				// this.cardManagement = result.data.data.bank_card_info
			},

			async getList() {
				this.flag = true;
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`${this.$http.API_URL.USER_ORDER}`, {
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
					page: this.curPage
				})
				this.flag = false;
				if (result.data.code == 0) {
					this.list.push(...result.data.data.data);
					this.maxPage = result.data.data.last_page; // 最大页码
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>