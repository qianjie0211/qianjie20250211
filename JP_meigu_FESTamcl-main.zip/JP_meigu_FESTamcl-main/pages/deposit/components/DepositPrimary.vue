<template>
	<view>
		<view class="flex" style="width: 90%;margin-left: auto;">
				  <view class="flex-1 bold" style="font-size: 23px;color: #FFFFFF;">チャージ</view>
				  <image src="/static/chongzhi.png" mode="widthFix" style="width: 100px;"></image>
		</view>
				
				<view style="position: relative;">
					<image src="/static/bg_2.png" mode="widthFix" style="width: 95%;margin-left: 10px;"></image>
					<view style="width: 80%; position: absolute;bottom: 20%;left: 30px;">
						<view style="display: flex;align-items: center;line-height: 1.6;">
							<view class="flex-1" style="font-size: 32rpx;">
								{{cardLabels[0]}}
							</view>
							<image mode="aspectFit" :src="`/static/${showAmount?'zhenyan':'yanjin'}.png`" @click.stop="handleShowAmount"
								:style="$theme.setImageSize(40)" style="margin-left: 10px;">
							</image>
						</view>
						<view style="font-size: 58rpx;font-weight: 700;line-height: 1.6;color: #ec1a14;">
							{{showAmount?$util.formatMoney(cardData.value1):hideAmount}}
						</view>
						</view>
					
				</view>
		

		<view class="common_block" style=" padding:20rpx 24rpx;">
			<TitleSecond :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT"></TitleSecond>
			<view class="common_input_wrapper">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;margin: 30rpx;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
						:style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatMoney(item)}}
					</view>
				</block>
			</view>
		</view>
		<view style="padding: 10px;">
			<view class="success" style="background-color: #FFFFFF;border-radius: 10px;">
				<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1"
					width="360" height="200" style="z-index: 10;">
					<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">転送伝票をアープロードしてください。</view>
			
					<image src="/static/card_f.png" mode="widthFix" style="width: 140%;"></image>
			
			
				</u-upload>
			</view>
		</view>
		

		<view class="common_block" style="padding:24rpx;">
			<TitleSecond :title="$lang.DEPOSIT_TIP_TITLE"></TitleSecond>

			<view style="background-color: #F7F9FF;padding:16rpx;border-radius: 16rpx;margin-top: 12rpx;">
				<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
					<view style="padding-top:16rpx;line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
				</block>
			</view>

		</view>
		<view style="background-color: #FFFFFF;color: #FFFFFF;margin-top: 120px;">.</view>
        
		<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
			<view class="text-center" style="margin:0 auto;width: 80%;background-color: #f2473f;padding: 15px;font-size: 16px;color: #fff;border-radius: 30px;"@click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	export default {
		// desc:入金模式 之  带有输入项提交等
		name: 'DepositPrimary',
		components: {
			TitleSecond,
			AccountAssets,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardData: {},
				fileList6: [],
			};
		},
		
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 入金金额预置值
			amountList() {
				return [1000000, 5000000, 10000000, 20000000,30000000,50000000];
			},
		},
		created() {
			this.getAccountInfo()
			this.amount = this.amountList[this.curPos];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			setStyle(val) {
				return {
					...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					color: val ? '#FFFFFF' : '#121212',
					borderRadius: `44rpx`,
					border: `1px solid ${val? this.$theme.TRANSPARENT:'#5A5A5A'}`
				}
			},
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					// this.$util.linkCustomerService();
					location.reload();
				}, 1000)
			},

			//个人信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log(result);
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money, // 可提
					value2: this.userInfo.freeze, // 冻结
					value3: this.userInfo.totalYingli, // 总盈利
				};
			},
		},
	}
</script>

<style>
</style>