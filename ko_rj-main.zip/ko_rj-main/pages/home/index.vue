<template>
	<view
		style="background-image:url(/static/backimg.png);background-repeat: no-repeat;background-position: 0 0;background-size: 100% 260px;">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<header style="padding: 40rpx 40rpx 20rpx 20rpx;
		display: flex;
		align-items: center;justify-content: space-between;">
			<view style="flex: 0 10%">
				<image style="margin-left: 10px;" src="/static/logo.png" mode="widthFix"
					:style="$theme.setImageSize(60)"></image>
			</view>
			<view style="flex:1 0 50%; font-size: 36rpx;color: #0A2448;text-align: center;">
				<!-- {{$lang.TABBAR_ACCOUNT}} -->RAYMOND JAMES
			</view>
			<view style="margin-left:auto;">
				<!-- <image src="/static/search.svg" mode="widthFix" style="margin-right: 8px;"
					:style="$theme.setImageSize(40)" @click="linkSearch()"></image> -->
				<image src="/static/news.svg" mode="widthFix" :style="$theme.setImageSize(40)"
					@click="$util.linkCustomerService()"></image>
			</view>
		</header>
		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->
		<view @click="$paths.linkSearch()"
			style="text-align: right;padding-right: 28px; margin:20px 16px 34px 16px;padding: 10px; border-radius: 6px; box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.01) 0px 0px 0px 1px; "
			:style="{backgroundColor:$theme.RGBConvertToRGBA(`#FFFFFF`,20)}">
			<image src="/static/searchw.png" mode="widthFix" :style="$theme.setImageSize(40) "></image>
		</view>
		<!-- <view>
			<image src="/static/banner.jpg" style="width: 95%;margin-left: 2.5%;margin-top: 10px;" mode="widthFix"></image>
		</view> -->
		<view class="common_block">
			<ButtonGroup></ButtonGroup>
		</view>

		<view style="margin: 20px 16px 0px 16px; #292861text-align: center;">
			<image src="/static/home1.png" mode="widthFix" :style="$theme.setImageSize(700)"></image>

		</view>
		<!-- <view
			style="display:flex;align-items: center; width: 350px; line-height: 2.8; background-color:#ffffff; font-size: 14px; text-align: left;padding-left: 30px;">
			<image src="/static/homenews1.png" mode="widthFix" :style="$theme.setImageSize(48)"></image>
			<text style="padding-left: 12px;" :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">일련의 윤방 공고도</text>
		</view> -->

		<view style="margin:20px 10px; display:flex; align-items: center;justify-content: space-between;">
			<image src="/static/home2.png" mode="widthFix" style="width: 48%; "></image>
			<image src="/static/home2_1.png" mode="widthFix" style="width: 48%; "></image>
		</view>



		<view
			style="display: flex;flex-direction: row;justify-content:space-between;flex-wrap: nowrap; margin: 20px 16px;">
			<block v-for="(v,k) in topList" :key="k">
				<view style=" background: ;width: 31%; text-align: center; border-radius: 6px;" @click="linkstockList"
					:style="{backgroundImage: v.returns*1>0 ? `linear-gradient(to bottom, #FFD6D6 ,#FFFFF3  )` :`linear-gradient(to bottom, #E0F0FF,#ECF6FF )`  }">
					<view style="padding: 8px 8px 4px 8px;font-size: 16px; color: #0A2448;">{{v.ko_name}} </view>
					<view style="padding: 4px 8px 4px 8px; color: #666;">{{v.code}}</view>
					<view style=" align-items: center; justify-content: space-between;padding: 4px 8px;"
						:style="{color:v.returns*1>0?`#FF0000`:`#1E90FF`}">
						<view style="" :style="{color:v.returns*1>0?`#FF0000`:`#1E90FF`}">
							{{$util.formatMoney(v.close*1,2)}}
						</view>
						<view style=" font-size: 12px;"> {{v.returns*1}}% </view>
					</view>
				</view>
			</block>
		</view>

		<view>
			<view style="margin: 10px 16px 10px 16px; font-size: 20px; color: #FF0000; ">+789678 . 65 ▼ 345 .</view>
			<view style="margin: 0 16px;">최고: 2344 , 최저: 42344 , 개장: 5678 , 장마감 789678 </view>
		</view>

		<view style="display: flex;justify-content: center;">
			<image src="/static/BBB.png" mode="widthFix"></image>
		</view>

		<view style="margin: 20px 16px 20px 16px; #292861text-align: center;">
			<image src="/static/homeban_2.png" mode="widthFix" :style="$theme.setImageSize(700)"></image>

		</view>




		<view style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); border-radius: 6px; margin: 20px 16px;">
			<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px ;">
				<view>
					<view>
						<text style="font-size: 20px; text-align: left; margin: 20px 16px;">인기 종목 </text>
						<view
							style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351;margin-top: -10px;">
						</view>
					</view>
				</view>
				<view style="margin-left: auto;" @click="linkstockList">
					<image src="/static/arrow_right.svg" mode="widthFix" :style="$theme.setImageSize(40)"></image>
				</view>
			</view>
			<template v-if="marketList.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<view style="margin:0 24rpx;padding-bottom: 24rpx;">
					<block v-for="(item,index) in marketList" :key="index">
						<view
							style="display: flex;align-items:center; padding:10px;border-radius: 8rpx;box-shadow: none;"
							:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}"
							@click="linkDetail(item)">
							<view style="margin-right: auto;">
								<image :src="`/static/stock_${item.follow?'follow':'unfollow'}.png`" mode="aspectFit"
									:style="$theme.setImageSize(50)" @click.stop="handleUnFollow(item.gid)">
								</image>
							</view>
							<!-- <view style="width: 90rpx;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view> -->
							<view style="flex:1;padding-left: 6px;">
								<view style="font-size: 28rpx;color: #121212">
									{{item.name}}
									<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
										:style="$theme.setImageSize(28)" style="padding-left: 20rpx;"></image>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="font-size: 24rpx;"
										:style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">
										{{item.code}}
									</view>
									<view style="font-size: 26rpx;font-weight: 700;"
										:style="$theme.setStockRiseFall(item.rate>0)">
										{{$util.formatMoney(item.close)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view
										style="padding: 6rpx 12rpx;border-radius: 10rpx; min-width: 50px; text-align:center;"
										:style="$theme.setStockRiseFall(item.rate>0,true)">
										{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
									</view>
								</view>
							</view>
						</view>
					</block>
				</view>
			</template>
		</view>






		<view style="margin: 20px 16px 20px 16px; #292861text-align: center;">
			<image src="/static/homeban_3.png" mode="widthFix" :style="$theme.setImageSize(700)"></image>
		</view>

		<view style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); border-radius: 6px; margin: 20px 16px;">
			<view style="margin: 20px 6px; padding: 20px 0 0 0 ;">
				<text style="font-size: 20px; text-align: left; margin: 20px 16px;">시장 동향</text>
				<view
					style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351; margin-top: -10px;">
				</view>
			</view>

			<view style="text-align: center;">
				<image src="/static/homeban_4.png" mode="widthFix" :style="$theme.setImageSize(600) "></image>
			</view>
			<view
				style="display: flex;align-items: center;justify-content:space-between;flex-wrap: nowrap;padding:12px 20px; margin-top: 10px;">
				<view style="width:25%;text-align: center;padding-bottom: 10px;  "   @click="$paths.linkToDay()">
					<view>
						<image src="/static/homem1.png" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="color: #0A2348; margin-top:8px;">{{$lang.TRADE_DAY_TITLE}}</view>
				</view>
				<view style="width:25%;text-align: center;padding-bottom: 10px;"  @click="$paths.linkToLarge()">
					<view>
						<image src="/static/homem2.png" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="color: #0A2348; margin-top:8px;">{{$lang.TRADE_LARGE_TITLE}} </view>
				</view>
				<view style="width:25%;text-align: center;padding-bottom: 10px;" @click="$paths.linkToIpo()">
					<view>
						<image src="/static/homem3.png" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="color: #0A2348; margin-top:8px;">{{$lang.TRADE_IPO_TITLE}} </view>
				</view>
				<view style="width:25%;text-align: center;padding-bottom: 10px;" @click="$paths.linkToVip()">
					<view>
						<image src="/static/homem4.png" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="color: #0A2348; margin-top:8px;">{{$lang.TRADE_VIP_TITLE}} </view>
				</view>
			</view>
		</view>


		<view style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); border-radius: 6px; margin: 10px 16px; 10px 16px">
			<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px ;">
				<view>
					<text style="font-size: 20px; text-align: left; margin: 20px 16px;">최신 소식
					</text>
					<view
						style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351;margin-top: -10px;">
					</view>
				</view>
				<view style="margin-left: auto;" @click="linkMarketNews()">
					<image src="/static/arrow_right.svg" mode="widthFix" :style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>


			<view style="margin: 2px; 2px "
				:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}">
				<block v-for="(item,index) in hotNewList.slice(0, 3) " :key="index">
					<view style="display: flex;align-items: center; margin-bottom: 16px;" @click="open(item.url)">
						<image src="/static/homefire.png" mode="widthFix" style="margin: 0 8px 8px 8px;"
							:style="$theme.setImageSize(40)"></image>
						<view>
							{{setText(item.title)}}
						</view>
					</view>
				</block>
			</view>

			<view style="margin: 10px 10px"
				:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}">
				<block v-for="(item,index) in hotNewList " :key="index">
					<view style="display: flex;align-items: center; padding: 14px 0 14px; 0"
						:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}"
						@click="open(item.url)">
						<view>
							<view style="font-size: 16px;"> {{setText(item.title)}} </view>
							<view style="font-size: 12px; color: rgba(10, 36, 72, 0.5); ">
								{{!item.sum_title||item.sum_title.length<=0?'': setsubText(item.sum_title) }}
							</view>
						</view>
						<view style="margin-left: auto;">
							<image :src="item.pic" mode="aspectFill" style="margin: 0 8px 8px 14px;"
								:style="$theme.setImageSize(180,130)"></image>
						</view>
					</view>
				</block>
			</view>
		</view>

		<!-- 	<MarketNewsTop></MarketNewsTop> -->

		<!-- 	<view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.STOCK_ALL">

			</TitlePrimary>
		</view>

		<view style="padding:10rpx 0rpx;background-color: #FFFFFF;margin:0 20rpx 40rpx 20rpx;border-radius: 32rpx;">
			<MarketHot></MarketHot>
		</view> -->

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import MarketNewsTop from '../market/components/MarketNewsTop.vue';
	import MarketHot from '../market/components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';

	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			TitlePrimary,
			CardItemPrimary,
			MarketNewsTop,
			MarketHot,
			IPOSuccessAlert,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isActLang: true, // 当前登入用户是否开启多语言权限	
				cardInfo: {}, // 资产卡
				isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.27
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
				marketList: [], // 市场股票
				hotNewList: [], //热点新闻
				topList: null, // 指数数组
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			// 今日
			setToday() {
				// return this.$util.formatToday(new Date());
			}
		},

		onLoad() {},
		onShow() {
			this.getAccountInfo();
			this.isAnimat = true;
			console.log(this.cardLabels);
			this.getMarketTop();
			this.gethotNewList();
			this.getTopList();

		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=3`,
				})
			},
			linkstockList() {
				uni.navigateTo({
					url: this.$paths.MARKET_STOCKLIST
				})
			},

			linkDetail(val) {
				console.log(`??`, val);
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?code=${val.code}`
				})
			},

			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 18 ? val : val.slice(0, 15) + '...'
			},

			setsubText(val) {
				let temp = '';
				return temp = val.length <= 60 ? val : val.slice(0, 56) + '...'
			},

			// 取关
			async handleUnFollow(id) {
				uni.showLoading({
					title: this.$lang.STATUS_SUBMIT,
				});
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				uni.showToast({
					title: this.$lang.TIP_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.getMarketTop();
				}, 1000)
			},




			open(url) {
				window.open(url)
			},
			// 获取市场top数据
			async getMarketTop() {
				

				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: 0
				});
				if (!result) return false;
				this.marketList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},

			//获取热点新闻数据
			async gethotNewList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top1`);
				if (!result) return false;
				this.hotNewList = result.article;
			},

			// 获取指数请求
			async getTopList() {
				const result = await this.$http.get(`api/goods/zhibiao`);
				if (!result) return false;
				this.topList = Object.values(result).slice(0, 3);
				console.log(' topList：', this.topList);
			},



			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.cardInfo = {
					value1: result.totalZichan || 0,
					value2: result.money || 0,
					value3: result.freeze || 0,
				};
			}
		},
	}
</script>