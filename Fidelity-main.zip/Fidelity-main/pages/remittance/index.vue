<template>
	<view>
		<view class="flex" style="padding:20px;">
			<view @click="fanhui()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.DAIKUAN}}</view>
			<image src="/static/icon_record.png" mode="widthFix" style="width: 15px;" @click="daikuan()"></image>
		</view>
		
		<view style="padding: 0px 20px;color: #FF315A;">{{$lang.SHENHE_DAIKUAN}}</view>

		<view class="padding-20">
			<view style="font-size: 28rpx;font-weight: 700;color: #fff;">
				{{$lang.JIEDAI_CHANPIN}}
			</view>
			<view class="common_input_wrapper"
				style="border-radius: 16rpx;padding-left: 40rpx;background-color:#34393e;border: 1px #3f4348 solid;" @tap="chooseIn()">
				<view style="color: #757479;" v-model="curTransferIn">{{curTransferIn}}</view>
				<image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(18)"></image>
			</view>
		</view>
		
		<view style="padding: 0px 20px;">
			<view class="flex">
			<view class="color-white">{{$lang.JIEDAI_JINE}}</view>
			<view style="color: #8c8c8d;margin-left: 10px;">(USDT)</view>
			</view>
			<input :placeholder="$lang.QINGSHU_JIEDAIE" style="border: 1px #464a4f solid;padding: 15px;border-radius: 10px;margin-top: 10px;" v-model="money"/>
		</view>
		
		<view style="padding:30px 20px;">
			<view class="color-white">{{$lang.HUANKUAN_ZHOUQI}}</view>
			<view style="background-color: #2c2f34;border-radius: 10px;padding: 15px;margin-top: 10px;color: #fff;font-size: 16px;" v-model="zhouqi">7</view>
		</view>
		
		<view style="border-top: 1px #34393e solid;color: #202328;">.</view>
		
		<view style="padding: 10px 20px; ">
			<view class="flex" style="justify-content: space-between;">
				<view style="color: #909192;">{{$lang.RILI_LV}}</view>
				<view style="color: #fff;">0.16%</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.LIXI}}</view>
				<view style="color: #fff;" v-model="lixi">{{(money*7*0.0016).toFixed(2)}}USDT</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.HUANKUAN_FANGSHI}}</view>
				<view style="color: #fff;">{{$lang.DAOQI_YICI}}</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.FANGKUAN_JIGOU}}</view>
				<view style="color: #fff;">Binance</view>
			</view>
		</view>
		
		<view class="padding-20" @click="replaceBank()">
			<view class="text-center" style="background-color: #02b975;color: #fff;border-radius: 10px;padding: 10px;">{{$lang.QUEREN}}</view>
		</view>
		
		<u-picker :show="isShowIn" :columns="[transferList]" @change="changeIn" @cancel="isShowIn=false"
			@confirm="confirmIn" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isShowIn: false, 
				curTransferIn:'产品1',
				lixi:'',
				zhouqi:"",
				list: {},
				money:''
			}
		},
		onShow() {
			this.getAccountInfo();
		},
		computed: {
			transferList() {
				return ['产品1', '产品2']
			},
		
		},
		created() {
			
		},
		methods: {
		fanhui(){
			uni.navigateBack({
				delta:1,
			})
		},
		daikuan(){
			uni.navigateTo({
				url:'/pages/remittance/daikuan'
			})
		},
		chooseIn() {
			this.isShowIn = true;
		},
		changeIn(e) {
			console.log(`changeIn e:`, e);
		},
		confirmIn(e) {
			console.log(`confirmIn e:`, e);
			this.curTransferIn = e.value[0];
			this.isShowIn = false;
			const temp = this.transferList.findIndex(item => item == this.curTransferIn);
			if (this.curTransferIn == this.curTransferOut) {
				this.curTransferOut = temp == 0 ? this.transferList[1] : this.transferList[0];
			}
		
			console.log(`??`, this.curTransferIn, this.transferList[0], this.curTransferOut);
			this.transferBalance();
		
		},
		async replaceBank() {
			uni.showLoading({
				title: 'Submitting'
			});
			const result = await this.$http.post('api/app/loan', {
				lixi: (this.money*7*0.0016).toFixed(2),
				zhouqi: 7,
				money: this.money
			})
			console.log(result);
			if (!result) return false;
			uni.showToast({
				title: 'Successfly',
				icon: 'success'
			})
			setTimeout(() => {
				uni.navigateTo({
					url:"/pages/remittance/daikuan"
				});
			}, 1000);
		},
		async getAccountInfo() {
			const result = await this.$http.get(`api/app/loan`);
			console.log('info result：', result);
			if (!result) return false;
			this.list = result;
			console.log(this.list.userlevel);
		},
		
		},
	}
</script>