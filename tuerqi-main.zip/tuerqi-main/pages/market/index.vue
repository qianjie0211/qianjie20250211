<template>

	<view :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/bg_geshi.png);background-size: contain;background-repeat: no-repeat;">
		<view class="flex " style=" justify-content: space-between;padding: 20px 10px;">
			<view class="flex" style="padding: 8px;" @click="chaxuan()">
				<view class="flex" @click="chaxuan()">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 240px;height: 35px;"></image>
				</view>
			</view>
			<view class="flex" style="background-color: #feedde;padding: 5px 15px;border-radius: 30px;">
				<!-- <image src="/static/sandian.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;" -->
				<!-- @click="$util.linkCustomerService()"></image> -->
				<!-- <image src="/static/shuxian.png" mode="widthFix" style="width:2rpx;"></image> -->
				<image src="/static/notify.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 10px;"
					@click="xiaoxi()">
				</image>
			</view>
			<!-- <image src="/static/sykefu.png" mode="widthFix" style="width: 25px;height: 25px;" @click="$util.linkCustomerService()"></image>
			<image src="/static/notify.png" mode="widthFix" style="width: 25px;height: 25px;" @click="xiaoxi()"></image> -->
		</view>


		<view style="padding: 20px 10px;">
			<view :class="setClass"
				style="padding-top: 10px; background-color: #fffaf7;border-radius: 28rpx;min-height: 100vh;">
				<view class="flex flex-b"
					style="color: #999;background-color: #ffe4cd;border-radius: 30px;padding: 5px 10px;">
					<view class="text-center" style="flex: 30%;">{{$lang.TRADE_EA_YBFIFJ}}</view>
					<view class="text-center" style="flex: 60%;">{{$lang.TRADE_EA_ODGVRFJ}}</view>
					<view class="text-center" style="flex: 20%;">{{$lang.TRADE_EA_OOLKDMJ}}</view>
				</view>
				<template v-if="curTab==0">
					<MarketTrack ref="track" @action="linkStock"></MarketTrack>
				</template>
				<template v-else-if="curTab==1">
					<MarketStockList ref="all"></MarketStockList>
				</template>
				<template v-else-if="curTab==2">
					<MarketHot ref="hot"></MarketHot>
				</template>
				<template v-else>
					<MarketKPI ref="kpi"></MarketKPI>
				</template>
			</view>
		</view>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList,
			MarketHot,
			MarketKPI
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					this.$lang.MARKET_INDEX_TAB_MARKET,
					this.$lang.MARKET_INDEX_TAB_HOP,
					this.$lang.MARKET_INDEX_TAB_KPI
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onReady() {
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			chaxuan() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			xiaoxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},
			linkStock() {
				this.changeTab(1);
			},
		},
	}
</script>