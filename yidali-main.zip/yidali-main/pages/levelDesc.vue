<template>
	<view :style="$theme.setBGSize(`480rpx`)" v-if="info">
		<HeaderSecond :title="info.title" color="#FFFFFF"></HeaderSecond>

		<view style="padding:40rpx;background-color: #FFFFFF;">
			<template v-if="info.content && info.content.length>0">
				<view v-html="info.content" style="color:#333333"></view>
			</template>
			<template v-else>
				<view style="color:#333333;text-align: center;min-height: 30vh;">{{$lang.API_EMPTY_CONTENT}}</view>
			</template>
		</view>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				info: {},
				cate_id:""
			}
		},
		onLoad(op){
			if(op.cate_id){
				this.cate_id=op.cate_id
			}
			this.getData();
			
		},
		onShow() {
			// this.getData();
		},
		
		methods: {
			async getData() {
				const result = await this.$http.post(`api/Article/content`, {
					cate_id: this.cate_id,
				});
				console.log(result);
				if (!result) return false;
				this.info = result;
			}
		}
	}
</script>

<style>
</style>