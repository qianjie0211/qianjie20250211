<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond style="background-color: #F8C351;" :title="$lang.TRADE_ISSUANCE_TITLE" :color="$theme.SECOND"></HeaderSecond>
		

		<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab ==0">
			<TradeIPOList></TradeIPOList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPORecord></TradeIPORecord>
		</template>
		<template v-else>
			<TradeIPOSuccessRecord></TradeIPOSuccessRecord>
		</template>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	import TradeIPORecord from './components/TradeIPORecord.vue';
	import TradeIPOSuccessRecord from './components/TradeIPOSuccessRecord.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIPOList,
			TradeIPORecord,
			TradeIPOSuccessRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>