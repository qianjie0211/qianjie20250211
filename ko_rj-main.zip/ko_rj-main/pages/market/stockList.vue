<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header style="padding:20px 16px 10px 16px;
	display: flex; background-color: #F8C351;
	align-items: center;justify-content: space-between;">

			<view style="margin-left: 6px;" class="custom_header_left" @click="$util.goBack()">
				<image src="/static/arrow_left.svg" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
			</view>
			<view style="flex: 1; font-size: 36rpx;color: #0A2448;text-align: center; ">
				 목록
			</view>
			<view style="margin-left: auto;">
				<image src="/static/search.svg" mode="widthFix" style="margin-right: 8px;"
					:style="$theme.setImageSize(40)" @click="linkSearch()"></image>
				<image src="/static/news.svg" mode="widthFix" :style="$theme.setImageSize(40)"
					@click="$util.linkCustomerService()"></image>
			</view>
		</header>

		<template>
			<view style="margin:20px 24rpx;padding-bottom: 24rpx;">
				<block v-for="(item,index) in marketList" :key="index">
					<view style="display: flex;align-items:center; padding:10px;border-radius: 8rpx;box-shadow: none;"
						:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}"
						@click="linkDetail(item)">
						<view style="margin-right: auto;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<!-- <view style="width: 90rpx;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view> -->
						<view style="flex:1;padding-left: 6px;">
							<view style="font-size: 28rpx;color: #121212 ;margin-right: 60px;">
								{{item.name}}
								<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
									:style="$theme.setImageSize(28)" style="padding-left: 20rpx;"></image>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="font-size: 24rpx;" :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">
									{{item.code}}
								</view>
								<view style="font-size: 26rpx;font-weight: 700;"
									:style="$theme.setStockRiseFall(item.rate>0)">
									{{$util.formatMoney(item.close)}}{{$lang.CURRENCY_UNIT}}
								</view>
								<view
									style="padding: 6rpx 12rpx;border-radius: 10rpx; min-width: 50px; text-align:center;"
									:style="$theme.setStockRiseFall(item.rate>0,true)">
									{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
				</block>
			</view>
		</template>

	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			EmptyData,
			CustomLogo,
		},

		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				marketList: [], // 市场股票
			}
		},
		onShow() {
			this.isAnimat = true;
			this.getMarketTop();
		},
		onReady() {
			// console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			this.isAnimat = false;
			console.log('onHide', this.$refs.tab0);
		},
		deactivated() {},
		methods: {
			linkSearch() {
				uni.reLaunch({
					url: this.$paths.SEARCH
				})
			},

			linkDetail(val) {
				console.log(`??`, val);
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?code=${val.code}`
				})
			},

			// 获取市场top数据
			async getMarketTop() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				// api未替换
				const result = await this.$http.get(`api/goods/list`);
				console.log('result:', result);
				const temp = !result || result.length <= 0 ? [] : result.filter(item => item.stock_id && item
					.stock_id > 0);
				this.marketList = !temp || temp.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code || '',
						close: item.close || 0,
						rate: item.returns || 0,
						type_id: item.project_type_id || 0,
					}
				});
				console.log(this.list);
			},

			// 设置样式
			setStyle(val) {
				return {
					padding: `12rpx 24rpx`,
					color: val ? '#000' : '#232323',
					background: val ? '#eecda5' : '',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: val ? '700' : '100',
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.swiper-item {
		display: flex;
		justify-content: center;
		/* 水平居中内容 */
		align-items: center;
		/* 垂直居中内容 */
		height: 100%;
		/* 交换元素的高度与 swiper 相同 */
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;
		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
	}

	.custom_header_left {
		// flex: 10%;
		margin-right: auto;
	}

	.custom_header_left>image {
		width: 24px;
		height: 24px;
	}

	.custom_header_center {
		display: block;
		color: #333333;
		font-size: 32rpx;
		padding: 0 10px;
		flex: 80%;
		text-align: center;
		font-weight: 700;
		width: 100%;
	}

	.custom_header_right {
		margin-left: auto;
	}
</style>