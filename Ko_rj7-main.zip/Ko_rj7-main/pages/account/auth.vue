<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #fff;">
		<!-- <HeaderSecond :title="$lang.AUTH_TITLE" :color="$theme.SECOND"></HeaderSecond> -->
		<view class="flex padding-20" style="background-color: #4644d1;">
			<view @click="fanhui()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
			</view>
			<view class="text-center flex-1 color-white bold font-size-16">{{$lang.AUTH_TITLE}}</view>
		</view>


		<view style="padding-top: 20px;padding-bottom: 30px;">

			<!-- <view style="background-color: #fef9fe;"> -->
			<!-- <view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/bank_card_bnner.png" :style="$theme.setImageSize(600,300)"></image>
			</view> -->

			<view class="common_block" style="margin:0 10px;padding:25rpx;">
				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color:#000;">
					성함
				</view>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom: 20px;">
					<input v-model="realName" type="text" placeholder="이름을 입력해주세요" placeholder-style="font-size:11px"
						style="width: 80%;"></input>
					<!-- <view style="margin-left: 10px;color:#707070;">{{calcSex}}</view> -->
				</view>

				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color:#000;">
					주민등록번호
				</view>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom: 20px;">
					<!-- 韩国专用证件号码输入校验 -->
					<!-- <input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD" maxlength=14
						placeholder-style="font-size:11px" @input="inputChange" style="width: 86%;"></input> -->
					<!-- 非校验 -->
					<template v-if="showPwd">
						<input v-model="cardNo" type="text" placeholder="올바른 주민등록번호를 입력해주세요" maxlength=14
							placeholder-style="font-size:11px" @input="inputChange" style="width: 86%;"></input>
						<!-- <input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"></input> -->
					</template>
					<template v-else>
						<input v-model="cardNo" type="password" placeholder="올바른 주민등록번호를 입력해주세요"
							placeholder-style="font-size:11px" style="width: 86%;"></input>
					</template>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}_dark.png`" @click="handleShowPwd"
						:style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>

			<view style="text-align: center;font-size: 32rpx;color: #000;margin-top: 20px;">
				{{statusLabels[userInfo.is_check]}}
			</view>

			<template v-if="userInfo.is_check !==1">
				<view style="margin-top: 30rpx;">
					<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 20px;color:#121212;">
						{{$lang.AUTH_CARD_F}}
					</view>
					<view
						style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #f4f4f4;border-radius: 10px;margin: 20rpx;">
						<image :src="!formData.obverseUrl?`/static/card_.png`:formData.obverseUrl"
							@click="selectImg('obverse')" style="margin: 10px;width: 220px;height: 140px;"></image>
					</view>

					<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 20px;color:#121212;">
						{{$lang.AUTH_CARD_B}}
					</view>
					<view
						style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #f4f4f4;border-radius: 10px;margin: 20rpx;">
						<image :src="!formData.reverseUrl?`/static/card_.png`:formData.reverseUrl"
							@click="selectImg('reverse')" style="margin: 10px;width: 220px;height: 120px;"></image>
					</view>
					<view style="margin: 10px;padding-bottom: 30px; text-align: center;color:#28d258;">
						{{$lang.AUTH_TIP_TEXT}}
					</view>

					<view class="common_btn" style="width: 80%;margin:40rpx auto;background-color: #33d669;"
						@click="gain_aouonym()">
						확인
					</view>

				</view>

			</template>
		</view>
		<!-- </view> -->
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				realName: '', // 姓名 이정현
				cardNo: '', // 证件号码
				showPwd: false, // 是否显示完整证件号
				fullCardNo: '', // 证件号码完整值

				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				userInfo: {},
			};
		},
		computed: {
			// 实名认证状态明文
			statusLabels() {
				return [
					this.$lang.AUTH_RESULT_REVIEW,
					this.$lang.AUTH_RESULT_PASS,
					this.$lang.AUTH_RESULT_REPOST,
				]
			},
		},
		onLoad() {
			this.getAccountInfo();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			console.log(`111`, this.formData);
			this.setStorageData();
		},

		methods: {
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('realName', this.realName);
				uni.setStorageSync('cardNo', this.cardNo);
				console.log(`111`, this.formData);
				uni.setStorageSync('obverseUrl', this.formData.obverseUrl);
				uni.setStorageSync('reverseUrl', this.formData.reverseUrl);
			},
			// 获取页面缓存信息
			// getStorageData() {
			// 	this.realName = this.realName.length > 0 ? this.realName : (uni.getStorageSync('realName') || '');
			// 	this.cardNo = this.cardNo.length > 0 ? this.cardNo : (uni.getStorageSync('cardNo') || '');
			// 	// this.formData.obverseUrl = this.formData.obverseUrl.length > 0 ?
			// 	// 	this.formData.obverseUrl : (uni.getStorageSync('obverseUrl') || '');
			// 	// this.formData.reverseUrl = this.formData.reverseUrl.length > 0 ?
			// 	// 	this.formData.reverseUrl : (uni.getStorageSync('reverseUrl') || '');
			// 	// this.realName = this.realName.length || '';
			// 	// this.cardNo = this.cardNo.length || '';
			// 	this.formData.obverseUrl = this.formData.obverseUrl.length || '';
			// 	this.formData.reverseUrl = this.formData.reverseUrl.length || '';
			// },

			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
			},

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg(1, imageFile.path)

				} else if (name == "reverse") {
					this.upimg(2, imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 1) {
						this.formData.obverseUrl = temp[0].url;
					} else {
						this.formData.reverseUrl = temp[0].url;
					}
				}
				console.log(`111`, this.formData);
				this.setStorageData();
			},
			fanhui() {
				uni.switchTab({
					url: '/pages/home/index'
				})
			},

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const tempCardNo = this.cardNo;
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName,
					// sex: this.calcSex,
					idno: tempCardNo,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				});
				if (result) {
					uni.showToast({
						title: result,
						icon: 'none'
					});
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.HOME
						});
					}, 1000);
				}
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.userInfo = result;
				this.realName = this.userInfo.real_name || '';
				this.cardNo = this.userInfo.idno || '';
				this.formData.obverseUrl = this.userInfo.front_image || '';
				this.formData.reverseUrl = this.userInfo.back_image || '';
				this.getStorageData();
			},
		},
	};
</script>