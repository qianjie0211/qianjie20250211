<template>
	<view style="padding:0 18px; padding-bottom: 100rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#010101; border-radius: 8rpx;line-height: 1.6;margin-top:24rpx;">


					<view style="background-color: #222222;padding: 10px 16px;border-radius: 12px;">
						<view
							style="display: flex;flex: 1; align-items: center;justify-content: space-between;margin-bottom: 4px;">
							<view>
								<view style="font-size: 35rpx;" :style="{color:$theme.LOG_VALUE}">
									{{(item.goods_info.name)}}
								</view>
								<template v-if="item.goods_info.project_type_id==5">
									<view style="font-size: 35rpx;" :style="{color:$theme.LOG_LABEL}">
										{{(item.goods_info.code)}}
									</view>
								</template>
							</view>

						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						status  0是未售出   1是已售出
						<view style="font-size: 24rpx;" :style="{color:$theme.PRIMARY}">
							{{item.status==0?$lang.TRADE_DAY_UNSOLD:$lang.TRADE_DAY_SOLD}}
						</view>
					</view> -->

						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_DAY_BUY_PRICE}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.price)}}
						</view>
					</view> -->

						<view
							style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px; background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_PRICE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.price)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_NUM}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.num)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_AMOUNT}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.amount)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_HOLD_LABEL_CUR_PRICE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.goods_info.current_price)}}
							</view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.SHOU_XUFEI}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_buy.buy_fee)}}
						</view>
					</view> -->
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_HOLD_LABEL_PROFIT_RATE}}
							</view>
							<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall((item.goods_info.current_price * 1 - item.order_buy.price * 1) /
								(item.order_buy.price * 1)>0)">
								{{$util.formatPercentage($util.formatNumber((item.goods_info.current_price * 1 - item.order_buy.price * 1) /
								(item.order_buy.price * 1)*100).toFixed(2) * 1)}}

							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_MODAL_YINGKUI}}
							</view>
							<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
								{{$util.formatNumber(item.order_buy.float_yingkui).toFixed(2) * 1}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_DAY_ORDER_SN}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_sn)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;background-color: #424242;margin: 4px 0;padding: 4px 8px;border-radius: 6px;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_DAY_CREATE_TIME}}
							</view>
							<view style="font-size: 24rpx;padding-left: 24rpx;color:#FFFFFF;">
								{{item.order_buy.created_at}}
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: center; font-size: 28rpx;background-color: #018ef8;padding: 2px 10px;border-radius: 12px;color: #FFFFFF; margin: 6px 10px; padding: 6px 0;"
							@tap.stop="handleSell(item.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'TradeDaySuccessList',
		components: {

		},
		data() {
			return {
				successList: [],

			}
		},
		props: {
			list: {
				type: Array,
				default: []
			},
			code: {
				type: [Number, String],
				default: 1
			}
		},
		onShow() {
			this.changeTab(this.curTab);
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id,
					type: this.code
				});
				console.log(result);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	
				this.changeTab(this.curTab);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					console.log(22222);
					// 第一种方法
					this.$emit("chicang_list")

				}, 1000);
			},



		},
	}
</script>

<style>
</style>