<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #FFFFFF; padding:10px 16px;border-radius: 8rpx;line-height: 1.8;margin:0 20px 20px 20px;">
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>상태</view>
					<view :style="{color:$theme.RISE}">{{item.desc_type}}</view>
				</view>
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>{{$lang.LOG_WITHDRAW_AMOUNT}}</view>
					<view :style="{color:$theme.RISE}" style="font-size: 18px;">{{$util.formatMoney(item.money)}}</view>
				</view>
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view class="hui1">{{$lang.LOG_TRADE_ORDER_SN}}</view>
					<view class="hui1">{{item.order_sn}}</view>
				</view>
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view class="hui1">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view class="hui1">{{item.created_at}}</view>
				</view>
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view class="hui1">{{$lang.LOG_TRADE_DW_DESC}}</view>
					<view>{{item.reason}}</view>
				</view>

				<template v-if="item.status==0">
					<view style="display: flex;align-items: center;justify-content: space-between; padding: 5px;">
						<!-- <view :style="item.style"> {{item.text}} </view> -->
						<view style="color:#fff;margin-left: auto;padding:6rpx 20px;background-color: #34d66a;border-radius: 5px;"
							@click="handleCancel(item.id)">
							{{$lang.BTN_CANCEL}}
							<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
						</view>
					</view>
				</template>
				<template v-else-if="item.status==2">
					<view style="display: flex;align-items: center;justify-content: space-between; padding: 5px;">
						<!-- <view :style="item.style"> {{item.text}} </view> -->
						<view style="color:#2D54AB;margin-left: auto;padding:6rpx 20px;background-color: #eecda5;border-radius: 5px;"
							@click="handleService()">
							{{$lang.BTN_SEND_SERVICE}}
							<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
						</view>
					</view>
				</template>
				<template v-else>
					<template v-if="item.text">
						<view :style="item.style"> {{item.text}} </view>
					</template>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},

			// 取消提现
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},

			async cancelWithdraw(id) {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'none',
				});
				const result = await this.$http.post(`api/app/qx`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.get(`api/user/withdraw`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						...item,
						// ...this.$theme.setStatusPrimary(item.status),
						// style: this.$theme.setStatusPrimary(item.status),
					}
				})
				console.log(this.list);
			},
		}
	}
</script>

<style>

</style>