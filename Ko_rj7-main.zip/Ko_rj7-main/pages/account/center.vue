<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderPrimary isSearch  :color="$theme.SECOND"></HeaderPrimary> -->
		<view style="position: relative;">
					<image src="/static/wd_bg.png" mode="widthFix" style="width: 100%;height: 80px;"></image>
				</view>
				
			<view class="flex " style="padding:20px;margin-top: -170px;position: absolute;width: 90%;">
				<view class="color-white">   내정보   </view>
				<view class="flex flex-1" @click="sousuo()" style="background-color: #a2a1e8;border-radius: 30px;padding: 6px 10px;margin-left: 20px;">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 15px;height: 30px;display: block;float: left;"></image>
					<view class="text-center" style="font-size: 10px;color: #fff;margin-left: 5px;">검색</view>
				</view>
				
				<view class="margin-left-10">
					<image src="/static/notification.png" mode="widthFix" style="width: 20px;height: 20px;" @click="xinxi()">
					</image>
				</view>
			</view>

		<Profile :info="userInfo"></Profile>


		<!-- <view style="display: flex;align-items: center;padding:50rpx 30rpx;" class="gap10">
			<view @click="linkDeposit()" class="flex-1 flex gap10 padding-10"
				style="background-color: #FFFCD6;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;">
					<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(70)"></image>
				</view>
				<view style="text-align: center;font-size: 30rpx;color:#484848 ;font-weight: 700;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>


			<view @click="linkWithdraw()" class="flex-1 flex gap10 padding-10"
				style="background-color: #fff;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(70)"></image>
				</view>
				<view style="text-align: center;font-size: 30rpx;color:#484848 ;font-weight: 700;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
		</view> -->
		
		<view style="position: relative;padding: 0px 10px;">
					<image src="/static/wo_dxtb.png" mode="widthFix" style="width: 100%;height: 80px;"></image>
				</view>
		
		<view style="margin:20rpx;">

			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 100rpx;padding-bottom: 100rpx;">
				<SignOut></SignOut>
			</view>
		</view>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemThird
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			sousuo(){
				uni.navigateTo({
					url:'/pages/search/index'
				})
			},
			xinxi(){
				uni.navigateTo({
					url:'/pages/notification'
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>