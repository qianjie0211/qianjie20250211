<!-- 绑定银行卡 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<CustomHeader title="개인 계좌 연동" @action="handleBack()"></CustomHeader>
		
		<view style="padding:10px 30rpx;margin:0 20rpx;background-color: #fff;border-radius: 10px;">
			<view style="padding: 10px;">
			<view class="bank-name">
				<view class="">성명:</view> <input placeholder="성명" v-model="value"> </input>
			</view>
			<view class="bank-name">
				<view class="">은행명: </view> <input placeholder="은행명" v-model="value2"> </input>
			</view>
			<view class="bank-name">
				<view class="">계좌번호: </view> <input placeholder="계좌번호" v-model="value4"> </input>
			</view>
			
		
			<view @click="replaceBank()" style="background-color:#190dbf;
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;">
				확인
			</view>
			</view>
			</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: '',
				value2: '',
				value3: '',
				value4: ''

			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value2,
					bank_sub_name: this.value3,
					card_sn: this.value4,
				})
				if (list.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		// font-weight: 700;
		display: flex;
		font-size: 28rpx;
		border-bottom: 2rpx solid #f4f4f4;

		view {
			width: 30%;
		}

		input {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>