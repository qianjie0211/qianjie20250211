<template>
  <div class="container page" style="background-color: #1b1b1b;min-height: 100vh;">
    <div class="header">
      <van-nav-bar :title="curLang.Announcement" class="nav-bar">
        <template #left>
          <van-icon name="arrow-left" color="#fff" @click="back()" />
        </template>
      </van-nav-bar>
    </div>
    <div class="content" style="text-align: center;line-height: 3;color:#FFF;">
      {{curLang.No_message}}
      <!-- <van-pull-refresh v-model="isLoading" @refresh="onRefresh" success-text="Success">
         <template #pulling>
          아래로 스크롤하여 새로 고침하세요
        </template>
        <template #loosing>
          아래로 스크롤하여 새로 고침하세요
        </template>
        <template #loading>
          로딩 중
        </template>
          <div class="listItem" v-for="(v,key) in notice" :key="key">
            <div class="listTitle">{{ v.name }}</div>
            <div class="listContent html"><p>{{ v.text }}<br></p></div>
            <div class="listTime"><div class="listTimeText">{{ v.create_time }}</div></div>
          </div>
      </van-pull-refresh> -->
    </div>
  </div>

</template>

<script>
export default {
  data() {
    return {
      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器

      isLoading: false,
      notice: {},
      loading: false,
      finished: false,
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    back() {
      return window.history.back();
    },
    getNoticeList() {
      this.$http({
        method: 'get',
        url: 'sys_get_notice_list'
      }).then(res => {
        console.log(res);
        this.notice = res.data
      })
    },
    onRefresh() {
      setTimeout(() => {
        this.$toast(this.curLang.success);
        this.isLoading = false;
        this.getNoticeList();
      }, 500);
    },
  },
  created() {
    this.getNoticeList();

    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    this.curCode = this.curLang.loginCode;
    const temp = this.$locales.filter((item) => item.value == this.curLocale);
    console.log(temp);
    this.langName = temp[0].text;
  }
};
</script>

<style lang='less' scoped>
@import "../../assets/css/base.css";

::v-deep .van-pull-refresh__track .van-pull-refresh__head * {
  color: #000000;
  font-size: 35px;
}

::v-deep .van-loading__text {
  color: #000000;
  font-size: 35px;
}

.container .content {
  height: calc(100% - 20px);
  overflow: auto;
}

.container .content .listItem {
  margin-bottom: 20px;
  padding: 20px 20px 0;
  position: relative;
  color: #FFF;
  background-color: transparent;
}

.container .content .listItem .listTitle {
  font-size: 38px;
}

.container .content .listItem .listContent {
  border-bottom: 2px solid #f2f2f5;
  padding: 5px 0;
  font-size: 25px;
}

.container .content .listItem .listTime {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  height: 70px;
}

.container .content .listItem .listTime .listTimeText {
  color: #656566;
  font-size: 30px;
}
</style>
