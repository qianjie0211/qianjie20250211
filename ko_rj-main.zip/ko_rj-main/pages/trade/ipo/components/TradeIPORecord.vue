<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="margin:30rpx ;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.SECOND}" style="font-size: 36rpx;">{{item.goods.name}}</view>
						<template v-if="item.message &&item.message.length>0">
							<view :style="setStyle()"> {{item.message}} </view>
						</template>
					</view>

					<view
						>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:6px;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_RECORD_PRICE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
					
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:6px;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:6px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPORecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: '#f8c35180',
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60px`,
					padding: `6px 20rpx`,
					fontSize: `16px`,
					textAlign: `center`,
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-order-log`);
				console.log(result);
				this.list = result || [];
			},
		},
	}
</script>