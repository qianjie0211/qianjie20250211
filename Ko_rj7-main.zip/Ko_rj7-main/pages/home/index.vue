<template>
	<view style="background-image: url(/static/shouye_bg.png);background-size: contain;background-repeat: no-repeat">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<view class="flex " style="padding: 15px 20px;">
			<image src="/static/logo.png" mode="widthFix" style="width: 80px;height: 30px;"></image>
			<view class="flex flex-1" @click="sousuo()"
				style="background-color: #a2a1e8;border-radius: 30px;padding: 6px 10px;margin-left: 20px;">
				<image src="/static/sousuo.png" mode="widthFix"
					style="width: 15px;height: 30px;display: block;float: left;"></image>
				<view class="text-center" style="font-size: 10px;color: #fff;margin-left: 5px;">검색</view>
			</view>

			<view class="margin-left-10">
				<!-- <image src="/static/fangdajing.png" mode="widthFix" style="width: 20px;height: 20px;margin-right: 10px;"
					@click="sousuo()"></image> -->
				<image src="/static/notification.png" mode="widthFix" style="width: 20px;height: 20px;"
					@click="xinxi()">
				</image>
			</view>
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->
		<!-- <view>
			<image src="/static/banner.png" style="width: 100%;" mode="widthFix"></image>
		</view> -->
		<view style="margin-top: 205px;background-color: #fff;">
			<ButtonGroup></ButtonGroup>
		</view>
		<!-- <view>
			<template>
				<image src="/static/laba.png" mode="widthFix" style="width: 90px;height: 90px;"></image>

				<view class="flex"
					style="padding: 3px;border: 1px #FED326 solid;margin: -70px 10px;border-radius: 10px;">
					<view style="margin-left: 40px;width: 100%;">
						<div class="marquee-container">
						  <div class="marquee">
						    <span>{{text1[0]}}</span>
						  </div>
						</div>
						<u-notice-bar :text="text1" icon="" direction="column" speed="40" bgColor="#f1f2f7"
							color="#a7a8ac" url="/pages/componentsB/tag/tag"></u-notice-bar>
					</view>
				</view>
			</template>
		</view> -->
		<!-- <view style="background-color: #fff;padding: 10px 0px;margin-top:15px;"> -->
		<!-- <view class="flex margin-left-10" style="">
				<image src="/static/yhg.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
				<view class="bold margin-left-5">미국증시</view>
			</view> -->

		<!-- <view class="flex flex-wrap gap10" style="padding: 10px 10px;"> -->
		<!-- <block v-for="(item,index) in setTop1" :key="index">
					<view
						style="flex:20%;padding:10px;border-radius: 6px;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
						:style="{ backgroundImage: `url(${item.rate > 0 ? '/static/zhishu_z.png' : '/static/zhishu-d.png'})`, backgroundSize: 'cover', backgroundPosition: 'center' }">
						<view class="text-center bold">
							<view class="font-size-16" style="color: #000;">
								{{item.name}}
							</view>
							<view :class="item.rate>0?'red':'green'">
								{{item.close}}
							</view>
							<view :class="item.rate>0?'red':'green'" style="margin-bottom: 40px;">
								{{item.rate}}
							</view>
						</view>
					</view>
				</block> -->
		<!-- </view> -->
		<!-- </view> -->

		<!-- <view class="flex" style="padding: 10px 20px;margin-top: 10px;">
			<image src="../../static/new.png" mode="widthFix" style="width: 60px;height: 60px;"></image>
			<view
				style="background: linear-gradient(to right, #f6f6f6, #fff); padding: 10px;width: 80%;border-radius:0px 30px 30px 0px;">
				<view>핫 뉴스 두 줄을 번갈아 방송하다…….</view>
				<view>핫 뉴스 두 줄을 번갈아 방송하다…….</view>
			</view>
		</view> -->

		<!-- <view class="flex  padding-10 gap10">
			<view>
				<image src="/static/sy_qq.png" mode="widthFix" style="width: 180px;"></image>
			</view>
			<view class="" style="line-height: 1.8;width: 100%;">
				<view>
					<image src="/static/sy_ww.png" mode="scaleToFill" style="height: 70px;width: 100%;"></image>
				</view>

				<view>
					<image src="/static/sy_ee.png" mode="scaleToFill" style="height: 70px;width: 100%;"></image>
				</view>
			</view>
		</view> -->

		<view style="padding:10px;background-color: #fff;">
			<CustomTitle title="증시현황"></CustomTitle>
			<view style="display: flex;align-items: center;justify-content: space-between;padding:12rpx;">
				<block v-for="(v,k) in $lang.MARKET_OVERVIEW_SELF_TABS" :key="k">
					<view style="flex:1; text-align:  center;" @click="changeTab(k)">
						<view style="padding:6rpx 0;border-radius: 12rpx 12rpx 0 0;"
							:style="{backgroundColor:curTab==k?$theme.RGBConvertToRGBA(`#4543d1`,30):$theme.TRANSPARENT,borderBottom:`3px solid ${curTab==k?`#4543d1`:$theme.TRANSPARENT }`  }">
							<text style="font-size: 16px;">{{v}} </text>
						</view>
					</view>
				</block>
			</view>
			<view style="display: flex;align-items: center;">
				<block v-for="(item,index) in setTop1" :key="index">
					<view
						style="flex:33.333%;padding:6px;margin:6px;border-radius: 6px;;border:2px solid rgba(0, 0, 0, 0);line-height: 1.8;"
						:style="{backgroundColor:stockId==item.stock_id?`#4543d14d`: '' }"
						@click='handleChangeType(item.stock_id)'>
						<view :style="{color: stockId==item.stock_id?'#121212':$theme.LOG_LABEL}"
							style="text-align: center;">
							{{item.name}}
						</view>
						<view style="text-align: center;" :style="$theme.setStockRiseFall(item.rate>0)">{{item.close}}
						</view>
						<view class="t1 " style="text-align: center;" :style="$theme.setStockRiseFall(item.rate>0)">
							{{(item.rate)}}%
						</view>
					</view>
				</block>
			</view>
			<template v-if="isShowKlineStock">
				<KlienOne :list="klineDataStock" ref="klineArea" />
			</template>
		</view>


		<!-- <view class="flex padding-20">
			<image src="/static/ermen.png" mode="widthFix" style="width: 15px;"></image>
			<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
			<view class="bold margin-left-5 flex-1">시장 개요</view>
			<image src="/static/huo.png" mode="widthFix" style="width: 80px;"></image>
			<view style="margin-right: 10px;" @click="gengduo()">>></view>
		</view> -->
		<!-- <template v-if="isShowKlineTwo">
			<KlineTwo :list="industryList" />
		</template> -->

		<!-- //新闻 -->
		<!-- <MarketNewsTop></MarketNewsTop> -->

		<!-- <view style="margin:10rpx 30rpx;">
			<TitlePrimary :title="$lang.STOCK_ALL">
			</TitlePrimary>
		</view> -->
		<!-- <view style="">
			<view style="background-color: #FFFFFF;">
				<view class="flex padding-20">
					<image src="/static/ermen.png" mode="widthFix" style="width: 15px;"></image>
					<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
					<view class="bold margin-left-5 flex-1">인기종목</view>
					<image src="/static/huo.png" mode="widthFix" style="width: 80px;"></image>
					<view style="margin-right: 10px;" @click="gengduo()">>></view>
				</view>

				<view class="flex " style="padding: 0px 20px;">
					<view style="flex: 50%;align-items: center;font-size: 12px;color: #999;">주식명/코드</view>
					<view style="flex: 20%;align-items: center;font-size: 12px;color: #999;">가격</view>
					<view style="font-size: 12px;color: #999;">증가 또는 감소</view>
				</view>
				<block v-for="(item,index) in list" :key="index" v-if="index<=9">
					<view class="flex " style="padding:10px 20px;border-bottom:1px solid #F3F3F3;"
						@click="link(item.code)">
						<view style="align-items: center;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex: 25%;align-items: center;">
							<view style="font-size: 26rpx;line-height: 1.6;color: #000;">
								{{item.name}}
							</view>
							<view style="font-size: 25rpx;" :style="{color:$theme.LOG_LABEL}">
								{{item.code}}
							</view>
						</view>
						<view style="flex:30%; font-size: 32rpx;text-align: center;font-weight: 700;"
							:style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatMoney(item.price)}}
						</view>
						<view style=" color:#FFFFFF;" :style="setStyle(item.rate*1>0)">
							<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(16)" style="padding-right: 12rpx;"></image>
							{{$util.formatNumber($util.formatMathABS(item.rate),2)}}%
						</view>
					</view>

				</block>

			</view>
			<view style="padding:10px 0px;">
				<image src="/static/bg_oiu.png" mode="widthFix" style="width: 100%;"></image>
			</view>
		</view> -->

		<!-- //新闻 -->
		<MarketNewsTop></MarketNewsTop>
		<view style="padding: 30px;"></view>

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import MarketNewsTop from '../market/components/MarketNewsTop.vue';
	import MarketHot from '../market/components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			TitlePrimary,
			CardItemPrimary,
			MarketNewsTop,
			MarketHot,
			IPOSuccessAlert,
			CustomTitle,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				isActLang: true, // 当前登入用户是否开启多语言权限	
				cardInfo: {}, // 资产卡
				cardLabels: [
					this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				],
				timer: null,
				curTab: 0, // tabs
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				top1: [],
				article: [],
				industryList: [],
				klineDataStock: null, // kline area
				top1Names: {
					141: "코스닥",
					17470: "코스피 200",
					255: "코스피",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				text1: ['투자자 여러분 주의하세요! 📢 Stock X가 새로운 최고가를 기록하며 주요 저항 수준을 돌파했습니다! 새로운 상승의 물결을 기대하세요!',
					'시장 업데이트! 📈 인기 주식 Y가 오늘 엄청난 유입으로 급등하고 있습니다! 이 좋은 기회를 놓치지 마세요!',
					'공지 알림📢 – 큰 소식입니다! Leading Bank Z가 예상보다 높은 분기 실적을 보고했습니다. 잠재적인 가격 변동을 주시하세요!',
					'투자 기회! 📢 제약 주식이 강력한 상승세를 보이고 있습니다! 새로운 랠리의 시작이 될 수 있습니다. 투자자 여러분, 이 분야의 주요 주식을 주시하세요!',
					'빠른 알림 📢 – W 회사가 방금 중요한 발표를 했고 주가가 흔들리고 있습니다! 현재 보유자 여러분, 위험을 관리하고 일중 움직임을 면밀히 모니터링하세요!',
					'Hot Off the Press! 🔥 IT 부문 주식이 예외적으로 좋은 성과를 보이고 있습니다! 여러 회사가 새로운 계약을 발표하여 기회를 창출하고 있습니다. 계속 지켜봐 주세요!',
				],
			}
		},
		computed: {
			setTop1() {
				const temp = Object.values(this.top1);
				if (!temp || temp.length <= 0) return [];
				return temp.map(item => {
					return {
						...item,
						name: this.top1Names[item.stock_id]
					}
				})
			},
			// 是否显示当前选中股票的kline area
			isShowKlineStock() {
				// console.log(`IS:`, this.klineDataStock);
				return this.klineDataStock && this.klineDataStock.length > 0;
			},
			// 是否显示柱状图表
			isShowKlineTwo() {
				return this.industryList.length > 0;
			},
		},
		onLoad() {},
		onShow() {
			this.getAccountInfo();
			this.getList();
			this.isAnimat = true;
			// console.log(this.cardLabels);
			this.getDetail();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
			// console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		deactivated() {
			// console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				// 每次切换时，重置当前选中股票
				const temp = this.setTop1[0].stock_id;
				this.handleChangeType(temp);
			},
			handleChangeType(val) {
				this.stockId = val;
				this.getDetail();
			},
			async getDetail() {
				const result = await this.$http.get(`api/goods/top1`, {
					current1: this.curTab,
					stockid: this.stockId
				});
				// console.log('getData:', result);
				if (!result) return false;
				this.top1 = result.top1
				this.article = result.article;
				this.industryList = result.bottom;
				this.klineDataStock = result.kline;
				// klineArea
				if (this.isShowKlineStock && this.$refs.klineArea) {
					this.$refs.klineArea.renderInit();
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					this.getDetail();
				}, 5000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					// console.log('clearTimer', this.timer);
				}
			},
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},

			linkMarketNews() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=3`,
				})
			},
			gengduo() {
				uni.reLaunch({
					url: '/pages/market/overview'
				})
			},
			sousuo() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			xinxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					borderRadius: `10rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/paihang`, {
					// current: this.curTab
				})
				// console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						uid: item.uid,
						close: item.close,
					}
				});
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				// console.log('info result：', result);
				if (!result) return false;
				this.cardInfo = {
					value1: result.totalZichan || 0,
					value2: result.money || 0,
					value3: result.freeze || 0,
				};
			},

			barStyle(value) {
				value = value * 2 * 10
				let percentage = Math.min(Math.abs(value), 100); // 确保百分比限制在 0 到 100 之间
				if (value > 0) {
					// 正数时，从中间往右显示红色，左边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #fe474f 50%, #fe474f ${50 + (percentage / 2)}%, #e9e9ea ${50 + (percentage / 2)}%)`,
					};
				} else if (value < 0) {
					// 负数时，从中间往左显示绿色，右边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea ${50 - (percentage / 2)}%, #1e6be1 ${50 - (percentage / 2)}%, #1e6be1 50%, #e9e9ea 50%)`,
					};
				} else {
					// 值为 0 时，保持全灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #e9e9ea 50%)`,
					};
				}
			},
		},
	}
</script>