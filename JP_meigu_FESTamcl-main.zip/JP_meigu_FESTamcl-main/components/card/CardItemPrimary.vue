<template>
	<view>
		<view style="display: flex;align-items: center;line-height: 1.6;">
			<view style="font-size: 32rpx;">
				{{labels[0]}}
			</view>
			<image mode="aspectFit" :src="`/static/${showAmount?'zhenyan':'yanjin'}.png`" @click.stop="handleShowAmount"
				:style="$theme.setImageSize(40)" style="margin-left: 10px;">
			</image>
		</view>
		<view class="flex">
			<view style="font-size: 50rpx;font-weight: 700;line-height: 1.6;color: #ec1a14;">
				{{showAmount?$util.formatMoney(info.value1):hideAmount}}
			</view>
			<view class="bold" style="margin-left: 5px;font-size: 16px;">JPY</view>
		</view>
		
		<view class="flex">
			<view style="font-size: 38rpx;font-weight: 700;line-height: 1.6;color: #ec1a14;">
				{{showAmount?$util.formatMoney(info.usd):hideAmount}}
			</view>
			<view class="bold" style="margin-left: 5px;font-size: 12px;">USD</view>
		</view>
		
		<view class="justify-center flex" style="font-weight: 500;left: 25px;width: 90%;color: #fff;margin-top: 10px;">
				<view style="background-color: #fa0c33;padding: 5px 30px;border-radius: 30px;font-size: 16px;" @click="linkWithdraw()">
					{{$lang.WITHDRAW_TITLE}}
				</view>
				<view style="width: 50px;">.</view>
				<view style="background-color: #f0a039;padding: 5px 30px;border-radius: 30px;font-size: 16px;" @click="linkDeposit()">
					{{$lang.DEPOSIT_TITLE}}
				</view>
				
			</view>
		</view>

		<!-- <view style="display: flex;align-items: center;font-size: 28rpx;">
			<view style="flex:1 0 50%;">
				<view>{{labels[1]}}</view>
				<view style="color: #ec1a14;">{{showAmount?$util.formatMoney(info.value2):hideAmount}}</view>
			</view>
			<view style="flex:1 0 50%;text-align: right;">
				<view>{{labels[2]}}</view>
				<view style="color: #ec1a14;">{{showAmount?$util.formatMoney(info.value3):hideAmount}}</view>
			</view>
		</view> -->
	</view>
</template>

<script>
	export default {
		name: 'CardItemPrimary',
		props: {
			info: {
				type: Object,
				default: {}
			},
			// label。单独分开，否则会因数据请求慢，导致label未加载
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			}
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
		}

	}
</script>