<template>
	<view style="background-image: url('/static/jiedai.png');height: 380px;">
		<view class="flex padding-20">
			<view @click="daikuan()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center">
				{{$lang.LOANS_INDEX_BORROWING}}
			</view>
		</view>

		<view style="padding: 20px;margin-top: 250px;">
			<view style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<view class="flex"
					style="background-color: #2771f7;padding: 15px;border-radius: 10px;justify-content: center;display: flex;"
					@click="qianwang()">
					<view style="color: #fff;">
						{{$lang.LOANS_INDEX_GO_TO_LOANS}}
					</view>
					<image src="/static/youjt.png" mode="widthFix" style="width: 20px;margin-left: 10px;"></image>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
					<view style="margin-left: 20px;">
						{{$lang.LOANS_INDEX_PRODUCT_ADVANTAGES}}
					</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>
				<view>
					<view>
						<view class="flex">
							<image src="/static/dz.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10">
								{{$lang.LOANS_INDEX_CUSTOMIZED_VIP_LOAN_SERVICE}}
							</view>
						</view>
						<view class="font-size-13" style="color: #a7a7a7;padding: 5px 0px;">
							{{$lang.LOANS_INDEX_THE_MAXMIN_LOAN_AMOUNT_IS}}
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/ll.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10">
								{{$lang.LOANS_INDEX_INTEREST_RATE_LEVEL}}
							</view>
						</view>
						<view class="font-size-13" style="color: #a7a7a7;padding: 5px 0px;">
							{{$lang.LOANS_INDEX_THE_HIGHER_THE_PRIME_LEVEL}}
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/lh.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10">
								{{$lang.LOANS_INDEX_FLEXIBLE_USE_OF_FUNDS}}
							</view>
						</view>
						<view class="font-size-13" style="color: #a7a7a7;padding: 5px 0px;">
							{{$lang.LOANS_INDEX_THE_LOAN_PERIOD_STARTS_FROM}}
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/lc.png" mode="widthFix" style="width: 23px;"></image>
							<view class="bold margin-left-10">
								{{$lang.LOANS_INDEX_SIMPLIFIEND_LOAN_PROCESS}}
							</view>
						</view>
						<view class="font-size-13" style="color: #a7a7a7;padding: 5px 0px;">
							{{$lang.LOANS_INDEX_1_3DAYS_TO_COMPIETE_THE_LOAN}}
						</view>
					</view>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
					<view style="margin-left: 20px;">
						{{$lang.LOANS_INDEX_HOW_TO_BORROW}}
					</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>

				<view class="flex text-center" style=" justify-content: space-between;  ">
					<view class="flex-1">
						<image src="/static/qq.png" mode="widthFix" style="width: 20px;"></image>
						<view>
							{{$lang.LOANS_INDEX_STEP_1}}
						</view>
						<view>
							{{$lang.LOANS_INDEX_FILL_OUT_THE_LOAN_APPLICATION_FORM}}
						</view>
					</view>
					<view class="flex-1">
						<image src="/static/ww.png" mode="widthFix" style="width: 20px;"></image>
						<view>
							{{$lang.LOANS_INDEX_STEP_2}}
						</view>
						<view>
							{{$lang.LOANS_INDEX_CONFIRMATION_OFLOAN_NEEDS}}
						</view>
					</view>
				</view>

				<view class="flex text-center margin-top-20" style=" justify-content: space-between;">
					<view class="flex-1">
						<image src="/static/ee.png" mode="widthFix" style="width: 20px;"></image>
						<view>
							{{$lang.LOANS_INDEX_STEP_3}}
						</view>
						<view>
							{{$lang.LOANS_INDEX_SIGN_LOAN_CONTRACT}}
						</view>
					</view>
					<view class="flex-1">
						<image src="/static/rr.png" mode="widthFix" style="width: 20px;"></image>
						<view>
							{{$lang.LOANS_INDEX_STEP_4}}
						</view>
						<view>
							{{$lang.LOANS_INDEX_FUND_SECURITY_LENDING}}
						</view>
					</view>
				</view>
			</view>



			<view style="margin-top: 20px;">
				<view style="background-color: #fff;border-radius: 10px;">
					<view class="flex padding-25" style="justify-content: center;display: flex;">
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
						<view style="margin-left: 20px;">
							{{$lang.LOANS_INDEX_FAQ}}
						</view>
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>

					</view>


					<!-- 	<view class="flex">
				<view>使用场外借贷需要满足哪些条件?</view>
				<image src="/static/jia.png"></image>
			</view> -->

					<view style="padding: 10px;">
						<template>
							<u-collapse @change="change" @close="close" @open="open">
								<u-collapse-item
									:title="$lang.LOANS_INDEX_WHAT_CONDITIONS_NEED_TO_BE_MET_TO_USE_OTC_LENGDING"
									name="Docs guide">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_MARKET_MAKERS_ON_THIS_PLATFORM}}
									</text>
								</u-collapse-item>
								<u-collapse-item :title="$lang.LOANS_INDEX_WHAT_ARE_THE_CRYPTOCURRENCIES">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_BORROWING_CURRENCIES_INCLUDE}}
									</text>
								</u-collapse-item>
								<u-collapse-item :title="$lang.LOANS_INDEX_HOW_LONG_IS_THE_LOAN_TERM_FOR_OTC_LOANS"
									name="Numerous tools">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_FLEXIBLE_LOAN_CYACLE}}
									</text>
								</u-collapse-item>
							</u-collapse>
							<u-collapse @change="change" @close="close" @open="open">
								<u-collapse-item :title="$lang.LOANS_INDEX_HOW_TO_CALCULATE_INTEREST" name="Docs guide">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_INTEREST_IS_CALCULATED_DAILY}}
									</text>
								</u-collapse-item>
								<u-collapse-item :title="$lang.LOANS_INDEX_HOW_TO_REPAY_PRINCIPAL_AND_INTEREST"
									name="Variety components">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_THE_INTEREST_IS_SETTLED_AT_THE_END_OF}}
									</text>
								</u-collapse-item>
								<u-collapse-item :title="$lang.LOANS_INDEX_CAN_I_PAY_IN_ADVANCE" name="Numerous tools">
									<text class="u-collapse-content">
										{{$lang.LOANS_INDEX_THE_INTEREST_IS_SETTLED_AT_THE_END_OF}}
									</text>
								</u-collapse-item>
							</u-collapse>
						</template>
					</view>







				</view>
			</view>


		</view>




	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			open(e) {
				// console.log('open', e)
			},
			close(e) {
				// console.log('close', e)
			},
			change(e) {
				// console.log('change', e)
			},
			daikuan() {
				uni.navigateBack({
					delta: 1,
				})
			},
			qianwang() {
				uni.navigateTo({
					url: '/pages/Loans/daikuan'
				})
			},

		}
	}
</script>

<style>
</style>