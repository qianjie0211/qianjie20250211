<template>
	<view >
		<view class="common_mask"  @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto;background-color:#202328 ;">
			<view class="popup_header" style="background-color:#202328 ;color: #fff;">
				{{$lang.TRADE_WEALTH_BUY_DETAIL}}
			
				<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #ccc;">{{$lang.LICAI_MINGCHENG}}</view>
				<view class="flex" >
					<view style="font-size: 16px;margin-left: 30px;color: #fff;">{{info.name}}</view>
				</view>
			</view>
			
				<template v-if="info.is_new==1">
					<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
						<view style="color: #ccc;">{{$lang.LICAI_LEIXING}}</view>
						<view class="flex" >
							<view style="background-color: #B2E8CD;font-size: 10px;padding: 5px;width: 80px;text-align: center;border-radius: 5px;color: #00B45A;">{{$lang.TRADE_WEALTH_NEW_USERS}}</view>
						</view>
					</view>
				</template>
				
				<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
					<view style="color: #ccc;">{{$lang.LICAI_YUGUSHOUYILV}}</view>
					<view class="flex" >
						<view style="color: #fff;">{{info.syl}}</view>
					</view>
				</view>
				
			<!-- <view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">预估收益</view>
				<view class="flex" >
					<view style="color: #000;">{{info.zhouqi+$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
				</view>
			</view> -->
			
			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #ccc;">{{$lang.LICAI_ZHOUQI}}</view>
				<view class="flex" >
					<view style="color: #fff;">{{info.zhouqi+$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
				</view>
			</view>
			
			<!-- <view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">发放日期</view>
				<view class="flex" >
					<view style="color: #000;">2024-06-15</view>
				</view>
			</view> -->
		
			
			
			
			
			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #ccc;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
				<view class="flex" >
					<view style="color: #fff;">{{info.min_price}}</view>
				</view>
			</view>
				
				
				<!-- <view
					style="display: flex;align-items: center;justify-content: space-between;line-height:3;padding:0 60rpx;">
					<view style="color:#666666;">{{$lang.TEADE_WEALTH_MIN_PRICE}}</view>
					<view style="color:#333333;font-size: 28rpx;">{{$util.formatDate(new Date())}}</view>
				</view> -->
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height:3;padding:0 40rpx;">
					<view style="color:#ccc;font-size: 16px;">{{$lang.LICAI_QINGSHURUMEIRUJINE}}</view>
					
				</view>
				<view class="common_input_wrapper"
					style="padding-left: 20px;margin:30rpx 40rpx;background-color: #202328;border: 1px solid #00aa98;" v-if="info.is_new!=1">
					<input v-model="amount" :placeholder="$lang.TRADE_WEALTH_BUY_AMOUNT" type="number"
						style="width: 80%;color: #fff;" :placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<view class="text-center padding-10" style="margin:20px auto; width: 90%;background-color: #03b874;border-radius: 10px;color: #fff;" @tap.stop="handleBuy()" v-if="info.is_new!=1">
					{{$lang.BTN_BUY}}
				</view>
				<view class="access_btn" style="margin:20px auto; width: 90%;" @click="home()" v-if="info.is_new!=0">
					{{$lang.LICAI_KEFU}}
				</view>
				
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'WealthBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				amount: "", // 数量
			}
		},
		computed: {},
		created() {},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			home() {
				uni.navigateTo({
					url:'/pages/service',
				})
			},

			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT);
					return false;
				}
				if (this.amount < this.info.min_price) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT_TIP);
					return false;
				}
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.info.name} Payment Amount ${this.$util.formatMoney(this.amount)}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.info.id,
					ganggan: 1,
					price: this.amount,
				});
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				setTimeout(() => {
					this.actionEvent();
				}, 1000);
			}
		}
	}
</script>

<style>
</style>