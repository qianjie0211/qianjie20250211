<template>
	<view style="background-color: #FFF;border-radius: 16rpx;padding:24rpx;margin:0 36rpx;">
		<view style="display: flex;align-items: center;">
			<view style="width: max-content;">{{$lang.ASSETS_TOTAL}}</view>
			<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit" style="padding-left: 24rpx;"
				:style="$theme.setImageSize(32)" @click="toggleMask()">
			</image>
			<view style="margin-left: auto;font-size: 40rpx;font-weight: 700;color:#121212;line-height: 1.4;">
				{{isMask?hideValue:$util.formatNumber(info.total)}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
			<view>{{$lang.ASSETS_AVAIL}}</view>
			<view style="color:#01b2ce;font-size: 32rpx;">{{isMask?hideValue:$util.formatNumber(info.money) }}</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
			<view>{{$lang.ASSETS_FREEZE}}</view>
			<view style="color:#B33DBB;font-size: 32rpx;">{{isMask?hideValue:$util.formatNumber(info.freeze) }}</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
			<view>{{$lang.ASSETS_HOLD_PROFIT}}</view>
			<view style="color:#2374CF;font-size: 32rpx;">{{isMask?hideValue:$util.formatNumber(info.holdProfit) }}
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
			<view>{{$lang.ASSETS_TOTAL_PROFIT}}</view>
			<view style="color:#5AD99E;font-size: 32rpx;">{{isMask?hideValue:$util.formatNumber(info.totalProfit) }}
			</view>
		</view>


		<!-- <view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<canvas canvas-id="assets" id="assets" class="charts"></canvas>
		</view> -->
	</view>
</template>

<script>
	// import uCharts from '@/common/u-charts.js';
	// import {
	// 	pieChart
	// } from '@/common/customUChart.js';
	// let uChartsInstance = {};
	export default {
		name: 'AssetsCard',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				// cWidth: 0,
				// cHeight: 0,
				isMask: null, // 掩码
				hideValue: '****', // 隐藏金额
			}
		},
		computed: {
			// chartData() {
			// 	return {
			// 		categories: [],
			// 		series: [{
			// 			name: '可用',
			// 			data: this.info.money,
			// 			color: '#2374CF',
			// 		}, {
			// 			name: '总盈利',
			// 			data: this.info.totalProfit,
			// 			color: '#5AD99E',
			// 		}, {
			// 			name: '冻结',
			// 			data: this.info.freeze,
			// 			color: '#B33DBB',
			// 		}],
			// 		// total: result.totalZichan * 1, // 总资产
			// 		// money: result.money * 1, // 可提
			// 		// freeze: result.frozen * 1, // 冻结
			// 		// totalProfit: result.totalYingli * 1, // 总盈利
			// 		// holdProfit: result.holdYingli * 1, // 持仓盈利
			// 	}
			// }
		},
		// created() {
		// 	//这里的 750 对应 css .charts 的 width
		// 	this.cWidth = uni.upx2px(370);
		// 	//这里的 500 对应 css .charts 的 height
		// 	this.cHeight = uni.upx2px(250);
		// },
		beforeMount() {
			this.isMask = uni.getStorageSync('mask');
			console.log(this.info);
		},
		mounted() {
			// this.genCharts();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// genCharts() {
			// 	const ctx = uni.createCanvasContext("assets", this);
			// 	uChartsInstance["assets"] = new uCharts(pieChart(ctx,
			// 		this.chartData,
			// 		this.cWidth,
			// 		this.cHeight))
			// },
		}
	}
</script>

<style lang="scss" scoped>
	// .charts {
	// 	width: 740upx;
	// 	height: 500upx;
	// }
</style>