<template>
	<view>
		<view style="display: flex;align-items: center;padding:36rpx">
			<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
			<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_SCORE_CHART}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<canvas canvas-id="score" id="score" class="charts"></canvas>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {areaChart} from '@/common/customUChart.js';
	let uChartsInstance = {};
	export default {
		name: 'ChartScoreArea',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
			}
		},
		computed: {
			chartData() {
				return {
					categories: this.info.dateriqi.map(item => this.$util.formatYearMonthDay(item * 1000)),
					series: [{
						name: '',
						data: this.info.pingfen.map(item => item * 1),
						color: this.$theme.RISE,
					}],
				}
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			genCharts() {
				const ctx = uni.createCanvasContext("score", this);
				uChartsInstance["score"] = new uCharts(areaChart(ctx,
					this.chartData,
					this.cWidth,
					this.cHeight))
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>