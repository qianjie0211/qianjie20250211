<template>
	<view>
		<view style="display: flex;align-items: center;padding:0 36rpx 0 36rpx;">
			<view style="width: 8rpx;height: 28rpx;" :style="{backgroundColor:$theme.PRIMARY}"></view>
			<view style="font-size: 28rpx;font-weight: 700;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_TRADE_VOLUME}}
			</view>
		</view>

		<!-- <view style="display: flex;align-items: center;padding:36rpx;">
			<block v-for="(item,index) in $lang.COPY_DETAIL_TV_TABS" :key="index">
				<view :style="setStyle(curTab==index)" @tap="changeTab(index)">{{item}}</view>
			</block>
		</view> -->

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<canvas canvas-id="volume" id="volume" class="charts"></canvas>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {
		columnChartVolume
	} from '@/common/customUChart.js';
	export default {
		name: 'ChartTradeVolume',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				// curTab: 0, // 当前tab
				cWidth: 0,
				cHeight: 0,
				chart: null,
			}
		},
		computed: {
			// 处理交易量图表数据
			tradeVolData() {
				// console.log(`交易量:`, this.list);
				const temp = this.list.map(item => {
					return {
						timestamp: item.date * 1000,
						value: item.zhengentou * 1
					}
				}).sort((a, b) => a.timestamp - b.timestamp, 0);
				let tempCategories = []; // 存储时轴
				let tempSeries = []; // 存储数据
				// 决定时轴显示及空字符间隙
				const divisor = parseInt(temp.length / 10);
				// console.log(`divisor:`, divisor);

				temp.forEach((item, index) => {
					if (divisor > 0) {
						tempCategories.push(
							index % divisor === 0 || index == temp.length - 1 ? item.timestamp : ''
						)
						tempSeries.push(item.value);
					} else {
						tempCategories.push(item.timestamp);
						tempSeries.push(item.value);
					}
				})
				return {
					categories: tempCategories.map(item => item == '' ? '' : this.$util.formatMonthDay(item)),
					series: [{
						name: '',
						data: tempSeries,
						color: this.$theme.RISE,
					}],
				}
			},
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			// changeTab(val) {
			// 	this.curTab = val;
			// 	this.genCharts();
			// },

			genCharts() {
				const ctx = uni.createCanvasContext("volume", this);
				this.chart = new uCharts(columnChartVolume(ctx,
					this.tradeVolData,
					this.cWidth,
					this.cHeight))
			},

			// setStyle(val) {
			// 	return {
			// 		fontSize: `24rpx`,
			// 		textAlign: `center`,
			// 		borderRadius: `32rpx`,
			// 		padding: `4rpx 8rpx`,
			// 		color: val ? this.$theme.WHITE : '#8E8D92',
			// 		border: `1px solid ${val ? '#3B3B3D' : this.$theme.TRANSPARENT}`,
			// 		backgroundColor: this.$theme.TRANSPARENT,
			// 		minWidth: `120rpx`,
			// 	}
			// }
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>