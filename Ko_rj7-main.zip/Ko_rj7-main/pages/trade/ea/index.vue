<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex padding-20" style="background-color: #fff;">
			<view @click="fanhui()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="font-size-19 bold flex-1 text-center" style="color: #34d66a;">EA 거래</view>
			<!-- <view @click="jilu()">
				<image src="/static/ea_jl.png" mode="widthFix" style="width: 20px;"></image>
			</view> -->
			
		</view>
		<view style="position: relative;">
			<image src="/static/ea_bg.png" mode="widthFix" style="width: 100%;height: 130px;"></image>
		</view>
		<view style="padding:0px 10px;margin-top: -20px; position: absolute;width: 95%;">
			<view class="flex flex-b" style="background-color: #fff;padding:15px 70px;border-radius: 10px;border: 1px #33d669 solid;" >
				<view @click="changeTab(0)">
					<image src="/static/tb_ee.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">상품목록</view>
				</view>
				<view @click="changeTab(1)">
					<image src="/static/tb_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">거래기록</view>
				</view>
			</view>
		</view>

		<!-- 韩国似乎没有EA介绍 -->
		<!-- <TabsPrimary :tabs="$lang.TRADE_EA_TABS.slice(1,3)" @action="changeTab" :acitve="curTab"></TabsPrimary> -->

		<!-- <template v-if="curTab ==0">
			<EaIntroduce></EaIntroduce>
		</template> -->

		<template v-if="curTab==0">
			<EaMarket></EaMarket>
		</template>
		<template v-else>
			<EaOrder></EaOrder>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import EaIntroduce from './components/EaIntroduce.vue';
	import EaMarket from './components/EaMarket.vue';
	import EaOrder from './components/EaOrder.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			EaIntroduce,
			EaMarket,
			EaOrder,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},
			jilu(){
				uni.navigateTo({
					url:'/pages/trade/ea/components/EaOrder'
				})
			},
		}
	}
</script>

<style>
</style>