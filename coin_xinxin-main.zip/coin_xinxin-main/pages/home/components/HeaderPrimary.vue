<template>
	<view >
		<header class="common_header">
			<image src="/static/user.png" mode="aspectFit" :style="$theme.setImageSize(55)"
				style="padding-right: 30rpx;" @tap="linkAccount()">
			</image>
			<view style="width: 70%;height: 48rpx;">
				<!-- {{title}} -->
				<!-- <view style="background-color: rgba(255, 255, 255, 0.7);height: 100%;border-radius: 44rpx;"
					@click="linkSearch()"> </view> -->

			</view>
			<view style="margin-left: auto;">
				<view style="display: flex;align-items: center;">
					<image mode="aspectFit" src="/static/translate.svg" :style="$theme.setImageSize(40)"
						@click="isShowList=true">
					</image>
					<image mode="aspectFit" src="/static/notify.png" :style="$theme.setImageSize(40)"
						@click="linkNotify()" style="padding-left: 30rpx;"></image>
				</view>
			</view>
		</header>

		<!-- 语言选择器 -->
		<u-picker :show="isShowList" :columns="[$util.LANGUAGE_LIST]" @change="changeLang" @cancel="isShowList=false"
			@confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="name"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	export default {
		name: 'HeaderPrimary',
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
		},
		data() {
			return {
				isShowList: false, // 多语言备选
			}
		},
		methods: {
			// 選擇一種 lang
			chooseLang() {
				this.isShowList = true;
			},
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				// this.curLang = e.value[0].name;
				this.isShowList = false;
				uni.setStorageSync('lang', e.value[0].lang);
				uni.reLaunch({
					url: this.$paths.HOME,
				})
			},

			linkAccount() {
				this.$emit(`action`, true);
			},
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},
			// 跳转到通知页面
			linkNotify() {
				uni.navigateTo({
					url: this.$paths.NOTIFIY_INDEX
				})
			},
		}
	}
</script>

<style>
	.common_header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
</style>