<template>
	<view style="background-color: #FFF;">
		<view v-for="(item,index) in list" :key="index"
			style="border-bottom: 0.037037rem solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
			<view style="margin: 10px 0;display: flex;justify-content: space-between;align-items: center;">
				<text style="font-weight: 900;color:#181945;font-size: 16px;">{{item.name}}</text>
				<text style="font-weight: 700;color:#4b5fcc;font-size: 16px;">{{item.code}}</text>
				<view @click="handleDetail(item.id)"
					style="background-color: #4b5fcc;color: #fff;border-radius: 40rpx;padding: 6rpx 40rpx;font-size: 26rpx">
					{{$lang.DETAIL}}
				</view>
			</view>
			<!-- <view
				style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
				<text style="flex:20%;">单价</text>
				<text style="flex:20%;text-align: right;color:darkred">{{$util.formatNumber(item.price)}}</text>
				<view style="flex:10"></view>
				<text style="flex:20%;">时间</text>
				<text style="flex:30%;text-align: right;">{{item.created_at.slice(0,10)}}</text>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
				<text style="flex:20%;">当前价</text>
				<text style="flex:20%;text-align: right;">{{$util.formatNumber(item.current_price)}}</text>
				<view style="flex:10"></view>
				<text style="flex:20%;">最新价</text>
				<text style="flex:30%;text-align: right;color:darkred">{{$util.formatNumber(item.last_price)}}</text>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
				<text style="flex:20%;">涨幅率</text>
				<text style="flex:20%;text-align: right;color:darkred">{{item.rate}}%</text>
				<view style="flex:10"></view>
				<text style="flex:20%;">涨幅金额</text>
				<text style="flex:30%;text-align: right;color:darkred">{{item.rate_num}}</text>
			</view> -->
		</view>
		<EmptyData v-if="list.length<=0"></EmptyData>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeList",
		props: ['type', 'height'],
		components: {
			EmptyData
		},
		data() {
			return {
				list: [],
			};
		},
		computed: {
			heightVal() {
				return this.height > 0 ? this.height : 85;
			},
		},
		mounted() {
			this.getList();
		},
		methods: {
			// 查看详情
			handleDetail(id) {
				this.$emit('action', id);
			},
			async getList() {
				console.log(this.type)
				const result = await this.$http.get(`api/goods-${this.type}/list`, {});
				console.log( result.data.data);
				this.list = result.data.data.map(item => {
					return {
						id:item.id,
						name: item.goods.name,
						code: item.goods.code,
						// price: item.price,
						// created_at: item.created_at.slice(0, 10),
						// current_price: item.goods.current_price,
						// last_price: item.goods.last_price,
						// rate: item.goods.rate,
						// rate_num: item.goods.rate_num,
					}
				})
			},
		}
	}
</script>

<style>

</style>