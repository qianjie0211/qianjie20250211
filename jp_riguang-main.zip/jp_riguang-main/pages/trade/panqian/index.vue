<template>
	<view>
		<view class="block">
			<view class="head">
				<img @click="$u.route({type:'navigateBack'});" :src="$icon.zjt" class="back">
				<view class="title left_in" style="margin-left: 0px;">プレマーケット取引</view>
				<view class="back"></view>
			</view>
		</view>
        
		<view>
			<view class="flex   font-size-15 bold " style="border-bottom: 1px #ededed solid;padding:10px 0px;">
				<view class="text-center" style="flex: 30%;">銘柄</view>
				<view class="text-center" style="flex: 30%;">価格</view>
				<view class="text-center" style="flex: 30%;">銘柄コード</view>
			</view>
			
			<view class="flex  font-size-12 " style="border-bottom: 1px #ededed solid;padding:10px 0px;" v-for="(item,index) in info" @click="link(item.code)">
				<view class="text-center" style="flex: 30%;"><span class="shares-name">{{item.name}}</span></view>
				<view class="text-center" style="flex: 30%;"><span class="shares-price-num">{{$util.formatMoney(item.pq_price)}}</span></view>
				<view class="text-center" style="flex: 30%;"><span class="shares-name">{{item.code}}</span></view>
			</view>
		</view>
	
	</view>
</template>

<script>

	export default {
		components: {
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				info: [], // 持有列表
			};
		},
		onShow() {
			this.isAnimat = true;
			this.panqian();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			async panqian() {
				const result = await this.$http.get(`api/Goods/panqian`);
				console.log('result:', result);
				// if (!result) return false;
				this.info = result
			},
		}
	}
</script>

<style>
	.th {
		height: 35px;
		border-bottom: 1px solid #ebebeb;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		margin: 0 7px
	}
	
	.th .th-td {
		font-weight: 600;
		font-size: 12px;
		color: #333;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}
	
</style>