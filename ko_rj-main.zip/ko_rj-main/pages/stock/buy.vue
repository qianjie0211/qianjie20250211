<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond style="background-color: #F8C351;" :title="!stockInfo?'': stockInfo.name" :color="$theme.SECOND"></HeaderSecond>

		<view style="display: flex;align-items: center;justify-content: center;margin: 20rpx 0;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<template v-if="stockInfo">
			<view class="common_block" style="display: flex;align-items: center;padding:10px;margin-top: 40rpx;">
				<view style="width: 90rpx;text-align: center;">
					<CustomLogo :logo="stockInfo.logo" :name="stockInfo.name"></CustomLogo>
				</view>
				<view style="flex: 0 0 40%;padding-left: 6px;" :style="{color:$theme.TITLE}">
					<view :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;">{{stockInfo.name}}</view>
					<view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;">{{stockInfo.code}}</view>
				</view>

				<view style="margin-left: auto;">
					<view :style="{color:$theme.LOG_VALUE}" style="text-align: right;">
						{{$util.formatNumber(stockInfo.current_price)}} {{` ${$lang.CURRENCY_UNIT}`}}
					</view>
					<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
						<image :src="`/static/arrow_${stockInfo.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(24)" style="padding-right: 20rpx;"></image>
						{{($util.formatNumber($util.formatMathABS(stockInfo.rate),2))}}%
					</view>
				</view>
			</view>

			<CustomTitle :title="$lang.STOCK_BUY_QUANTITY"></CustomTitle>

			<view style="display: flex;flex-wrap:wrap;padding:10px;">
				<block v-for="(item,index) in quantityList" :key="index">
					<view style="width:18%;line-height: 1.6;" :style="setStyle(curQuantity==item)"
						@click="chooseQTY(item)">
						{{$util.formatNumber(item)}}
					</view>
				</block>
			</view>

			<view class="common_input_wrapper" style="padding-left: 40rpx;margin: 10rpx 40rpx;">
				<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY" @input="handleInput"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>

			<!-- 杠杆数组大于1，视为开启杠杆功能 -->
			<template v-if="leverList.length>1">
				<CustomTitle :title="$lang.LEVER"></CustomTitle>
				<view style="display: flex;flex-wrap:wrap;padding:10px;">
					<block v-for="(item,index) in leverList" :key="index">
						<view style="width:10%;line-height: 1.6;" :style="setStyle(curLever==item)"
							@click="chooseLever(item)">
							{{item}}
						</view>
					</block>
				</view>
			</template>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
				:style="{color:$theme.LOG_LABEL}">
				<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(quantity)}}
				</view>
				<template v-if="leverList.length>1">
					<view>{{$lang.LEVER}}</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{curLever}}
					</view>
				</template>
			</view>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
				:style="{color:$theme.LOG_LABEL}">
				<view>{{$lang.STOCK_BUY_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(stockInfo.current_price*curQuantity/curLever)}}
				</view>
			</view>
			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
				:style="{color:$theme.LOG_LABEL}">
				<view>{{$lang.STOCK_BUY_FEE}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(stockInfo.current_price*curQuantity/curLever*fee)}}
				</view>
			</view>

			<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
				<view class="common_btn" style="margin:40rpx auto;width: 80%; background-color: #008000;" @click="placeOrder()">
					{{$lang.BTN_BUY}}
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			CardItemThird,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [100, 150, 200, 300, 500], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				quantity: 100, // 数量输入框 
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前选中杠杆值
				show: false,
				stockInfo: null,
				userInfo: {},
				fee: 1, // 手续费
				cardData: {}, // 资产信息
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
		},
		onLoad(option) {
			this.getStockDetail(option.code)
			this.getconfig();
			this.getAccountInfo()
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
			},
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : '#A8A8A8',
					borderRadius: `16rpx`,
					textAlign: 'center',
					margin: '10rpx',
					padding: `8rpx 10rpx`,
				}
			},

			// 获取配置
			async getconfig() {
				const result = this.$http.get(`api/app/config`);
				console.log(`config result:`, result);
				// const temp = result.reduce((map, item) => {
				// 	map.set(item.key, item.value);
				// 	return map;
				// }, new Map());
				// this.fee = temp.get('TransRate') || this.fee;
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async getStockDetail(code) {
				const result = await this.$http.get(`api/product/info`, {
					code: code,
				})
				this.stockInfo = result[0]
			},
			//购买
			async placeOrder() {
				const money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.STOCK_BUY_TIP_QUANTITY,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					ganggan: this.curLever,
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					console.log(11);
					uni.switchTab({
						url: this.$paths.POSITION,
					});
				}, 1000)
			},
			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money, // 可提
					value2: this.userInfo.freeze, // 冻结
					value3: this.userInfo.totalZichan, // 总资产
				};
				if (this.userInfo.ganggan) {
					console.log(this.userInfo.ganggan);
					console.log(this.$util.leverList(this.userInfo.ganggan));
					this.leverList = this.$util.leverList(this.userInfo.ganggan);
					this.leverList.push(3)
				}
			},
		},
	}
</script>