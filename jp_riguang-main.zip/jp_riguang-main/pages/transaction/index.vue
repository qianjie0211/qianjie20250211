<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="page">
			<view class="block">
				<view class="head">
					<img :src="$icon.laba" class="head-ring" @click="$u.route({url:'/pages/notification'});">
					<view class="head-search">
						<img :src="$icon.sousuo" @click="$u.route({url:'/pages/search/index'});">
					</view>
					<img :src="$icon.chilun" class="head-setting" @click="$u.route({url:'/pages/account/center'});">
				</view>
			</view>

			<view
				style="background-color: #FFFFFF;padding: 20rpx 10px;min-height:96vh;border-radius: 10px;">
				<TabsThird :tabs="tabLabels" @action="changeTab" :acitve="curTab"></TabsThird>
				
				<template v-if="curTab == 0">
					<TradeRecord></TradeRecord>
				</template>

				<template v-if="curTab == 1">
					<DepositRecord></DepositRecord>
				</template>

				<template v-if="curTab == 2">
					<WithdrawalRecord></WithdrawalRecord>
				</template>
				
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsThird from '@/components/tabs/TabsThird.vue';
	import TradeRecord from './components/TradeRecord.vue';
	import DepositRecord from './components/DepositRecord.vue';
	import WithdrawalRecord from './components/WithdrawalRecord.vue';
	export default {
		components: {
			HeaderSecond,
			TabsThird,
			TradeRecord,
			DepositRecord,
			WithdrawalRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		computed: {
			// tabs的明文
			tabLabels() {
				return [
					'取引明細',
					'入金明細',
					'出金明細'
				];
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curTab = Number(opt.code) || 0;
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			fanhui() {
				uni.switchTab({
					url: '/pages/home/index'
				})
			},
		},
	}
</script>