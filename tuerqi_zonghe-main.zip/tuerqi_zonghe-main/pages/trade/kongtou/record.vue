<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color: #010101;">
			<HeaderSecond :title="$lang.K_T" :color="$theme.SECOND"></HeaderSecond>
			<TabsFourth :tabs="setTabs" @action="changeTab" :acitve="curTab"></TabsFourth>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding-top: 20rpx;padding-bottom: 160rpx;">
				<template v-if="curTab==0">
					<block v-for="(item,index) in list" :key="index">
						<view class="common_block" style="border-radius: 24rpx;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view :style="{color:$theme.SECOND}" style="font-size: 36rpx;">{{item.goods.name}}
								</view>
								<template v-if="item.message &&item.message.length>0">
									<view :style="setStyle()"> {{item.message}} </view>
								</template>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_PRICE}}
								</view>
								<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatCoin(item.price)}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
									{{$util.formatCoin(item.apply_amount)}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
								<view style="color:#FFFFFF;">{{$lang.TRADE_IPO_RECORD_CT}}</view>
								<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
							</view>
						</view>
					</block>
				</template>
				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view class="common_block" style="border-radius: 24rpx;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view :style="{color:$theme.SECOND}" style="font-size: 36rpx;">{{item.goods.name}}
								</view>
								<template v-if="item.message &&item.message.length>0">
									<view :style="setStyle()"> {{item.message}} </view>
								</template>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_PRICE}}
								</view>
								<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatCoin(item.price)}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
									{{$util.formatCoin(item.apply_amount)}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_SUCCESS_QUANTITY}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
									{{$util.formatCoin(item.success)}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatCoin(item.success_num_amount)}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_SUCCESS_FREEZE}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatCoin(item.freeze)}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
								<view style="color:#FFFFFF;">
									{{$lang.TRADE_IPO_SUCCESS_UNPAY_AMOUNT}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
									{{item.success*item.price-item.freeze<=0?0:
								$util.formatCoin(item.success*item.price*1-item.freeze*1)}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
								<view style="color:#FFFFFF;">{{$lang.TRADE_IPO_SUCCESS_ORDER_SN}}</view>
								<view :style="{color:$theme.LOG_VALUE}">{{item.order_sn}}</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
								<view style="color:#FFFFFF;">{{$lang.TRADE_IPO_SUCCESS_CT}}</view>
								<view :style="{color:$theme.LOG_VALUE}">{{item.created_at}}</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';

	export default {
		components: {
			HeaderSecond,
			TabsFourth,

		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				list: [],
			};
		},
		computed: {
			setTabs() {
				return [
					this.$lang.TRADE_IPO_RECORD_APPLY,
					this.$lang.TRADE_IPO_RECORD_SUCCESS,
				]
			}
		},
		onLoad(op) {
			if(op.type){
				this.type=op.type
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.curTab == 0) this.getApplyList();
			if (this.curTab == 1) this.getSuccessList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			if (this.curTab == 0) this.getApplyList();
			if (this.curTab == 1) this.getSuccessList();
			uni.stopPullDownRefresh();
		},

		methods: {
			changeTab(val) {
				this.list = [];
				this.curTab = val;
				if (this.curTab == 0) this.getApplyList();
				if (this.curTab == 1) this.getSuccessList();
			},
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			async getApplyList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/GoodsBishengou/user-all-apply-log`,{
					type: this.type,
				});
				if (!result) return false;
				console.log(`result:`, result);
				this.list = result;
			},
			async getSuccessList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/GoodsBishengou/user-success-log`,{
					type: this.type,
				});
				if (!result) return false;
				console.log(`result:`, result);
				this.list = result;
			}
		}
	}
</script>

<style>
</style>