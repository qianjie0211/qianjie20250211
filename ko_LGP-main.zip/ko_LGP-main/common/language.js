// 统一语言转换
const LANGUAGE_DATA = {
	SIGN_IN: "로그인", // 登入
	SIGN_UP: "회원 가입", // 创建账户
	SIMGN_OUT: "", // 登出
	USER_NAME: '전화번호를 입력해주세요', // 请输入账户
	PASSWORD: '비밀번호를 입력', // 请输入密码
	PASSWORD_CONFIRM: '비밀번호 재입력', // 请再次输入密码
	INVITATION_CODE: '초대 코드 입력', // 输入邀请码
	// 底部导航 
	HOME: '홈', // 主页
	FAVORITES: '관심종목', // 感兴趣的
	MARKET_QUOTATION: '실시간현황', // 行情
	POSITION: '국내주식잔고/손익', // 盈亏/余额
	USER_CENTER: '더보기', // 个人中心
	// 主页 按钮组
	TRADE_SHORT:'스캘핑', // 短打交易
	TRADE_LARGE:'블록딜', // 大宗交易
	TRADE_IPO:'블록딜', // 新股申购
	TRADE_MARKET:' AI스마트거래', // 日内交易
	TRADE_DISCOUNT:'할인거래', // 折价交易
	TRADE_SALE:'신주 판매', // 新股配售
	
	SERVICE: '고객센터', // 客服
	CHANGE_PWD:'로그인 비밀번호 변경', // 更改登入密码
	CHANGE_PAY_PWD:'결제 비밀번호 변경', // 更改支付密码
	CARD_MANAGEMENT:'은행 계좌 연동', // 存款/取款账户联动 
	ABOUT:'회사 소개', // 关于我们
	SEARCH:'검색', // 检索
	DETAIL:'세부', // 详情
	
	// =============== 2024.03.04 ==============
	WITHDRAWAL:'자금인출', // 提款 Withdrawal
	AUTH: '본인인증', // 身份验证/ 实名登记
	
	
	ORDER: '스마트 주문', // 智能订单
	NEW_SHARE: '공모주', // 公开发行股 
	CREATE_BANK: '돈을 인출', // 提款
	

	ENPTY_DATA: '내역 없음', // 暂无记录
	ALL_MSG: '종목', // 实时事件
	PRODUCT_DEATIL:'주식 세부정보', // 库存详情
	FULL_INFO: '전체요약', // 完整摘要
	HOT_GOODS: '인기종목', // 热门商品
	MARKET_INDICATORS: '시장지표', // 市场指标
	MARKET_ISSUES: '시장이슈', // 市场问题
	CAPITAL_DETAIL:'입출금 세부 내역',// 资金明细/存取款记录/资金流水
	VERIFIED:'확인됨[인증되지 않음]', // 已验证[未验证]
	AUDIT:'확인됨[검토중]',  // 已确认[审核中]
	AUDIT_FAILED:'확인됨[감사 실패]', // 已确认[审核失败]

	
	
	
};
export default LANGUAGE_DATA;