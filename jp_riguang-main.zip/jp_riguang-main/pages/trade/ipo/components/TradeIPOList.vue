<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">

			<view class="item">
				<!-- 顶部区域 -->
				<view class="item-top">
					<view class="item-top-name">
						{{item.name}}
						<span>{{item.code}}</span>
					</view>
				</view>

				<view style="line-height: 2;">
					<view class="flex flex-b font-size-10">
						<view>発行価格</view>
						<!-- {{item.price}} -->
						<view style="color: #ec4d78;">{{
							setPrice(item.online_date)? item.estPrice: $util.formatMoney(item.price*1)
							}}</view>
					</view>
					<view class="flex flex-b font-size-10">
						<view>募集株数</view>
						<view>{{$util.formatNumber(item.fa_amount*1)}}</view>
					</view>
					<view class="flex flex-b font-size-10">
						<view>最低申込単位</view>
						<view>{{$util.formatNumber(item.min_num*1)}}</view>
					</view>
					<view class="flex flex-b font-size-10">
						<view>申込締切日</view>
						<view>{{item.shengou_date}} ~ {{item.end_date}}</view>
					</view>
				</view>

				<view style="padding: 10px;" @click="handleDetail(item)">
					<view class="text-center bold color-white"
						style="background-color: #013f9c;padding: 5px;border-radius: 5px;font-size: 14px;">申込する</view>
				</view>

				<!-- 中部区域 -->
				<!-- <view class="item-middle">
					{{$util.formatMoney(item.price)}}
				</view> -->

				<!-- 底部区域 -->
				<!-- <view class="item-foot">
					<view class="item-list">
						{{$lang.TRADE_IPO_POST_QTY}} <span>{{$util.formatNumber(item.fa_amount*1)}}</span>
					</view>
					<view class="item-list">
						{{$lang.TRADE_LARGE_MIN_QTY}} <span>{{$util.formatNumber(item.min_num*1)}}</span>
					</view>
					<view class="item-list">
						{{$lang.TRADE_LARGE_MAX_QTY}} <span>{{$util.formatNumber(item.max_num*1)}}</span>
					</view>
					<view class="item-list">
						{{$lang.TRADE_IPO_SUB_CT}} <span>{{item.shengou_date}}</span>
					</view>
				</view> -->
			</view>
		</block>

		<!-- 选择杠杆的弹层 -->
		<template v-if="showModal">
			<view class="common_mask" @click.stop="showModal=false"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto">
				<view class="popup_header" style="font-size: 11px;background-color: #013f9c;">
					{{itemInfo.name}}
					<image src="/static/close.png" mode="aspectFit"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);width: 15px;"
						@click.stop="showModal=false" />
				</view>



				<view style="padding-bottom: 30rpx;font-size: 14px;">
					<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
					<template v-if="leverList.length>1">
						<view style="padding-left: 25px;font-size: 14px;font-weight: 800;margin-top: 20px;"
							:style="{color:$theme.LOG_LABEL}">
							現在の抽選倍率
						</view>

						<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
							<block v-for="(item,index) in leverList" :key="index">
								<view
									style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
									:style="setStyle(curLever==item)" @click="chgangeLever(item)">
									{{item}}
								</view>
							</block>
						</view>
					</template>
				</view>

				<view style="padding: 0px 20px;">
					<input placeholder="購入申請数量" type="number" v-model="value"
						style="border: 1px #ccc solid;font-size: 15px;padding: 8px;border-radius: 5px;"
						placeholder-style="font-size: 13px;" />
				</view>
				<view style="padding: 10px 30px;" class="flex flex-b">
					<view style="padding-right: 10px;">資金残高</view>
					<view :style="{color: $theme.SECOND}">{{available +` ` + $lang.CURRENCY_UNIT}}</view>
				</view>
				<view class="bold text-center" @tap.stop="purchase()"
					style="background-color: #013f9c;padding: 10px;border-radius: 5px;color: #fff;font-size: 14px;margin: 20px;">
					申込を確定する
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				itemInfo: {}, // 单条数据详情
				showModal: false, // 显示弹层
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
				available: 0,
				value: '',
			}
		},
		beforeMount() {
			this.getList();
			this.getAccountInfo();
		},
		methods: {
			// 处理每条数据显示上市值还是预估值(当前日>上市日)
			setPrice(inputDate) {
				// 获取当前日期（日本时区）
				const currentDate = new Date(new Date().toLocaleString("en-US", {
					timeZone: "Asia/Tokyo"
				}));
				// 将传入的日期转换为时间戳
				const inputDateTime = new Date(inputDate).getTime();
				// 将当前日期转换为时间戳
				const currentDateTime = currentDate.getTime();
				// 比较并返回结果
				console.log(inputDateTime > currentDateTime);
				return inputDateTime > currentDateTime;
			},

			setStyle(val) {
				return {
					...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					color: val ? '#FFFFFF' : '#121212',
					borderRadius: `44rpx`,
					border: `1px solid ${val? this.$theme.TRANSPARENT:'#5A5A5A'}`
				}
			},
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				// this.handleShowModal();
				this.itemInfo = val;
				this.showModal = true;
			},
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: this.$lang.TRADE_IPO_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.purchase();
				}
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				// 判断输入框是否有有效数量
				if (!this.value || isNaN(this.value) || this.value <= 0) {
					uni.showToast({
						title: '数量を入力してください',
						icon: 'none'
					});
					return;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					num: this.value,
					id: this.itemInfo.id,
					ganggan: this.curLever,
					// price: this.price
					// 等后端一个字段 by 2024.11.25
				})
				if (!result) return false;
				uni.showToast({
					title: '購読完了',
					icon: 'success'
				});
				this.showModal = false;
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						estPrice: item.sg_price, // 预估值，上市日前显示
						shengou_date: item.shengou_date,
						online_date: item.online_date,
						end_date: item.end_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
						// rate: item.goods.rate,
						// rate_num: item.goods.rate_num,
					}
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.available = this.$util.formatMoney(result.money) || 0;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},
		}

	}
</script>

<style>
	.item {
		background: #fff;
		box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .36);
		margin-bottom: 7px;
		padding: 0 8px
	}

	.item .item-top {
		padding: 8px 0;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.item .item-top .item-top-name {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-weight: 600;
		font-size: 12px;
		color: #333;
		line-height: 17px
	}

	.item .item-top .item-top-name span {
		height: 24px;
		background: #ec4d78;
		border-radius: 5px;
		padding: 0 11px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 400;
		font-size: 11px;
		color: #fff;
		margin-left: 14px
	}

	.item .item-top .item-top-btn1 {
		min-width: 98px;
		height: 24px;
		background: #013f9c;
		border-radius: 5px;
		padding: 0 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 100;
		font-size: 11px;
		color: #fff
	}

	.item .item-top .item-top-btn2 {
		min-width: 98px;
		height: 24px;
		background: #adc1bb;
		border-radius: 5px;
		padding: 0 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 100;
		font-size: 11px;
		color: #fff
	}

	.item .item-middle {
		height: 29px;
		font-weight: 500;
		font-size: 13px;
		color: #e04e50;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center
	}

	.item .item-foot {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-wrap: wrap;
		flex-wrap: wrap;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.item .item-list {
		width: calc(50% - 7px);
		font-weight: 300;
		font-size: 12px;
		color: #666;
		line-height: 17px;
		padding: 6px 0;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.item .item-list span {
		font-weight: 500;
		font-size: 12px;
		color: #333
	}
</style>