<!-- 下单 -->
<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 90%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">{{productDetails.name}}</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#fff);height: 180px;" >
		</view>
		</view>
		
        <view
        	style="display: flex;flex-direction: column;width: 95%;border-radius: 10px;margin-left: 10px;margin-top: -170px;" v-if="productDetails">
			<view  style="padding: 10px 0px;background-color: #fff; border-radius: 10px;">
				<view class="flex justify-center">現在の残高</view>
				<view class="flex justify-center bold font-size-21 padding-top-10">{{$util.formatNumber(userinfo.money)}}</view>
			</view>
			
			<view style="background-color: #fff;margin-top: 10px;border-radius: 10px;">
		   <view class="flex" >
		   	<view class="flex-2 bold" style="margin-left: 10px;font-size: 20px;">{{productDetails.name}}</view>
		   	<view class="flex-1" style="padding: 50px 20px;">
		   		<view class="flex">
		   			<view  style="margin-left: 10px;font-size: 16px;">{{$util.formatNumber(productDetails.current_price)}}</view>
		   			<view style="margin-left: 10px;font-size: 16px;color: red;">{{$util.formatNumber(productDetails.rate)}}%</view>
		   		</view>
		   	</view>
		   </view>
	
			<view class="flex margin-left-5">
				<view class="bold " style="margin-left: 5px;">数量</view>
			</view>
			<view class="margin-top-10 text-center">


				<u-row justify="space-between" style="padding: 5px 10px;">
					<u-col span="4">
						<view :class="quantity==100?'actity':'noactity'" @click="quantity=100;quantity1=''">100</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==200?'actity':'noactity'" @click="quantity=200;quantity1=''">200
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==300?'actity':'noactity'" @click="quantity=300;quantity1=''">300
						</view>
					</u-col>

				</u-row>
				<u-row justify="space-between" style="padding: 5px 10px;">
					<u-col span="4">
						<view :class="quantity==500?'actity':'noactity'" @click="quantity=500;quantity1=''">500
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==800?'actity':'noactity'" @click="quantity=800;quantity1=''">800
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==1000?'actity':'noactity'" @click="quantity=1000;quantity1=''">1000
						</view>
					</u-col>

				</u-row>
			</view>



			<view style="background-color: #f7f9ff;width: 90%;margin: 10px 20px;height: 50px;border-radius: 10px;">
				<!-- <image mode="aspectFit" src="/static/money.png" :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="quantity1" style="padding: 15px;font-size: 12px;" type="number" placeholder="購入数量を入力してください" @input="sl_input"></input>
			
			<!-- 下面输入框是整百输入 -->
			<!-- 	<input v-model="quantity" style="padding: 15px; font-size: 12px;" type="number" placeholder="数量を入力してください"
					@input="sl_input" /> -->
			</view>
			
			<view class="margin-top-10 text-center">
				<u-grid :border="false" col="3">
					<u-grid-item v-for="(item,index) in userinfo.ganggan">
						<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
							{{item}}
						</view>
					</u-grid-item>
				</u-grid>
			</view>
			
			<view class="flex" style="font-size: 28rpx;padding: 2px 10px;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">お支払い額</view>
				<view class="flex-2 text-right"><text
						v-if="productDetails.project_type_id==2">$</text>{{productDetails.current_price*this.quantity/this.ganggan|addZero}}
				</view>
			</view>
			<view class="flex" style="font-size: 28rpx;padding: 2px 10px;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">手数料</view>
				<view class="flex-2 text-right"><text
						v-if="productDetails.project_type_id==2">$</text>{{productDetails.current_price*this.quantity/this.ganggan*this.fee|addZero}}
				</view>
			</view>
			<!-- <view class="bg_trade_info flex" style="padding: 2px 10px;">
				<view style="color: #7e7d7e;"> 現在の残高</view>
				<view class="" style="width: 79%;justify-content: flex-end; display: flex; "
					:style="{color:$util.THEME.PRIMARY}">
					{{$util.formatNumber(userinfo.money)}}
				</view>
			</view> -->
			<u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm" cancelText="キャンセル"
				confirmText="確信する"></u-picker>
			
			<view class="padding-10 "
				style="margin: 20px;background-color: #18bfb4;color: #fff;font-size: 16px;width: 85%;justify-content: center;display: flex;border-radius: 10px;"
				@click="placeOrder()">
				買う
			</view>
		</view>

	</view>
	</view>
	</view>
</template>

<script>
	var flag = false;
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				errorMessage: '',
				list: '',
				quantity: '100',
				productDetails: "",
				quantity1: "",
				ganggan: 1,
				userinfo: '',
				fee:0.0015
			};
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.product(option.code)
			this.sockets()
			this.getconfig()
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// this.columns = [item.ganggan]
			// const productDetails = JSON.parse(decodeURIComponent(option.productDetails));
			// this.productDetails = productDetails
			// this.columns = [productDetails.ganggan]

		},
		methods: {
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				console.log(result);

				const temp = result.data.data.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				
				this.fee = temp.get('TransRate') || this.fee;
				console.log(2222,this.fee);

			},
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);
					// console.log(data);


					if (that.productDetails) {
						if (that.productDetails.stock_id == data.pid) {

							let current_price = data.last.replace(",", '')
							// current_price=current_price.replace("+",'')

							that.productDetails.current_price = current_price;
							let rate = data.pcp.replace("+", '')
							rate = rate.replace("%", '')

							that.productDetails.rate = rate;

							that.productDetails.rate_num = data.pc;

						}
					}
				});
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			sl_input(e) {
				const inputValue = e.target.value;
				// 匹配整百的数字，例如 100, 200, 300 等  
				const regex = /^(\d{1,})(00)?$/;
				const hundredRegex = new RegExp(`^${Math.floor(inputValue / 100)}00$`);

				if (hundredRegex.test(inputValue) || inputValue === "") {
					this.quantity = inputValue; // 如果输入的是整百数字或者空字符串，则保留  
					this.errorMessage = ""; // 清除错误信息  
				} else {
					let quantity = this.quantity.slice(0, -1 * (this.quantity.length - 1)); // 移除最后一个字符（通常是非法字符）
					if (this.quantity < 100) {
						// console.log(1111)
						this.$nextTick(() => {
							this.quantity = this.quantity * 100;
						})
						return
					} else {
						// console.log(2222,this.quantity.length,this.quantity,quantity)
						this.$nextTick(() => {
							this.quantity = quantity * Math.pow(10, this.quantity.length - 1);
						})
						return
					}
					// this.errorMessage = '请输入整百数字';
				}
			},

			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.productDetails.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			// 产品详情
			async product(code) {

				let list = await this.$http.get('api/product/info', {
					code: code,
				})
				this.list = list
				this.productDetails = list.data.data[0]

			},
			//购买
			placeOrder() {
				if (flag) return;

				let money = (this.productDetails.current_price * this.quantity * 1).toString().replace(
					/\B(?=(\d{3})+(?!\d))/g, ",")
				uni.showModal({
					title: "注文確認",
					content: this.productDetails.name + ' ' + this.quantity.toString().replace(
						/\B(?=(\d{3})+(?!\d))/g, ",") + " 株 決済額 \n" + money + "円",
					cancelText: "キャンセル", // 取消按钮的文字
					confirmText: "注文", // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f55850',
					cancelColor: '#39B54A',
					success: (res) => {
						if (res.confirm) {
							console.log('comfirm') //点击确定之后执行的代码
							this.buy()
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})


			},
			buy() {
				flag = true;
				uni.showLoading({

					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				this.$http.post('api/product/purchase', {
					num: this.quantity || 0,
					gid: this.productDetails.gid,
					price: this.productDetails.current_price,
					ganggan: this.ganggan
				}).then(res => {
					flag = false;
					uni.hideLoading();
					if (res.data.code == 0) {
						uni.$u.toast(res.data.data.message);
						setTimeout(() => {
							uni.switchTab({
								url: this.$util.PAGE_URL.ACCOUNT_TRADE,
							});
						}, 1000)
					} else {
						uni.$u.toast(res.data.message);
					}
					setTimeout(() => {
						flag = false;
					}, 2000)
				}).catch(er => {
					setTimeout(() => {
						flag = false;
					}, 2000)
				})
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})


				this.userinfo = list.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 85%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 50rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #0332783b;
		border-radius: 10px;
		color: #3c1f20;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #000;
		border: 1px solid #bdbdbd;
		border-radius: 10px;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>