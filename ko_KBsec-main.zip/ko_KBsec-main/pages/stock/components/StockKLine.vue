<template>
	<view style="display: flex;align-items: center;justify-content: center;padding:36rpx;">
		<view class="charts" id="kline-stock">
		</view>
	</view>
</template>

<script>
	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea,
		klineCandle
	} from '@/common/klineConfig.js';
	export default {
		name: 'StockKLine',
		props: {
			list: {
				type: Array,
				default: {}
			},
			active: {
				type: Number,
				default: 0,
			}
		},
		data() {
			return {
				klineChart: null, // Kline实例化
				indicator: null, // 创建技术指标，移除时需使用
			}
		},
		computed: {
			chartData() {
				return this.list;
			}
		},
		mounted() {
			this.renderInit();
		},
		unmounted() {
			dispose("kline-stock");
		},
		destroyed() {
			dispose('kline-stock');
		},

		methods: {
			renderInit() {
				setTimeout(() => {
					this.genKline();
				}, 1000)
			},

			clearData() {
				if (this.klineChart) this.klineChart.clearData();
			},

			genKline() {
				this.clearData();
				if (!this.klineChart) {
					this.klineChart = init('kline-stock');
				}
				// 显示技术指标
				if (!this.indicator) {
					this.indicator = this.klineChart.createIndicator('MA', false);
				}

				this.klineChart.setStyles({
					grid: klineGird,
					// 第一个用面积图 后面用蜡烛图
					candle: this.active == 0 ? klineArea : klineCandle,
				});
				// 只有 curKLine==0 显示技术指标
				if (this.active !== 0) {
					if (this.indicator) {
						this.klineChart.removeIndicator(this.indicator);
						this.indicator = null;
					}
				}
				this.klineChart.applyNewData(this.chartData, 0)
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 680upx;
		height: 500upx;
	}
</style>