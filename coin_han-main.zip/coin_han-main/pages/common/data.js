import i18n from '@/common/locales/config.js'
const {mine} = i18n.messages[i18n.locale];



const langs = [
	{
		name:'English',
		value:'en'
	},
	{
		name:'ไทย',
		value:'th'
	},
	{
		name:'Japanese',
		value:'jp'
	},
	{
		name:'한국어',
		value:'kor'
	},
	{
		name:'Français',
		value:'fra'
	},
	{
		name:'Español',
		value:'spa'
	},
	{
		name:'Tiếng Việt',
		value:'yn'
	},
	{
		name:'Simplified Chinese',
		value:'zh'
	},
	{
		name:'Traditional Chinese',
		value:'hk'
	},
]

export {

	langs
}