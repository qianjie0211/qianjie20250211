<template>
	<view style="padding-bottom: 160rpx;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:36rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 16rpx;">
				<view style="display: flex;align-items: center;">
					<view style="flex:6%">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex:94%;">
						<view style="padding-left: 10px;font-size: 36rpx;color:#121212;">
							{{item.name}}
						</view>
						<view style="display: flex;align-items: center;">
							<text style="font-size: 28rpx;padding-left: 10px;flex:70%"
								:style="{color:$theme.LOG_LABEL}">{{item.code}}</text>
							<view :style="setStyle()" @click="handleDetail(item)">
								{{$lang.BTN_BUY}}
							</view>
						</view>
					</view>
				</view>

				<view
					style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_BLOCK_PRICE}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_IPO_POST_QTY}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.fa_amount*1)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
					<view style="flex: 1 0 45%;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_BLOCK_MIN_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.min_num*1+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_BLOCK_MAX_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.max_num*1+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
				</view>

				<template v-if="item.shengou_date">
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_SUB_CT}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{item.shengou_date}}</view>
					</view>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	import TradeIssuanceBuy from './TradeIssuanceBuy.vue';
	export default {
		name: 'TradeIssuanceList',
		components: {
			EmptyData,
			CustomLogo,
			TradeIssuanceBuy,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			handleDetail(val) {
				this.$emit('action', val);
			},
		}
	}
</script>