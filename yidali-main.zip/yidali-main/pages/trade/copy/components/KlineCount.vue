<template>
	<view>
		<view style="display: flex;align-items: center;padding:36rpx">
			<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
			<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_INVESTORS_NUM}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 120rpx;">
			<view class="charts" id="kline-count"> </view>
		</view>
	</view>
</template>

<script>
	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea
	} from '@/common/klineConfig.js';
	export default {
		name: 'KlineCount',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				klineCount: null,
			}
		},
		computed: {
			chartDataCount() {
				if (this.list && this.list.length > 0) {
					const tempSort = this.list.sort((a, b) =>
						new Date(a.updated_at).getTime() - new Date(b.updated_at).getTime());
					// console.log(`temp`, tempSort);
					return tempSort.map(item => {
						return {
							timestamp: new Date(item.updated_at).getTime(),
							close: item.gentoushu * 1
						}
					});
				}
			},
		},
		created() {},
		mounted() {
			setTimeout(() => {
				this.genKlineCount();
			}, 1000)
		},
		unmounted() {
			dispose("kline-count");
		},
		methods: {
			clearData() {
				if (this.klineCount) this.klineCount.clearData();
			},

			genKlineCount() {
				if (!this.klineCount)
					this.klineCount = init('kline-count');
				this.klineCount.setStyles({
					grid: klineGird,
					candle: klineArea,
				});
				// console.log(`count:`, this.chartDataCount)
				this.klineCount.applyNewData(this.chartDataCount, 0)
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 680upx;
		height: 500upx;
	}
</style>