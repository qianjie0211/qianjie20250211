<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`300rpx`,`bg_1`)">
		<HeaderSecond :title="!stockInfo?'': stockInfo.name" color="#FFFFFF"></HeaderSecond>

		<view style="background-color: #FFFFFF;min-height: 96vh;width: 95%;margin-left: 10px; border-radius: 10px;">

			<!-- <view style="display: flex;align-items: center;justify-content: center;margin: 20rpx 0;">
				<view class="common_card_bg card_bg_4" style="width: 640rpx;background-color: #FFFFFF;">
					<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
				</view>
			</view> -->

			<template v-if="stockInfo">
				<view style="padding: 20px;">
					<view :style="{color:$theme.TITLE}">
						<view class="bold" :style="{color:$theme.LOG_VALUE}" style="font-size: 16px;">{{stockInfo.name}}
						</view>
					</view>
					<view class="flex" style="padding: 10px;">

						<view class="flex-1" :style="{color:$theme.LOG_LABEL}" style="font-size: 16px;">
							{{stockInfo.code}}
						</view>

						<view class="flex-1" :style="$theme.setStockRiseFall(stockInfo.rate>0)"
							style="font-size: 18px;">
							{{$util.formatMoney(stockInfo.current_price)}} {{` ${$lang.CURRENCY_UNIT}`}}
						</view>

						<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
							<image :src="`/static/arrow_${stockInfo.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(24)" style=""></image>
							{{$util.formatMathABS(stockInfo.rate)}}%
						</view>
					</view>
				</view>

				<CustomTitle :title="$lang.STOCK_BUY_QUANTITY"></CustomTitle>

				<view style="display: flex;flex-wrap:wrap;padding:10px;">
					<block v-for="(item,index) in quantityList" :key="index">
						<view
							style="border-radius: 8rpx;width:20%;margin:20rpx;padding:10rpx 20rpx;line-height: 1.6;text-align: center;"
							:style="setStyle(curQuantity==item)" @click="chooseQTY(item)">
							{{$util.formatNumber(item)}}
						</view>
					</block>
				</view>

				<view class="common_input_wrapper" style="padding-left: 40rpx;margin: 10rpx 40rpx;border-radius: 30px;">
					<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY"
						@input="handleInput" :placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<!-- 杠杆数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<CustomTitle :title="$lang.LEVER"></CustomTitle>
					<view style="display: flex;flex-wrap:wrap;padding:10px;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:18%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="setStyle(curLever==item)" @click="chooseLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(quantity)}}
					</view>
					<template v-if="leverList.length>1">
						<view>{{$lang.LEVER}}</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{curLever}}
						</view>
					</template>
				</view>

				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_AMOUNT}}</view>
					<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
						{{$util.formatMoney(stockInfo.current_price*curQuantity/curLever)}}
					</view>
				</view>
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_FEE}}</view>
					<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
						{{$util.formatMoney(stockInfo.current_price*curQuantity/curLever*fee)}}
					</view>
				</view>

				<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
					<view class="text-center"
						style="margin:0 auto;width: 80%;background-color: #f96643;padding: 10px;border-radius: 30px;color: #fff; font-size: 20px;"
						@click="placeOrder()">
						{{$lang.BTN_BUY}}
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			CardItemPrimary,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [100, 300, 500, 1000, 2500, 5000], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				quantity: 100, // 数量输入框 
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前选中杠杆值
				show: false,
				stockInfo: null,
				userInfo: {},
				fee: 1, // 手续费
				cardData: {}, // 资产信息
				code: '', // url上的code
				socket: null,
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
		},
		onLoad(option) {
			this.code = option.code || '';
			this.getConfig();
			this.getStockDetail();
			this.getAccountInfo();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			// sockets() {
			// 	//创建webSocket
			// 	this.webSocketTask = uni.connectSocket({
			// 		url: this.$http.WssUrl,
			// 		header: {
			// 			'content-type': 'application/json'
			// 		},
			// 		success(res) {
			// 			console.log('成功', res);
			// 		},
			// 	})

			// 	// 监听WebSocket连接打开事件
			// 	this.webSocketTask.onOpen((res) => {
			// 		console.info("监听WebSocket连接打开事件", res)
			// 	});

			// 	// 监听WebSocket错误
			// 	uni.onSocketError((res) => {
			// 		console.info("监听WebSocket错误" + res)
			// 	});
			// 	var that = this;
			// 	// 接收websocket消息及处理
			// 	this.webSocketTask.onMessage((res) => {
			// 		var data = JSON.parse(res.data);
			// 		// console.log(data);


			// 		if (that.productDetails) {
			// 			if (that.productDetails.stock_id == data.pid) {

			// 				let current_price = data.last.replace(",", '')
			// 				// current_price=current_price.replace("+",'')

			// 				that.productDetails.current_price = current_price;
			// 				let rate = data.pcp.replace("+", '')
			// 				rate = rate.replace("%", '')

			// 				that.productDetails.rate = rate;

			// 				that.productDetails.rate_num = data.pc;

			// 			}
			// 		}
			// 	});
			// },

			// websocket链接
			connect() {
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WssUrl);
				this.socket = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					// 监听WebSocket连接打开事件
					this.socket.onOpen((res) => {
						console.info("监听WebSocket连接打开事件", res)
					});
					// 监听WebSocket错误
					uni.onSocketError((res) => {
						console.info("监听WebSocket错误" + res)
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.stockInfo && this.stockInfo.stock_id == data.pid) {
							console.log(this.stockInfo.stock_id, `ws data:`, data);
							this.stockInfo.current_price = parseFloat(data.last.replace(",", ''));
							this.stockInfo.rate = parseFloat(data.pcp.replace("%", ''));
							this.stockInfo.rate_num = data.pc;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
			},
			setStyle(val) {
				return {
					...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					color: val ? '#FFFFFF' : this.$theme.PRIMARY,
					borderRadius: `44rpx`,
					border: `1px solid ${val? this.$theme.TRANSPARENT:'#f96643'}`,
				}
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				console.log(`config result:`, result);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.fee = temp.get('TransRate') || this.fee;
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async getStockDetail() {
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
				})
				console.log(`stock info:`, result);
				if (!result) return false;
				this.stockInfo = result[0];
				this.connect();
			},
			//购买
			async placeOrder() {
				const money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} 、${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f96643',
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.STOCK_BUY_TIP_QUANTITY,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					ganggan: this.curLever,
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.POSITION,
					});
				}, 1000)
			},
			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money, // 可提
					value2: this.userInfo.freeze, // 冻结
					value3: this.userInfo.totalZichan, // 总资产
				};
				if (this.userInfo.ganggan) {
					this.leverList = this.$util.leverList(this.userInfo.ganggan);
				}
			},
		},
	}
</script>