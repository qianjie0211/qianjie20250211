<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 30rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.SECOND}" style="font-size: 36rpx;">{{item.goods.name}}</view>
						<template v-if="item.message &&item.message.length>0">
							<view :style="setStyle()"> {{item.message}} </view>
						</template>
					</view>

					<view
						style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFXCVXGDSD}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view > İhraç miktarı </view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>
					
					<view
						style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFXKJKXRG}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								{{item.order_sn}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.TRADE_IPO_RECORD_CREATETIME}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
					</view>

					<!-- <view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
					</view> -->
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPORecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: '#ff8501',
					color: '#fff',
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `10rpx 20rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-all-apply-log`);
				console.log(result);
				this.list = result || [];
			},
		},
	}
</script>