<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.TRADE_BLOCK_TITLE}}</text>
			</view>
		</header>

		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in $lang.TRADE_BLOCK_TABS" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#1C1C1C`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<TradeBlockList :list="list" @action="showBuy"></TradeBlockList>
		</template>
		<template v-else>
			<TradeBlockRecord :list="record"></TradeBlockRecord>
		</template>

		<template v-if="isShow">
			<TradeBlockBuy :info="itemInfo" @action="handleClose"></TradeBlockBuy>
		</template>
	</view>
</template>

<script>
	import TradeBlockList from './components/TradeBlockList.vue';
	import TradeBlockRecord from './components/TradeBlockRecord.vue';
	import TradeBlockBuy from './components/TradeBlockBuy.vue';
	export default {
		components: {
			TradeBlockList,
			TradeBlockRecord,
			TradeBlockBuy,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				list: [],
				record: [],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.isShow = false;
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getList();
				if (this.curTab == 1) this.getRecordList();
			},
			// 显示购买弹层
			showBuy(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				this.changeTab(val);
			},

			// 记录
			async getRecordList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				if (!result) return false;
				this.record = result;
				console.log(this.record);
			},

			// 产品列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				if (!result) return false;
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				});
			},

			// 设置样式
			setStyle(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>