<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding-top: 28rpx;">
					<view class="bold" style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view  style="font-size: 32rpx;color: #fff;">{{item.goods.name}}</view>
					</view>
					
					<view class="flex" style="padding: 10px;">
						<view class="flex-1">
							<view style="color: #ccc;">{{$lang.MAIRU_JIAGE}}</view>
							<view style="margin-top: 5px;color: #fff;">{{$util.formatMoney(item.price)}}</view>
						</view>
						<view class="flex-1" >
							<view style="color: #ccc;">{{$lang.ZHIFU_JINE}}</view>
							<view style="margin-top: 5px;text-align: center;color: #fff;">{{$util.formatMoney(item.amount)}}</view>
						</view>
						<view style="text-align: center;">
							<view style="color: #ccc;">{{$lang.SHULIANG}}</view>
							<view style="margin-top: 5px;color: #fff;">{{item.num}}</view>
						</view>
					</view>

					<!-- <view style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_LARGE_LOG_PRICE}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view> -->
					<view style="border-radius: 12rpx;padding:20rpx;margin-bottom: 28rpx;border: 1px #00a997 solid;">
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_LOG_NUM}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.num}}
							</view>
						</view> -->
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.GANGGAN}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.double}}
							</view>
						</view> -->
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;margin-top: 10px;">
							<view style="color: #ccc;">
								{{$lang.ZHIFU_JINE}}
							</view>
							<view style="font-size: 28rpx;color: #fff;">
								{{$util.formatMoney(item.amount)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;"
							>
							<view style="color: #ccc;">{{$lang.MAIRU_SHIJIAN}}</view>
							<text style="color: #fff;">{{item.created_at}}</text>
						</view>
					</view>
				</view>
				<view style="border-top: 1px #CFCFCF solid;">.</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeRecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
		},
	}
</script>