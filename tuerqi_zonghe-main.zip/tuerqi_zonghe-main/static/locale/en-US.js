export default {
	TRADE_WEALTH_RECORD_TOTAL:'Total Amount',
	"BLOCK_QTY": "Quantity",
	"FORGET_PWD": "Forgot my password?",
	"FORGET_PWD_SERVICE": "Contact customer service",
	//英语
	BLOCK_BUY_STOCK: 'buy stocks',
	TRADE_IPO_SUCCESS_STATUS: 'Purchase Status',
	TRADE_IPO_SUCCESS_STATUS_A: 'In the process of subscription',
	S_K_R: 'Payee name',
	S_R_S_K_R: 'Enter payee name',
	Y_H_Z_H: 'Bank account number',
	S_R_Y_H_Z_H: 'Enter bank account number',
	I_B_A_N: 'IBAN',
	S_R_I_B_A_N: 'Enter IBAN',
	S_W_I_F_T: 'SWIFT/BIC',
	S_R_S_W_I_F_T: 'Enter SWIFT/BIC',
	Y_H_M_C: 'Bank name',
	S_R_Y_H_M_C: 'Enter bank name',
	F_H_D_M: 'Branch code',
	S_R_F_H_D_M: 'Enter branch code',
	ZHE_JIA_BAIFENB: 'Discount Percentage',

	B_B: 'Coin',
	TXT_TIME: `Time`,
	TABS_TIMES: [`1M`, `5M`, `15M`, `30M`, `1H`, `4H`, `1D`, `1W`, `1Y`],
	INDICATOR_TITLE: `Indicator`,
	CANDLE_TITLE: `Candle`,
	//交易
	M_C: 'Name',
	Z_X_J: 'Latest Price',
	Z_F: 'Increase',

	G_P: 'Stock',
	J_Y_S: 'Exchange',
	//购买
	ACCOUNT_AMOUNT_AVAILABLE: 'Available Funds',
	ACCOUNT_COLD_AMOUNT: 'Freeze funds',
	ACCOUNT_AMOUNT_TOTAL: 'Total assets',
	STOCK_BUY_QUANTITY: 'Quantity',
	STOCK_BUY_TIP_QUANTITY: 'Please enter quantity',
	STOCK_BUY_AMOUNT: 'Payment amount',
	STOCK_BUY_FEE: 'Fees',
	STOCK_BUY_CONFIRM: 'Confirm purchase',
	GANG_GAN: 'Lever',
	//首页
	GU_PIAO: 'Stock',
	X_G_S_G: 'IPO',
	E_T_F: 'ETF',
	J_M_H_B: 'COIN',
	X_B_S_G: 'ICO',
	R_M_G_P: 'Hot Stocks',
	K_T: 'Airdrop',
	H_Y_J_Y: 'Main Contract',
	TRADE_DBS: ['Main Contract', 'Status', 'history'],
	//  ===============  2024.10.13=============
	DAI_KUAN: 'Loan',
	JINGPING_SHENHE: 'After review by the platform, you can apply for a loan from the platform!',
	LOANS_ZXDJE: 'Total credit amount',
	LOANS_JDJE: 'Loan Amount',
	LOANS_QSRJDJE: 'Please enter the loan amount',
	LOANS_YJDJE: 'Amount borrowed',
	LOANS_QR: 'Confirm',
	LOANSJILU_DKJL: 'Loan Record',
	LOANSJILU_ZT: 'State',
	LOANSJILU_SQJE: 'Application amount',
	LOANSJILU_TYJE: 'Agreed amount',
	LOANSJILU_HKJE: 'Repayment amount',
	LOANSJILU_SQSJ: 'Application Period',
	LOANSJILU_SQZ: 'Applying',
	LOANSJILU_YTG: 'Passed',
	LOANSJILU_YHK: 'Repaid',
	LOANSJILU_WTG: 'Failed',


	CONTRACT_VIEW: `Click To View`,
	CONTRACT_ORDER_DATE: `Date`,
	// contract history
	CONTRACT_HISTORY_LOT: `Buy lots`,
	CONTRACT_HISTORY_MARGIN: `Margin`,
	CONTRACT_HISTORY_PRICE_BUY: `Buy price`,
	CONTRACT_HISTORY_PRICE_SELL: `Sell price`,
	CONTRACT_HISTORY_FEE: `Transaction fee`,
	CONTRACT_HISTORY_PROFIT: `Profit`,
	CONTRACT_HISTORY_DATE: `Date`,

	// =============== add 2024.09.19 ========
	IPO_START_CT: `Subscription Start Time`,
	IPO_END_CT: `Subscription End Time`,
	IPO_DATE: `ICO Date`,
	IPO_SUB_NOW: `Subscribe Now`,
	IPO_MODAL: `Access for more information? `,
	DAY_TITLE: `Joint lifting project`,
	DAY_PROFIT: `Profit`,
	BLOCK_TITLE: `OTC BLOCK trading`,
	TRADE_BLOCK_LOG_TRADE_AMOUNT: `Traded Amount`,
	DEPOSIT_TIPS: `All deposits from any cryptocurrency wallet should use the wallet address provided by Starx，Please copy the wallet address provided, perform a manual transfer using your personal cryptocurrency wallet, and then click 'Next' to upload the transaction record.`,
	FUNDS_TITLE: `Fund Projects`,
	FUNDS_PERIOD: `Retention period`,
	FUNDS_RATE: `Profit rate`,
	FUNDS_MODAL_ESTIMATE: `Estimate profit rate`,
	FUNDS_HISTORY_TOTAL: `Total Traded Amount`,
	COPY_HISTORY: `Copy trading history`,
	COPY_STATUS: `Subscription Status`,
	COPY_PAY_PRICE: `Pay Price`,
	COPY_PRICE: `Price`,
	COPY_PROFIT: `Profit`,
	COPY_RUN_DAYS: `Runtime`,

	PEIFU: 'Compensation',

	PEIFU_NAME: 'Option Number',

	PEIFU_STATUS: 'Win or Lose',
	PEIFU_RETURN: 'Refund of Insurance Premium',

	LAUNCH_TIPS: [
		`Connecting...`,
		`Determining application version...`,
		`Network environment safety inspection in progress...`,
		`Connecting to international investing institutes...`,
		`connecting to institutional account permissions...`,
	],

	BAOXIAN_PRICE: 'Insured Amount',
	BAOXIAN_1: 'In Coverage',
	BAOXIAN_2: 'Covered',
	BAOXIAN_STATUS: 'Insurance Status',



	// =============== add 2024.09.16 ========
	FUTURES_TITLE: `Futures`,

	// ===============  ========
	// forex
	FOREX_TITLE: `Stock`,

	SEARCH_TAB_COIN: `Coin`,
	SEARCH_TAB_FOREX: `Forex`,
	SEARCH_TAB_STOCK: `Stock`,
	SEARCH_TAB_ALL: `All`,

	BTN_DEL: `Delete`,
	FILTER: `Filter`,
	CURRENCY_UNIT: ``, // USDT
	BTN_DETAIL: `Detail`,
	BTN_SELL: `Sell`,
	TRADE_IPO_RECORD_CT: `Date`,
	BAOXIAN: 'Insurance',
	// 交易页面
	TRADE_TITLE: 'Investment Results',
	TRADE_HOLD_LOG: 'Holding',
	TRADE_SELL_LOG: 'History',
	TRADE_TOTAL_BUY_AMOUNT: 'Total Purchase',
	TRADE_VALUATION_GAIN_LOSS: 'Valuation Profit and Loss',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: 'Total Profit',
	TRADE_RATE_RESPONSE: 'Return Rate',
	TRADE_TOTAL_GAIN: 'Total Profit',

	// Holding Data Plain Text
	TRADE_HOLD_LABEL_PROFIT_RATE: 'Return Rate',
	TRADE_HOLD_LABEL_PROFIT_AMOUNT: 'Realized Profit and Loss',
	TRADE_HOLD_LABEL_BUY_AMOUNT: 'Purchase Quantity',
	TRADE_HOLD_LABEL_TOTAL_PRICE: 'Total Purchase Price',
	TRADE_HOLD_LABEL_BUY_PRICE: 'Purchase Price',
	TRADE_HOLD_LABEL_CUR_PRICE: 'Current Price',

	// Selling Data Plain Text
	TRADE_SELL_LABEL_PROFIT_RATE: 'Return Rate',
	TRADE_SELL_LABEL_PROFIT_AMOUNT: 'Realized Profit and Loss',
	TRADE_SELL_LABEL_BUY_AMOUNT: 'Purchase Quantity',
	TRADE_SELL_LABEL_TOTAL_PRICE: 'Total Purchase Price',
	TRADE_SELL_LABEL_BUY_PRICE: 'Purchase Price',
	TRADE_SELL_LABEL_SELL_PRICE: 'Selling Price',

	// Holding and Selling Modal Data Plain Text
	TRADE_MODAL_BUY_TIME: 'Purchase Time',
	TRADE_MODAL_SELL_TIME: 'Selling Time',
	TRADE_MODAL_FLOAT_PROFIT: 'Current Profit and Loss',
	TRADE_MODAL_PROFIT: 'Total Profit and Loss',
	TRADE_MODAL_BUY_PRICE: 'Purchase Price',
	TRADE_MODAL_BUY_QTY: 'Quantity',
	TRADE_MODAL_LEVER: 'Leverage',
	TRADE_MODAL_FEE: 'Commission',
	TRADE_MODAL_YINGKUI: 'Profit and Loss Amount',
	TRADE_MODAL_BUY_AMOUNT: 'Total Purchase Amount',
	TRADE_MODAL_STOCK_CODE: 'Stock Code',

	// Second Confirmation for Selling
	SELL_TIP: 'Are you sure you want to confirm the sale?',

	// 日内交易
	TRADE_DAY_TITLE: `Day Trading`,
	TRADE_DAY_TABS: ['Joint Lifting', 'Status', 'history'],
	TRADE_DAY_BUY: 'Apply',
	TRADE_DAY_TIP: 'Product Guide',
	TRADE_DAY_TIP_TEXT: [
		'Apply to participate in the main institutional synchronous position building trading strategy. After the application is passed, the funds will be collected into the main account of the institution for synchronous position building and purchase, and the profits will be settled according to the market after the market closes.',
		'In order to ensure the privacy and security of the main position building, customers will see the corresponding position information on the position interface after the main force completes the position building and reaches the expected profit target position, and can manually sell the current trading items.',
	],
	TRADE_DAY_BUY_AMOUNT: 'Application Amount',
	TRADE_DAY_SUCCESS: 'Approved Amount',
	TRADE_DAY_TIP_INPUT_AMOUNT: 'Enter Amount',
	TRADE_DAY_ORDER_SN: 'Order Number',
	TRADE_DAY_CREATE_TIME: 'Date Time',
	TRADE_DAY_ORDER_STATUS: 'pending application',
	TRADE_DAY_MODAL_CONTENT: 'Click to confirm.',
	TRADE_DAY_BALANCE: `Balance`, // 余额
	TRADE_DAY_UNSOLD: `Unsold`, // 未出售
	TRADE_DAY_SOLD: `Sold`, // 已出售
	TRADE_DAY_UNREVIEW: `Unreviewed`, // 0未审核
	TRADE_DAY_TONGGUOSHULIANG: `Approved token`,
	TRADE_DAY_PASSED: `Passed`, // 1已通过
	TRADE_DAY_REJECTED: `Rejected`, //  2已拒绝
	TRADE_DAY_APPROVAL_STATUS: [`Unreviewed`, `Passed`, `Rejected`],


	// 大宗交易
	TRADE_BLOCK_TITLE: `Block`,
	TRADE_BLOCK_PRICE: 'Discounted price',
	TRADE_BLOCK_RATE: 'Increase Rate',
	TEADE_LARGE_RATE_AMOUNT: 'Increase Amount',
	TRADE_BLOCK_MIN_QTY: 'Minimum Purchase',
	TRADE_BLOCK_MAX_QTY: 'Maximum Purchase',
	TRADE_BLOCK_MIN_DAY: 'Minimum Holding Days',
	TRADE_BLOCK_ITEM_LABELS: ['Price', 'Increase Rate'],
	TRADE_BLOCK_ORDER_TITLE: 'Subscription Application Order',
	TRADE_BLOCK_BUY_AMOUNT: 'Purchase Price',
	TRADE_BLOCK_TIP_BUY_COUNT: 'Enter Purchase Quantity',
	TRADE_BLOCK_ORDER_AMOUNT: 'Purchase Amount',
	TRADE_BLOCK_TIP_BUY_PWD: 'Please enter a 6-digit trading password',
	TRADE_BLOCK_LOG_FINISH: 'Purchase Completed',
	TRADE_BLOCK_LOG_PRICE: 'Purchase Price',
	TRADE_BLOCK_LOG_NUM: 'Subscription amount',
	TRADE_BLOCK_LOG_AMOUNT: 'Purchase Amount',
	TRADE_BLOCK_LOG_LEVER: 'Leverage',
	TRADE_BLOCK_LOG_CREATE_TIME: 'Purchase Time',
	TRADE_BLOCK_BUY_TOTAL_AMOUNT: 'Total Purchase Amount',


	// trade copy  跟单交易
	TRADE_COPY_TITLE: 'Quantitative Trading',
	TRADE_COPY_SEARCH_TIP: 'Enter keyword',
	TRADE_COPY_FOLLOWERS: 'Followers',
	TRADE_COPY_RATE: 'Profit Rate',
	TRADE_COPY_WIN: '30 Day Win',
	TRADE_COPY_TOTAL: 'Minimum Trading Amount',
	TRADE_COPY_TOTAL_AMOUNT: 'Invested Capital',
	TRADE_COPY_BTN_COPY: 'More info',
	TRADE_COPY_BTN_COPY_A: 'immediate implementation',

	COPY_DETAIL_TITLE: 'Detail',
	COPY_DETAIL_30DAY_PROFIT: '30 Day Profit',

	COPY_DETAIL_CHARTS: 'Charts', // 图表
	COPY_DETAIL_DATA: 'Data', // 数据
	COPY_DETAIL_SCORE: 'Score', // 评分
	COPY_DETAIL_INVESTORS: 'Investors', // 跟投
	COPY_DETAIL_ORDERS: 'Orders', // 订单
	COPY_DETAIL_TOTAL_RETURNS: 'Total Returns',
	COPY_DETAIL_TOTAL_RETURNS_TIP: 'Include Position Gains',
	COPY_DETAIL_TR_TABS: ['7-day', '30-day', '90-day', '180-day', 'All'],

	COPY_DETAIL_CLOSE_PROFIT: 'Close Profit', // 平仓盈亏
	COPY_DETAIL_TRADE_COUNT: 'Trade Count', // 交易笔数
	COPY_DETAIL_AVERAGE_PROFIT: 'Average Profit', // 平均盈利
	COPY_DETAIL_AVERAGE_DT: 'Average Date', // 平均持仓时间
	COPY_DETAIL_WIN_RATE: 'Win Rate', // 胜率

	// 月度表现
	COPY_DETAIL_MONTH_PL: 'Month Profit And Loss',

	// 周 盈亏
	COPY_DETAIL_WEEK_PL: 'Week Profit And Loss',

	// 交易量
	COPY_DETAIL_TRADE_VOLUME: 'Trading Volume',
	COPY_DETAIL_TV_TABS: ['24H', '7-day', '3-week', '1-month', '6-month'],

	// Data 分栏
	COPY_DETAIL_DATA_SPECIES: 'Species Preferences',
	COPY_DETAIL_DATA_THEAD_SPECIES: 'Species',
	COPY_DETAIL_DATA_THEAD_PROFIT: 'Profit(USD)',
	COPY_DETAIL_DATA_THEAD_VOL: 'Volume(Lots)',

	COPY_DETAIL_DATA_TRADE_DATA: 'Transaction data',
	// 最大回撤
	COPY_DETAIL_DATA_MAX: 'Max retracement(USD)',
	// 持有盈亏
	COPY_DETAIL_DATA_HOLD_PROFIT: 'Holding Profit(USD)',
	// 交易笔数
	COPY_DETAIL_DATA_TRADE_COUNT: 'Trade Count',
	// 胜率
	COPY_DETAIL_DATA_WIN_RATE: 'Win Rate(%)',
	// 平均盈利(USD)
	COPY_DETAIL_DATA_AVERAGE_PROFIT: 'Average Profit(USD)',
	// 平均亏损(USD)
	COPY_DETAIL_DATA_AVERAGE_LOSS: 'Average Loss(USD)',
	// 交易周数
	COPY_DETAIL_DATA_TRADE_WEEK: 'Trade Week',
	// 最大衰落期(天)
	COPY_DETAIL_DATA_MAX_DECAY_PERIOD: 'Max Decay Period(D)',
	// 净值/余额(USD)
	COPY_DETAIL_DATA_NET_BALANCE: 'Net/Balance(USD)',
	// 存款(USD)
	COPY_DETAIL_DATA_DEPOSIT: 'Deposit(USD)',
	// 取款(USD)
	COPY_DETAIL_DATA_WITHDRAWAL: 'Withdrawal(USD)',
	// 账户时区
	COPY_DETAIL_DATA_TIME_ZONE: 'Time Zone',
	// 最近交易
	COPY_DETAIL_DATA_RECENT_TRADE: 'Recent Trades',

	// 评分
	COPY_DETAIL_SCORE_INFO: 'Score Detail',
	COPY_DETAIL_SCORE_CHART: 'Score Chart',
	COPY_DETAIL_SCORE_CURRENT: 'Current Score',
	COPY_DETAIL_SCORE_TIP: 'Total score of 10, with 6 items assessed',
	// 评分六项： 盈利能力 风控能力 稳健性 非侥幸获利 资金规模 出入场优势
	COPY_DETAIL_SCORE_SIX: ['profitability', 'Risk Control Capability',
		'robustness', 'Not Fluke', 'Funds Size', 'Entry/Exit'
	],

	// 跟投 分栏
	COPY_DETAIL_INVESTORS_NUM: 'Number of Follow-up', // 跟投数量
	// 跟投资金总金额(USDT)
	COPY_DETAIL_INVESTORS_AMOUNT: 'Total follow-on investment (GBX)',

	// 订单 分栏
	COPY_DETAIL_ORDERS_BUY: 'Buy',
	COPY_DETAIL_ORDERS_SELL: 'Sell',
	COPY_DETAIL_ORDERS_PROFIT: 'Profit',
	COPY_DETAIL_ORDERS_LOST: 'Lost',
	COPY_DETAIL_ORDERS_PIPS: 'Pips',

	// 跟单 弹层
	COPY_MODAL_NET_VALUE: 'Net Value (USD)',
	COPY_MODAL_FOLLOW_FEE: 'Follow-up Fee (USD)',
	COPY_MODAL_DAY: 'Day',
	COPY_MODAL_CHOOSE_ACCOUNT: 'Choose Account',
	COPY_MODAL_CHOOSE_MODE: 'Choose Mode',
	COPY_MODAL_MODE_TIP: 'By Fixation Method',
	COPU_MODA_MODE_TIP1: 'Open positions according to a set fixed criteria',
	COPY_MODAL_QTY: 'Enter Quantity',
	COPY_MODAL_BALANCE: 'Balance',
	COPY_MODAL_AMOUNT: 'Amount',


	LAUNCH_TITLE: 'STARX',
	LAUNCH_PROGRESS_TITLE: 'Loading...',
	TRANSLATE_TITLE: 'Please select language',
	WELCOME: `Welcome`,
	HELLO: '',

	// Check Network
	TIP_NETWORK_TYPE_NONE: 'There is no network or the network status is poor.',

	BTN_BUY: 'Buy',
	MOBILE: 'Phone Number',
	Baipi: 'White Paper',
	news: 'News',

	no_buy: "During trading, both long (buy) and short (sell) positions for the same asset cannot be held simultaneously. Investors are limited to holding either a long or short position to ensure trading consistency and effective risk management.",

	// API TIP
	API_TOKEN_EXPIRES: 'Login status has expired, please log in again',
	API_HTTP_ERROR: 'Request abnormality, please check your network',
	REQUEST_DATA: 'Request Data',
	API_EMPTY_DATA: 'Empty Data',
	API_EMPTY_CONTENT: 'Empty Content',
	BTN_DETAIL_NOW: 'View now',
	DIALOG_IPO_SUCCESS_TIP_TEXT: 'You have won the public offering subscription',
	DIALOG_IPO_SUCCESS_LABEL_QTY: 'Quantity',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: 'Total amount',
	API_SEND_CODE: 'Sending verification code',
	YUQI_SOUYING:'Expected earnings',
	API_SEND_CODE_SUCCESS: 'Verification code sent successfully',
	API_SIGN_IN_NOW: 'Logging in',
	API_SIGN_UP_NOW: 'Registering',
	API_DATA_SUBMIT: 'Submitting',
	API_POST_SUCCESS: 'Success',
	API_GET_ACCOUNT_INFO: 'Get account information',
	API_STATUS_UPLOAD: 'Uploading...',

	// common text 
	COMMON_CANCEL: 'Cancel',
	COMMON_CONFIRM: 'Confirm',
	COMMON_NEXT_STEP: 'Next',
	// 输入值的小数位置最大不可超过设置值
	COMMON_TIP_ENTER_POINT_PREFIX: `Up to `,
	COMMON_TIP_ENTER_POINT_SUFFIX: ` decimal places`,
	COMMON_TOP_ENTER_NUMBER: 'Please enter a valid value',
	COMMON_COPY: 'Copy',
	COMMON_COPY_SUCCESS: 'Copy Success',
	COMMON_MIN_LENGTH: 'Minimum 8 Characters',
	COMMON_MORE: 'More',
	COMMON_BUY: 'Buy',
	COMMON_SELL: 'Sell',


	TABBAR_HOME: `Homepage`,
	TABBAR_MARKET: 'Market',
	TABBAR_CONTRACT: 'Transaction',
	TABBAR_ACCOUNT: 'Asset',
	TABBAR_COIN: 'Coin', // coin trade




	// Wealth 交易
	TRADE_WEALTH_TITLE: 'Funds',
	TRADE_WEALTH_RECORD_TITLE: 'Trading history',
	TRADE_WEALTH_HOLD_RECORD: 'Hold Record',
	TRADE_WEALTH_HISTORY: 'History',
	TRADE_WEALTH_NEW_USERS: 'New Users',
	TRADE_WEALTH_BUY_DETAIL: 'Buy Detail',
	TRADE_WEALTH_RATE: 'Rate',
	TRADE_WEALTH_CYCLE: 'Cycle',
	TRADE_WEALTH_CYCLE_UNIT: 'Day',
	TEADE_WEALTH_MIN_PRICE: 'Min Price',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: 'Please Enter Amount',
	TRADE_WEALTH_BUY_AMOUNT_TIP: 'Amount Must Bigger Min Price',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: 'Profit Rate',
	TRADE_WEALTH_HOLD_CYCLE: 'Cycle',
	TRADE_WEALTH_HOLD_PRICE: 'Price',

	TRADE_WEALTH_HOLD_NUM: 'Num',
	TRADE_WEALTH_HOLD_PROFIT: 'Profit',

	TRADE_WEALTH_HOLD_PAY_PRICE: 'Pay Price',
	// TRADE_WEALTH_HOLD_PROFIT: 'Profit',
	TRADE_WEALTH_HOLD_SN: 'SN',
	TRADE_WEALTH_HOLD_CRETIME: 'Create Time',
	TRADE_WEALTH_HOLD_ENDTIME: 'End Time',

	//理财
	LICAI_LICAI: 'Finance',
	LICAI_REN: 'Person',
	LICAI_YUGUSHOUYILV: 'Estimated yield',
	LICAI_ZHOUQI: 'cycle',
	LICAI_ZUIDIMAIRU: 'Minimum buy',
	LICAI_MINGCHENG: 'Name',
	LICAI_LEIXING: 'Type',
	LICAI_FAFANGRIQI: 'Release Date',
	LICAI_QINGSHURUMEIRUJINE: 'Please enter the purchase amount',
	LICAI_CHICANG: 'History',
	LICAI_YISHUHUI: 'Redeemed',
	LICAI_KEFU: 'Contact Customer Service',


	// access
	SIGN_IN_TITLE: "Sign In",
	SIGN_UP_TITLE: "Create Account",
	BTN_SIGN_IN: 'Sign In',
	BTN_SIGN_UP: 'Create Account',
	BTN_SIGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Go To The Sign In',
	ACCOUNT_NAME: 'Account',
	ACCOUNT_EMAIL: 'Email',
	ACCOUNT_PASSWORD: 'Password',
	VERIFY_ACCOUNT_PASSWORD: 'Verify Password',
	INVITATION_CODE: 'Invitation Code ',
	TIP_REMEMBER_PWD: 'Remember Password',
	TIP_AGREE: 'I Agree',
	TIP_PRVITE_PACT: 'Privte And Pact',
	TIP_VERIFY_CODE: 'Verify COde',
	TIP_ENTER_EMAIL: 'Enter Your Email Account',
	TIP_ENTER_EMAIL_CODE: 'Enter Your Email Code',
	TIP_EMAIL_CODE: 'Email Code',

	TIP_ENTER_ACCOUNT_NAME: 'Enter Your Email',
	TIP_ENTER_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_VERIFY_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_INVITATION_CODE: 'Enter Your Invitation Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_CHECK_AGREE: 'Please checked agree',
	TIP_SUCCESS_SIGNIN: 'Sign In Suceesfully',
	TIP_SUCCESS_REGISTER: 'Registration Suceesfully, Please Sign In',
	TIP_SIGN_OUT_SUCCESS: 'Sign Out Suceesfully',

	Heyue_baozhengjin: "Margin",

	PRVITE_PACT_TITLE: 'Privte And Pact',
	ABOUT_US_TITLE: 'About US',

	// card label
	CARD_ASSETS_TOTAL: 'Total',
	CARD_ASSETS_AVAIL: 'Avail',
	CARD_ASSETS_FREEZE: 'Freeze',
	// card btn text
	ASSETS_LIST_USING: 'Available balance',
	CARD_BTN_TREAD_LOG: 'Total asset valuation',
	ASSETS_LIST_FREEZE: 'Used amount',


	// search
	SEARCH_TITLE: 'Search',
	TIP_SEARCH: 'Enter Coin',
	SEARCH_HISTORY: 'History',
	SEARCH_CLEAR: 'Clear',
	LOADING_SEATCH: 'Searching...',
	SEATCH_RESULT_COUNT: 'Result Count',
	SEATCH_HOT_PICKS: 'Hot Picks',



	// 期权
	Qiquan_name: 'Options',
	Qiquan_price: 'Please enter amount',
	Qiquan_zhang: 'Buy(Long)',
	Qiquan_die: 'Buy(Short)',
	Qiquan_time: 'Select expiration time',
	Qiquan_profit: 'Profit',
	Qiquan_result: 'Trading Results',
	Qiquan_progress: 'Trading in progress...',
	Qiquan_name_coin: 'Name',
	Qiquan_type: 'Type',
	Qiquan_BUY_PRICE: 'Buy Price',
	Qiquan_now_PRICE: 'Now Price',
	Qiquan_ordersn: 'Order sn',
	Qiquan_Amount: 'Transaction Amount',
	Qiquan_Amount1: 'Amount',

	Qiquan_Expected: 'Expected profit and loss',
	Qiquan_pl: 'Profit and Loss',
	Qiquan_pl_Money: 'Profit and Loss Money',
	Qiquan_buytime: 'Buy Time',
	Qiquan_ying: 'Profit',
	Qiquan_shu: 'loss',
	Qiquan_success: 'Successful transaction',
	Qiquan_endprice: 'End Amount',


	max_ping1: 'Can close',
	max_ping2: 'positions',

	// page/market/index
	MARKET_INDEX_TAB_TRACK: 'Track', // 关注
	MARKET_INDEX_TAB_STOCK: 'Market', // 股票市场
	MARKET_INDEX_TAB_HOP: 'Trending', // 热门股票
	MARKET_INDEX_TAB_KPI: 'Index', // 市场指标
	MARKET_INDEX_TAB_RISE: 'Top gainers', // 
	MARKET_INDEX_TAB_FALL: 'Top losers', // 
	MARKET_INDEX_TAB_COIN: 'Currency', // Coin
	// 去市场看看
	MARKET_INDEX_TIP_GO_COIN: 'Go Coin',


	// 个人中心
	ACCOUNT_CENTER_TITLE: 'Account',


	COIN_PRICE_TYPE_MARKET: 'Market',
	COIN_PRICE_TYPE_LIMIT: 'Limit',

	// Coin overview
	COIN_VIEW_TAB_MINUTE: 'Minute',
	COIN_VIEW_TAB_DAILY: 'Daily',
	COIN_VIEW_TAB_MONTHLY: 'Monthly',
	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_VIEW_BTN_BUY: 'Buy',
	COIN_VIEW_BTN_SELL: 'Sell',
	COIN_VIEW_OPEN: 'Open',
	COIN_VIEW_CLOSE: 'Close',
	COIN_VIEW_HIGH: 'High',
	COIN_VIEW_LOW: 'Low',
	COIN_VIEW_AMOUNT: 'Trade Amount',

	COIN_VIEW_TAB_DEPTH: 'Depth',
	COIN_VIEW_TAB_TRADE: 'Latest Trade',

	COIN_VIEW_TRADE_TITLE_DATE: 'Date Time',
	COIN_VIEW_TRADE_TITLE_PRICE: 'Price',
	COIN_VIEW_TRADE_TITLE_AMOUNT: 'Quantity',

	COIN_VIEW_DEPTH_TITLE_PRICE: 'Price',
	COIN_VIEW_DEPTH_TITLE_BUY_QTY: 'Buy QTY',
	COIN_VIEW_DEPTH_TITLE_SELL_QTY: 'Sell QTY',

	COIN_BUY_TITLE_PRICE: 'Price',
	COIN_BUY_TITLE_QTY: 'Quantity',

	COIN_BUY_BALANCE: 'Balance',
	COIN_BUY_MAX_QTY: 'Max QTY',
	COIN_BUY_TOTAL_AMOUNT: 'Margin',
	COIN_BUY_TIP_ENTER_QTY: 'Enter Quantity',
	COIN_BUY_TIP_ENTER_PRICE: 'Enter Amount',
	COIN_BUY_TIP_ENTER_POINT: 'Up to 4 decimal places',

	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',

	COIN_CUR_ORDER: 'Current Orders',
	COIN_TRADE_RECORD: 'Trade Record',

	COIN_RECORD_TITLE: 'Record',
	COIN_RECORD_CURRENT: 'Current',
	COIN_RECORD_HISTORY: 'History',
	COIN_RECORD_SUCCESS: 'Success',

	COIN_RECORD_TIP_CUR_COIN: 'Only show the current coin',

	COIN_CURRENT_PRICE: 'Price',
	COIN_CURRENT_QTY: 'Quantity',
	COIN_CURRENT_TOTAL: 'Total',
	COIN_CURRENT_BTN_CANCEL: 'Cancel',

	COIN_HISTORY_TRADE_FEE_buy: 'Buy Fee',

	COIN_HISTORY_TRADE_FEE: 'Close Fee',
	COIN_HISTORY_TRADE_PRICE: 'Trade Price',
	COIN_HISTORY_TRADE_QTY: 'Trade Volume',

	COIN_BUY_PRICE: 'Buy Price',
	COIN_CLOSE_PRICE: 'Close Price',

	COIN_HISTORY_TIP_CANCEL: 'Cancel',
	COIN_HISTORY_TIP_TRADE: 'Trade',
	ZhuangTai: 'Status',
	// Contract 
	CONTRACT_DETAIL_BNT_BUY: 'Buy(Long)',
	CONTRACT_DETAIL_BTN_SELL: 'Sell(Short)',
	CONTRACT_PROFIT: 'Profit Amount',
	CONTRACT_LOSS: 'Loss Amount',
	CONTRACT_PROFIT_LOSS_SET: 'Take Profit And Stop Loss(Optional)',
	CONTRACT_LEVER: `Lever`,
	CONTRACT_FEE: 'Fee',
	CONTRACT_DESC_MODAL_TITLE: 'Contract Desc',
	CONTRACT_DESC_BTN: 'OK',
	CONTRACT_DESC_CONTENT: [
		`Contract Deposit: (Purchase Number*Nominal Value)/Multiple, nominal value 1000.`,
		`Number of vacancies: Balance sheet numbers, margins, margin fees.`,
		`Handling Fee: Margin * Currency Handling Rate (0.05%)*Multiple.`,
		`User Rights: User Balance + Total Margin + Position Gain/Loss.`,
		`Risk Ratio: User Privilege/Total Margin 100, generally less than 20% for liquidation.`
	],


	CONTRACT_RECORD_CURRENT: 'Current',
	CONTRACT_RECORD_HOLD: 'Holding',
	CONTRACT_RECORD_HISTORY: 'History',

	CONTRACT_RECORD_TIP_CUR_CONTRACT: 'Only show current contract',

	CONTRACT_HOLD_QUICK_CLOSE: 'All Close',

	CONTRACT_HOLD_BTN_PROFIT_LOSS: 'Take Profit And Stop Loss',
	CONTRACT_HOLD_BTN_CLOSE: 'Close Order',

	CONTRACT_HOLD_BUY_PRICE: 'Buy price', // 单价	
	CONTRACT_HOLD_BUY_QTY: 'Buy lot size', // 购买数量
	CONTRACT_HOLD_BUY_TOTAL: 'Margin', // 购买总价

	CONTRACT_HOLD_CURRENT_PRICE: 'Current Price',
	CONTRACT_HOLD_BUY_FEE: 'Fee', // 手续费
	CONTRACT_HOLD_BUY_PL: `Profit or Loss`,

	CONTRACT_RATE: `Risk/Reward`,

	CONTRACT_HOLD_TAKE_PROFIT: 'Take Profit',
	CONTRACT_HOLD_STOP_LOSS: 'Stop Loss',
	CONTRACT_HOLD_FLOAT_PL: `Float P & L`,

	CONTRACT_PROFIT_LOSS_MODAL_TITLE: 'Take Profit And Stop Loss',

	CONTRACT_TAKE_PROFIT_AMOUNT: 'Take Profit Amount',
	CONTRACT_STOP_LOSS_AMOUNT: 'Stop Loss Amount',
	CONTRACT_CLOSE_QTY: 'Enter Quantity',
	CONTRACT_ESTIMATED_PROFIT: 'Estimated Profit',
	CONTRACT_ESTIMATED_LOSS: 'Estimated Loss',
	CONTRACT_TIP_ENTER_PROFIT_BUY: 'Profit must be greater than price',
	CONTRACT_TIP_ENTER_PROFIT_SELL: 'Profit must be less than price',
	CONTRACT_TIP_ENTER_LOSS_BUY: 'Loss must be less than price',
	CONTRACT_TIP_ENTER_LOSS_SELL: 'Loss must be greater than price',

	// Notify
	NOTIFY_TITLE: 'Announcement',


	// Profile
	PROFILE_AUTH_VERIFIED: 'Verified',
	PROFILE_AUTH_UNVERIFIED: 'Unverified',
	PROFILE_SETTING_TITLE: 'Setting',
	PROFILE_SERVICE_TITLE: 'Service',
	PROFILE_ADDRESS: 'Withdraw Address', // 提现地址
	PROFILE_BANK: 'Bank Account',
	PROFILE_DEFAULT_COIN: 'Default Coin',
	PROFILE_LANGUAGE: 'Language',
	PROFILE_SIGN_IN_PASSWORD: 'Sign In Password',
	PROFILE_PAY_PASSWORD: 'Pay Password',

	PROFILE_QA: `Q & A`,
	PROFILE_PACT: 'Privte And Pact',
	PROFILE_SHARE: 'Share',
	PROFILE_SERVICE: 'Service',
	PROFILE_ABOUT: 'About Us',

	SHARE_LINK: 'Share Link',
	SHARE_COPYLINK: 'Copy Share Link',

	// account assets and contract
	ACCOUNT_TAB_ASSETS_TITLE: 'Assets',
	ACCOUNT_TAB_CONTRACT_TITLE: 'Contract',
	ACCOUNT_HIDE_ZERO_DATA: 'Hide Balance 0 Data',

	ASSETS_LIST_BALANCE: 'Balance',

	ASSETS_RECORD_TAB_HOLD: 'Hold',
	ASSETS_RECORD_TAB_SELL: 'Sell',

	ASSETS_RECORD_HOLD_STATUS: 'Hold',

	ASSETS_CONTRACT_RECORD: 'Contract Record',


	// Deposit
	DEPOSIT_TITLE: 'Deposit',
	DEPOSIT_RECORD_TITLE: 'Cash Balance Record',
	DEPOSIT_ADDRESS: 'Address',
	ZHUYI_TIXIAN: 'Note',
	TIXIAN_ZHUSHI: 'Please select or enter the amount and click Confirm. The system will automatically jump to the fund customer service manager for you. After the deposit is successful, please upload the deposit screenshot to avoid the inability to check your deposit order and affect your trading products! ',
	DEPOSIT_AMOUNT: 'Amount',
	DEPOSIT_ENTER_AMOUNT: 'Enter Amount',
	DEPOSTI_UPLOAD: 'Upload transfer voucher',
	DEPOSIT_RECORD_AMOUNT: 'Trade Amount',
	DEPOSIT_RECORD_SN: 'Order SN',
	DEPOSIT_RECORD_CT: 'Date Time',
	DEPOSIT_RECORD_DESC: 'Desc',
	DEPOSIT_COIN: 'Coin',

	// withdraw
	WITHDRAW_TITLE: 'withdrawl',
	WITHDRAW_ADDRESS: 'Address',
	WITHDRAW_AMOUNT: 'Amount',
	WITHDRAW_ENTER_AMOUNT: 'Enter Amount',
	WITHDRAW_PASSWORD: 'Password',
	WITHDRAW_ENTER_PASSWORD: 'Enter Password',
	WITHDRAW_MIN_AMOUNT: 'Minimum Amount',
	WITHDRAW_AVAILABLE_AMOUNT: 'Available Amount',
	WITHDRAW_FEE_AMOUNT: 'Trading Fee',
	WITHDRAW_RECORD_TITLE: 'Withdraw Record',
	WITHDRAW_RECORD_AMOUNT: 'Trade Amount',
	WITHDRAW_RECORD_SN: 'Order SN',
	WITHDRAW_RECORD_CT: 'Date Time',
	WITHDRAW_RECORD_DESC: 'Trade Desc',
	WITHDRAW_RECORD_FEE: 'Fee',
	WITHDRAW_RECORD_ADDRESS: 'Address',
	WITHDRAW_RECORD_COIN: 'Coin',
	WITHDRAW_COIN: 'Coin',
	WITHDRAW_BANK_CODE: 'Bank Account',
	WITHDRAW_TIP_ADD_ADDRESS: 'Go Add Address',
	WITHDRAW_TIP_ENTER_ADDRESS: 'Enter Address',
	WITHDRAW_TIP_CHOOSE: 'Choose Coin',
	WITHDRAW_MODAL_TITLE: 'Want to cancel a withdrawal?',

	// 劃轉
	TRANSFER_TITLE: 'Transfer',
	TRANSFER_IN_ACCOUNT: 'Transfer In Account',
	TRANSFER_OUT_ACCOUNT: 'Transfer Out Account',
	TRANSFER_TIP: 'The transfer-in account cannot be the same as the transfer-out account',
	TRANSFER_AMOUNT: 'Transfer Amount',
	TRANSFER_BALANCE: 'Balance',
	TRANSFER_ASSETS_TITLE: 'Assets',
	TRANSFER_CONTRACT_TITLE: 'Contract',
	TRANSFER_Options_TITLE: 'Options',


	TRANSFER_RECORD_TITLE: 'Transfer Record',
	TRANSFER_RECORD_DESC: 'Desc',
	TRASNFER_RECORD_REVIEW: 'Under review', // 审核中
	TRANSFER_RECORD_PASS: 'Passed', // 已通过
	TRANSFER_RECORD_REJECT: 'Rejected', // 已拒绝

	// 变更登入密码、变更支付密码
	PASSWORD_OLD: 'Old Password',
	PASSWORD_NEW: 'New Password',
	PASSWORD_VERIFY: 'Verify New Password',
	PASSWORD_ENTER_OLD: 'Enter Old Password',
	PASSWORD_ENTER_NEW: 'Enter New Password',
	PASSWORD_ENTER_VERIFY: 'Verify New Password',
	PASSWORD_TIP_VERIFY_FAIL: 'New password is different',

	// Address
	ADDRESS_INDEX_TITLE: 'Withdraw Address',
	ADDRESS_ADD_TITLE: 'Add Withdraw Address',
	ADDRESS_TIP_ENTER_ADDRESS: 'Enter Address',
	ADDRESS_CHOOSE_COIN: 'Choose',
	ADDRESS_WALLET_ADDRESS: 'Wallet Address',
	ADDRESS_WALLET_IMAGE: 'Upload Image',

	// TRADE_IPO
	TRADE_IPO_TITLE: 'ICO Coin Rush',
	TRADE_IPO_RECORD_TITLE: 'ICO Record',
	TRADE_IPO_LIST_PRICE: 'Price',
	TRADE_IPO_LIST_TOTAL: 'Total Issuance',
	TRADE_IPO_LIST_RC: 'Reserve Capacity',
	TRADE_IPO_LIST_LOCK: 'Lock',
	TRADE_IPO_LIST_DAY: 'Day',
	TRADE_IPO_DETAIL_TITLE: 'Detail',
	TRADE_IPO_PRICE: 'Price',
	TRADE_IPO_CT: 'Date Time',
	TRADE_IPO_SN: 'Order SN',
	TRADE_IPO_RECORD_DESC: 'Desc',
	TRADE_IPO_DETAIL_URL: 'White Paper',
	TRADE_IPO_DETAIL_WEBSITE: 'Website',
	TRADE_IPO_DETAIL_COIN_DESC: 'Coin Desc',
	TRADE_IPO_RECORD_APPLY_AMOUNT: 'Apply Amount',
	TRADE_IPO_RECORD_APPLY: 'Apply',
	TRADE_IPO_RECORD_SUCCESS: 'Success',
	// IPO 交易 申购成功记录
	TRADE_IPO_SUCCESS_SUB: 'Subscription',
	TRADE_IPO_SUCCESS_PRICE: 'Price',
	TRADE_IPO_SUCCESS_QUANTITY: 'Quantity',
	TRADE_IPO_SUCCESS_AMOUNT: 'Success Amount',
	TRADE_IPO_SUCCESS_FREEZE: 'Freeze',
	TRADE_IPO_SUCCESS_CT: 'Date Time',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order SN',
	TRADE_IPO_SUCCESS_UNPAY_AMOUNT: 'Unpay Amount',

	// Capital flow
	FLOW_TITLE: 'Capital Flow',
	FLOW_AMOUNT_AFTER: 'Amount After',
	FLOW_AMOUNT_BEFORE: 'Amount Before',
	FLOW_AMOUNT: 'Amount',
	FLOW_CT: 'Date Time',
	FLOW_DESC: 'Desc',

	// AUTH
	AUTH_TITLE: 'Authn',
	AUTH_REAL_NAME: 'Real Name',
	AUTH_CARD_ID: 'Card ID',
	AUTH_CARD_F: 'Card Front Image',
	AUTH_CARD_B: 'Card Back Image',
	AUTH_SUCCESS: `uccessfully authenticated. Identity information cannot be edited further. If you need assistance, please contact `,

	// 借贷 Borrow
	BORROW_TITLE: 'Credit',
	BORROW_TIP_UPLOAD: 'Please upload your credentials',
	BORROW_TIP_UPLOAD_TIP: 'Upload your credit score',
	BORROW_BTN_UPLOAD: 'Upload',
	BORROW_BTN_NOW: 'Borrow Now',
	BORROW_TIP_SUCCESS: 'Congratulations, the review was successful!',
	BORROW_RECORD: 'Apply Record',
	BORROW_RECORD_AMOUNT: 'Amount',
	BORROW_RECORD_LOANS: 'Loans',
	BORROW_RECORD_STATUS_APPLY: 'Apply',
	BORROW_RECORD_STATUS_PASS: 'Passed',
	BORROW_RECORD_STATUS_FAIL: 'Fail',
	BORROW_LINK_SERVICE: 'Contact Customer Service',
	BORROW_TIP_YOUR_SCORE: 'Your credit score',
	BORROW_REUPLOAD: 'Click Reupload',
	BORROW_TIP_UPLOAD_FAIL: 'Audit failure',
	BORROW_ENTER_AMOUNT: 'Please Enter Amount',
	BORROW_TIP_REVIEW: 'Under Review',
	JIGOU_ZHANGHU: 'Institutional account',
	SHENQING_JILV: 'Application record',
	SHOU_XUFEI: 'Handling fee',
	PINZHONG: 'Product',

	ZUIDI_MAIRU: 'Minimum Buy-in',

	//最新
	JIA_MI_HUOBI: 'Cryptocurrency holdings',
	GU_PIAO_CHICANG: 'Stock holdings',
	BI_BI_JIAOYIP: 'Coin-to-coin trading',
	HE_YUE_JIAO_YI: 'Contract trading',
	
	WEI_ZHONG_QIAN:'Not winning',
	SHEN_SHOUZ_HONG:'Subscription in progress',
	SHEN_GOUZHO_NGQIANG:'Subscription winning',
	SHEN_GOUZH_ANG:'Subscribed amount',
	SHEN_GOUZH_ONGNG:'Listed',

}