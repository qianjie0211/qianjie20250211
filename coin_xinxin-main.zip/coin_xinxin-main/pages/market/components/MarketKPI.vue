<template>
	<view>
		<TabsFifth :tabs="$lang.MARKET_INDEX_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="padding:10px;margin:20rpx;display: flex;align-items: center;border-bottom:1px Solid #F3F3F3;">

					<view style="text-align: center;padding-right: 20rpx;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>

					<view style="flex:1 0 86%;">
						<view :style="{color:$theme.PRIMARY}" style="font-size: 32rpx;line-height: 1.6;">
							{{item.name}}
						</view>
						<view style="display: flex;align-items: center;">
							<view style="width: 120rpx;" :style="{color:$theme.LOG_LABEL}">{{item.code}}</view>
							<view style="flex:1 0 40%; font-size: 32rpx;text-align: center;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{$util.formatMoney(item.price)}}
							</view>
							<view style="flex:1 0 24%; color:#FFFFFF;" :style="setStyle(item.rate*1>0)">
								<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
									:style="$theme.setImageSize(16)" style="padding-right: 12rpx;"></image>
								{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>

		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketKPI',
		components: {
			TabsFifth,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					borderRadius: `44rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/zhibiao`, {
					current: this.curTab
				})
				// console.log('result, result);
				if (!result) return false;
				this.list = Object.values(result).map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		}
	}
</script>

<style>
</style>