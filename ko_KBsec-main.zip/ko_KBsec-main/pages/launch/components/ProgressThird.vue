<template>
	<view>
		<view
			style="position:relative;margin:30rpx 120rpx; background-color:#FFFFFF;height:12rpx;border-radius: 20rpx;padding:0 3px;">
			<view :style="setStyle"></view>
			<view :style="imgMove"> </view>
		</view>
		<view style="text-align: center;color:#38AA9A;font-size: 24rpx;">
			<!-- {{`${$lang.STATUS_LOADING} `}} -->
			{{`${percentage} %`}}
		</view>
	</view>
</template>

<script>
	// desc:带有一个小火煎的进度条
	export default {
		name: 'ProgressThird',
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		computed: {
			setStyle() {
				return {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '16rpx',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg, #FFFFFF ,#18BFB4)`,
					borderRadius: '20rpx',
				};
			},
			// 小火箭的位移
			imgMove() {
				return {
					backgroundImage: `url('/static/launch_loading_icon.png')`,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: `${this.percentage+1}% 0px`,
					backgroundSize: '8%',
					width: ' 100%',
					height: '36rpx',
					position: 'absolute',
					left: 0,
					right: 0,
					top: '-18rpx',
					bottom: 0,
					zIndex: 9,
				};
			}
		},
		mounted() {
			// console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			// console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						uni.$u.sleep(1500).then(() => {
							// uni.switchTab({
							// 	url: this.$CONSTANTS.HOME,
							// })
						})
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					// console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>