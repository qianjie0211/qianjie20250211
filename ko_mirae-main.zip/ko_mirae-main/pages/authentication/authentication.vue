<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<CustomHeader :title="`실명인증`" @action="handleBack()"></CustomHeader>
		
		<view style="padding: 15px;">
		<view style="background-color: #fff;border-radius: 10px;">
		<view class="" style="margin-top: 30rpx;padding: 30rpx;">
			<view style="text-align: center;">
				<h3 :style="{color:userinfo.is_check==2? 'darkred':'#18BFB4'}">{{setTitle(userinfo.is_check)}}</h3>
			</view>
			<!-- <view v-if="userinfo.is_check==1" style="text-align: center;">
				<h3>실명인증</h3>
			</view>
			<view v-if="userinfo.is_check==2" style="text-align: center;color: darkred;">
				<h3>검토가 실패하면 다시 제출해 주세요.</h3>
			</view> -->
			<!-- 			<view class="flex ">
				<u-icon name="/static/zjt.png" class="padding-left-10" @click="$u.route({type:'navigateBack'})"
					imgMode="widthFix"></u-icon>
				<view class="color-white text-center width100 font-size-18">검색</view>

			</view> -->
			<view>
				<view class="input-list" style="background-color: #EFF1F8;">
					<u--input placeholder="성함 입력" border="surround" v-model="value1"></u--input>
				</view>
				<view class="input-list" style="background-color: #EFF1F8;">
					<u--input placeholder="주민 번호 입력" border="surround" v-model="value2"></u--input>
				</view>
			</view>
		</view>
		<view>
			<view v-if="userinfo.is_check!=1">
				<view class="text-center" style="margin:0 20px;line-height: 1.8;">신분증앞면</view>
				
				<image :src="formData.obverseUrl" style="width: 90%;margin-left: 5%;height: 120px;margin-top: 20px;" v-if="formData.obverseUrl" @click="obverse_btn"></image>
				
				<view class="idCardUpdate-box" @click="obverse_btn" v-if="!formData.obverseUrl">
					<img src="/static/purchase/upload.png" class="img">
				</view>
					
				
				<view class="text-center" style="margin: 20px;line-height: 1.8;">신분증뒷면</view>
					
				<image :src="formData.reverseUrl" style="width: 90%;margin-left: 5%;height: 120px;margin-top: 20px;"
					v-if="formData.reverseUrl" @click="reverse_btn"></image>

				<view class="idCardUpdate-box1" @click="reverse_btn" v-if="!formData.reverseUrl">
					<img src="/static/purchase/upload.png" class="img">
				</view>
				
				<view class="btn" @click="gain_aouonym()" style="padding: 20px 20px;">
					<view class="b-btn" style="background-color:  #f28930;">실명 인증 확인</view>
				</view>
			</view>
        </view>
		</view>
		</view>
	</view>
</template>


<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import {
		pathToBase64
	} from '@/common/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'

	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {

		},
		methods: {
			setTitle(val) {
				const temp = ['검토중', '실명인증', '검토가 실패하면 다시 제출해 주세요'];
				return temp[val];
			},

			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			obverse_btn() {
				if (this.obverseUrl) {

					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast('전면을 클릭하여 추가');
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast('뒷면을 클릭해서 추가했어요');
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB

						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],

				});
			},
			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			},
			home() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			// 认证
			async gain_aouonym() {
				if (this.userinfo.is_check == 0) {
					uni.showToast({
						title: '검토중',
						icon: 'none'
					})
					return;
				}
				uni.showLoading({
					title: "제출 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				if (list.data.code == 0) {


					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);

				}
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.value1 = list.data.data.real_name
				this.value2 = list.data.data.idno
				this.userinfo = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},

			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "업로드 중"
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()


				let mdd = md5("XPFXMedS" + Request + str_url + time)

				uni.uploadFile({
					url: this.$BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: tempFilePath,
					name: 'file',

					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data)
						if (type == 1) {
							this.formData.obverseUrl = data[0].url;
						} else {
							this.formData.reverseUrl = data[0].url;

						}

					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222, e)
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
		mounted() {
			this.userInfo()
		}
	};
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}

	.header {
		height: 50px;
		background: #014b8d;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 9px;
			height: 16px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}
	}

	.info-box {
		background: #fff;
		min-height: 100vh;
	}

	.input-list {
		margin-top: 10px;
		margin-bottom: 10px;
		// border: #283480 1px solid;
		border-radius: 4px;
	}

	.idCardUpdate-box {
		height: 140px;
		width: 80%;
		margin-left: 10%;
		background: url(/static/purchase/zheng.png);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-webkit-flex-direction: column;
		flex-direction: column;

		.img {
			width: 59px;
			height: 59px;
		}
	}

	.idCardUpdate-box1 {
		height: 140px;
		width: 80%;
		margin-left: 10%;
		background: url(/static/purchase/fan.png);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-webkit-flex-direction: column;
		flex-direction: column;

		.img {
			width: 59px;
			height: 59px;
		}
	}

	.btn {
		padding: 0 16px;
		margin-bottom: 20px;
	}

	.b-btn {
		width: 100%;
		height: 46px;
		line-height: 46px;
		background: #014b8d;
		border-radius: 10px;
		text-align: center;
		font-size: 17px;
		font-weight: 500;
		color: #fff;
		margin-bottom: 20px;
		margin: 16px 0;

	}
</style>