<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;background-color: #FFFFFF;">
		<header class="common_header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center"></view>
			<view class="right"></view>
		</header>

		<view style="padding:36rpx; padding-bottom: 200rpx;">
			<view style="font-size: 40rpx;font-weight: 900;color: #121212;">{{$lang.CTC_GENORDER_TITLE}}</view>

			<view style="display: flex;align-items: center;padding: 48rpx 0;">
				<CustomLogo logo="" :name="$lang.CTC_USDT" :size="48" />
				<view style="font-size: 28rpx;padding-left: 40rpx;" :style="{color:$theme.LOG_VALUE}">
					{{curMode==0?$lang.CTC_BUY:$lang.CTC_SELL}}
					{{$lang.CTC_USDT}}
				</view>
			</view>

			<template v-if="info">
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.CTC_RATE}}</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						${{$util.formatCurrency(info.huilv)}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.CTC_QTY}}</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatCurrency(info.shuliang)}}
						{{$lang.CTC_USDT}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.CTC_TOTAL}}</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						${{$util.formatCurrency(info.zongmoney)}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.CTC_SELL_METHOD}}</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{info.fukuan}}
					</view>
				</view>
			</template>
		</view>

		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;background-color: #FFFFFF;">
			<view style="margin:40rpx auto;width: 80%;min-height: 40px;line-height: 40px;font-size: 16px;"
				:style="setStyle()" @click="$util.linkCustomerService()">
				{{$lang.CTC_NEXT_STEP}}
			</view>
		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			CustomLogo
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curMode: 0, // 当前模式，[买|卖]
				id: '', // url传参
				type: '',
				info: null, // 
			};
		},
		computed: {},
		onLoad(opt) {
			this.id = Number(opt.id) || this.id;
			this.type = Number(opt.type) || this.type;
		},
		onShow() {
			this.isAnimat = true;
			this.geInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async geInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/app/c2corder`, {
					id: this.id,
				});
				if (!result) return false;
				console.log(result);
				this.info = result;
			},

			setStyle() {
				// this.curMode ==0?
				const _buy = this.$theme.linerGradient(90, '#295FFF', '#48DAFF');
				const _sell = this.$theme.linerGradient(90, '#FF8D29', '#FF533B');
				return {
					// backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					...this.curMode == 0 ? _buy : _sell,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 32rpx;
		display: flex;
		align-items: center;

		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1;
			text-align: left;
		}
	}
</style>