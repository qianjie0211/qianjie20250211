<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderSecond :title="$lang.DEPOSIT_TITLE" color="#FFFFFF"></HeaderSecond> -->
		<view class="flex padding-20">
			<view @click="fanhui()">
				<image src="../../static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="flex-1 text-center color-white font-size-18">入金</view>
		</view>

		<DepositPrimary></DepositPrimary>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import DepositPrimary from './components/DepositPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			DepositPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			fanhui(){
				uni.switchTab({
					url:'/pages/home/index'
				})
			},
		}
	}
</script>