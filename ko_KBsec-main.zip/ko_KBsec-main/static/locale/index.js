import koKR from './ko-KR.js';

// 到处前，根据项目需求，注释不需要的语言包。
// 注意：此处需与`Translate`中定义的数组对应。
export default {
	'ko-KR': koKR, // 韩语
};