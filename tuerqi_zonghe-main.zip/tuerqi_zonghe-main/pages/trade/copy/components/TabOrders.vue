<template>
	<view style="padding:0 36rpx 36rpx 36rpx;">
		<template v-if="!list ||list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #3B3B3D;padding:36rpx 0;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 40rpx;font-size: 28rpx;font-weight: 500;">
							{{item.name}}
						</view>
						<view :style="setStyle(item.type==1)">
							{{item.typeText}}
						</view>
						<view style="margin-left: auto;" :style="{color:item.profit>0?$theme.RISE:$theme.FALL}">
							{{item.profit}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 28rpx;">
						<view>{{item.rate}}</view>
						<view style="padding-left: 12rpx;">{{$lang.COPY_DETAIL_ORDERS_LOST}}</view>
						<view style="padding-left: 20rpx;color:#8E8D92;font-size: 28rpx;">{{item.price}}</view>
						<view style="margin-left: auto;">
							<text style="padding-right: 12rpx;" :style="{color:item.pips>0?$theme.RISE:$theme.FALL}">
								{{item.pips}}</text>
							<text :style="{color:item.pips>0?$theme.RISE:$theme.FALL}">
								{{$lang.COPY_DETAIL_ORDERS_PIPS}}
							</text>
						</view>
						<!-- <view>
							<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_ORDERS_BUY_PRICE}}</view>
							<view style="color:#FFFFFF;font-size: 28rpx;font-weight: 500;">{{item.buyPrice}}</view>
							<view style="color:#8E8D92;font-size: 20rpx;">{{$util.formatDate(item.buyDT)}}</view>
						</view>
						<view style="text-align: center;">
							<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_ORDERS_SELL_PRICE}}</view>
							<view style="color:#FFFFFF;font-size: 28rpx;font-weight: 500;">{{item.sellPrice}}</view>
							<view style="color:#8E8D92;font-size: 20rpx;">{{$util.formatDate(item.sellDT)}}</view>
						</view>
						<view style="text-align: right;">
							<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_ORDERS_PROFIT}}</view>
							<view style="font-size: 28rpx;font-weight: 500;"
								:style="{color:item.profit>0?$theme.RISE:$theme.FALL}">{{item.profit}}</view>
							<view style="font-size: 20rpx;" :style="{color:item.rate>0?$theme.RISE:$theme.FALL}">
								{{item.rate+` %`}}
							</view>
						</view> -->
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	
	export default {
		name: 'TabOrders',
		components: {
		
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {}
		},

		computed: {
			list() {
				// this.info.dddingdan
				let temp = [];
				this.info.dddingdan.type.forEach((item, index) => {
					temp.push({
						name: this.info.dddingdan.name[index],
						type: item * 1,
						typeText: item * 1 == 1 ? this.$lang.COPY_DETAIL_ORDERS_BUY : this.$lang
							.COPY_DETAIL_ORDERS_SELL,
						price: this.info.dddingdan.jiage[index],
						pips: this.info.dddingdan.pips[index] * 1,
						rate: this.info.dddingdan.chajia[index] * 1,
						profit: !this.info.dddingdan.usdt[index] ? 0 : this.info.dddingdan.usdt[index] * 1
					})
				});

				return temp;
			}
		},

		methods: {
			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>

<style>
</style>