<template>
	<view>
		<view>
			<view class="flex" style="padding: 20px;">
				<view class="flex" @click="jiantou()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				
				<view class="flex-1 text-center" style="color: #fff;font-size: 18px;">{{$lang.TRADE_WEALTH_RECORD_TITLE}}</view>
			</view>
			<!-- <HeaderSecond :title="$lang.TRADE_WEALTH_RECORD_TITLE"></HeaderSecond> -->
			<view style="display: flex;align-items: center;justify-content: space-around; padding:20rpx 40rpx;">
				<view :style="setStyle(curTab==0)" @click="changeTab(0)">
					{{tabs[0]}}
				</view>
				<view style="width: 1px;height: 30rpx;background-color: #CFCFCF;"></view>
				<view :style="setStyle(curTab==1)" @click="changeTab(1)">
					{{tabs[1]}}
				</view>
			</view>
			<view style="padding: 0px 20px;">
				<view style="border-top: 1px #CFCFCF solid;">.</view>
			</view>
			
		</view>

		<view style="margin:0 10px;padding:10rpx;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;margin:30rpx 0;border-radius:24rpx;border: 1px #00aa98 solid;">
						<view style="display: flex;align-items: center;">
							<view style="flex:1 0 80%;color:#00aa8f;font-size: 36rpx;">
								{{item.goodname}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_RATE}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{item.fudu}}%</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_CYCLE}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{$util.formatCoin(item.price,4)}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_PAY_PRICE}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{$util.formatCoin(item.pay_price,4)}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{$util.formatCoin(item.shouyi,4)}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{item.ordersn}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_CRETIME}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{item.time}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#ccc;">{{$lang.TRADE_WEALTH_HOLD_ENDTIME}}</view>
							<view style="color:#fff;font-size: 28rpx;">{{item.endtime}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				curTab: 0,
				list: [],
			}
		},
		computed: {
			tabs() {
				return [this.$lang.LICAI_CHICANG, this.$lang.LICAI_YISHUHUI];
			}
		},
		onShow() {
			this.getList();
		},
		onHide() {},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			jiantou(){
				uni.navigateBack({
					delta:1,
				})
			},
			// 设置tab样式
			setStyle(val) {
				return {
					margin: `10rpx 40rpx`,
					borderBottom: `3px solid ${val?'#00a68a':'transparent'}`,
					fontSize: `28rpx`,
					color: val ? '#00a68a' : '#666660',
				}
			},
			// 获取列表数据
			async getList() {
				const result = await this.$http.post(`api/jijin/order`, {
					status: this.curTab + 1, // 1是持仓   2是历史
				});
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			}
		}
	}
</script>

<style>
</style>