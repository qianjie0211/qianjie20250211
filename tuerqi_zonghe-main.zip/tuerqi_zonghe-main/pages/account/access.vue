<template>
	<view class="access_bg" :class="isAnimat?'fade_in':'fade_out'">
		<view style="display: flex;align-items: center;justify-content: center;padding-top: 1vh;">
			<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(300)"></image>
		</view>
		<view style="display: flex;flex-direction: column;justify-content: space-between;">
			<view :class="isSignIn?'left_in':'right_in'">
				<view class="common_block color-white" style="padding:40rpx 20rpx;margin:32rpx;">
					<view
						style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
						<view style="font-size: 32rpx;">
							{{$lang.WELCOME+` ${isSignIn?$lang.SIGN_IN_TITLE:$lang.SIGN_UP_TITLE}`}}
						</view>
						<view>
							<view style="display: flex;align-items: center;" @click="isShowList=true">
								<view style="padding-right: 20rpx;">{{setLang}}</view>
								<image src="/static/arrow_down_solid.png" :style="$theme.setImageSize(16,12)">
								</image>
							</view>
						</view>
					</view>

					<!-- <view class="flex gap20 margin-bottom-20 color-white" v-if="!isSignIn">
						
						<view :style="inv==0?'border:1px solid #018ef8':''" style="padding: 5px 10px;border-radius: 5px;" @click="inv=0">Email</view>
						<view :style="inv==1?'border:1px solid #018ef8':''" style="padding: 5px 10px;border-radius: 5px;" @click="inv=1">Phone</view>
						
					</view> -->

					<!-- 手机号登录及注册 -->

					<TitleSecond :title="$lang.ACCOUNT_NAME" v-if="inv==0"></TitleSecond>
					<view class="input_wrapper" style="margin-bottom: 20rpx;" v-if="inv==0">
						<!-- <image src="/static/account_name.png" mode="aspectFit"></image> -->
						<input v-model="user" type="text" :placeholder="$lang.ACCOUNT_NAME"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>



					<view v-if="!isSignIn">
						<!-- <TitleSecond :title="$lang.TIP_EMAIL_CODE" v-if="inv==0"></TitleSecond> -->

						<!-- <view class="input_wrapper" style="" v-if="inv==0">

							<input v-model="email_code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
								:placeholder-style="$theme.setPlaceholder()">

							<view class="radius10 color-white" style="background-color: #018ef8;padding: 2px 10px;color: #fff;"
								@tap="getCode">{{tips}}</view>
							<u-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"
								startText="Send" changeText="X" endText='Send'></u-code>
							</input>

						</view> -->



						<TitleSecond :title="$lang.SIGN_UP_MOBILE" v-if="inv==1"></TitleSecond>
						<view class="input_wrapper" style="" v-if="inv==1">
							<input v-model="user" type="text" :placeholder="$lang.SIGN_UP_MOBILE"
								:placeholder-style="$theme.setPlaceholder()">
							</input>
						</view>
					</view>

					<!-- 通用的输入密码 -->
					<TitleSecond :title="$lang.ACCOUNT_PASSWORD"></TitleSecond>
					<view class="input_wrapper" style="margin-bottom: 40rpx;">
						<!-- <image src="/static/account_password.png" mode="aspectFit"> </image> -->
						<input v-model="password" :password="isMask" :placeholder="$lang.TIP_ENTER_ACCOUNT_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()"></input>
						<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
							style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
							@click="toggleMask()">
						</image>
					</view>

					<template v-if="isSignIn">
						<view style="text-align: center;padding-right: 24rpx;font-size: 11px;font-weight: 300;"
							@click="$util.linkCustomerService()">
							<text>{{$lang.FORGET_PWD}}</text>
							<text style="color:#038ef8;padding-left: 12rpx;">{{$lang.FORGET_PWD_SERVICE}}</text>
						</view>
					</template>

					<!-- 注册所需 -->
					<template v-if="!isSignIn">
						<TitleSecond :title="$lang.VERIFY_ACCOUNT_PASSWORD"></TitleSecond>
						<view class="input_wrapper" style="margin-bottom: 40rpx;">
							<!-- <image src="/static/account_password.png" mode="aspectFit"> </image> -->
							<input v-model="verifyPassword" :password="isMask"
								:placeholder="$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD"
								:placeholder-style="$theme.setPlaceholder()"></input>
							<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
								style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
								@click="toggleMask()">
							</image>
						</view>

						<TitleSecond :title="$lang.INVITATION_CODE"></TitleSecond>
						<view class="input_wrapper" style="margin-bottom: 40rpx;">
							<!-- <image src="/static/account_code.png" mode="aspectFit"> </image> -->
							<input v-model="code" type="text" :placeholder="$lang.TIP_ENTER_INVITATION_CODE"
								maxlength="11" :placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</template>

					<!-- 通用按钮 已包含相关逻辑判断 -->
					<view class="common_btn" @click="handleConfirm()" style="margin:80rpx auto 20rpx auto;">
						{{isSignIn?$lang.BTN_SIGN_IN:$lang.BTN_SIGN_UP}}
					</view>
				</view>

				<!-- 记住密码，以及登入注册的切换 -->
				<view style="display: flex;align-items: center;justify-content: space-between;margin: 40rpx 60rpx;">
					<template v-if="isSignIn">
						<u-checkbox-group>
							<!-- circle -->
							<u-checkbox shape="" :activeColor="$theme.SECOND" :label="$lang.TIP_REMEMBER_PWD"
								v-model="isRemember" labelColor="#666666" labelSize="24rpx" @change="changeRemember"
								:checked="isRemember" :iconColor="$theme.SECOND"></u-checkbox>
						</u-checkbox-group>
					</template>
					<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}" @click="handleChange()">
						{{isSignIn?$lang.SIGN_UP_TITLE:$lang.GO_TO_SIGN_IN}}
					</view>
				</view>
			</view>
			<template v-if="!isSignIn">
				<view style="padding-bottom: 200rpx;">
					<!-- 隐私协议 -->
					<view style="display: flex;align-items: center;justify-content: center;">
						<view>
							<u-checkbox-group>
								<u-checkbox shape="" :activeColor="$theme.SECOND" :label="$lang.TIP_AGREE"
									v-model="isAgree" labelColor="#fff" labelSize="24rpx" @change="changeAgree"
									:checked="isAgree" :iconColor="$theme.SECOND"></u-checkbox>
							</u-checkbox-group>
						</view>
						<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}"
							@click="linkPact()">
							{{$lang.TIP_PRVITE_PACT}}
						</view>
					</view>
				</view>
			</template>
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="isShowList" :columns="[$util.LANGUAGE_LIST]" @change="changeLang" @cancel="isShowList=false"
			@confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="name"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import TitleSecond from "@/components/title/TitleSecond.vue";
	export default {
		components: {
			TitleSecond
		},
		data() {
			return {
				inv: 0,
				isAnimat: false, // 页面动画
				showLang: false, // lang modal
				isMask: null, // 掩码
				user: "", // 账户
				password: '', // 密码
				verifyPassword: '', // 确认密码
				emailCode: '', // 邮箱验证码（印度）
				code: '', // 邀请码
				isSignIn: true,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
				email_code: "",
				seconds: 60,
				tips: 'Send',
				isShowList: false, // 多语言备选
				mobile: ""
			};
		},
		computed: {
			setLang() {
				const temp = uni.getStorageSync('lang') || this.$LANGCODE;
				const tempName = this.$util.LANGUAGE_LIST.filter(item => item.lang == temp)[0].name;
				return tempName;
			}
		},
		onLoad(opt) {
			console.log(`opt`, opt);
			// 处理邀请链接，及附带邀请码
			if (opt.code && opt.code.length > 0) {
				this.code = opt.code;
			}
			// 读取缓存中的页面信息
			console.log(this.user);
			console.log(this.password);
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
		},
		onShow() {
			this.isAnimat = true;
			if (this.code.length > 0) this.isSignIn = false;
			this.isMask = uni.getStorageSync('mask');
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
			// 读取缓存中的页面信息
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
		},
		onHide() {
			this.isAnimat = false;
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 選擇一種 lang
			chooseLang() {
				this.isShowList = true;
			},
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				// this.curLang = e.value[0].name;
				this.isShowList = false;
				uni.setStorageSync('lang', e.value[0].lang);
				uni.reLaunch({
					url: this.$CONSTANTS.LAUNCH,
				})
			},


			codeChange(text) {
				this.tips = text;
			},
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				return !emailPattern.test(val)
			},
			async getCode() {
				if (this.checkEmail(this.user)) {
					uni.$u.toast(this.$lang.TIP_ENTER_EMAIL);
					return false;
				}
				if (!this.user || this.user == '') {
					uni.$u.toast(this.$lang.TIP_ENTER_EMAIL);
					return false;
				}

				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: 'Getting verification code'
					})

					const result = await this.$http.post(`api/app/sendSmsCode`, {
						mobile: this.user,
					})


					uni.hideLoading()
					console.log('result:', result);
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
				} else {
					uni.$u.toast('Send after the countdown ends');
				}
			},
			end() {
				// uni.$u.toast('倒计时结束');
			},
			start() {
				// uni.$u.toast('倒计时开始');
			},
			// handleClose() {
			// 	this.showLang = false;
			// },

			// handleSelected(val, index) {
			// 	console.log(index, val);
			// 	this.showLang = false;
			// 	uni.setStorageSync('lang', val.lang);
			// 	uni.reLaunch({
			// 		url: this.$CONSTANTS.LAUNCH,
			// 	})
			// },

			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.navigateTo({
					url: this.$CONSTANTS.PRVITE_PACT,
				});
			},
			// 切换当前 登录或注册
			handleChange() {
				this.inv = 0
				this.isSignIn = !this.isSignIn;
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.mobile == '') {
					// uni.showToast({
					// 	title: this.$lang.MOBILE,
					// 	icon: 'none',
					// });
					// return false;
				}

				if (this.user.length < 8) {
					uni.showToast({
						title: this.$lang.COMMON_MIN_LENGTH,
						icon: 'none',
					});
					return false;
				}
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				// if (!this.isSignIn && this.email_code == ''&&this.inv==0) {
				// 	uni.$u.toast("Please fill in the email verification code");
				// 	return false;
				// }

				if (!this.isSignIn && this.verifyPassword == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.isAgree != true) {
					uni.showToast({
						title: this.$lang.TIP_CHECK_AGREE,
						icon: 'none',
					});
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$CONSTANTS.HOME,
					});
				}, 1000);
			},
			async register() {
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					email: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: this.email_code,
					inv: this.inv
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				this.signIn();
			},
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.u-checkbox__icon-wrap {
		background-color: transparent !important;
	}

	.access_bg {
		width: 100%;
		min-height: 100vh;
		background-color: #000;
	}

	.input_wrapper {
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		margin: 20rpx 0;
		padding: 20rpx 10px;
		border-radius: 10rpx;
		height: 54rpx;
		line-height: 54rpx;
		border: 1px solid #fff;

		/* background-color: #F5F5F5; */
		input {
			color: #fff;
			width: 80%;
		}

		image {
			padding-right: 40rpx;
			width: 40rpx;
			height: 40rpx;
		}
	}
</style>