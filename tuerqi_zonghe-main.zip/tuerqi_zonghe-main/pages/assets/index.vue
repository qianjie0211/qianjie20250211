<template>
	<view style="background-color: #000;min-height: 100vh;">
		<!-- <HeaderPrimary isSearch :title="$lang.ACCOUNT_CENTER_TITLE" :color="$theme.SECOND"></HeaderPrimary> -->
		<!-- 	<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_4" style="width: 640rpx;">
				<CardItemSecond :info="cardData" :labels="cardLabels"></CardItemSecond>
			</view>
		</view> -->
		
		<view style="background-color: #101010;padding:40px 20px 20px 20px;">
			<view class="flex flex-b">
				<view class="flex gap5">
					<view style="color: #cdcdce;font-size: 16px;">{{$lang.CARD_BTN_TREAD_LOG}}</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click.stop="toggleData()"
						:style="$theme.setImageSize(30)">
					</image>
				</view>
				<view>
					<image mode="aspectFit" :src="`/static/center_right.png`" @click.stop="linkTradeLog()"
						:style="$theme.setImageSize(32)">
					</image>
				</view>
			</view>
			<view class="flex flex-b margin-top-10">
				<view class="flex">

					<view class="font-size-22">{{showAmount?$util.formatMoney(cardData.value2):hideAmount}}</view>
					<view class="font-size-14 margin-top-5 margin-left-10" @click.stop="show=true">
						{{cardData.type==3?'TRY':'USDT'}}
					</view>

					<image mode="aspectFit" :src="`/static/arrow_down_solid.png`" @click.stop="show=true"
						style="margin-left: 5px;margin-top: 8px;" :style="$theme.setImageSize(20)">
					</image>
				</view>
			</view>

			<view class="flex margin-top-10">
				<view class="flex-1">
					<view style="color: #cdcdce;font-size: 16px;">{{$lang.ASSETS_LIST_USING}}</view>
					<view style="margin-top: 10px;">{{$util.formatMoney(cardData.value1)}}</view>
				</view>
				<view class="flex-1">
					<view style="color: #cdcdce;font-size: 16px;">{{$lang.ASSETS_LIST_FREEZE}}</view>
					<view style="margin-top: 10px;">{{$util.formatMoney(cardData.value3)}}</view>
				</view>
			</view>
			<view class="flex flex-b margin-top-10 gap10">
				<view style="padding: 8px 16px;background-color: #048ef8;border-radius: 5px;" class="flex-1 text-center"
					@click="linkAuth()">{{$lang.AUTH_TITLE}}</view>
				<!-- <view style="padding: 8px 16px;background-color: #5e5e5e;border-radius: 5px;" class="flex-1 text-center" @click="linkTransfer()">{{$lang.DAI_KUAN}}</view> -->

				<view style="padding: 8px 16px;background-color: #5e5e5e;border-radius: 5px;" class="flex-1 text-center"
					@click="$u.route({url:'/pages/transfer/index'});">{{$lang.TRANSFER_TITLE}}</view>
			</view>

			<view class="flex flex-b margin-top-10 gap10">
				<view style="padding: 8px 10px;background-color: #048ef8;border-radius: 5px;" class="flex-1 text-center"
					@click="$u.route({url:'/pages/address/index'});">{{$lang.PROFILE_ADDRESS}}</view>


				<view style="padding: 8px 10px;background-color: #5e5e5e;border-radius: 5px;" class="flex-1 text-center"
					@click="$u.route({url:'/pages/account/password'});">{{$lang.PROFILE_SIGN_IN_PASSWORD}}</view>
			</view>

			<view class="flex flex-b margin-top-10 gap10">
				<view style="padding: 8px 10px;background-color: #048ef8;border-radius: 5px;" class="flex-1 text-center"
					@click="$u.route({url:'/pages/deposit/index'});">{{$lang.DEPOSIT_TITLE}}</view>


				<view style="padding: 8px 10px;background-color: #5e5e5e;border-radius: 5px;" class="flex-1 text-center"
					@click="$u.route({url:'/pages/withdraw/index'});">{{$lang.WITHDRAW_TITLE}}</view>
			</view>
		</view>

		<u-picker :show="show" :columns="columns" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			@cancel="show=false" @confirm="qiehuan"></u-picker>

		<!-- <view class="common_block"
			style="display: flex;align-items: center;justify-content: space-between;border-radius: 24rpx;padding:20rpx rpx;">
			<view @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top0.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#fff;line-height: 1.4;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top1.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#fff;line-height: 1.4;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<view @click="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top5.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#fff;line-height: 1.4;">
					{{$lang.AUTH_TITLE}}
				</view>
			</view>
			<view @click="linkTransfer()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top00.png" mode="aspectFit" :style="$theme.setImageSize(65)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#fff;line-height: 1.4;">
					{{$lang.DAI_KUAN}}
				</view>
			</view>

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#fff;line-height: 1.4;">
					{{$lang.PROFILE_SERVICE}}
				</view>
			</view>
		</view> -->

		<!-- <view style="display: flex;justify-content: space-around;margin:0 10rpx;">
			<block v-for="(v,k) in tabs" :key='k'>
				<view :style="setStyleTab(curTab ==k)" @click="changeTab(k)">
					{{v}}
				</view>
			</block>
		</view> -->

		<template v-if="!list || list.length<=0">
			<EmptyData />
		</template>
		<!-- <template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view @tap="handleShowModal(item)" class="common_block"
					style="padding:20rpx 24rpx;line-height: 1.6;border-radius: 16rpx;">
					<view :style="{color:$theme.LOG_VALUE}" style="font-size: 28rpx;line-height: 1.6;font-weight: 700;">
						{{item.name}}
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.status==1? $lang.TRADE_HOLD_LABEL_PROFIT_RATE
												:$lang.TRADE_SELL_LABEL_PROFIT_RATE}}
						</view>
						<template v-if="item.status==1">
							<view :style="$theme.setStockRiseFall(item.buyProfitRate*1>0)">
								{{item.buyProfitRate*1>0?'+':''}}
								{{$util.formatNumber(item.buyProfitRate)}}%
							</view>
						</template>
						<template v-if="item.status==2">
							<view :style="$theme.setStockRiseFall(item.sellProfitRate*1>0)">
								{{item.sellProfitRate*1>0?'+':''}}
								{{$util.formatNumber(item.sellProfitRate)}}%
							</view>
						</template>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<template v-if="item.status==1">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_MODAL_YINGKUI}}
							</view>
							<view :style="$theme.setStockRiseFall(item.buyFloatProfit*1>0)">
								{{item.buyFloatProfit*1>0?'+':''}}
								{{$util.formatNumber(item.buyFloatProfit*1)}}
								{{$lang.CURRENCY_UNIT}}
							</view>
						</template>
						<template v-if="item.status==2">
							<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_SELL_LABEL_PROFIT_AMOUNT}}
							</view>
							<view :style="$theme.setStockRiseFall(item.sellProfit*1>0)">
								{{item.sellProfit*1>0?'+':''}}
								{{$util.formatNumber(item.sellProfit*1)}}
								{{$lang.CURRENCY_UNIT}}
							</view>
						</template>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_HOLD_LABEL_BUY_AMOUNT}}
						</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.buyQTY)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_HOLD_LABEL_TOTAL_PRICE}}
						</view>
						<view :style="{color:$theme.LOG_VALUE}">
							<template v-if="item.status==1">
								{{$util.formatNumber(item.buyTotal)+` ${$lang.CURRENCY_UNIT}`}}
							</template>
							<template v-if="item.status==2">
								{{$util.formatNumber(item.sellTotal)+` ${$lang.CURRENCY_UNIT}`}}
							</template>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_HOLD_LABEL_BUY_PRICE}}
						</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.status==1?$lang.TRADE_HOLD_LABEL_CUR_PRICE:$lang.TRADE_SELL_LABEL_SELL_PRICE}}
						</view>
						<template v-if="item.status==1">
							<view :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.currentPrice)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</template>
						<template v-if="item.status==2">
							<view :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.sellPrice)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</template>
					</view>
				</view>
			</block>
		</template> -->

		<!-- 弹层 -->
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;padding-bottom: 80rpx;">
				<view class="popup_header" style="display: flex;align-items: center;justify-content:space-between;"
					:style="{backgroundColor:$theme.PRIMARY}">
					<text :style="{color:$theme.STOCK_NAME}"
						style="font-size: 36rpx;text-align: center;flex:1 0 90%;">{{detail.name}}</text>
					<image src="/static/close.png" :style="$theme.setImageSize(40)" @click="handleClose()"></image>
				</view>
				<view class="item" style="padding-top: 24rpx;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_TIME}}</view>
					<view :style="{color:$theme.LOG_VALUE}">{{detail.buyCT}}</view>
				</view>
				<template v-if="detail.status==2">
					<view class="item">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_SELL_TIME}}
						</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{detail.sellCT}}
						</view>
					</view>
				</template>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FLOAT_PROFIT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyFloatProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellFloatProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>

				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_PROFIT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_PRICE}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
					</view>
				</view>

				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_QTY}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyQTY)+` ${$lang.CURRENCY_UNIT}`}}
					</view>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LEVER}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{detail.lever}}
					</view>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FEE}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyFee)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellFee)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>
				<view class="item">
					<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_AMOUNT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyAmont)+` ${$lang.CURRENCY_UNIT}`}}
					</view>
				</view>
				<template v-if="detail.status==1">
					<view style="display: flex;justify-content: space-around;margin:30rpx 60rpx;">
						<view class="common_btn"
							style="margin:24rpx;width: 80%;border:1px solid #1C1C1C;color:#1C1C1C;background-color: transparent;"
							@tap="linkDetail(detail)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="common_btn"
							style="margin:24rpx;width: 80%;border:1px solid #1C1C1C;background-color: #1C1C1C;color:#FFF;"
							@tap.stop="handleSell(detail.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</template>
			</view>
		</template>

		<!-- 資金賬戶 合約賬戶 -->
		<!-- <view style="display: flex;align-items: center;margin:0 40rpx;">
			<block v-for="(item,index) in setTabs" :key="index">
				<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view> -->

		<template>
			<AssetsList :list="list" @action="handleType"></AssetsList>
		</template>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import CardItemSecond from '@/components/card/CardItemSecond.vue';
	import AssetsList from './components/AssetsList.vue';
	import ContractList from './components/ContractList.vue';
	export default {
		components: {
			HeaderPrimary,
			CardItemSecond,
			AssetsList,
			ContractList,
		},
		data() {
			return {
				columns: [
					['TRY', 'USDT']
				],
				type: "",
				showAmount: uni.getStorageSync('show') || false, // 显示金额
				hideAmount: '******', // 隐藏金额
				isAnimat: false, // 页面动画
				show: false,
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
				// curTab: 0, // assets or contract
				// list: [], // 列表数据
				// isHideZero: false, // 是否隐藏余额为0的数据
				// contractData: {}, // 合约资产
				// qianbao_dan: 0,
				// setTabs: ""
				list: [],
				curPage: 1, // 当前页码
				// maxPage: 1, // 最大页码
				isShow: false, // 是否显示弹层
				detail: null, // 单条数据详情
				curTab: 0,
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			// 持仓 和里斯
			tabs() {
				return [
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
		},
		onShow() {

			this.isAnimat = true;
			// this.getAccountInfo();
			// this.getconfig();
			// if (this.curTab == 0)
			this.getAssetsList();
			// if (this.curTab == 1) {
			// 	this.getAccountContract();
			// 	this.getContractList();
			// }

			// if (this.curTab == 2) {
			// 	this.getAccountContract();
			// 	this.getContractList();
			// }
			// this.getAccountContract();
			this.changeTab(this.curTab);

		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.getAccountInfo();
			// if (this.curTab == 0) 
			this.getAssetsList();
			// if (this.curTab == 1) {
			// 	this.getAccountContract();
			// 	this.getContractList();
			// }
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			linkTradeLog() {
				uni.navigateTo({
					url: this.$CONSTANTS.CAPITAL_FLOW
				})
			},
			toggleData() {
				this.showAmount = !this.showAmount;
				this.$util.setShowData(this.showAmount);
			},
			qiehuan(e) {
				console.log(111, e);
				if (e.value == "USDT") {
					this.type = 2
				} else {
					this.type = ''
				}
				this.getAssetsList()
				this.show = false
			},
			changeTab(val) {
				this.curTab = val;
			},
			// 跳转到股票详情
			linkDetail(val) {
				this.handleClose();
				uni.reLaunch({
					url: this.$CONSTANTS.COIN_DETAIL + `?code=${val.locate}`
				});
				// uni.navigateTo({
				// 	url: `${this.$CONSTANTS.STOCK_OVERVIEW}?code=${val.locate}`
				// });
			},
			handleShowModal(item) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.detail = item;
				console.log(this.detail);

			},
			// 关闭弹层
			handleClose() {
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	

			},
			setStyleTab(val) {
				return {
					minWidth: `120rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `44rpx`,
				}
			},
			// 设置样式
			setStyle(val, w = 120) {
				// const temp = this.curTab == 0 ? this.$theme.RISE : this.$theme.FALL;
				return {
					minWidth: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#F6F8FC',
					color: val ? '#FFFFFF' : '#666666',
					borderRadius: `44rpx`,
				}
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$CONSTANTS.WITHDRAW_INDEX
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$CONSTANTS.DEPOSIT_INDEX
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$CONSTANTS.ACCOUNT_AUTH,
				})
			},
			linkTransfer() {
				uni.navigateTo({
					url: '/pages/Loans'
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			// handleType(val) {
			// 	this.isHideZero = val;
			// 	this.getAssetsList();
			// },

			async getAssetsList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/assets`, {
					type: this.type, // 2:assets 1:contract
					// hide_money: this.isHideZero ? 1 : 0,
				});
				if (!result) return false;
				console.log(`assets:`, result);
				this.list = result;
				this.cardData = {
					value1: result[0].money * 1,
					value2: result[0].zong_money * 1,
					value3: result[0].freeze * 1,
					type: result[0].type,
				};
			},

			// async getContractList() {
			// 	uni.showLoading({
			// 		title: this.$lang.REQUEST_DATA,
			// 	});
			// 	const result = await this.$http.post(`api/user/finance`, {
			// 		type: this.curTab + 1,
			// 		name: 'USDT',
			// 	});
			// 	if (!result) return false;
			// 	console.log(`contract:`, result);
			// 	this.list = result;
			// },

			// async getAccountContract() {
			// 	uni.showLoading({
			// 		title: this.$lang.API_GET_ACCOUNT_INFO
			// 	});
			// 	const result = await this.$http.post(`api/user/assets`, {
			// 		type: 2,
			// 		name: 'USDT',
			// 	});
			// 	console.log(`assets:`, result);
			// 	if (!result) return false;
			// 	this.contractData = {
			// 		value1: result[0].money,
			// 		value2: result[0].zong_money,
			// 		value3: result[0].freeze,
			// 	}
			// },

			//用户信息
			// async getAccountInfo() {
			// 	uni.showLoading({
			// 		title: this.$lang.API_GET_ACCOUNT_INFO
			// 	});
			// 	const result = await this.$http.get(`api/user/info`);
			// 	if (!result) return false;
			// 	this.userInfo = result
			// }
		},
	}
</script>
<style lang="scss" scoped>
	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 12rpx;
		margin: 0 20rpx;
		line-height: 1.4;
	}
</style>