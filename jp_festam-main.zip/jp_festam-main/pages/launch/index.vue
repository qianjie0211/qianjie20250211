<template>
	<view class="launch">

		<view style="text-align: center;padding-top: 10vh;">
			<image src='/static/logo.png' mode="aspectFit" :style="$theme.setImageSize(420)">
			</image>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/lanuch_sc.png" mode="aspectFit" :style="$theme.setImageSize(352)"></image>
		</view>
		<view class="bold" style="text-align: center;font-size: 36rpx;font-family: 900;color:#595857;padding-top: 20vh;">
			{{$lang.LAUNCH_TITLE}}
		</view>

		<ProgressThird></ProgressThird>
	</view>
</template>

<script>
	import ProgressThird from './components/ProgressThird.vue';
	export default {
		components: {
			ProgressThird,
		},
	}
</script>

<style lang="scss" scoped>
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		// background-image: linear-gradient(135deg, #29F5F4, #F82A6B);
		position: relative;
	}
</style>