<template>
	<view style="background-image: url(/static/xin_bg.png);background-size: contain;background-repeat: no-repeat;">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<view class="flex " style=" justify-content: space-between;padding: 20px 10px;">
			<view class="flex" style="padding: 8px;" @click="chaxuan()">
				<image src="/static/sousuo.png" mode="widthFix" style="width: 230px;height: 35px;"></image>
			</view>
			<view class="flex" style="background-color: #feedde;padding: 5px 15px;border-radius: 30px;">
				<!-- <image src="/static/sandian.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;"
					@click="isShowList=true"></image> -->
				<!-- <image src="/static/shuxian.png" mode="widthFix" style="width:2rpx;"></image> -->
				<image src="/static/sykefu.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 10px;"
					@click="$util.linkCustomerService()">
				</image>
			</view>

		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->
		<!-- <view>
			<image src="/static/banner.png" style="width: 95%;margin-left: 2.5%;margin-top: 10px;" mode="widthFix"></image>
		</view> -->
		<!-- <view style="padding: 150px 10px;">
			<ButtonGroup></ButtonGroup>
		</view> -->

		<!-- <view style="margin:10px 40rpx;">
			<TitlePrimary>
				
			</TitlePrimary>
		</view> -->
		<view style="background-color: #fff5e7;margin-top: 140px;border-radius: 10px 10px 0px 0px;">
			<view style="padding:10px 10px;">
				<view
					style="background-color: #fffefc;border-radius: 10px;padding-top: 15px;border: 1px #fff solid;box-shadow: 20px rgba(0, 170, 0, 0.1);">
					<ButtonGroup></ButtonGroup>
				</view>
			</view>

			<view>
				<!-- <view class="bold" style="padding: 0px 10px;padding-top: 20px;">{{$lang.TRADE_EA_OIFJ}}</view> -->
				<view class="flex flex-b" style="background-color: #fff5e7;border-radius: 20px;padding:10px 5px;  ">
					<view
						style="background-image: url(/static/zhishu2.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;width: 48%;padding: 5px;">
						<block v-for="(item,index) in top1.slice(0,1)" :key="index">

							<view style="padding: 5px 10px;border-radius: 15px;line-height: 1.5;"
								@click='handleChangeType(index)'>
								<view class=" bold">
									<view class="flex">
										<view class="font-size-16 flex-1" style="color: #000;">
											{{item.name}}
										</view>
										<view class="font-size-12 " style="color: #999;">
											{{item.code}}
										</view>
									</view>

									<view class="flex">
										<view>
											<view :style="{ color: item.rate > 0 ? 'darkgreen' : 'red' }" class="font-size-16">
												{{$util.formatMoney(item.current_price)}}
											</view>
											<view :style="{ color: item.rate > 0 ? 'darkgreen' : 'red' }" class="font-size-15">
												%{{$util.formatMoney(item.rate)}}
											</view>
										</view>
										<!-- <image src="/static/youjian.png" mode="widthFix" style="width: 30px;margin-left: auto;"></image> -->
									</view>

								</view>
							</view>
						</block>
					</view>
					<view
						style="background-image: url(/static/zhishu.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;width: 48%;padding: 5px;">
						<block v-for="(item,index) in top1.slice(2, 3)" :key="index" v-if="index<=0">

							<view style="padding: 5px 10px;border-radius: 15px;line-height: 1.5;"
								@click='handleChangeType(index)'>
								<view class=" bold">
									<view class="flex">
										<view class="font-size-16 flex-1" style="color: #000;">
											{{item.name}}
										</view>
										<view class="font-size-12 " style="color: #999;">
											{{item.code}}
										</view>
									</view>

									<view class="flex">
										<view>
											<view :style="{ color: item.rate > 0 ? 'darkgreen' : 'red' }"
												class="font-size-16">
												{{$util.formatMoney(item.current_price)}}
											</view>
											<view :style="{ color: item.rate > 0 ? 'darkgreen' : 'red' }"
												class="font-size-15">
												%{{$util.formatMoney(item.rate)}}
											</view>
										</view>
										<!-- <image src="/static/youjian.png" mode="widthFix" style="width: 30px;margin-left: auto;"></image> -->
									</view>

								</view>
							</view>
						</block>
					</view>

				</view>
				<view class="flex " style="padding: 5px 10px;">
					<image src="/static/xinwentu.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
					<view class=" bold font-size-15 margin-left-10 margin-top-5">{{$lang.API_UJGTIR}}</view>
				</view>

				<MarketNewsTop></MarketNewsTop>
				<view style="margin:0rpx 20rpx;">
					<TitlePrimary :title="$lang.STOCK_ALL"></TitlePrimary>
				</view>

				<view
					style="padding:10rpx 0rpx;background-color: #FFFFFF;margin:0 20rpx 40rpx 20rpx;border-radius: 32rpx;">
					<MarketHot ref="hot"></MarketHot>
				</view>
			</view>

			<u-picker :show="isShowList" :columns="[$util.LANGUAGE_LIST]" @change="changeLang"
				@cancel="isShowList=false" @confirm="confirmLang" :cancelText="$lang.BTN_CANCEL"
				:confirmText="$lang.BTN_CHANGE_BANK_CARD" :cancelColor="$theme.MODAL_CANCEL"
				:confirmColor="$theme.PRIMARY" keyName="name" visibleItemCount="9"></u-picker>



			<!-- IPO申购成功弹层 -->
			<IPOSuccessAlert></IPOSuccessAlert>
		</view>
	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import MarketNewsTop from '../market/components/MarketNewsTop.vue';
	import MarketHot from '../market/components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	var uChartsInstance = {};
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			TitlePrimary,
			CardItemPrimary,
			MarketNewsTop,
			MarketHot,
			IPOSuccessAlert,
		},
		data() {
			return {
				curTab: 0, // 国内走势ITEM
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				isAnimat: false, // 页面动画
				isActLang: true, // 当前登入用户是否开启多语言权限	
				cardInfo: {}, // 资产卡
				isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.27
				isShowList: false, // 多语言备选
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
				top1: [],
				timer: null,
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			// 今日
			setToday() {
				// return this.$util.formatToday(new Date());
			}
		},

		onShow() {
			this.getAccountInfo();
			this.isAnimat = true;
			this.getData();
			this.setTimeout()
		},
		onHide() {
			this.isAnimat = false;
			if (this.timer) this.clearTimer();
		},
		onUnload() {
			if (this.timer) this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			if (this.timer) this.clearTimer();
		},

		methods: {

			setTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.$refs.hot.getList()
					this.getData();
				}, 3000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			chooseLang() {
				this.isShowList = true;
			},
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				// this.curLang = e.value[0].name;
				this.isShowList = false;
				uni.setStorageSync('lang', e.value[0].lang);
				this.$forceUpdate();
				// uni.reLaunch({
				// 	url: this.$paths.HOME,
				// })
				window.location.reload()
			},
			setBackgroundImageStyle(item) {
				const image = item.rate > 0 ? '/static/zhishu.png' : '/static/zhishu.png';
				return {
					backgroundImage: `url(${image})`,
					backgroundSize: 'cover',
					backgroundRepeat: 'no-repeat',
				};
			},
			setBackgroundImage(item) {
				const image = item.rate > 0 ? '/static/zhishul.png' : '/static/zhishul.png';
				return {
					backgroundImage: `url(${image})`,
					backgroundSize: 'cover',
					backgroundRepeat: 'no-repeat',
				};
			},
			async getData() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/top1`, {
					current: 0,
					stockid: this.stockId
				});
				// console.log('getData:', result);
				if (!result) return false;
				this.top1 = result.top1
				this.article = result.article;
				this.industryList = result.bottom;

				// if (!this.kLineChart) {
				// 	this.kLineChart = init('chart-type-k-line')
				// 	this.kLineChart.setStyles({
				// 		"candle": {
				// 			"type": "area",
				// 			"tooltip": {
				// 				"showRule": "none",
				// 			}
				// 		},
				// 	});
				// }
				// this.kLineChart.applyNewData(result.kline)
			},
			handleChangeType() {
				uni.reLaunch({
					url: '/pages/market/overview'
				})
			},

			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=3`,
				})
			},
			chaxuan() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			// kefu() {
			// 	uni.navigateTo({
			// 		url: '/pages/service'
			// 	})
			// },
			xiaoxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				// console.log('info result：', result);
				if (!result) return false;
				this.cardInfo = {
					value1: result.totalZichan || 0,
					value2: result.money || 0,
					value3: result.freeze || 0,
				};
			}
		},
	}
</script>