<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding:30rpx;background-color: #FFFFFF;margin:30rpx 20rpx;border-radius:24rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:1 0 80%;color:#121212;font-size: 36rpx;">
							{{item.goods_info.name}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.COIN_CURRENT_PRICE}}</view>
						<view style="color:#00AA98;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.price,3)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.order_buy.num}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.YONGHU_ZHIFU}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.user_pay,3)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.yingkui,3)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.order_sn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.MAIRU_SHIJIAN}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.buy_time}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeSellList',
		components: {
			EmptyData
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 获取持有列表数据
			async getList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 2, // 1持仓，2历史
					gp_index: 0,
				});
				console.log(`result:`, result);
				if (!result) return false;
				// check data
				const temp = result.filter(item => item.goods_info && item.order_buy && item.order_sell);
				this.list = temp;
				console.log(`list:`, this.list);
			},
		}
	}
</script>

<style>
</style>