<template>
	<view>
		<view class="mask" @click="isShow=false"></view>
		<view class="modal_wrapper">
			<view
				style="background-color:#151517;border-radius: 24rpx 24rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
				<view style="text-align: center;font-size: 32rpx;font-weight: 700;color:#FFFFFF;">
					{{$lang.CONTRACT_DESC_MODAL_TITLE}}
				</view>
				<view style="padding: 40rpx;line-height: 1.6;">
					<view style="color:#C9C9C9;padding-bottom: 40rpx;">{{$lang.CONTRACT_DESC_Q}}</view>
					<view style="font-size: 28rpx;color:#8E8D92;">{{$lang.CONTRACT_DESC_A}}</view>
				</view>
				<view
					style="margin:28rpx auto;width: 90%;border-radius:50rpx;background-color: #16E2E2;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
					@tap="handleClose()">
					{{$lang.CONTRACT_DESC_BTN}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'ContractDesc',
		data() {
			return {
				isShow: false,
			}
		},
		methods: {
			handleClose() {
				this.isShow = false;
				this.$emit('action', 1);
			},
		}
	}
</script>

<style lang="scss" scoped>
	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>