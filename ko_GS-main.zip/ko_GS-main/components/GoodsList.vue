<template>
	<view class="" style="margin-top: 0rpx;">
		<!-- <view
			style="border-radius:16rpx 0 7px 0px;padding:4px 10px;width: 70px;text-align: center;font-size: 13px;color: #fff;background-color: #38AA9A;">
			{{$lang.ALL_MSG}}
		</view> -->

		<EmptyData v-if="list.length<=0"></EmptyData>

		<block v-for="(item,index) in list.slice(0, 15)" :key="index">
			<view style="padding: 5px 8px;">
			<view style="padding: 12rpx 10rpx;display: flex;align-items: center;border-radius: 10px;background-color: #f5f5f5;"
				
				@click="$u.route('/pages/productDetails/productDetails',{code:item.code});">

				<view style="flex: 6%;padding:10rpx 0;">
					<template v-if="!item.logo || item.logo==''">
						<view :style="$util.setImageSize(60)"
							style="background-color:#18BFB4;text-align: center;line-height: 60rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
							{{item.ko_name.slice(0,1)}}
						</view>
					</template>
					<template v-else>
						<view style="display: flex;flex-direction: column;justify-content: center;">
							<image mode="aspectFit" :src="item.logo" :style="$util.setImageSize(60)"
								style="border-radius: 100%;"></image>
						</view>
					</template>
				</view>

				<view style="flex: 44%;padding-left: 10rpx;">
					<view>{{item.ko_name}}</view>
					<view style="font-size: 24rpx;color: #999;">{{item.code}}</view>
				</view>

				<view style="flex:30%;color:#121212;">
					{{$util.formatNumber(item.close*1)}}
				</view>

				<view style="flex:20%;" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
							:style="$util.setImageSize(20)"></image>
						<view>{{$util.formatMathABS(1*item.returns).toFixed(2)}}%</view>
					</view>
				</view>

			</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		props: ['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>