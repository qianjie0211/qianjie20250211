<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;">
		<HeaderSecond style="background-color: #F8C351;" :title="info.title" :color="$theme.SECOND"></HeaderSecond>
<!-- 		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx; margin-top: 20px;" :style="{color:$theme.SECOND}">
			{{info.title}}</view> -->

		<view style="padding: 40rpx;">
			<template v-if="info.content && info.content.length>0">
				<view v-html="info.content" style="color:#333333"></view>
			</template>
			<template v-else>
				<view style="color:#333333;text-align: center;">{{$lang.API_EMPTY_CONTENT}}</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
			};
		},
		computed: {},
		onLoad() {
			this.getData();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 获取数据
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/article/privacy`);
				console.log('result:', result);
				if (!result) return false;
				this.info = {
					title: result.title || this.$lang.PRVITE_PACT_TITLE,
					content: result.content,
				}
			}
		}
	}
</script>