<!-- 行情 -->
<template>
	<view class="common_page_bg2 " style="min-height: 100vh;">
		<!-- <Header :title="$lang.MARKET_QUOTATION"></Header> -->
		<view class="flex" style="justify-content: space-between;padding:25px 15px;">
			<image src="../../static/sy_logo.png" mode="widthFix" style="width: 35px;"></image>
			<view class="flex" style="background-color: #fff;padding: 5px 10px;border-radius: 30px;">
				<view class="common_header_right" @click="$u.route({url:'/pages/service/service'});">
					<image mode="aspectFit" src="/static/sy_kf.png" :style="$util.calcImageSize(20)"></image>
				</view>
				<view class="common_header_right margin-left-10" @click="$u.route({url:'/pages/email/email'});">
					<image mode="aspectFit" src="/static/sy_tz.png" :style="$util.calcImageSize(20)"></image>
				</view>
			</view>
		</view>
        
		<view style="padding: 0px 15px;margin-top: -10px;">
		<view class="sc_bg">
			<ButtonGroup :btns="$util.mqBtnsConfig()" @action="handleBtnClick" col="33.33"></ButtonGroup>
		</view>
		</view>

		<view>
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	export default {
		components: {
			Header,
			ButtonGroup,
			TabOne,
			TabTwo,
			TabThree,
		},
		data() {
			return {
				current: 0
			}
		},
		onShow() {},


		methods: {
			handleBtnClick(index) {
				this.current = index;
			},
		},

		mounted() {},

		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">

</style>