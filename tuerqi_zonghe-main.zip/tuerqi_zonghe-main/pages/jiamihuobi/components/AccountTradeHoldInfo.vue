<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto;padding-bottom: 80rpx;">
			<view class="popup_header" style="display: flex;align-items: center;justify-content:space-between;">
				<text :style="{color:$theme.STOCK_NAME}"
					style="font-size: 36rpx;text-align: center;flex:1 0 90%;">{{info.name}}</text>
				<image src="/static/close.png" :style="$theme.setImageSize(40)" @click="actionEvent()"></image>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_TIME}}</view>
				<view :style="{color:$theme.BLACK}">{{info.buyCreateTime}}</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FLOAT_PROFIT}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatMoney(info.floatProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>

			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_PROFIT}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatMoney(info.profit*1)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_PRICE}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatMoney(info.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>

			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_QTY}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatNumber(info.buyNum)}}
				</view>
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LEVER}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{info.lever}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FEE}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatMoney(info.buyFee)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>
			<view class="item">
				<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_AMOUNT}}
				</view>
				<view :style="{color:$theme.BLACK}">
					{{$util.formatMoney(info.amount)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>

			<view style="display: flex;justify-content: space-between;margin:30rpx 60rpx;">
				<view class="common_btn" style="width: 40%;" @tap="linkStockInfo(info.code)">
					{{$lang.BTN_DETAIL}}
				</view>
				<view class="common_btn" style="width: 40%;" @tap.stop="handleSell(info.id)">
					{{$lang.BTN_SELL}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'AccountTradeHoldInfo',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
			}
		},

		methods: {
			// 跳转到股票详情
			linkStockInfo(code) {
				uni.navigateTo({
					url: `${this.$CONSTANTS.STOCK_OVERVIEW}?code=${code}`
				});
			},

			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id
				});
				console.log(result);
				this.actionEvent()
			},
		}
	}
</script>

<style lang="scss">
	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 12rpx;
		margin: 0 20rpx;
		line-height: 1.8;
	}
</style>