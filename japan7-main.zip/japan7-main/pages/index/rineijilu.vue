<template>
	<view>
	<view class="flex" style="background-color: #010245;height: 100px;">
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;" @click="home2()" ></image>
		<view style="color: #fff; font-size: 18px;margin-left: 120px;">申請記録</view>
		</view>
	
	<view style="background-color: #f1f4ff;width: 100%; border-radius: 10px;height: 80px;margin-top: -10px;"></view>
		<view class="flex bold" style="margin-top: -50px;font-size: 18px;margin-left: 50px;">
			<view class="flex-2" style="font-size: 18px;" @click="dianji(1)" :class="top_index==1?'active':''">注文詳細</view>
		<view class="flex-1" style="font-size: 18px;" @click="dianji(2)" :class="top_index==2?'active':''">申請内容</view>
		</view>
		<view style="background-color: #fff;width: 90%;margin: 20px;border-radius: 10px;height: 160px;" v-if="top_index==1&&list" v-for="(item,index) in list">
			<view style="padding: 10px;">
			<view class="margin-top-5 bold font-size-16">{{item.zt}}</view>
			<view class="margin-top-5">取引金額</view>
			<view class="margin-top-10 font-size-16 bold">{{item.money}}</view>
			<view class="flex margin-top-5">
				<view>株価収益率</view>
				<view style="margin-left: 200px;">{{item.syl}}</view>
			</view>
			<view class="flex margin-top-5">
				<view>申請日</view>
				<view style="margin-left: 120px;">{{item.created_at}}</view>
			</view>
			</view>
			
		</view>
		
			<view style="background-color: #fff;width: 90%;margin: 20px;border-radius: 10px;height: 160px;"v-if="top_index==2&&list" >
				<view style="padding: 10px;">
				<view class="margin-top-5 bold font-size-16">9999</view>
				<view class="flex">
				<view class="margin-top-5">取引金額</view>
				<button style="width: 60px; font-size: 14px;margin-right: 30px;background-color: #010245;color: #fff;" @click="sell(item.id)">売る</button>
				</view>
				<view class="margin-top-10 font-size-16 bold">665</view>
				<view class="flex margin-top-5">
					<view>注文番号</view>
					<view style="margin-left: 200px;">55</view>
				</view>
				<view class="flex margin-top-5">
					<view>申請日</view>
					<view style="margin-left: 200px;">88555</view>
				</view>
				</view>
	</view>
	
	
	</view>
		
	</view>
</template>

<script>
	export default {
		data() {
	
			return {
				money: "",
				top_index: 1,
				list: "",
	
			}
		},
	
		methods: {
			dianji(index) {
				this.top_index = index;
				this.list=""
				if (index == 1) {
					this.order_list()
				}else if (index == 2) {
					this.sell_list()
				}
			},
			jiaoyi() {
				uni.navigateBack({
					url: `/pages/index/rineijilu`
				});
			},
			home2() {
						uni.navigateBack({
								delta: 1, //返回层数，2则上上页
							});
						},
			async sq_list() {
			
				let list = await this.$http.get('api/Rinei/sq_list', {
					money: this.money
				})
			
				this.list = list.data.data
			
			},
			async sell(id) {
			
				let list = await this.$http.post('api/Rinei/sell', {
					id: id
				})
				this.order_list()
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
					return uni.$u.toast(list.data.data);
				}
				
			},
			async sell_list() {
			
				let list = await this.$http.get('api/Rinei/sell_list', {
					money: this.money
				})
			
				this.list = list.data.data
			},
			async order_list() {
	
				let list = await this.$http.get('api/Rinei/order_list', {
					money: this.money
				})
	
				this.list = list.data.data
				console.log(this.list );
	
			},
			async buy() {
				if (this.money <= 0) {
					return uni.$u.toast("金額を入力してください");
				}
				let list = await this.$http.get('api/Rinei/buy', {
					money: this.money
				})
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
					this.money=0;
					this.dianji(1)
					return uni.$u.toast(list.data.data);
					
				}
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},
	
		onShow() {
			this.gaint_info()
			this.is_token()
			this.dianji(1)
		},
		onLoad() {
	
		},
	
	}
</script>

<style>
</style>