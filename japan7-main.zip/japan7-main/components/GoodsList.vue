<template>
	<view >
		<view style="padding: 5px 0 5px 0; margin-top: 20px;background-color: #f3fcfb;border-radius: 10px;">
			<text style="padding: 5px 30px; background-color: #38aa9a;border-radius: 10px 0px 10px 0px;">銘柄</text>
		</view>
		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)" 
				style="padding: 5px; margin:8px 10px;display: flex;align-items: center;">
				
				<view style="display: inline-block;flex:30%;padding-left: 6px;" >
					<view>{{item.name}}</view>
					
					<view style="color:#626262;">{{item.code}}</view>
				</view>
				<view class="bold"  style="flex:20%;margin-left: 50px;font-size: 15px;">
					{{item.close}}
				</view>
				
				<view style="display: inline-block;flex:5%;text-align: right;font-weight: 700;">
					
					<view style="display: inline-block;padding:4px;font-size: 10px;color: crimson;">
						<view class="flex">
						<image src="/static/sanjiaozhang.png" mode="widthFix" style="width: 10px;height: 10px;margin-right: 10px;"></image>
						{{(1*item.returns).toFixed(2)}}%
						</view>
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
			this.sockets()
		},
		onHide() {
			clearInterval(this.timer);
			uni.closeSocket({
				success: () => {
				},
			})
		},
			
		onUnload() {
			uni.$off('onSuccess');
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
				},
			})
		},
		methods: {
			sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data=JSON.parse(res.data);
					// console.log(data);
			
					this.list.forEach(item => {
					    if (item.stock_id === data.pid) {
					        item.close = data.last;
							let rate=data.pcp.replace("+",'')
							rate=rate.replace("%",'')
							
							item.returns = rate;
							
							// item.rate_num = data.pc;
					    }
					});
					// console.log(data.pid);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {

				// this.list=[]
				let list = await this.$http.post('api/goods/top2', {
					current: 0,
					limit:50
				})
				// if(this.page==1){
				this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
		}
	}
</script>