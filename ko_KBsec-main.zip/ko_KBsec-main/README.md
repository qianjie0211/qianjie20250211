# ko_nh
fork NHIP

```
<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
```

# UI
```
https://lanhuapp.com/link/#/invite?sid=lx0nHmkZ
```


# 页面

- ✅ launch:启动页
- ✅ signIn:登入
- ✅ signUp:注册
- ✅ pact:隐私协议


- about:关于我们
- search:搜索
- notify:公告列表、详情、首页滚动最新公告
- home:首页
- market/index:市场 [关注、股票列表、热门、指标]
- ✅ stock/overview:股票概览
- market/overview:市场概览、热门、指标、新闻
- password:变更登入密码、变更支付密码
- bankCard:绑定银行卡。移除原状态切换逻辑，即当前页面直接修改。
- ✅ deposit:充值
- ✅ withdraw:提现 
- flow:资金流水
- notify:消息中心
- account/center:个人中心
- auth:实名认证
- position:持仓

##  主营业务
- ✅ trade/day:日内交易 (AI智能交易) 
- ✅ trade/block:大宗交易 (当前项目，无需密码查看)
- ✅ trade/ipo:IPO交易
- trade/vip: VIP抢筹 
- ✅ trade/issuance:新股配售 

```
弹层无法遮蔽tabbar解决方案：
uni.hideTabBar(); // 隐藏tabBar
uni.showTabBar(); // 显示tabBar
```

# Update Log 2024.06.04
- 定义通用动画。
- 所有页面添加`fadeIn`、`fadeOut`。
- 部分组件添加动画效果。