<template>
	<view :class="isAnimat?'fade_in':'fade_out'" >
		<HeaderSecond :title="$lang.TRADE_DAY_TITLE" :color="$theme.SECOND"></HeaderSecond>
		<view style="position: relative;">
			<image src="/static/rn_bg.png" mode="widthFix" style="width: 100%;height: 130px;"></image>
		</view>
		
		<view style="padding:0px 10px;margin-top: -20px; position: absolute;width: 95%;">
			<view class="flex flex-b" style="background-color: #fff;padding:15px 30px;border-radius: 10px;border: 1px #33d669 solid;" >
				<view @click="changeTab(0)">
					<image src="/static/tb_ee.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">단타 급등주</view>
				</view>
				<view @click="changeTab(1)">
					<image src="/static/tb_qq.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">신청상태</view>
				</view>
				<view @click="changeTab(2)">
					<image src="/static/tb_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">기록</view>
				</view>
			</view>
		</view>
		
		<view >
			<template v-if="curTab==0">
				<TradeDayBuy @action="changeTab"></TradeDayBuy>
			</template>

			<template v-else-if="curTab==1">
				<TradeDayOrderList></TradeDayOrderList>
			</template>
			<template v-else>
				<TradeDaySuccessList></TradeDaySuccessList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeDayBuy from './components/TradeDayBuy.vue';
	import TradeDayOrderList from './components/TradeDayOrderList.vue';
	import TradeDaySuccessList from './components/TradeDaySuccessList.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>