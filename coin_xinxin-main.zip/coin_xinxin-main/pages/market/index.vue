<template>
	<view style="background-image: url('/static/beiji.png');background-position: 0 0;
		 background-repeat: no-repeat;background-size: 100% 100%; min-height: 100vh; ">
		<!-- <image src="/static/beiji.png" mode="widthFix" style="width: 100%;"></image> -->

		<view :class="isAnimat?'fade_in':'fade_out'">
			<!-- <header style="padding-top: 60rpx;border-bottom: 1px Solid #E7E8ED;">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
				<view style="display: flex;margin:10px 10rpx;">
					<block v-for="(item,index) in tabs" :key='index'>
						<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
							{{item}}
						</view>
					</block>
				</view>
			</scroll-view>
		</header> -->

			<!-- <view :class="setClass" > -->
			<!-- <template v-if="curTab==0"> -->
			<MarketCoin ref="coin"></MarketCoin>
			<!-- </template>
			<template v-else>
				<MarketTrack ref="track" @action="linkTrack"></MarketTrack>
			</template> -->
			<!-- </view> -->
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	// import MarketTrack from './components/MarketTrack.vue';
	import MarketCoin from './components/MarketCoin.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			// MarketTrack,
			MarketCoin,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
			}
		},

		computed: {
			// // tabs设置。
			// tabs() {
			// 	return [
			// 		this.$lang.MARKET_INDEX_TAB_COIN,
			// 		this.$lang.MARKET_INDEX_TAB_TRACK,
			// 		// this.$lang.MARKET_INDEX_TAB_HOP,
			// 		// this.$lang.MARKET_INDEX_TAB_KPI
			// 	]
			// },
			// // 切换tab的动效
			// setClass() {
			// 	return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			// },
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.curTab == 0 && this.$refs.coin) this.$refs.coin.getList();
			// if (this.curTab == 1 && this.$refs.track) this.$refs.track.getList();
		},
		onReady() {
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			// changeTab(val) {
			// 	this.curTab = val;
			// },
			// // 设置样式
			// setStyle(val, w = 120) {
			// 	return {
			// 		width: `${w}rpx`,
			// 		padding: `12rpx 32rpx`,
			// 		color: val ? '#2f77fe' : '#000',
			// 		textAlign: 'center',
			// 		fontSize: `36rpx`,
			// 		fontWeight: `700`,
			// 		borderBottom: `4rpx Solid ${val? '#2f77fe' : '#f1f2f7' }`
			// 	}
			// },
			// linkTrack() {
			// 	this.changeTab(0);
			// },
		},
	}
</script>