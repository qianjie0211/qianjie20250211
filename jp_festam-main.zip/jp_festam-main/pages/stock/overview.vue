<template>
	<view :class="isAnimat?'fade_in':'fade_out'" >
		<view>
			<HeaderSecond :title="stockTitle" color="#FFFFFF"></HeaderSecond>

		</view>

		<view style="padding-bottom: 20px;margin-top: 10px;">
			<template v-if="stockInfo">
				<StockInfoPrimary :info="stockInfo"></StockInfoPrimary>


				<view
					style="background-color: #FFFFFF; min-height: 60vh;margin-top: 10px;width: 95%;border-radius: 10px;margin-left: 10px;">

					<view style="padding: 20px; justify-content: space-between;">

						<view class="flex" style="padding: 10px;">
							<view>
								<view :style="{color:$theme.TITLE}">
									<view class="bold" :style="{color:$theme.LOG_VALUE}"
										style="font-size: 16px;width: 110px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
										{{stockInfo.name}}
									</view>
								</view>
								<view class="flex-1" :style="{color:$theme.LOG_LABEL}" style="font-size: 16px;">
									{{stockInfo.code}}
								</view>
							</view>


							<view class="flex-1">
								<image :src="`/static/line_${stockInfo.rate*1>0?'rise':'fall'}.png`"
									style="width:100px;height: 30px;"></image>
							</view>


							<view>
								<view :style="$theme.setStockRiseFall(stockInfo.rate>0)" style="font-size: 18px;">
									{{$util.formatMoney(stockInfo.current_price)}} {{` ${$lang.CURRENCY_UNIT}`}}
								</view>
								<view>
									<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
										<image :src="`/static/arrow_${stockInfo.rate>0?'rise':'fall'}.png`"
											mode="aspectFit" :style="$theme.setImageSize(20)">
										</image>
										{{$util.formatMathABS(stockInfo.rate)}}%
									</view>
								</view>

							</view>

						</view>
					</view>

					<TabsSeventh :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"
						v-show="stockInfo.project_type_id==1"> </TabsSeventh>

					<view :style="{display:curTab==0?'block':'none' }">
						<view
							style="display: flex;align-items: center;justify-content: space-around;margin:0 10px;padding:8rpx 4rpx;border-radius: 6rpx;padding-right: 6rpx;">
							<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key="index">
								<!-- <view
									style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
									:style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
									{{item}}
								</view> -->
							</block>
						</view>
						<view style="padding:20rpx;">
							<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
							</view>
						</view>
					</view>
					<template v-if="curTab==0">
						<view
							style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
							<view class="text-center"
								style="margin:0 auto;width: 80%;background-color: #f2bc8e;padding: 10px;border-radius: 30px;color: #fff;font-size: 18px;"
								@click="linkBuy">
								{{$lang.BTN_BUY}}
							</view>
						</view>
					</template>

					<template v-if="curTab==1">
						<StockDetail :code='code' :id='stockInfo.stock_id'></StockDetail>
					</template>

					<template v-if="curTab==2">
						<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
					</template>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSeventh from '@/components/tabs/TabsSeventh.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import StockDetail from './components/StockDetail.vue'
	import StockNews from './components/StockNews.vue';
	import StockInfoPrimary from './components/StockInfoPrimary.vue';

	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';

	export default {
		components: {
			HeaderSecond,
			TabsSeventh,
			TabsFourth,
			StockDetail,
			StockNews,
			StockInfoPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				timer: null,
				socket: null,
				lishi: [], // k綫數據
			};
		},
		computed: {
			stockTitle() {
				return this.stockInfo && this.stockInfo.name ?
					this.stockInfo.name : this.$lang.STOCK_OVERVIEW_TITLE
			}
		},

		onLoad(option) {
			this.code = option.code || '';
			this.getData();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		methods: {
			// sockets() {
			// 	//创建webSocket
			// 	this.webSocketTask = uni.connectSocket({
			// 		url: this.$http.WssUrl,
			// 		header: {
			// 			'content-type': 'application/json'
			// 		},
			// 		success(res) {
			// 			console.log('成功', res);
			// 		},
			// 	})
			// 	// 监听WebSocket连接打开事件
			// 	this.webSocketTask.onOpen((res) => {
			// 		console.info("监听WebSocket连接打开事件", res)
			// 	});
			// 	// 监听WebSocket错误
			// 	uni.onSocketError((res) => {
			// 		console.info("监听WebSocket错误" + res)
			// 	});
			// 	var that = this;
			// 	// 接收websocket消息及处理
			// 	this.webSocketTask.onMessage((res) => {
			// 		var data = JSON.parse(res.data);
			// 		console.log(data);
			// 		if (that.stockInfo) {
			// 			if (that.stockInfo.stock_id == data.pid) {
			// 				console.log(2222);

			// 				let current_price = data.last.replace(",", '')
			// 				// current_price=current_price.replace("+",'')

			// 				that.stockInfo.current_price = current_price;
			// 				let rate = data.pcp.replace("+", '')
			// 				rate = rate.replace("%", '')

			// 				that.stockInfo.rate = rate;

			// 				that.stockInfo.rate_num = data.pc;
			// 				// that.qiehuan()
			// 				this.lishi[this.lishi.length - 1].close = current_price;

			// 				this.kLineChart.applyNewData(this.lishi)

			// 			}
			// 		}

			// 	});
			// },
			// websocket链接
			connect() {
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WssUrl);
				this.socket = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);

				if (this.socket) {
					// 监听WebSocket连接打开事件
					this.socket.onOpen((res) => {
						console.info("监听WebSocket连接打开事件", res)
					});
					// 监听WebSocket错误
					uni.onSocketError((res) => {
						console.info("监听WebSocket错误" + res)
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(`ws data:`, data, this.stockInfo);
						if (this.stockInfo.stock_id == data.pid) {
							this.stockInfo.current_price = parseFloat(data.last.replace(",", ''));
							this.stockInfo.rate = parseFloat(data.pcp.replace("%", ''));
							this.stockInfo.rate_num = data.pc;
							// 
							// this.stockInfo.info.ask = data.ask ? data.ask * 1 : 0;
							// this.stockInfo.info.last = data.last ? data.last * 1 : 0;
							// this.stockInfo.info.high = data.high ? data.high * 1 : 0;
							// this.stockInfo.info.low = data.low ? data.low * 1 : 0;
							// this.stockInfo.info.turnover = data.turnover ? data.turnover * 1 : 0;

							if (this.curKLine == 0) {
								this.lishi[this.lishi.length - 1].close = parseFloat(data.last.replace(",", ''));
								this.kLineChart.applyNewData(this.lishi)
							}
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},

			setStyle(val) {
				return {
					...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					color: val ? '#FFFFFF' : this.$theme.PRIMARY,
					borderRadius: `44rpx`,
					border: `1px solid ${val? this.$theme.TRANSPARENT:'#5A5A5A'}`,
				}
			},
			changeTab(val) {
				this.curTab = val;
			},
			handleShowKLine(val) {
				this.curKLine = val;
			},

			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb919'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},

			// 买入
			linkBuy() {
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?code=${this.code}`
				});
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 5000);
			},

			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			// 产品详情
			async getData() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				if (!result) return false;
				console.log(`info:`, result);
				this.stockInfo = result[0];
				if (!this.timer) {
					// 延时,等DOM渲染
					setTimeout(() => {
						if (!this.kLineChart) {
							this.kLineChart = init('chart-type-k-line');
							this.kLineInit(); // 初始化Kline
						}
						this.genKLineData(); // 获取并生成KLine数据	
					}, 50);
				}
				// 每5s執行該函數時，處理定時器
				if (this.timer) this.clearTimer();
				this.onSetTimeout();
			},

			// 获取并生成KLine数据
			async genKLineData() {
				console.log(`??`,this.stockInfo);
				const result = await this.$http.post(`api/product/lishi`, {
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "area" : "candle_solid",
					},
				});
				console.log(`kline:`, result);
				if (!result) return false;
				this.lishi = result;
				this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(result);
			},
		},
	}
</script>