<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex" style="padding:30px  20px;">
			<view class="flex-1" style="background-color: #fff;border-radius: 20px;padding: 5px 10px;">
				<view class="flex" @click="shouye()">
					<image src="/static/search_dark.png" mode="widthFix" style="width: 15px;"></image>
					<view style="margin-left: 5px;font-size: 10px;color: #999;">銘柄名/コードを入力してください</view>
				</view>
				
			</view>
			<view>
				<image src="/static/service.png" mode="widthFix" style="width: 25px;margin-left: 20px;" @click="kefu()"></image>
			</view>
		</view>
		<!-- <view  style="height: 120px;" >
			<header  style="padding-top: 60rpx;">
				<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;"
					@touchmove.stop>
					<view style="display: flex;margin:0 10rpx;">
						<block v-for="(item,index) in tabs" :key='index'>
							<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
								{{item}}
							</view>
						</block>
					</view>
				</scroll-view>
			</header>
			<view class="justify-center flex" style="padding: 30px 0px;">
				<view style="color: #FFFFFF;font-size: 20px;">株式市場</view>
			</view>
		</view> -->
		

		<view :class="setClass"
			style="padding: 20rpx 0;background-color: #FFFFFF;margin:20rpx 20rpx 0 20rpx;border-radius: 28rpx 28rpx 0 0;min-height: 100vh;">
			<view class="flex bold" style="padding: 5px 20px;justify-content: space-between;width: 40%;" >
				<view>
					<view style="font-size: 16px;"  @click="yan_show=false">国内株</view>
					<view style="border-bottom:3px solid #eecda5;" v-if="!yan_show"></view>
				</view>
				
				<view>
					<view style="font-size: 16px;" @click="yan_show=true">米国株</view>
					<view style="border-bottom:3px solid #eecda5;" v-if="yan_show"></view>
				</view>
				
			</view>
			
			
			
			<block v-for="(item,index) in setList" :key="index" v-if="!yan_show">
			<view class="flex" style="background-color: #fefaf5;width: 90%;margin-left: 10px;padding: 5px;border-radius: 10px;justify-content: space-between;margin-top: 10px;"@click="link(item.code)">
				
				<view>
					<view style="width: 95px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{item.name}}</view>
					<view style="color: #929191;">{{item.code}}</view>
				</view>
				<view>
					<image :src="`/static/line_${item.rate*1>0?'rise':'fall'}.png`" style="width: 80px;height: 30px;"></image>
				</view>
				<view>
					<view style="font-size: 16px;margin-left: 10px;">{{item.price}}</view>
					<view class="flex">
						<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="widthFix" style="width: 10px;margin-right: 5px;"></image>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)" >{{$util.formatNumber($util.formatMathABS(item.rate),2)}}%</view>
					</view>
				</view>
			</view>
			</block>
			
			
			
			<block v-for="(item,index) in meigu" :key="index" v-if="yan_show">
			<view class="flex" style="background-color: #fefaf5;width: 90%;margin-left: 10px;padding: 5px;border-radius: 10px;justify-content: space-between;margin-top: 10px;"@click="link(item.code)">
				
				<view>
					<view style="width: 95px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">
					{{item.name}}</view>
					<view style="color: #929191;">{{item.code}}</view>
				</view>
				<view>
					<image :src="`/static/line_${item.rate*1>0?'rise':'fall'}.png`" style="width: 80px;height: 30px;"></image>
				</view>
				<view>
					<view style="font-size: 16px;">{{item.price}}</view>
					<view class="flex">
						<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="widthFix" style="width: 10px;margin-right: 5px;"></image>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)" >{{$util.formatNumber($util.formatMathABS(item.rate),2)}}%</view>
					</view>
				</view>
			</view>
			</block>
			
			
			
			
			
			
			<!-- <template v-if="curTab==0">
				<MarketTrack ref="track" @action="linkStock"></MarketTrack>
			</template>
			<template v-else-if="curTab==1">
				<MarketStockList ref="all"></MarketStockList>
			</template> -->
			<!-- <template v-else-if="curTab==2">
				<MarketHot ref="hot"></MarketHot>
			</template>
			<template v-else>
				<MarketKPI ref="kpi"></MarketKPI>
			</template> -->
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList,
			MarketHot,
			MarketKPI
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
				list: [],
				meigu:[],
				
				 yan_show: false,

			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					// this.$lang.MARKET_INDEX_TAB_MARKET,
					// this.$lang.MARKET_INDEX_TAB_HOP,
					// this.$lang.MARKET_INDEX_TAB_KPI
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
			best() {
				if (this.list && this.list.length > 0) {
					return this.list.length <= 3 ? this.list : this.list.slice(0, 3);
				}
			},
			setList() {
				if (this.list && this.list.length > 0) {
					return this.list.length <= 3 ? [] : this.list.slice(3, this.list.length);
				}
			}
			
			
			
		},
		created() {
			this.getList();
			this.getmeigu();
		},
		

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onReady() {
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			toggleShow() {
				this.isShow = !this.isShow;
			},
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			shouye() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			changeTab(val) {
				this.getList();
				this.getmeigu();
			},
			async getList() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/top2`, {
					current: this.curTab
				})
				if (!result || result.length <= 0) return false;
				const temp = result.filter(item => item.stock_id && item.stock_id > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						// logo: item.logo,
						name: item.name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
						stockId: item.stock_id,
					}
				});
				// this.connect(); // 启动 websocket链接
			},
			async getmeigu() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/meigu_top`, {
					current: this.curTab
				})
				if (!result || result.length <= 0) return false;
				const temp = result.filter(item => item.AvgVolume && item.AvgVolume > 0);
				this.meigu = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						// logo: item.logo,
						name: item.Name,
						code: item.Symbol,
						price: item.Last,
						rate: item.ChgPct,
						follow: 0,
						gid: item.Id,
						close: item.Last,
						stockId: item.Id,
					}
				});
				// this.connect(); // 启动 websocket链接
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? '#FFFFFF' :this.$theme.TRANSPARENT }`
				}
			},
			linkStock() {
				this.changeTab(1);
			},
		},
	}
</script>
<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/bg_1.png);
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 160rpx;
	}
</style>