<!-- 关于我们 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<view style="padding: 40rpx;">
			<template v-if="info.content && info.content.length>0">
				<view v-html="info.content" :style="{color:$theme.PAGE_TITLE}"></view>
			</template>
			<template v-else>
				<view style="text-align: center;" :style="{color:$theme.PAGE_TITLE}">{{$lang.API_EMPTY_CONTENT}}</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
			};
		},
		computed: {},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getData();
			uni.stopPullDownRefresh();
		},
		methods: {
			//关于我们
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/article/about-us`);
				if (!result) return false;
				console.log('result:', result);
				this.info = {
					title: result.title || this.$lang.ABOUT_US_TITLE,
					content: result.content,
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>