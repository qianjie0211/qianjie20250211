<template>
	<view class="tabs_wrapper">
		<block v-for="(item,index) in tabs" :key='index'>
			<view :class="setClass(acitve==index)" @click="changeTab(index)">
				<view style="position: relative;height: 80rpx;padding: 0 20px;color: transparent;">
					{{item}}
					<template v-if="acitve==index">
						<view
							style="position: absolute;bottom: 0rpx;left: 0;right: 0;height: 10rpx;width: 32%; background-image:linear-gradient(90deg,#f55c48,#f55c48);border-radius: 16rpx;margin:0 auto;">
						</view>
					</template>
					<view
						style="position: absolute;top:16rpx;left: 0;right: 0;font-size: 32rpx;font-weight: 800;width: 100%;text-align: center;"
						:style="{color:acitve==index?$theme.SECOND:'#898996'}">
						{{item}}
					</view>
				</view>

			</view>
		</block>
	</view>
</template>

<script>
	export default {
		// 單行，激活項的文字帶有絕對定位的底邊
		name: "TabsThird",
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			changeTab(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
			setClass(val) {
				return `item ${val?'item_act':''}`
			},
		}
	}
</script>
<style lang="scss" scoped>
	.tabs_wrapper {
		display: flex;
		align-items: center;

		.item {
			flex: 1;
			border-radius: 16rpx;
			text-align: center;
			font-size: 32rpx;
			line-height: 1.8;
			color: #818181;
		}

		.item_act {
			color: #121212;
		}
	}
</style>