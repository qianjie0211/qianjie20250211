<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding: 30vh 0;padding-bottom: 5vh;">
			<image src='/static/app_logo.png' mode="aspectFit" :style="$theme.setImageSize(500,300)">
			</image>
		</view>
		
		<view style="display: flex;align-items: center;justify-content: center;padding: 10px 0;padding-bottom: 5vh;">
			<!-- <image src='/static/lanuch_sc.png' mode="aspectFit" :style="$theme.setImageSize(400,300)">
			</image> -->
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$theme.setImageSize(512)"></image>
		</view> -->
		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="bold" style="margin-top: 300px;text-align: center;font-size: 36rpx;font-family: 700;color:#d3b493;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view> -->

		<ProgressSecond></ProgressSecond>
	</view>
</template>

<script>
	import ProgressSecond from './components/ProgressSecond.vue';
	export default {
		components: {
			ProgressSecond,
		},
	}
</script>

<style lang="scss" scoped>
	.launch {
		width: 100%;
		height: 100vh;
		background-image: url(/static/launch_bg.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
	}
</style>