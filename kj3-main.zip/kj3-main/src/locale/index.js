import koKR from "./ko-KR";
import jaJP from "./ja-JP";
import enUS from "./en-US";

export default {
  "ko-KR": koKR,
  "ja-JP": jaJP,
  "en-US": enUS,
};
