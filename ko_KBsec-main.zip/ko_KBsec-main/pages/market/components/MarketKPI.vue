<template>
	<view>
		<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 20rpx 20rpx 20rpx;"
			@touchmove.stop>
			<block v-for="(item,index) in $lang.MARKET_INDEX_TABS" :key='index'>
				<view :style="setStyleTab(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</scroll-view>

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="display: flex;align-items: center;padding:16rpx 0;background-color: #F8F8F8;border-radius: 8rpx;margin:0 12rpx 20rpx 12rpx">
					<view style="width: 90rpx;text-align: center;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex:1 0 auto;">
						<view style="padding:0 20rpx;display: flex;align-items: center;">
							<view style="font-size: 28rpx;color: #121212;">
								{{item.name}}
							</view>
						</view>
						<view style="margin-left: auto;">
							<view style="display: flex;align-items: center;padding-right: 20rpx;">
								<view style="margin-left: auto;font-size: 26rpx;"
									:style="$theme.setStockRiseFall(item.rate>0)">
									{{item.rate>0?'+':'-'}} {{$util.formatNumber(item.price)}}
								</view>
								<view style="margin-left: auto;" :style="$theme.setStockRiseFall(item.rate>0)">
									{{item.rate>0?'+':'-'}} {{($util.formatNumber(Math.abs(item.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketKPI',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				curTab: 0,
			}
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.$emit('action', this.curTab);
			},
			// 设置样式
			setStyleTab(val) {
				return {
					color: val ? '#FFFFFF' : '#666666',
					borderRadius: `8rpx`,
					// border: `4rpx solid #38AA9A`,
					backgroundColor: val ? '#1C1C1C' : '#FFFFFF',
					minWidth: `80rpx`,
					margin: '10rpx',
					padding: `10rpx 16rpx`,
					textAlign: 'center',
					fontSize: `26rpx`,
					display: `inline-block`,
				}
			},
		}
	}
</script>

<style>
</style>