<template>
	<view style="margin-top: 90px;">
		
		<view style="background-color: #fff;min-height: 70vh;">
			<view class="flex flex-b padding-10 hui1" style="border-bottom: 1px #ccc solid;">
				<view>주식명/코드</view>
				<view>매입가격</view>
				<view>최대매입</view>
				<view>주문신청</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding: 20rpx; border-bottom: 1px #ccc solid;">
					<view class="flex">
						<view style="flex: 30%;">
							<view class="bold">{{item.name}}</view>
							<view class="font-size-12 hui1">{{item.code}}</view>
						</view>
						
						<view style="flex: 25%;">
							<view class="flex">
								<view style="font-size: 15px;font-weight: 600;color: #33d669;">{{$util.formatMoney(item.price)}}</view>
								<view class="margin-left-5">원</view>
							</view>
							<!-- <view class="flex">
								<view class="hui1" style="font-size: 16px;font-weight: 500;margin-left: auto;">{{item.day}}</view>
								<view class="margin-left-5">일</view>
							</view> -->
						</view>
						
						<view style="flex: 25%;">
							<view class="flex">
								<view style="font-size: 16px;font-weight: 600;">{{item.max_num}}</view>
								<view class="margin-left-5">주</view>
							</view>
						<!-- 	<view class="flex">
								<view class="hui1" style="font-size: 16px;font-weight: 500;">{{item.max_num}}</view>
								<view class="margin-left-5">주</view>
							</view> -->
						</view>
						<view :style="setStyle()" @click="handleDetail(item)">
							주문
						</view>
						
					</view>
					
					
					
				</view>
			</block>
		</view>
		<template v-if="isShow">
			<TradeLargeBuy :info="itemInfo" @action="handleClose"></TradeLargeBuy>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeLargeBuy from './TradeLargeBuy.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeLargeList',
		components: {
			CustomTitle,
			EmptyData,
			TradeLargeBuy,
			CustomLogo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		computed: {},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: '#33d669',
					color: '#fff',
					borderRadius: `10rpx`,
					minWidth: `60rpx`,
					padding: `15rpx 20rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},

			handleDetail(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
						day: item.day,
					}
				});
			},
		},
	}
</script>