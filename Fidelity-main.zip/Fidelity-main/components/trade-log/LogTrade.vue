<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="margin-bottom:20px;padding:10px;border-radius: 10px;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_AMOUNT_BEFORE}}
					</view>
					<view>
						<view style="color: #fff;">
							{{`€ `+$util.formatMoney(`${item.before*1}`,3)}}
						</view>
						<view style="color: #AAA;font-size: 12px;text-align: right;">
							{{`$ `+$util.formatUSD(`${item.before*eurToUsd}`,3)}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_AMOUNT_AFTER}}
					</view>
					<view>
						<view style="color: #fff;">
							{{`€ `+$util.formatMoney(`${item.after*1}`,3)}}
						</view>
						<view style="color: #AAA;font-size: 12px;text-align: right;">
							{{`$ `+$util.formatUSD(`${item.after*eurToUsd}`,3)}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_DW}}
					</view>
					<view>
						<view :style="$theme.setStockRiseFall(item.money*1>0)">
							{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
						</view>
						<view style="color: #AAA;font-size: 12px;text-align: right;">
							{{`$ `+$util.formatUSD(`${item.money*eurToUsd}`,3)}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style=" color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style=" text-align: right;color: #fff;">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view style=" color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_DESC}}:</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: flex-end;">
					<text
						style="white-space:pre-wrap;text-align: right;color: #fff;font-size: 12px;">{{item.desc}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				eurToUsd: 1, // 欧转美
			};
		},
		beforeMount() {
			this.getList();
			this.getconfig();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/user/finance`);
				if (!result) return false;
				this.list = result;
			},
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		}
	}
</script>

<style>

</style>