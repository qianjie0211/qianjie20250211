<!-- 实时传输 -->
<template>
	<view >
		<CustomHeader title="出金" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">

			<view class="text-center font-size-20">
				即時出金
			</view>
			<view class="text-center bold margin-top-10 font-size-24">
				{{$util.formatNumber(userInformation.money*1)}}円
			</view>

			<view style="color: #181945;width: 50%;margin-left: 25%;"
				class="radius10 color-white text-center margin-top-10">
				出金可能金額
			</view>

			<view class="margin-top-20 hui2">
				<view>銀行名</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true"  border="surround" v-model="value4" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c"
						 >
					</u--input>
				</view>
			</view>
			
			<view class="margin-top-20 hui2">
				<view>支店名</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true" border="surround" v-model="value5" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
					</u--input>
				</view>
			</view>
			<view class="margin-top-20 hui2">
				<view>支店番号</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true" border="surround" v-model="value6" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
					</u--input>
				</view>
			</view>
			<view class="margin-top-20 hui2">
				<view>取引種類</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true" border="surround" v-model="value7" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
					</u--input>
				</view>
			</view>
			<view class="margin-top-20 hui2">
				<view>口座名義</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true" border="surround" v-model="value8" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
					</u--input>
				</view>
			</view>
			<view class="margin-top-20 hui2">
				<view>口座番号</view>
				<view class="margin-top-10">
					<u--input placeholder="" :disabled="true" border="surround" v-model="value9" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
						
					</u--input>
				</view>
			</view>
			<view class="margin-top-20 hui2">
				<view>出金金額</view>
				<view class="margin-top-10">
					<u--input placeholder="出金金額を入力してください" border="surround" v-model="value1" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
						<template slot="suffix">
			
							<view @click="whole(userInformation.money)">全額</view>
			
						</template>
					</u--input>
				</view>
			</view>

			<view class="margin-top-20 hui2">
				<view>資金パスワード</view>
				<view class="margin-top-10">
					<u--input placeholder="6桁のパスワードを入力してください" border="surround" v-model="value2" shape="circle" customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c"></u--input>
				</view>
			</view>
			<view class="margin-top-30 text-center radius10 padding-10 color-white" style="background-color: #4b5fcc;"
				@click="to_withdraw()">
				出金
			</view>

			<view class="guize">
				<view>1. 収益を出金するには、売却時点から2営業日待つ必要がありますのでご了承ください。</view>
				<view>2. 出金する前に、本人確認と口座登録の必要があります。</view>
				<view>3. 出金可能時間：平日午前9時から午後6時まで（土日祝日は出金できません）。</view>
				<view>4. 出金の最低金額は10,000円です。</view>
				<view style="color:#ff3636"> 5. 出金申請後、基本的には当日に着金し、2時間以内に入金されます。</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				value4: "",
				value5: "",
				value6: "",
				value7: "",
				value8: "",
				value9: "",
				userInformation: ''
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async to_withdraw() {
				uni.showLoading({
					title: "出金中ですのでお待ちください...。",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
					bank_name: this.value4,
					bank_sub_name: this.value5,
					zd_number: this.value6,
					qy_type: this.value7,
					realname: this.value8,
					card_sn: this.value9,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.value4 = list.data.data.bank_card_info.bank_name
				this.value5 = list.data.data.bank_card_info.bank_sub_name
				this.value6 = list.data.data.bank_card_info.zd_number
				this.value7 = list.data.data.bank_card_info.qy_type
				this.value8 = list.data.data.bank_card_info.realname
				this.value9 = list.data.data.bank_card_info.card_sn
				
			
				
			},


		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {

		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;

	}

	.guize {
		margin-top: 10px;

		view {
			padding-top: 2px;
			font-size: 12px;

			text {
				color: #ff3636;
			}
		}
	}
</style>