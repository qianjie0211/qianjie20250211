<template>
	<view style="padding:0 18px; padding-bottom: 100rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin-top:24rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view :style="setStyle(item.status)"> {{item.zt}} </view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_DAY_BUY_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.money)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_DAY_SUCCESS}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.success||0)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_DAY_ORDER_SN}}
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.ordersn}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_DAY_CREATE_TIME}}
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			// 申请状态样式
			setStyle(val) {
				// 背景色
				const temp = ['#FFB044', '#03B467', '#FF2D30'];
				// 文字色
				// const tempColor = [
				// 	'#FFB044', this.$theme.PRIMARY, this.$theme.THIRD,
				// ];
				return {
					// PRIMARY
					backgroundColor: this.$theme.RGBConvertToRGBA(temp[val], 10),
					color: temp[val],
					borderRadius: `6rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
					// minWidth: `80rpx`,
					padding: `2rpx 12rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>