<template>
	<view :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/wode_bgp.png);background-size: contain;background-repeat: no-repeat;">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<view class="flex " style=" justify-content: space-between;padding: 20px 10px;">
			<view class="flex" style="padding: 8px;" @click="chaxuan()">
				<view class="flex" @click="chaxuan()">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 240px;35px"></image>
				</view>
			</view>
			<view class="flex" style="background-color: #feedde;padding: 5px 15px;border-radius: 30px;">
				<!-- <image src="/static/sandian.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;"
						@click="$util.linkCustomerService()"></image> -->
				<!-- <image src="/static/shuxian.png" mode="widthFix" style="width:2rpx;"></image> -->
				<image src="/static/notify.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 10px;"
					@click="xiaoxi()">
				</image>
			</view>
			<!-- <image src="/static/sykefu.png" mode="widthFix" style="width: 25px;height: 25px;" @click="$util.linkCustomerService()"></image>
				<image src="/static/notify.png" mode="widthFix" style="width: 25px;height: 25px;" @click="xiaoxi()"></image> -->
		</view>

		<view style="">
			<Profile :info="userInfo"></Profile>
			<view style="padding: 0px 10px;">
				<view
					style="background-image: url(/static/user_top.png);background-size: cover;padding: 10px;border-radius: 10px;">
					<view style="align-items: center;">
						<view class="flex flex-b" style="width: 100%;padding: 5px;border-radius: 10px;">
							<view style="display: flex;align-items: center;line-height: 1.6;">
								<view style="color:#fff;font-size: 32rpx;font-weight: 700;">
									{{$lang.CARD_ASSETS_TOTAL}}
								</view>
								<!-- <image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`"
								@click="handleShowAmount()" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
							</image> -->
							</view>
						</view>
						<view
							style="font-size: 36rpx;font-weight: 700;line-height: 1.6;color: #000;background-color: #FFFFFF;padding: 0px 10px;border-radius: 5px;">
							{{showAmount?$util.formatMoney(userInfo.totalZichan):hideAmount}}
						</view>
					</view>

					<view style="display: flex;align-items: center;font-size: 28rpx;padding: 5px;margin-top: 5px;">
						<view style="flex:1 0 50%;">
							<view style="color:#fff;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}</view>
							<view style="color: #fff;">{{showAmount?$util.formatMoney(userInfo.money):hideAmount}}
							</view>
						</view>
						<view style="flex:1 0 50%;text-align: right;">
							<view style="color:#fff;">{{$lang.ACCOUNT_COLD_AMOUNT}}</view>
							<view style="color: #fff;">{{showAmount?$util.formatMoney(userInfo.freeze):hideAmount}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<view style="padding:30rpx 20rpx;" class="gap10 flex flex-b">
				<view @click="linkDeposit()" class=" flex"
					style="background-color: #fedbc1;border-radius: 5px;padding: 0px 8px;flex: 45%;">
					<view style="align-items: center;justify-content: center;margin-top: 10px;">
						<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="text-align: center;font-size: 30rpx;color:#000;font-weight: 700;">
						{{$lang.DEPOSIT_TITLE}}
					</view>
					<image src="/static/tx.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;">
					</image>
				</view>


				<view @click="linkWithdraw()" class=" flex"
					style="background-color: #fedbc1;border-radius: 5px;padding: 2px 8px;flex: 50%;">
					<view style="align-items: center;justify-content: center;margin-top: 5px;">
						<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(80)">
						</image>
					</view>
					<view style="text-align: center;font-size: 30rpx;color:#000;font-weight: 700;padding: 10px;">
						{{$lang.WITHDRAW_TITLE}}
					</view>
					<image src="/static/cz.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;">
					</image>
				</view>


			</view>



			<view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx 32rpx 0 0;">

				<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

				<view style="margin-top: 80rpx;padding-bottom: 120rpx;">
					<SignOut></SignOut>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemThird
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: true, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {

			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			chaxuan() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			xiaoxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				// this.cardData = {
				// 	value1: this.userInfo.totalZichan || 0,
				// 	value2: this.userInfo.money || 0,
				// 	value3: this.userInfo.freeze || 0,
				// };
			},
		},
	}
</script>