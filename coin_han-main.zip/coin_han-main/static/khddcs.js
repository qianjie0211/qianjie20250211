console.log(window.alert('天美科技-搭建联系QQ:951810789 电报联系:@tianmeibbs 官方唯一联系方式！任何人都是骗子请勿相信！')); 

