<template>
	<view :style="{height:`${ $util.calcPageHeight()}px`}"  style="background-color: #fff;">
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 90%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="home2()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">検索</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#fff);height: 180px;" >
		</view>
		</view>
		<view class="flex" style="margin:0px 20px 20px 30px;margin-top: -160px;">
			<u-search shape="square" placeholder="株式コードを入力してください" v-model="keyword" :showAction="false" height="30px"
				:searchIconColor="$util.THEME.PRIMARY" searchIconSize="30" bgColor="#fff"
				@clear="keyword=''" :actionText="$lang.SEARCH" @search="searchButton" @custom="searchButton"></u-search>
		</view>

		<view class="" style="margin: 10px;background-color: #fff;border-radius: 10px;">
			<!-- <view class="flex padding-top-10 padding-bottom-10">
				<view class="margin-left-10 bold font-size-15" >検索履歴</view>
			</view>
             <view style="border-bottom:2px solid #ccc;"></view> -->
			<!-- <view class="box" style="border-radius: 10px; " v-if="searchList"> -->
				<view class="box" style="border-radius: 10px; ">
				<view class="top flex flex-b padding-10">
					<view class="flex-2  font-size-16">銘柄/コード</view>
					
					<view class="flex-1">時価</view>
					<view class=" t-r  font-size-16">振幅</view>
					<view class="t-r font-size-16" style="margin-left: 40px;"></view>
				</view>
				<view style="border-bottom:2px solid #ccc;"></view>

				

				<view class=" box-item flex flex-b padding-10" v-for="(item,index) in searchList"
					@click="$u.route($util.PAGE_URL.STOCK_OVERVIEW,{code:item.number_code,id:item.id});">
					<view class="list-name flex-2 font-size-16">
						<view class="list-name-txt ">
							{{item.name}}
							<view style="color: #999999;padding: 3px;margin-left: 5px;">{{item.number_code}}</view>
						</view>
					</view>
					<view class="flex-1 t-c num-font" :class="item.rate>0?'red':'green'">
						{{$util.formatNumber(item.current_price)}}
					</view>
					<view class="per flex-1 t-r" style="color: red;">
						{{item.rate}}%
					</view>
					<view class="flex justify-end" style="margin-left: 10px;" :class="item.rate>0?'red':'green'">
						<view class="icon yzx " @click="handleClickDelProduct(item.gid)"></view>
					</view>
				</view>
				
				
			</view>
			<view style="width: 60%;margin-left: 30%;margin-top: 30%;" v-if="!searchList">
				<u-image src="/static/wujieguo.png" width="80%" mode="widthFix"></u-image>
				<view class="font-size-20" :style="{color:$util.THEME.LABEL}">
					データがありません</view>
			</view>
		</view>
	</view>
</template>
<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords: [],
				gp_select: [{
					name: "国内",
				}, {
					name: "海外",
				}],
				gp_index: 0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
			console.log(this.keywords)
		},
		methods: {
			gp_select_click(e) {
				this.storehouse = ""
				this.gp_index = e.index
			},
			home2() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			dianji(keyword) {
				this.keyword = keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},

			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('クエリは空白にできません。 もう一度検索してください');

				} else {
					uni.showLoading({
						title: "検索...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index: this.gp_index
					})
					this.searchList = list.data.data
					console.log(8888, list.data.data)
					uni.hideLoading();
					if (list.data.data.length > 0) {
						if (this.keywords.indexOf(this.keyword) < 0) {
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords", this.keywords)
						}
					}
				}

			},

		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}
</style>