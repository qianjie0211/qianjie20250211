<template>
	<view style="background-color: #000;min-height: 100vh;">
		<view>
			<!-- <HeaderSecond :title="$lang.PAGE_TITLE_DE"></HeaderSecond> -->
			<view class="flex padding-20">
				<view @click="$util.goBack()">
					<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.PAGE_TITLE_DE}}</view>
			</view>
		</view>

		<template v-if="!cardManagement || cardManagement.length<=0">
			<EmptyData></EmptyData>
		</template>

		<view class="padding-20 radius20" v-for="(item,index) in cardManagement">
			<view style="border-radius: 12rpx;border:1px solid #02B975;padding:24rpx;">
				<!-- <image :src="'/static/tb.png'" mode="widthFix" style="width: 50px;height: 50px;" v-if='item.type==1'>
				</image>
				<image :src="'/static/'+item.huobi+'.png'" mode="widthFix" style="width: 50px;height: 50px;" v-else>
				</image> -->
				<view class="flex">
					<view class="flex-1" style="color: #AAA;">{{$lang.MING_CHENG}}</view>
					<view style="text-align: right;font-size: 32rpx;color: #FFF;">
						{{item.realname}}
					</view>
				</view>
				
				<view class="flex">
					<view class="flex-1" style="color: #AAA;"> {{$lang.BANK_NAME}}</view>
					<view style="text-align: right;font-size: 32rpx;color: #FFF;">
						{{item.bank_name}}
					</view>
				</view>
				<view class="flex">
					<view class="flex-1" style="color: #AAA;">{{$lang.BANK_CARD}}</view>
					<view style="text-align: right;font-size: 32rpx;color: #FFF;">
						{{item.bank_code}}
					</view>
				</view>
				
				
				<view class="margin-left-20">
					<!-- 	<view class="bold font-size-18 color-white">{{item.huobi}}</view>
					<view style="color: #999999;margin-top: 10px;">{{item.address}}</view> -->


				</view>
			</view>
		</view>
		<!-- <view class="padding-10 text-center color-white"
			style="margin:20px auto; width: 90%;background-color: #02B975;border-radius: 10px;" @tap='renewal()'>Add
			Account</view>
		<view style="height: 50px;"></view> -->
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				cardManagement: [],
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$paths.HOME
				});
			},
			chongzhi() {
				uni.redirectTo({
					url: '/pages/Introduction/personaldata'
				})

			},
			renewal() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_BING_BANK_ADD
				});
			},
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				if (!result) return false;
				console.log(result);
				if (result.bank_card_info && result.bank_card_info.length > 0) {
					this.cardManagement = result.bank_card_info.filter(item => item.type == 1);
					console.log(88888, this.cardManagement);

				}
			},
		},
		onLoad(option) {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		background: #f8f8f8;
		min-height: 100vh;
	}

	.top-pad {
		padding-top: 50px;
	}

	.header {
		height: 50px;
		background: #fff;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-center {
			font-size: 18px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}

		.header-left {
			width: 24px;
			height: 24px;
		}
	}

	.card {
		margin: 15px 15px 0 15px;
		padding: 15px;
		background: -webkit-linear-gradient(315deg, #1c4199, #40a2db);
		background: linear-gradient(135deg, #1c4199, #40a2db);
		border-radius: 6px;

		.card-top {
			color: #fff;
		}

		.card-num {
			font-size: 18px;
			font-weight: 700;
			color: #fff;
			margin-top: 15px;
		}
	}

	.pad {
		padding: 40px 15px;
	}

	.b-btn {
		width: 100%;
		height: 44px;
		line-height: 44px;
		background: #1c4199;
		border-radius: 22px;
		text-align: center;
		font-size: 16px;
		font-weight: 500;
		color: #FFFFFF;
		margin: 15px 0;
	}
</style>