<!-- 主页 -->
<template>
	<view >
		<view class="bg_bnner">
			<Header :title="$lang.HOME"></Header>
		</view>
		<ButtonGroup :btns="$util.businessBtnsConfig()" col="33"></ButtonGroup>
		<Favorites :list="freeList"></Favorites>
		<GoodsList :list="goodsList"></GoodsList>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				userinfo: [],
				// show_money: true,
				page: 1,
				goodsList: [],
				gp_index: 0,
				freeList: []
			}
		},
		mounted() {
			
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.free()
			this.startTimer()
		},
		
		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		},
		methods: {
			// 银转证
			silver(money, bank_card_info, idno) {
				// if (bank_card_info && idno !== null) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/service/service'
				});
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let list = await this.$http.post('api/goods/top2', {
					current: 0,
					limit:50
				})
				// if(this.page==1){
				this.goodsList = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = result.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title:  this.$t('index.ccaf'),
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/signin/signin'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let result = await this.$http.get('api/goods/top1', {current1:1})
				this.freeList = result.data.data
			},
		},
	}
</script>

<style lang="scss">

</style>