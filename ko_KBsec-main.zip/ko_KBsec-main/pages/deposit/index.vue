<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;background-color: #EBEDF2;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.DEPOSIT_TITLE}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<view style="padding-bottom: 160rpx;">
			<template v-if="info">
				<AssetsCard :info="info" />
			</template>

			<view style="padding:30px  20px 10px 20px;">
				<view style="width: max-content;padding: 0 24rpx;margin-bottom: 24rpx;">
					{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}
				</view>


				<view style="background-color: #FFF;border-radius: 16rpx;padding:24rpx;">
					<view style="display: flex;align-items: center;flex-wrap: wrap;margin: 30rpx 0;">
						<block v-for="(item,index) in amountList" :key="index">
							<view
								style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="setStyle(curPos==index)" @click="quantity(item,index)">
								{{$util.formatNumber(item,0)}}
							</view>
						</block>
					</view>

					<view class="common_input_wrapper" style="padding-left: 40rpx;">
						<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
							:placeholder-style="$theme.setPlaceholder()" style="flex: auto;"></input>
					</view>
				</view>
			</view>

			<view class="common_btn" style="margin:60rpx auto;width: 80%;background-color: #1C1C1C;color:#FFF;"
				@click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>

			<view style="padding: 10px 20px;">
				<view style="font-size: 28rpx;font-weight: 700;text-align: center;padding-bottom: 20rpx;"
					:style="{color:$theme.LOG_LABEL}">
					{{$lang.DEPOSIT_TIP_TITLE}}
				</view>
				<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
					<view style="line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
				</block>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 掩码
				info: null, //
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				hideValue: '****', // 隐藏金额
			};
		},
		computed: {
			// // 资产分布数据
			// assetsData() {
			// 	if (this.info) return this.info;
			// },
			// 入金金额预置值
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
			this.isMask = uni.getStorageSync('mask');
			this.amount = this.amountList[this.curPos];
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			setStyle(val) {
				return {
					backgroundColor: val ? '#01B2CE' : '#E9E9E9',
					color: val ? '#FFFFFF' : '#333333',
					borderRadius: `8rpx`,
					// border: `1px solid #F88B8B1A`
				}
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					this.$util.linkCustomerService();
				}, 1000)
			},
			//个人信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(result);
				this.info = {
					total: result.totalZichan * 1, // 总资产
					money: result.money * 1, // 可提
					freeze: result.frozen * 1, // 冻结
					totalProfit: result.totalYingli * 1, // 总盈利
					holdProfit: result.holdYingli * 1, // 持仓盈利
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 40rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>