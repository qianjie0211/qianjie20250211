<template>
	<view>
		<view class="flex padding-15">
			<view @click="fanhui()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="flex-1 text-center font-size-16">{{$LANG.API_UFXFHDFHRG}}</view>
		</view>
		<block v-for="(item, index) in list" :key="index">
		<view style="padding: 10px;">
			<view style="background-color: #fff;border-radius: 10px;border: 1px #dbd4c8 solid;">
				<view class="bold" style="padding: 10px;font-size: 16px;">{{item.goods_info.ct_name}}</view>
				
				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;padding: 0px 10px;">
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$LANG.API_UFBDFBVXRG}}
						</view>
						<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
							{{item.order_buy.price}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$LANG.API_UFXGDSGRRG}}
						</view>
						<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.order_buy.num}}
						</view>
					</view>
				</view>
				
				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;padding: 0px 10px;">
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$LANG.API_UFXCBRHG}}
						</view>
						<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
							{{item.order_buy.amount}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$LANG.API_UFXEYJRG}}
						</view>
						<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.order_buy.buy_fee}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;padding: 0px 10px;">
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$lang.API_UFXKJKXRG}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.order_sn}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view >
							{{$lang.API_UFXCVXRG}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.order_buy.updated_at}}
						</view>
					</view>
				</view>
			</view>
		</view>
		</block>
		
		
		
		
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				list: [],
				
			};
		},
		computed: {
			
		},
		created() {
			this.getList();
		},
		methods: {
			
			fanhui(){
				uni.navigateBack({
					delta:1
				})
			},
			
			// 获取接口数据
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/GoodsScramble/viplog`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
			
			
		},
	};
</script>