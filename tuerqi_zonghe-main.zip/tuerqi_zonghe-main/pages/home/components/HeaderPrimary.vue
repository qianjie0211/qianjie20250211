<template>
	<header class="common_header">
		<image src="/static/user.png" mode="aspectFit" :style="$theme.setImageSize(70)" style="padding-right: 30rpx;"
			@tap="linkAccount()">
		</image>
		<!-- <view style="font-weight: 500;font-size: 28rpx;" :style="{color:$theme.SECOND}">{{title}} </view> -->
		
		<!-- <image src="/static/sousuo.png" mode="widthFix" @click="linkSearch()"></image> -->
		
		<view class="flex" style="border: 1px #488ce8 solid;border-radius: 20px;width: 100%;">
			<view class="text-center flex-1" style="padding: 5px;border-radius: 20px 0 20px 20px;" :style="inv==0?'background-color: #488ce8;':''" @click="actinv(0)">{{$lang.FOREX_TITLE}}</view>
			<view class="text-center flex-1" style="padding: 5px;border-radius: 0px 20px 20px 20px;" :style="inv==1?'background-color: #488ce8;':''" @click="actinv(1)">{{$lang.MARKET_INDEX_TAB_COIN}}</view>
		</view>
		
		
		<view class="flex justify-center">
			<view style="display: flex;align-items: center;">
				<!-- <image mode="aspectFit" src="/static/search.png" :style="$theme.setImageSize(40)" @click="linkSearch()"></image> -->
				<image mode="aspectFit" src="/static/notify.png" :style="$theme.setImageSize(55)" @click="linkNotify()"
					style="padding-left: 30rpx;"></image>
			</view>
		</view>

	</header>
</template>

<script>
	export default {
		name: 'HeaderPrimary',
		
		props: {
			// 标题
			title: {
				type: String,
				default: '',
			
			},
			inv: {
				type: String,
				default: 0,
			
			},
		},
		methods: {
			actinv(index){
				this.inv=index
				this.$emit(`actinv`, index);
			},
			linkAccount() {
				this.$emit(`action`, true);
			},
			// 跳转到查询页面
			linkSearch() {
				uni.switchTab({
					url: this.$CONSTANTS.MARKET_INDEX
				})
			},
			// 跳转到通知页面
			linkNotify() {
				uni.navigateTo({
					url: this.$CONSTANTS.NOTIFIY_INDEX
				})
			},
		}
	}
</script>

<style>
	.common_header {
		padding:20px 20px !important;
		display: flex;
		align-items: center;
	}
</style>