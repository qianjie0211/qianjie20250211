<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="padding-5">
				<view style="border: 1px #f2bc8f solid;border-radius: 10px;background-color: #fff;">
					<view class="" style="padding: 10px 5px;border-radius: 10px;">
					<view class="bold" style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;">{{item.goods.name}}</view>
					</view>
					
					<view class="flex" style="padding: 10px;">
						<view class="flex-1">
							<view>{{$lang.TRADE_LARGE_LOG_AMOUNT}}</view>
							<view style="margin-top: 5px;">{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
						<view class="flex-1">
							<view>支払金額</view>
							<view style="margin-top: 5px;">{{$util.formatMoney(item.amount)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
						<view>
							<view>{{$lang.TRADE_LARGE_LOG_NUM}}</view>
							<view style="margin-top: 5px;">{{item.num}}</view>
						</view>
					</view>

					<!-- <view style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_LARGE_LOG_PRICE}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view> -->
					<view style="border-radius: 12rpx;padding:10rpx;">
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_LOG_NUM}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.num}}
							</view>
						</view> -->
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_LOG_LEVER}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.double}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;margin-top: 10px;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_LOG_AMOUNT}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.amount)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;"
							:style="{color:$theme.LOG_LABEL}">
							<view>{{$lang.TRADE_LARGE_LOG_CREATE_TIME}}</view>
							<text>{{item.created_at}}</text>
						</view>
					</view>
				</view>
				</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeRecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
		},
	}
</script>