<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderThird :title="$lang.TRADE_DAY_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;width: 60px;" @click="linkRecord()">{{$lang.TRADE_DAY_RECORD}}</view>
		</HeaderThird>


		<view class="flex" style="width: 90%;margin-left: auto;">
				  <view class="flex-1 bold" style="font-size: 18px;color: #FFFFFF;">AIインテリジェント取引</view>
				  <image src="/static/rinei.png" mode="widthFix" style="width: 120px;"></image>
		</view>
		<view style="background-color: #FFFFFF;min-height: 90vh;padding:40rpx;width: 85%;border-radius: 10px;margin-left: 10px;">
			<TradeDayBuy></TradeDayBuy>
		</view>
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeDayBuy from './components/TradeDayBuy.vue';
	export default {
		components: {
			HeaderThird,
			TradeDayBuy,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_DAY_RECORD
				})
			}
		},
	}
</script>