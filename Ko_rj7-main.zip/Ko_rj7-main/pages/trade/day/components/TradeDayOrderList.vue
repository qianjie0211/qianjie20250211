<template>
	<view style="margin-top: 70px;">
		<view class="flex flex-b hui1" style="padding: 15px 10px;">
			<view class="font-size-12">신청금액</view>
			<view class="font-size-12">{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}</view>
			<view class="font-size-12">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="background-color: #fff;min-height: 80vh;">
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px #ccc solid;">
					<view class="flex padding-10">
						<view style="flex: 10%;">{{$util.formatMoney(item.money)}}</view>
						<view style="flex: 70%;text-align: center;">{{$util.formatMoney(item.success)}}</view>
						<view style="text-align: center;flex: 15%;" :style="setStyle(item.status)">{{item.zt}}</view>
					</view>
				</view>
			</block>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 申请状态样式
			setStyle(val) {
				// 背景色
				const tempBG = [
					this.$theme.RGBConvertToRGBA('#34d66a', 20),
					this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 20),
					this.$theme.RGBConvertToRGBA(this.$theme.THIRD, 20),
				];
				// 文字色
				const tempColor = [
					'#34d66a', this.$theme.PRIMARY, this.$theme.THIRD,
				];
				return {
					// PRIMARY
					backgroundColor: tempBG[val],
					color: tempColor[val],
					borderRadius: `12rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
					minWidth: `80rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},

			// 申请列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map((item, index) => {
					return {
						...item,
						// 状态值明文、icon
						...this.$theme.setStatusPrimary(item.status),
						// 状态值 样式:字号、字色、背景等
						style: this.$theme.setStatusPrimary(item.status),
					}
				});
			},
		}
	}
</script>