<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderSecond title="IPO" :color="$theme.SECOND"></HeaderSecond> -->
		<view class="flex padding-20" style="background-color: #4644d1;">
			<view @click="fanhui()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
			</view>
			<view class="text-center flex-1 color-white bold font-size-16">IPO</view>
		</view>
		
		<view style="position: relative;">
			<image src="/static/ipo_bg.png" mode="widthFix" style="width: 100%;height: 130px;"></image>
		</view>
		
		<view style="padding:0px 10px;margin-top: -20px; position: absolute;width: 95%;">
			<view class="flex flex-b" style="background-color: #fff;padding:15px 30px;border-radius: 10px;border: 1px #33d669 solid;" >
				<view @click="changeTab(0)">
					<image src="/static/tb_ee.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">종목</view>
				</view>
				<view @click="changeTab(1)">
					<image src="/static/tb_qq.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">청약내역</view>
				</view>
				<view @click="changeTab(2)">
					<image src="/static/tb_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">청약 성공</view>
				</view>
			</view>
		</view>
		

		<!-- <TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary> -->

		<template v-if="curTab ==0">
			<TradeIPOList></TradeIPOList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPORecord></TradeIPORecord>
		</template>
		<template v-else>
			<TradeIPOSuccessRecord></TradeIPOSuccessRecord>
		</template>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	import TradeIPORecord from './components/TradeIPORecord.vue';
	import TradeIPOSuccessRecord from './components/TradeIPOSuccessRecord.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIPOList,
			TradeIPORecord,
			TradeIPOSuccessRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
			fanhui(){
				uni.switchTab({
					url:'/pages/home/index'
				})
			},
		}
	}
</script>