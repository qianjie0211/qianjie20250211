<template>
	<view>
		<view class="flex flex-b gap10 padding-10" v-if="inv==1">
<!-- :style="item.rate>0?'background-image: url(/static/home/zhang.png);':'background-image: url(/static/home/die.png);'" -->
			<view v-for="(item, key, index) in list" :key="key" v-if="index < 3" style="background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;background-color: #1f1f1f;border-radius: 5px;"  class="text-center flex-1 padding-10"
				@click="linkInfo(item.locate)">
				<view class="font-size-10">{{item.name}}</view>
				<view style="font-size: 40rpx;font-weight: 700;margin-top: 5px;" >
					{{item.current_price}}
				</view>
				<image :src="item.rate>0?'/static/zhang.png':'/static/die.png'" mode="widthFix" style="width: 100%;height: 40px;"></image>
				<view class="font-size-10 margin-top-5">
					{{$util.formatNumber(item.rate_num)}} {{`${item.rate>0?'+':'-'}`+$util.formatPercentage($util.formatNumber($util.formatMathABS(item.rate),2))}}
				</view>
				
				
			</view>
		</view>


		<!-- <view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.news">
				
			</TitlePrimary>
		</view>
		<view  style="margin:10rpx 40rpx;" >
			<view v-for="(item,index) in news_list" class="margin-top-10" @click="tiaozhuan(item.id)">
				<view class="bold font-size-14" style=" width: 100%; white-space: nowrap;overflow: hidden; text-overflow: ellipsis;">{{item.title}}</view>
				<view class="hui1 font-size-12">{{item.created_at}}</view>
				<view class="font-size-12 hui3" style="display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;text-overflow: ellipsis;white-space: normal;">{{item.sum_title}}</view>
				<view style="height: 1px;background-color: #999999;margin-top: 10px;"></view>
			</view>
		</view> -->

		<!-- <view>
			<NotifyPrimary ref="notify"></NotifyPrimary>
		</view> -->


		<!-- 	<view style="padding: 10px;">
			<image src="/static/home1.png" mode="aspectFit" style="width: 100%;"></image>
		</view> -->
		<view class="flex padding-10 gap5" @click="$u.route({type:'switchTab',url:'/pages/market/index'});" v-if="inv==0">
			<image src="/static/home/huo.png" mode="widthFix" style="width: 25px;"></image>
			
			<view class="flex flex-b" style="width: 100%;">
				<view>
					<view class="font-size-18 bold" style="color: #fff;">{{$lang.R_M_G_P}}</view>
					<view class="flex" style="width: 120%;">
						<view style="border: 1px #fff solid;margin-top: 2px;width: 95%;"></view>
						<view style="border-radius: 50%;width: 8px;height: 8px;background: #fff;margin-left: 5px;"></view>
					</view>
				</view>
				<image src="/static/arrow_right.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view>
		<block v-for="(item,index) in list_gupiao" :key="index" v-if="inv==0">
			<view class="common_block" style="border-radius: 24rpx;padding:40rpx;">
				<view style="display: flex;align-items: center;" @click="linkInfo1(item.locate)">
					<view style="margin-right: auto;" class="flex align-center"> 
						<!-- <CustomLogo logo="/static/guoqi.png" :name="item.name" :size="50"></CustomLogo> -->
						<image src="/static/guoqi.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					</view>
					<view style="padding-left: 30rpx;flex:auto">
						<view style="align-items: center;" class="flex-b flex">
							<view style="padding-right: 60rpx;font-size: 28rpx;"  class="flex-2" 
								:style="{color:$theme.SECOND}">
								{{item.name}}
							</view>
							<view style="font-size: 32rpx;font-weight: 500;text-align: center;" class="flex-1"   :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.current_price}}
							</view>
							<view class="text-center flex-1" style="padding: 2px 4px;border-radius: 5px;width: 70px;" :style="$theme.setStockRiseFall2(item.rate>0)">
								{{`${item.rate>0?'+':'-'} `+$util.formatPercentage($util.formatNumber($util.formatMathABS(item.rate),2))}}
							</view>
						</view>
					</view>
				</view>
				
			</view>
		</block>
		
		
		<view style="padding:10px;">
			<!-- <image src="/static/banner-4.png" mode="widthFix" style="width: 100%;height: 90px;"></image> -->
		</view>
		
		
		<view style="width: 100%;justify-content: center;display: flex;padding: 10px 0px;" v-if="inv==0">
			<!-- <TitlePrimary :title="$lang.MARKET_INDEX_TAB_COIN"> -->
			<TitlePrimary >
				<view style="font-size: 13px;" @click="linkMarket()" :style="{color:$theme.SECOND}">
					{{$lang.COMMON_MORE}}
					<!-- <view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view> -->
				</view>
			</TitlePrimary>
		</view>
		
		
		
		
		

		<template v-if="inv==1">
			<block v-for="(item,index) in list" :key="index" >
				<view class="common_block" style="border-radius: 24rpx;padding:40rpx;">
					<view style="display: flex;align-items: center;" @click="linkInfo(item.locate)">
						<view style="margin-right: auto;">
							<CustomLogo :logo="item.logo" :name="item.name" :size="50"></CustomLogo>
						</view>
						<view style="padding-left: 30rpx;flex:auto">
							<view style="align-items: center;" class="flex-b flex">
								<view style="padding-right: 60rpx;font-size: 28rpx;" 
									:style="{color:$theme.SECOND}">
									{{item.name}}
								</view>
								<view style="font-size: 32rpx;font-weight: 500;text-align: center;"  :style="$theme.setStockRiseFall(item.rate>0)">
									{{item.current_price}}
								</view>
								<view class="text-center" style="padding: 2px 4px;border-radius: 5px;width: 70px;" :style="$theme.setStockRiseFall2(item.rate>0)">
									{{`${item.rate>0?'+':'-'} `+$util.formatPercentage($util.formatNumber($util.formatMathABS(item.rate),2))}}
								</view>
							</view>
						</view>
					</view>
					<view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;line-height: 1.4;">
						{{`24H: ` }}<template v-if="item.vol">{{(item.vol*1).toFixed(0)}}</template>
					</view>
				</view>
			</block>
			<view style="width: 100%;justify-content: center;display: flex;padding: 10px 0px;" v-if="inv==1">
				<!-- <TitlePrimary :title="$lang.MARKET_INDEX_TAB_COIN"> -->
				<TitlePrimary >
					<view style="font-size: 13px;" @click="linkMarket()" :style="{color:$theme.SECOND}">
						{{$lang.COMMON_MORE}}
						<!-- <view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view> -->
					</view>
				</TitlePrimary>
			</view>
			<!-- <view style="padding: 20px;"></view> -->
		</template>
	</view>
</template>

<script>
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import NotifyPrimary from '../../notify/components/NotifyPrimary.vue';
	export default {
		name: 'CoinList',
		components: {
			TitlePrimary,
			NotifyPrimary
		},
		props: {
			// 标题
			inv: {
				type: String,
				default: ''
			},
		},
		data() {
			return {
				gpIndex: 1,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
				list3: "",
				news_list: "",
				list_gupiao:""
			};
		},
		created() {
			this.getList();
			this.getList_gu()
			// this.get_NewsList()
			if (this.$refs.notify) this.$refs.notify.getList();
		},

		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			tiaozhuan(id) {
				uni.navigateTo({
					url: "/pages/webview?id=" + id
				})
				// window.location.href=url
			},
			isValidIndex(index) {
				// this.iindex=this.iindex+1;
				// console.log(this.iindex <= 2)
				// return this.iindex <= 2;  
			},
			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$CONSTANTS.MARKET_INDEX + `?type=0`,
				})
			},
			// 跳转到 coin trade index
			linkInfo(code) {
				uni.reLaunch({
					url: this.$CONSTANTS.COIN_INDEX + `?code=${code}`
				});
			},
			linkInfo1(code) {
				uni.navigateTo({
					url:  `/pages/forex/detail?code=${code}`
				});
			},
			
			

			// websocket链接
			connect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WS_COIN_URL);
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {


							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},
			async getList_gu() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/list`, {
					page: this.curPage,
					gp_index: 5,
					limit:10
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list_gupiao = result;
				
				// if (this.socket) this.disconnect();
				// this.connect(); // 启动 websocket链接
			},
			
			
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/list`, {
					page: this.curPage,
					gp_index: this.gpIndex
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				if (this.socket) this.disconnect();
				this.connect(); // 启动 websocket链接
			}
		}
	}
</script>

<style>
</style>