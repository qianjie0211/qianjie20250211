<!-- 用户基本信息 -->
<template>
	<view style="padding: 10px;background-color: #FFF; border-radius: 10px;">
		<view class="flex" style="padding: 20px;">
			<view>
				<image :src="info.touxiang?info.touxiang:'/static/applogo.png'" mode="widthFix" style="width: 50px;height: 50px;"></image>
			</view>
		<view style="margin-left: 15px;">
			<view class="bold" style="font-size: 18px;">{{info.real_name}}</view>
			<view style="color: #a0a6ac;">{{info.p_mobile}}</view>
		</view>
		</view>
		

		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<!-- <view style="flex:20%;text-align: center;">
				<image style="border-radius: 10px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.calcImageSize(120)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 24px;text-align: left;font-weight: 700;color:#3C1E20;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;" :style="{color:$util.THEME.LABEL}">
					{{info.p_mobile}}
				</view>
			</view> -->
			<!-- <view class="common_btn btn_primary" style="flex:20%;" @click="handleWithDraw()">{{$lang.WITHDRAW}}</view> -->
		</view>
		<view>
		<view style="display: flex;align-items: center;justify-content: space-around;">
			<view >
				<view class="flex">
					
					<view :style="{color:$util.THEME.LABEL}">{{$lang.AMOUNT_TOTAL}}</view>
					<view style="margin-left: 20px;">
						<image src="/static/zhenyan.png" mode="widthFix" style="width: 20px;height: 20px;margin-right: 10px;" @click="yan_show=false" v-if="yan_show"></image>
						<image src="/static/yanjin.png" mode="widthFix" style="width: 20px;height: 20px;margin-right: 10px;" @click="yan_show=true" v-if="!yan_show"></image>
					</view>
					
				</view>
				
				<view style="font-size: 20px;font-weight: 500;margin-top: 10px;color: #19bfbd;" v-if="yan_show">
					{{$util.formatNumber(info.totalZichan)}}
				</view>
				<view style="font-size: 24px;font-weight: 500;margin-top: 10px;color: #19bfbd;" v-if="!yan_show">
					********
				</view>
			</view>
			<view >
				<view :style="{color:$util.THEME.LABEL}">{{$lang.AMOUNT_AVAILABLE}}</view>
				<view style="font-size: 20px;font-weight: 500;margin-top: 10px;color: #19bfbd;" v-if="yan_show">
					{{$util.formatNumber(info.money)}}
				</view>
				<view  style="font-size: 24px;font-weight: 500;margin-top: 10px;color: #19bfbd;" v-if="!yan_show">
					********
				</view>
			</view>
		</view>
		<view class="flex margin-top-20">
			<!-- <button style="width: 120px;height: 35px;background-color: #97e2dd;color: #FFF;font-size: 15px;" @click="home()"  >出金</button> -->
			<!-- <button style="width: 120px;height: 35px;background-color: #18bfb4;color: #FFF;font-size: 15px;" @click="top()"  >入金</button> -->
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true,
				
			};
		},
		methods:{
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
		home() {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/account/withdraw'
					});
			},
		top() {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/account/deposit'
					});
			},
		}
	}
</script>

<style>

</style>