<template>
	<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
		<canvas canvas-id="total" id="total" class="charts"></canvas>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {
		areaChart
	} from '@/common/customUChart.js';
	export default {
		name: 'ChartTotalReturns',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				chart: null,
			}
		},
		computed: {
			// 处理图表数据
			chartData() {
				// console.log(`总收益:`, this.list);
				const temp = this.list.map(item => {
					return {
						timestamp: item.date * 1000,
						value: item.zonggentou * 1
					}
				});
				let tempCategories = []; // 存储时轴
				let tempSeries = []; // 存储数据
				// 决定时轴显示及空字符间隙
				const divisor = parseInt(temp.length / 10);
				// console.log(`divisor:`, divisor);
				temp.forEach((item, index) => {
					if (divisor > 0) {
						if (index % divisor === 0) {
							tempCategories.push(item.timestamp);
							tempSeries.push(item.value);
						}
					} else {
						tempCategories.push(item.timestamp);
						tempSeries.push(item.value);
					}
				})
				// 时轴排序
				tempCategories = tempCategories.sort((a, b) => a - b, 0);
				// console.log(`tempCategories:`, tempCategories);
				// 数据排序
				tempSeries = tempSeries.sort((a, b) => a - b, 0);

				return {
					categories: tempCategories.map(item => this.$util.formatMonthDay(item)),
					series: [{
						name: '',
						data: tempSeries,
						color: this.$theme.RISE
					}]
				}
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.renderInit();
		},
		unmounted() {},
		destroyed() {},
		methods: {
			renderInit() {
				setTimeout(() => {
					this.genKline();
				}, 1000)
			},

			genKline() {
				const ctx = uni.createCanvasContext("total", this);
				this.chart = new uCharts(areaChart(ctx, this.chartData,
					this.cWidth,
					this.cHeight))
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>