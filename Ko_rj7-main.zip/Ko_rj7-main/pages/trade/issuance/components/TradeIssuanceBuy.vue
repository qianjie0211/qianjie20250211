<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" style="">
				{{info.name}}
				<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view style="padding:30rpx;">
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:2;">
					<text :style="{color:$theme.LOG_LABEL}">배정가격</text>
					<text style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(info.price,2)}} {{$lang.CURRENCY_UNIT}}</text>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">최고배정</text>
					<text style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.PRIMARY}">
						{{info.max_num+` ${$lang.QUANTITY_UNIT}`}}</text>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">배정일</text>
					<text style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.PRIMARY}">
						{{info.shengou_date}}</text>
				</view>

				<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_MODAL_3}}</text>
					<text :style="{color:$theme.PRIMARY}">
						{{!info.online_date? $lang.TRADE_ISSUANCE_MODAL_NULL_DATE  :info.shengou_date}}</text>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_MODAL_4}}</text>
					<text :style="{color:$theme.PRIMARY}">
						{{!info.gb_date? $lang.TRADE_ISSUANCE_MODAL_NULL_DATE  :info.gb_date}}</text>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_MODAL_5}}</text>
					<text :style="{color:$theme.PRIMARY}">
						{{!info.rj_date? $lang.TRADE_ISSUANCE_MODAL_NULL_DATE  :info.rj_date}}</text>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_MODAL_6}}</text>
					<text :style="{color:$theme.PRIMARY}">
						{{!info.online_date? $lang.TRADE_ISSUANCE_MODAL_NULL_DATE  :info.online_date}}</text>
				</view> -->

				<view class="common_btn" style="margin: 30rpx auto;width: 80%;background-color: #35d66b;" @tap.stop="handleConfirm()">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeIssuanceBuy',
		props: {
			info: {
				type: Object,
				default: {},
				list: [],
			},
		},
		data() {
			return {
				isShow: false, // 购买前二次确认的弹层
				// amount: '', // 金额
				// password: '', // 支付密码
				// leverList: [], // 杠杆值数组
				// current: 0,
				// availBal: 0,
			}
		},

		computed: {
			// // 当前杠杆值。无论是否显示杠杆，此处都无需注释
			// curLever() {
			// 	return this.leverList[this.current];
			// },
			// // 金额计算
			// buyAmount() {
			// 	return !this.curLever ? 0 : this.info.price * this.amount / Number(this.curLever.index);
			// },
		},

		// created() {
		// 	this.gerUserInfo();
		// },

		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);

			},
			// 选择杠杆
			chgangeLever(val) {
				this.current = val;
			},

			handleConfirm() {
				this.buy();
				this.getList();
			},
			async getList() {
				this.list = []; // 请求前清除数据。
				const result = await this.$http.get(`api/goods-scramble/calendar`, {
					type: 2, // 传参 1或2
				})
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
						zhekou: item.zhekou,
						
					}
				});
			},
			async buy() {
				const result = await this.$http.post(`api/goods-scramble/doOrder`, {
					id: this.info.id,
					// num: this.amount,
					price: this.info.price,
					ganggan: 1,
				});
				if (!result) return false;
					this.actionEvent();
					uni.showToast({
					title: '구독 성공',
					})
				setTimeout(() => {
					this.actionEvent();
				}, 1000);
			},
		}
	}
</script>

<style>
</style>