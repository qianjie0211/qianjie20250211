<template>
	<header class="common_header">
		<!-- <view class="header_title" :style="{color:color}">{{title}}</view> -->
		<!-- <view class="header_search" @click="linkSearch()">
			
		</view> -->

		<!-- <image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)" @click="linkNotifiy()" style="padding-right: 8rpx;"></image> -->
		
		
		<div style="position: relative; width: 220px;"  @click="linkSearch()">
		    <input type="text" class="search-input" placeholder="">
		    <img src="/static/sousuo1.png" alt="Search" class="search-icon" style="width: 18px; height: 18px;">
		</div>
		
		
		
		<!-- <view style="flex:1 0 50%; font-size: 18px;color: #fff;">Diversity Hall</view> -->

		<view style="margin-left:auto;">
			<view style="display: flex;align-items: center;">
				<template v-if="isSearch">
					<image mode="aspectFit" src="/static/center_service.png" :style="$util.setImageSize(40)"  @click="$util.linkService()">
					</image>
					<image mode="aspectFit" src="/static/more.png" :style="$util.setImageSize(40)"style="margin-left: 15px;" @click="user"></image>
				</template>
			</view>
		</view>
	</header>
</template>

<script>
	import {
		NOTIFICATION,
		SERVICE,
		SEARCH
	} from '@/common/paths.js';
	export default {
		name: 'HeaderPrimary',
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#FFFFFF'
			},
			isSearch: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {};
		},
		methods: {
			// 跳转到通知页面
			linkNotifiy() {
				uni.navigateTo({
					url: NOTIFICATION
				})
			},
			user(){
				uni.switchTab({
					url:'/pages/account/center'
				})
			},
			// // 跳转到客服
			linkService() {
				uni.navigateTo({
					url: SERVICE
				})
			},
			linkService5() {
				uni.navigateTo({
					url: '/pages/Introduction/personaldata'
				})
			},
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: "/pages/search"
				})
			}
		}
	}
</script>
<style>
	.search-input {
		width: 180px;
		height: 30px;
		border-radius: 20px;
		border: none;
		padding-right: 40px;
		background-image: url('/static/sousuo.png'); /* 输入框背景图 */
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		outline: none;
	}
	.search-icon {
		position: absolute;
		right: 10px;
		top: 50%;
		transform: translateY(-50%);
		cursor: pointer;
	}
</style>