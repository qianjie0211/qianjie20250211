<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderPrimary isSearch :title="$lang.TABBAR_HOME" color="#FFFFFF"> </HeaderPrimary> -->
		<view class="flex" style="padding:30px  20px;">
			<view class="flex-1" style="background-color: #fff;border-radius: 20px;padding: 5px 10px;">
				<view class="flex" @click="shouye()">
					<image src="/static/search_dark.png" mode="widthFix" style="width: 15px;"></image>
					<view style="margin-left: 5px;font-size: 10px;color: #999;">銘柄名/コードを入力してください</view>
				</view>
				
			</view>
			<view>
				<image src="/static/service.png" mode="widthFix" style="width: 25px;margin-left: 20px;" @click="kefu()"></image>
			</view>
		</view>
     
		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/card_bg_0.PNG" mode="widthFix" style="width: 100%;"></image>
			<!-- <view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view> -->
		</view>
		
		<view style="background-color: #fefaf5;width: 95%;border-radius: 10px;margin-left: 10px;">
			<ButtonGroup></ButtonGroup>
		</view>
		
		<!-- <TrackList></TrackList> -->

		<MarketNews></MarketNews>
		
		<!-- <view style="position: relative;">
			<view>
				<view style="position: relative;">
					<image src="/static/syhh.png" mode="widthFix"
						style="width: 95%;margin-top: 15px;padding: 0px 10px;"></image>
					<view class="bold" style="position: absolute;bottom: 70%;left: 25px;font-size: 22px; color: #fff;">
						資産
					</view>
					<image src="/static/sytongqian.png" mode="widthFix"
						style="width: 90%; position: absolute;bottom: 10%;left: 20px;">
					</image>
					<view style="position: absolute;bottom: 45%;left: 45px;font-size: 16px; color: #000;">総資産</view>
					<image src="/static/zhenyan.png" mode="widthFix"
						style="position: absolute;bottom: 47%;left: 105px;width: 20px;" @click="yan_show=false"
						v-if="yan_show"></image>
					<image src="/static/yanjin.png" mode="widthFix"
						style="position: absolute;bottom: 47%;left: 105px;width: 20px;" @click="yan_show=true"
						v-if="!yan_show"></image>
				</view>
				<view class="bold" style="position: absolute;bottom: 10%;left: 40px;font-size: 28px; color: #ec1a14;"
					v-if="yan_show">{{$util.formatMoney(userInfo.totalZichan)}}</view>
				<view class="bold" style="position: absolute;bottom: 8%;left: 40px;font-size: 28px; color: #ec1a14;"
					v-if="!yan_show">******</view>
				<view class="bold"
					style="position: absolute;bottom: 12%;font-size: 14px; color: #fff;background-color: #f0a039;padding: 10px;border-radius: 20px;padding: 3px 15px;margin-left: 260px;"
					@click="zichan()">資産詳細</view>
			
			</view>
			</view> -->

		<view >
			<view style="padding:0 20rpx;">
				<!-- <TitleSecond > -->
					
					
				<!-- </TitleSecond> -->
			</view>

			<MarketHot ref="hot"></MarketHot>
		</view>

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
</template>

<script>
	// import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import TrackList from './components/TrackList.vue';
	import MarketNews from './components/MarketNews.vue';
	import MarketHot from './components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	export default {
		components: {
			// HeaderPrimary,
			ButtonGroup,
			TitleSecond,
			TrackList,
			MarketNews,
			MarketHot,
			IPOSuccessAlert,
		},
		data() {
			return {
				isAnimat: false, // 页面动画	
				yan_show: true,
				userInfo: {},
			}
		},
		computed: {
			// 今日
			setToday() {
				return this.$util.formatToday(new Date());
			}
		},

		onLoad() {},
		onShow() {
			this.getAccountInfo()
			this.isAnimat = true;
			if (this.$refs.hot) this.$refs.hot.getList();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},

		methods: {
			// 关闭子組件 websocket 及定時器
			closeAll() {
				if (this.$refs.hot) this.$refs.hot.disconnect();
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
			zichan() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/transaction/index'
				});
			},
			shouye() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				this.$util.linkCustomerService();
			},

			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
		},
	}
</script>