<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{setTitle}}</text>
			</view>
		</header>

		<view style="margin: 80rpx 40rpx;">
			<TitlePrimary :title="$lang.ENTER_OLD_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 24rpx;">
				<input v-model="oldPassword" :password="isMask" :placeholder="$lang.ENTER_OLD_PASSWORD"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleMask">
				</image>
			</view>

			<TitlePrimary :title="$lang.ENTER_NEW_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 24rpx;">
				<input v-model="newPassword" :password="isMask" :placeholder="$lang.ENTER_NEW_PASSWORD"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleMask">
				</image>
			</view>

			<TitlePrimary :title="$lang.ENTER_VERIFY_NEW_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="padding-left: 24rpx;">
				<input v-model="newPassword2" :password="isMask" :placeholder="$lang.ENTER_VERIFY_NEW_PASSWORD"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleMask">
				</image>
			</view>

			<view class="common_btn" style="margin:60rpx auto;background-color: #1C1C1C;color:#FFF;"
				@click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 掩码
				oldPassword: "", // 旧密码
				newPassword: "", // 新密码
				newPassword2: "", // 验证新密码
				role: '', // 根据当前角色，处理逻辑。
			};
		},
		computed: {
			// 当前页面用于:role=pay视为变更支付密码，否则视为变更登入密码
			isPay() {
				return this.role == 'pay';
			},
			// 当前页面header标题
			setTitle() {
				return this.isPay ? this.$lang.PAY_PASSWORD_TITLE : this.$lang.SIGNIN_PASSWORD_TITLE
			}
		},
		onLoad(opt) {
			console.log(opt.role);
			this.role = opt.role || '';
		},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('mask');
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 检查表单
			checkForm() {
				if (this.oldPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_OLD_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword2 == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword != this.newPassword2) {
					uni.showToast({
						title: this.$lang.ENTER_VERIFY_FAIL,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.updatePassword();
				}
			},
			//修改密码
			async updatePassword() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const temp = this.isPay ? `updatePayPassword` : `updateLoginPassword`
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPassword,
					newpass: this.newPassword,
					confirmpass: this.newPassword2,
				});
				console.log(result);
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$CONSTANTS.ACCOUNT_CENTER
					});
				}, 1000)
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>