import enUS from './en-US.js';
import zhTW from './zh-hant.js';
import jaJP from './ja-JP.js';
import koKR from './ko-KR.js';
import itIT from './it-IT.js';
import arIL from './ar-IL.js';

// LANGUAGES

export default {
	'en-US': enUS, // 英语
	'zh-TW': zhTW, // 繁中
	'ja-JP': jaJP, // 日语
	'ko-KR': koKR, // 韩语
	'it-IT': itIT, // 意大利语
	'ar-IL': arIL, // 阿拉伯语
};