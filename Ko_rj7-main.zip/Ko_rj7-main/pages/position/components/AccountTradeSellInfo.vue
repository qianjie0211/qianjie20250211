<template>
	<view class="common_mask" @click="actionEvent()">
		<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
			<view class="popup_header">
				<text :style="{color:$theme.STOCK_NAME}"
					style="text-align: center;font-size: 36rpx;">{{info.name}}</text>
				<image src="/static/close.png" :style="$theme.setImageSize(36)" @click="actionEvent()"
					style="position: absolute;right: 20px;top:15px;"></image>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_TIME}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{info.buyCreateTime}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_SELL_TIME}}
				</view>
				<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
					{{info.sellCreateTime}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FLOAT_PROFIT}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(info.floatProfit)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>

			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_PROFIT}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(info.profit)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_PRICE}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(info.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>

			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_QTY}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.buyNum)+` ${$lang.QUANTITY_UNIT}`}}
				</view>
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LEVER}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{info.double}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FEE}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(info.sellFee)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_AMOUNT}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatMoney(info.amount)+` ${$lang.CURRENCY_UNIT}`}}
				</view>
			</view>
			<view class="item">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_STOCK_CODE}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{info.code}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'AccountTradeSellInfo',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
			}
		},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
		},
	}
</script>

<style lang="scss">
	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 12rpx;
		margin: 0 20rpx;
		line-height: 1.8;
	}
</style>