<template>
	<view>
		<view style="">
			<HeaderSecond :title="$lang.CHONGZHI_JILV" color="#fff"></HeaderSecond>
		</view>
		<view style="border-top: 1px #272729 solid;margin-top: -10px;">.</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view>
				<block v-for="(item,index) in list" :key="index">
					<view
						style="padding:10rpx 30rpx;border-radius: 24rpx;line-height: 1.8;margin:0 20rpx 20rpx 20rpx;color: #fff;">
						<view style="text-align: right;color: #bdbdbd;">
							{{item.desc_type}}
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view >
								{{$lang.JIAOYI_JINE}}
							</view>
							<view style="font-size: 18px;color: #bdbdbd;">
								{{$util.formatMoney(item.money)}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view>{{$lang.DINGDAN_HAO}}</view>
							<view style="color: #bdbdbd;">
								{{item.order_sn}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view >{{$lang.CHONGZHI_SHIJIAN}}</view>
							<view style="color: #bdbdbd;">
								{{item.created_at}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view >{{$lang.XIANGQING}}</view>
							<view style="color: #bdbdbd;">
								{{item.pay_channle}}
							</view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="flex:6%;">
							<image :src="item.icon" :style="$theme.setImageSize(24)"></image>
						</view>
						<text style="flex:97%;white-space:pre-wrap;" :style="{color:item.color}">{{item.text}}</text>
					</view> -->
					
					</view>
					<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view>
				</block>
				
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/HeaderSecond.vue';
	import EmptyData from '@/components/EmptData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad() {},
		onShow() {
			this.getList();
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},

		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/recharge`);
				if (!result) return false;
				console.log(`result:`, result);
				this.list = result;
			},
		}
	}
</script>

<style>
</style>