<!-- 用户基本信息 -->
<template>
	<view style="padding-top: 20px;">
		<view style="display: flex;align-items: center;padding:0rpx 40rpx;">
			<view style="flex:20%">
				<image style="width: 60px;border-radius: 100px;" mode="widthFix" src="/static/my2.png"></image>
			</view>
			<view style="flex:80%;padding-left: 10px;">
				<view style="font-size: 20px;text-align: left;font-weight: 700;color: #333;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;color: #fff;">
					{{info.p_mobile}}
				</view>
			</view>
		</view>
		
		<view style="padding: 0px 15px;">
		<view class="cc_bg" style="padding: 10px 20px;border-radius:10px;">
			<view style="margin-top: 10px;">
				<view>총자산
					<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
						:style="$util.setImageSize(30)" @click="toggleAmount()" style="padding-left: 20rpx;"></image>
				</view>
				<view style="color:#18BFB4;font-size: 36rpx;margin-top: 5px;">
					{{yan_show? $util.formatNumber(info.totalZichan):hideAmount  }}
				</view>
			</view>

			<view style="margin-top: 8px;">
				<view>예수금 </view>
				<view style="color:#18BFB4;font-size: 36rpx;margin-top: 5px;">{{yan_show? $util.formatNumber(info.money):hideAmount  }}
				</view>
			</view>
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true,
				hideAmount: '****',
			};
		},
		methods: {
			toggleAmount() {
				this.yan_show = !this.yan_show;
			}
		}
	}
</script>

<style>

</style>