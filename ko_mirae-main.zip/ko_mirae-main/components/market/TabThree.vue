<template>
	<view style="padding: 15px;min-height: 100vh;">
	<view class="sc_kxbg" style="padding: 6px;border-radius: 10px;">
		<!-- <view style="position: relative;" >
			<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #283480;position: absolute;top: 10px;"></view>
		</view> -->
		<u-tabs :list="list1" style=""
			activeStyle="color:#fff;font-weight: 700;background:#f38325;padding:5px 10px;border-radius:6px"
			lineColor="rgba(0,0,0,0)" @change="change" :current="current">
		</u-tabs>

		<view>
			<view class="list">

				<view class="flex flex-b titles">
					<view style="margin-right: 20px;"></view>
					<view class="flex-2">종목명</view>
					<view class="flex-1 t-r" v-if="current==0">현재 지수</view>
					<view class="flex-1 t-r" v-else>현재가</view>
					<view class="flex-1 t-r">등락률</view>
				</view>
				<view class="item flex flex-b" v-for="(item,index) in list">
					<view style="margin-right: 10px;">
						<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
					</view>
					<view class="t flex-2" style="font-size: 14px;font-weight: 500;">
						{{item.ko_name}}
					</view>
					<view class="t1 flex-1 t-r num-font" :class="item.returns>0?'':'die'">
						{{$util.formatNumber(item.close)}}
					</view>
					<view class="t1 flex-1 t-r" :class="item.returns>0?'':'die'">{{(item.returns*1).toFixed(2)}}%</view>

				</view>
			</view>
			<view style="text-align: center;color: #999999;" class="content-end-text">특징종목은 총 100위까지<br>순위만 제공합니다.
			</view>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				show: false,
				list1: [{
					name: '지수',
				}, {
					name: '환율',
				}, {
					name: '원자재'
				}, {
					name: '가상화폐'
				}],

				list: [],
				current: 0,

			}
		},

		methods: {

			async lists() {
				uni.showLoading({

				})
				let list = await this.$http.post('api/goods/zhibiao', {
					current: this.current,
				})
				this.list = list.data.data
				uni.hideLoading()
			},
			qiehuan(index) {
				console.log(index)
				this.current1 = index;
				this.lists()
			},
			change(index) {
				console.log(index)
				this.current = index.index;
				this.current1 = 0;
				this.lists()
			},
			changes(index) {
				console.log(index)
				this.current = index.indexs[0];
				this.current1 = 0;
				this.show = false;
				this.$forceUpdate()
				this.lists()
			},
		},

		mounted() {

			this.lists()
		},

		onLoad() {},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	.list {
		padding: 0 0 10px;

		.titles {
			padding: 10px;

			uni-view {
				color: #91a2b1;
			}
		}

		.item {
			padding: 10px;

			.t {
				font-size: 16px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				color: #ff3636;
				// font-weight: 600;
			}

			.t1.die {
				color: #18BFB4;
				// font-weight: 600;
			}

			.num {
				color: #999;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #014b8d;

			span {
				background: #014b8d;
			}
		}
	}
</style>