<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view style="padding: 6px;margin:0 10px;margin-top:10px;padding-top:10px;">
		<block v-for="(item,index) in list" :key="index">
			<view style="display: flex;align-items: center;margin:10px;padding-bottom: 10px;"
				@click="actionEvent(item,index)">
				<view style="width: 80rpx;">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(40)"></image>
				</view>
				<text style="font-weight: 700;font-size: 15px;color: #333333;">{{item.name}}</text>
				<view style="margin-left: auto;padding-right: 20rpx;">
					<view class="arrow rotate_45" :style="$util.setImageSize(20)"></view>
				</view>
			</view>
		</block>
		<view style="display: flex;align-items: center;margin:10px;padding-bottom: 10px;" @click="handleCopy()">
			<view style="width: 80rpx;">
				<image mode="aspectFit" src="/static/icon_share.png" :style="$util.setImageSize(40)"></image>
			</view>
			<text style="font-weight: 700;font-size: 15px;color: #333333;">{{$lang.INVITATION_CODE}}</text>
			<template v-if="code.length>0">
				<view style="margin-left: auto;">
					<view
						style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
						{{code}}
					</view>
				</view>
			</template>
		</view>
		<view style="display: flex;align-items: center;margin:10px;padding-bottom: 10px;" @click="handle()">
			<view style="width: 80rpx;">
				<image mode="aspectFit" src="/static/women.png" :style="$util.setImageSize(40)"></image>
			</view>
			<text style="font-weight: 700;font-size: 15px;color: #333333;">{{$lang.INT_ATIN_CODE}}</text>
			<template v-if="code.length>0">
				<view style="margin-left: auto;">
					<view>
						<image src="/static/yjt.png" mode="widthFix" :style="$util.setImageSize(40)"></image>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: {
			code: {
				type: String,
				default: '',
			}
		},
		data() {
			return {};
		},
		computed: {
			list() {
				return [{
						name: this.$lang.ACCOUNT_TRADE_LOG,
						url: this.$paths.ACCOUNT_TRADE_LOG,
						icon: 'capital_deatil',
						mode: 'link',
					},
					{
						name: this.$lang.PAGE_TITLE_DE,
						url: '/pages/account/bangk',
						icon: 'icon_cneter_remittance',
						mode: 'link',
					},
					{
						name: this.$lang.ACCOUNT_CHANGE_PWD,
						url: this.$paths.ACCOUNT_PWD,
						icon: 'signin_pwd',
						mode: 'link',
					},


				];
			}
		},
		methods: {
			actionEvent(item, index) {
				// if (item.url == "/pages/servicePush") {
				// 	this.$util.linkService();
				// 	return
				// }
				uni.navigateTo({
					url: item.url,
				})
			},
			handle() {
				uni.navigateTo({
					url: '/pages/levelDesc?cate_id=2',
				});
			},
			// async handle() {
			// 	const result = await this.$http.post(`api/Article/content`, {
			// 		cate_id: 2,
			// 	});
			// 	console.log(result);
			// 	if (!result) return false;
			// 	this.info = result;
			// },
			// 点击复制邀请链接
			async handleCopy() {
				// 获取域名
				const temp = window.location.origin + `/#`;

				const result = await uni.setClipboardData({
					data: temp + this.$paths.ACCOUNT_ACCESS +
						`?code=${this.code}`, //要被复制的内容
				});
				console.log(temp + this.$paths.ACCOUNT_ACCESS + `?code=${this.code}`)
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.TIP_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			}
		}
	}
</script>