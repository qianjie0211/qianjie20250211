<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderThird :title="$lang.TRADE_LARGE_TITLE" color="#000">
			<!-- <view style="color:#FFFFFF;width: 70px;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view> -->
		</HeaderThird>

	<!-- <view class="flex" style="width: 90%;margin-left: auto;">
			  <view class="flex-1 bold" style="font-size: 23px;color: #FFFFFF;">大口取引</view>
			  <image src="/static/dazong.png" mode="widthFix" style="width: 120px;"></image>
	</view> -->
	<view class="flex" style=" justify-content: space-between; padding: 10px 70px;">
		<view style="background-color: #4d4d4d;color: #fff;padding: 5px 20px;border-radius: 30px;">製品を買う</view>
		<view @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
	</view>

		
			<TradeLargeList ref="list"></TradeLargeList>
	
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeLargeList from './components/TradeLargeList.vue';

	export default {
		components: {
			HeaderThird,
			TradeLargeList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_LARGE_RECORD
				})
			}
		},
	}
</script>