import Vue from 'vue';

// 客服跳转 读取系统配置客服url，外部打开。用于上架
const linkService = async () => {
	const result = await Vue.prototype.$http.get(`api/app/config`);
	console.log('reslut:', result);
	console.log('window:', window);
	console.log('navigator:', navigator);
	if (!result) return false;
	// "CustomerLink"
	const temp = result.reduce((map, item) => {
		map.set(item.key, item.value);
		return map;
	}, new Map());

	let url = temp.get('CustomerLink');

	if (window.android) {
		window.android.callAndroid("open," + url)
		return false;
	}
	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
		.nativeExt) {
		window.webkit.messageHandlers.nativeExt.postMessage({
			msg: 'open,' + url
		})
		return false;
	}
	let u = navigator.userAgent;
	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if (isiOS) {
		window.location.href = url;
		return false;
	}
	window.open(url)
}

/*
跳转到客服，内部分为两种方式：
1. 直接跳转到软件内客服页面
2. 调用客服跳转函数，用于上架
*/
const linkCustomerService = () => {
	// 1. 直接跳转到软件内客服页面  // 應客戶需求無需上架 by/2024.07.08
	uni.navigateTo({
		url: Vue.prototype.$paths.SERVICE
	});

	// 2.调用客服跳转函数，用于上架
	// linkService();
}

// 切换底部导航文字多语言
const switchTabBar = () => {
	// 为兼容RTL模式，改为数组对象，直接定义。
	const TABBAR = [{
			text: Vue.prototype.$lang.TABBAR_HOME,
			iconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEwAAABECAMAAAAcGiN0AAAAAXNSR0IArs4c6QAAAtxQTFRFAAAAAAAA////gICA////qqqq////v7+/////mZmZzMzM////qqqq1dXVkpKStra2v7+/39/fxsbG4+PjzMzM5ubmoqKiubm50dHRlZWVv7+/1dXV6urqxMTE2NjYpKSkyMjI29vb3d3dv7+/z8/PpaWltLS0w8PDxsbGoaGhycnJmZmZzMzMwsLCzs7OxcXF0dHR3NzcyMjI09PTysrK1dXV4ODgurq6xMTExsbG0NDQ2dnZ0dHRysrK09PT1dXVxcXFzs7Oz8/P4ODg2trar6+vzMzMxsbGzc3N1dXV3NzcyMjIycnJzMzM2dnZ39/f4ODgzs7O29vbysrK0NDQtLS0y8vL1tbWsLCwtbW119fX3d3dsrKyzMzM0dHR1tbWzc3NycnJzs7O09PT1dXV0dHR1tbW0tLSysrKz8/P09PT3Nzcy8vL1NTUycnJ0tLS0tLS19fX1NTU2NjY1dXV2NjY0dHR1dXV09PT1NTU19fX1dXV3Nzc2dnZ3Nzc09PTzc3N09PT2trazc3N1NTU1dXV0tLS19fX19fX2NjY29vb1dXV1tbW39/f1dXV4+Pjz8/P29vb29vb4eHh3t7e4eHh19fX39/f1dXV39/f4uLi5OTk0tLS2tra39/f29vb3d3d4uLi29vb29vb3t7e4ODg19fX3t7e4eHh4+Pj3Nzc4+Pj5OTk5ubm3d3d39/f3d3d39/f4uLi3d3d4ODg4uLi3t7e4ODg4ODg3t7e5eXl4eHh4+Pj5ubm5ubm3d3d39/f5OTk5ubm2dnZ3d3d39/f5OTk4ODg4uLi5OTk4uLi5OTk5+fn5+fn6enp4ODg5+fn6enp4+Pj5+fn4eHh5eXl5+fn6urq7Ozs6urq7Ozs7u7u7Ozs7u7u6Ojo6urq7Ozs7u7u7Ozs8PDw7Ozs7+/v8fHx7+/v8fHx8/Pz9fX18fHx9fX19/f39fX19/f3+fn5+/v7/f39////k6jyKwAAAPR0Uk5TAAEBAgIDAwQEBQUFBgYHBwgICQkKCgsLCwwMDAwNDQ4ODg8QEBERERITExQUFRUWFhYXFxgYGRoaGxsbHB0dHh8fICEiIyMkJCQkJSYoKCgpKiorKywsLC0tLS0yMjIyMzQ0NDc4ODk6Ojo6Ozs9Pj8/QUFCQkNDRUdHSEhJSUtMTExNTU9QUlNUVFZXWVpaW1xdXV5eX19gYGBgYWFhYmJiY2RkZGVlZWVmZmdnaGhpaWlqampra2xtbW5ubm9wcHBwcXFxcXJycnNzc3R0dXV1dnZ3d3d3d3h4eHl5enp6ent7fHx8fX19fX5+fn9/f39/f9quiRkAAANPSURBVFjDY2CgPuBSc42MIROEuqpxIRnFZpbde/DOMzLB7X292WZsMLN4/Wc//vSZAvDp8Wx/XohZ3NF7P36mEHzcG80NMovVaxfFZgFN2+XFCjRMpf8DmPfuLZngHdgtH/pVGBiYg+6C2O+uLJtDJlh25R3IhLsBzAx8daCwf384UYDcZCWQePg9yGs1PAzyy0HRcT+DifxEypRxH+SgpfIMqodAph5XpyTJqx8HBdtBVQbtiyDD9otSYpjofpBhFzSpaNhF7aFkGBPueGUi0TDppJb6WGGsWnTSW6otWUkwjD33zMtnB5NYsOgQr7/28ukkIxIME5kKFH4zUQKLDocdwJT5MI6FeMOkV4Py7AYNLDoCTwKlXhbwk2DYWpBh27Sw6Ag5DTKsXICKhpWNGkbIMGYWJlyGsbCQaJhicpanCFbD2O1S0ux5STFMoerCja0pvFgMY3Kbe/n6Yj9m4g1jCTwL5CwxwWKYUPtzYE7pEiDeMN78F0DeCV8shqmvA9UhK6WJN0yg7CWQdzoMi2Fa20CV7VrSDQsZNWzUsJFj2Bqk2kmgBDk7BZ9Gqp0ghq3Bb5jIdFC9OU0OUmalPgXKHfCGSDntBNabDxIgVbriorfAJuJCCbyGcRReevH8VCYHhOe47f3HF33QSlSq7eaLp/MtoF2HspsfPjyq5cXf1tDIaW/PUIC1VuNWbenxgZaATJZFHa3usI6NXuP6ja2WjARaQawSEvCuCwOHqY0SoqnCLSEIrxGYpK1sZJjQi23NsyDDjkhQ0j6TOAIy7Kwmg+oeUGv7vBUlhtmcB7W2d6sySE4B9QieNguQb5ZAMyjWP08WY+AsBaWYj1cbvPV1yQL63g1XQb58X8zJwORyDuTGj0+Obt5AFth89AnIrE9nXYDxIdH08jMVwMsmUBwyWc96S7lZb2dZgxMKq8uCV5Sa9WqBMzQ9MsnGz7vz8i3Z4OWtefGyiGY9q0F4RWc3maCzItwAtUXPJKSsTiZQFmJiGOlAPW/CDEKd/BkT8ojqO8tW3ntNODm8vlcpTYRh9tuJGsr5tMmWCMM8jhGX6A+6EWGY8TyiRnM+zjQkwjDeqBW3nhIa5np6a0U4LzExwGNOxLhchDkPjRMVACK0iQHTKRpEAAAAAElFTkSuQmCC`,
			selectedIconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABECAMAAAAhiEISAAAAAXNSR0IArs4c6QAAAtBQTFRFAAAA////AAAAAIAAAICA////AFVV////////M2Yz////////JElJJG1J////IGBAIGBg////HFVVqsbG5ubm////6Ojo////O3Zi6+vr////n6+vv8+/0tLSnLi4xtXG1ePjv9nMxdHRqr+/1d/fwtbMzNbWxNjOvdDGkrak2+TkucrK5e3txNXMtc7Fv8/HydjRvNLLuM3GrsnDvtHLn7Oz3+bm2+HhmLOor8W/m7mvmbCspsC3wdPPmLGpqb25q7+7obi0nbavl7Spore0o7+4nbmyn7qzs8fArcK/q8C9m7mwmreujKmjmLWsm7evrMC9rcS7o7y2iaqiqsO6rsXApr22sMO+ucrFnLWukrCpobq0us/Hm7SwrcK+uMzGs8bCuMrEoLmzrsG9pry3qcC6pL21mrStmLGspr65r8W/n7izr8XAnrm0n7iypr24r8S/vs/LssjBm7avrsO+qb+6ssbDtMfCqMC7rsS+tcnFo7y1t8vHrcO9oru1qL+5pr+3r8W/r8XAqsG7ssbBrsK9ssbBt8vGr8S/ucvHuczHqcC7qsG7qMC6v8/Nu8zIyNfTwtPOxtTQuszIwtLPxdXRs8fCu8zJwtLOxdXRwdHNydbTt8vGwdLNydfTuczHxtXRv9DLydjTxdXRzNnWzNrWvs/LytjV2eLg0N3a097b2uTh09/b2uThwNHNyNfU2OLf2eLg3ObjwtLPzNrW3ufl2OPg2+Xj3eXj3ebk2OLg3ebk3ufl4enn1uDe4+ro1+Hf2ePh4enn4uvo4+vo6fDu0t3b6/Dv2eTh3ujm5+7s7fLw2+Ti4enn6vDu4uro5+3s6O7s6O7t7PHw8/b25Ovp6O7t6e/t6/Dv7PHw7fLx9fj39/n4+Pr56vDu7PHw7/Py8PTz8fX08vb18/b29Pf29vj49/n5+Pr5+fr6+vv7+vz7+/z8/f7+/v7+////WSVSSgAAAN50Uk5TAAECAgICAwMEBQUGBwcHCAgICQkKCgsMDQ0NEBAREhISFBYYGBkZGhscHB0dHh8gISIkJicoKCsvMDM3OTo+PkBBRkdHSElKTVRVV1hZWVlZWltdXWVtbm5xenp6e319goKDhIaGh4iKioyNjY6Pj5OUmJmam5yfoaGio6eqrbCys7O1trnAwMPFx8rKy8zN0tXV19jY2dnZ2drc3d3d3t/i5OXl5ebn5+nr6+zs7vHx8fHy8vL09PT09fX19vf3+fn5+fn5+vr7+/v7/Pz8/f39/f39/v7+/v7+/v7+lvplHAAAArVJREFUWMNjYKAdkLb29iELeFtLYxjGblK49u57ssGd1YUm7MjmiUasfE8hWBkhijCPL/HkW0oNfHsykQ9uoMeRd+8pBu+OeMDM414BFnl58xqZ4OZLsAEruKAGhoD8++7qtOL0DLJAevG0qyAvvg2EGtgFMv5WnRT5KU6q7hbIjE4odw2Is16OkjQstx5kxioIR3IniNNLWa7oBZmxXQTMVt8D4nRTZmA3yIw96qMG0sZAVqfsWFPsurhc86JlSDWQNXzfjYvLbLDqSjt049JcZRINVJ0E5LwuYcSiiWc7KEflk2ig0RIQr4kLiyahc0CZx/VkGdjCjcvAJ82jBg47AwXt3YzZsRso7+iix0qqgWKVh64v9cRqoHbryUuzbBlJNDDyPJCzmBOLgYwp996/f9UuS6KBDY+AnFNCWAzkagRVdIsMSTSw+QmQcw6bgdwtIHVLjEYNHDVw1MDBaaDaRGCmf1kKLZaqHwClDgtAOLzbgJwbuRAOR+0bIG+BLkEDOeIOPnu4zh3Kc97y/v3TNjYIh6Xi7PNHCy2gUkHH3r6/X8RHuG0jGpCV7AArpBm9+mZU6cOkxENzEizhfYew/ikFKqS3vhQ0+HDIsCqqc2GtU5R2gzg9lDXnekBm7FaCdBw3gjhzGCkxj3E+yIwN0JCaB+KcCKbEwOAzIDNmQ3nlIM7rzb4S/GQCCd/Nr0FmlEEN1DwN7qq92LWcTLDrBdiA05owB9c8e08F8KwGHgI6E15Rbt6rCTqIFGU+8yWl5r2casaKFEscmTsuvyC7F/7uxeUdmRxoEW+Q2jF5OplgckeqFsMooC1gt4oiPHQRZcVOtIFJBy4QHlu5cCCJWPNY9hOX/PYyE2kg223iDLzCRqSBTFuJM3ATE7F+jj9OjHlHY4iPZmE7P38CwM9OmD5JDgChNgjiGVuazwAAAABJRU5ErkJggg==`,
			pagePath: `pages/home`,
		},
		// {
		// 	text: Vue.prototype.$lang.TABBAR_MARKET,
		// 	iconPath: `static/tarba.png`,
		// 	selectedIconPath: `static/tarbar1_act.png`,
		// 	pagePath: `pages/market/index`,
		// },
		{
			text: Vue.prototype.$lang.TABBAR_FOLLOW,
			iconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEoAAABECAQAAACM02uKAAAAAXNSR0IArs4c6QAAB6lJREFUaN7tWutTE1cUT3goKvhCWy1YoPhqpWJnrNPiqyItSLUw2oq2pqhFKRYFgoAh2V2/9y/ov9DvnXGmH5g+xlINCckmu9kkmxd5GSMxk9nJZDKZ28TsZjdLgF26if3Qcz/B3Zv723POnvM7516ZrICAMrwRbTN34eelHejn6CfoYbBBJlb+riV6n01GNTGYQuKSDwqOQS+nHQPzh4BcICBv7cJFCgJI8UcSCd717gdlq0JyNj4fLQUgZlAa+xlQsSIkrMU3VUpIr2DBWC+oXF5Lu7zjKQSUfMRgvG0Z7wLrPTfYB1PIC5gYnj0zs/fHTT9tlHI82v3bB/qv/aoEB9ZLlaOhsJ6OxGHWBV33H78vK6LMVKPXIjALy91f8DHfMKslxzCxQ1ZkARXmrmgOVhw2vLHkEUsNq06/Gm+UlUBAJX4rmdvVdGHJA+b2HGZE/5WsRPL77ue5iOgfWzLtUDCTL+C/GmUlE+s9Zt/Faf9G3qRniJkMTgsO/hKI4Utm36jGUM+b9Ofi+MKUrISiO8eC0vMt5Fe+HlBznf+D4rMzQzt6GWvhc4LXCGp2s3WQghNIBDK1/idAgXLboUCOe9gU/wFQoNze9VLNJjCs97WDIrfg1ykO83Df4+fUooCarSe+NV9D9xQMjPXkGJtRE4jtJl7LD8ySgwIbbRcoOJsiiIN8sxEnFjlmi0KzZ2TyoocE8m33rXhOD4Hx5zXsXKga62XZWQLx3MdaShCn9G1BVT51xgaYAoCosw+zcOOI9XpgZ9GDJ1hnuspljXQBgBh7Mx6jey8wxbKkOKw766xa/reedEkACsjJ/cGRFKd2i0DMX1HIesrUmeSQat/E0wOrlL3tK7EEQaDAOvw0G3XSPwRbr+saPEoGVgxKcDSHD9p25jNNYgdRZ6u3vLW4BZRn//fLLoYSe8bAujWA8tYSAzFO1AmqLMdBRUZ3ITXfmFEI/Qysz/HaXfOdxC3n2MJUUBVU+VW+CeeI+Zr+eIbWYae84yG15wdD05INVwdlOBC4n+Rs6xrWNWTTazrZnqXyfCw0ZWqlI5Jc22wfDGsoJLWkaKfgkIq4Yq7W7kD3WGoKbLkyKHO1+RzrK5moY+x9mJfv0cvJnNmsg+btWbD6RsfAauVtHMIvpc0pFwUKyBfqyO8TnDd0T+mO8inIz+WuO5lnXkD63mxoAJWW9vB0PqRUOmZRSJIHK4X4R9yHRIHCaz1j3K+N6Ne9tUye+8zSwwRJILd8E+OYNI54lTYF0U2cJU5in9p6HAOhB1xwi2q0TQQorCXFcV+807ZeQAKSG79JcGKV66bx/XTeq2Dnbeux3WibR8kCC2vmTwgGZWnKOnECcSl1DcLoCn4xntOsc+SPd5Z78mHZ47aQmnnpiMbRmudby4NyVlkvBdUhtaFfv1UQJDnRGoEYp7fdXKHNkw2fTc5RRqt+ZXS7wK8PVKLN9r0COm6vxLjNPcr4kbMPCDC2f4eTzhEpxN5XFJJnaE/SG5BDS2reZWS+LqRiWmjaLZKDmqkIPaArbZVup/B1v33AmNChkBzU0wOM2851iVn3sMxOt6IWVcZtEoPCFEzOn6kSWcAfjdMGNJ6WGJRvks6MN8WuRN8MTNDhWSEpKNvmiCb7K4aT4ltoVrrn6r5LExtpQGmbo1D2bbUHxa/GL9LMajy4SUJQutYsZYvBaLP41Wkm8gqBb2IxGxb896QApT+SBUUh+n3iVxu7eaCcg2xiNK9bs6YaIrT5zO+J9im5he7qeZV00LVcZvv/fx9dKyhzdZh2dKxD7NqFDfbbdPj8gU5p6RO4XF7HhlY5wllBPON0SLgjduWTPUFVdn/rVea7qYxrGFgReO6jtYIi+pgc9usWkaBOJWlLYezuzj6WB4bVuo+FsgJe7qtnaBuhENNlnqnKhs5M0cGhkURdmFMoxSDTJbR5DWaUe8dofUNinF3fzeRM/FIeX3R2UvnnlmpyFB/EFEIHqpg/b6khjsVp6uIat78hDNLjY8zJA6Wxbc7/KDc4bi2tNBIiBoV4lJYa7yDzWuSQELY6u8+da5aQ3QUsS95I/MsjxbmTtub0qQX9l3dstn4l3wLl+uPhaUYBnqGCRWm6R3klqvk3oHRfpINoB9uVCT0wdb7YXLiNjTWgfUxtna7+VO7lSgxQYW9xfReD1noiPFufeTWsI85pdSxMoJf/eIf7PWsrn3xovuGfTnIqv3SXfaXvFVSRb5PnA3cWVRQkZjybJE4wWiA7uBcJEuma0a+yD2MDpn78tnM0pI7BSV5LZO5wMY4V5LyC9KDvvhgPDanIfSU4QcNrsSvh6eQKQBJpTvBsMpU7iHTtLlQgbZrbK9WY3fdkFyhzNTkueMfiS9qRmd6N/3t7O9garmNuQ6Q77aPajbzOib4nqI7AEg7IOfJoOygzbrM0WTvc/f57gfHFqWdK3x3nVeKYfU9wU8ZcQI6+y9DoFELc1nJravJDCpb+KkSaiAjwkz8PMT0aCjFwizPy82LczwhrFgRdSzJ2ROlGivlLbivjdKIIoAITM4LSOqgkuzPaCk86ua3ryFbfXanvusRh/RHhRRa+nzjmeJNnblCGHsbPW3qkGeYe0xlt0W+ClFT+ATq2ByPXWXm0AAAAAElFTkSuQmCC`,
			selectedIconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEoAAABECAYAAAAm2qMBAAAAAXNSR0IArs4c6QAADVFJREFUeNrtXAlwG9UZdsIdznCTUgKUhmOGoZCWEGg5mgINU0rpTAppC2TaDkNbOtNO00IpLWkaQj2ExCE4xHZsx7ct67AsS7JWWq3u+5Yly5dsWbLkK7Itx5csS/0fJbBerY/YkpHdvJkdyzP79u1++95/fN//NitrkS2RSFxUqySeLBM37K3EsZxqqSivhsBOZOKB7g2O42Vi/r5yifCXgUDguqx0t3w+fwtLKSlxdXkH/f29k73h07HTkeH40Ggko49wZCTePxyeCZ0ejHqDPWOYSacvENS9BC98fUoBag50bJHbLRUDw0PTiTXSpqLRuLW9tVXpNP8I/r1wWQDBBdZJbLqnHN42X2xmJrEWWyg8OCUwqPbDz8uWDFQZzt9tbnWHE2u8AVgzNXJxCfzccM4giY2aB7VuR2g6FlvrOCXi8XiiZ7B/pkGn2ntOdgtOvlrjcihm4ALUhoBr9ftibKW05Sinav9bhcd23rh7x00379p5Q6Yevzm0f+v75cW/Oimsa9C6naMjZ0ZpAfOGekbVbsfjiwaKcJj3gLdIMkpnJsYTEou+718V+b/IWqXtnbK8WyqljY2dvcFYnGYiqJps0kVfTN/c1ELjJRISs97D02juyVrlDR7nUoZcktPd35s0GYbPjMby6hj3L3iRT3HG18YnJ5OgNrU2j7NUkqeQJ8xaAy0YDG6olYmNY5MTSbOqhmgsWPACTEJ8gNoRgsrECR6LkbXG2r6yvIfcPm80eVK4uxecEEKDRkzt2BH0x7JrSp7KWoOtQatsT37ewJiizXLDvB1ldpOT2tHS1jwGfy5Yi0CVYA011Of19YUmSyS87fN2NHpcPmpHjcsezlqjLZfHPEYD1FSZmPfkvB3Nrc0Bakd1k23NAvUJt+bIeaDOAzVvjHRhqbjhQIVEwKzEhbsRd3YeKEorELBu5WkVFsQ9QeCY6OoLRSsJ0WvngfpyFl0s0KpesrV7wtT8tNGoxc4D9TlIfJ0yB2KfpBA7Oj2dQPTJ/z1QLDW+mSHD5IMjw0kp12R0Cu7b3i42a+9dE0AdrCzcXq+RS6plmOgUxn1ssblkJQSEErOhe3R8PClXG50Yj4OtUguNqrsX4pcyGigERlsodANLhRcADx8jpw4MJf7iQkuNqSLe9oYC43RcWXd/X/QYp2Z/1q5di8okMhoolcv0XYXTahimIdAsrc1BzKLaRNfP3dV1C1MhOQWqShI9gmaWymnrO4Xxd6/6OArNpCJB3V5HR2sEGdq5aNlaBa73+/2XkfvVKaXbeHqlBwjFpD5IkoKlJtO5XPedKw2UcUB5BgaurCaw+i5gFhfisCEOipeKeSVn7ctxbu0uSMzDE1NTdCDFioTcg0qHY+NS7usYpzonI4BCD8szyJ4HNaeTTqhA9HJ70B9FXopys9NCg/pdINcOw7JKWmqIcNM3O/uPsiteWM4LPFRb9j712p2hnqkF2YNUAgVdr2Ap8fdg4Am6JQZUbKxOLZOfEnEfVzZZe6hABgcHogBkkuvvGwrHWQrcItDp7ptriSPpSWQy3cPXKrfx1LLtQoPsO6aOjtuQMyCf+8ZH+x/0D/TNGljhMHerPJ4rVwQolcd+Nyg1etDM4nTeydbeEuGoZX9FwiOadbhZ+7yzs2OcjvAnN3ioaDXeeAh+XkUF56SA+WCBgHOkXiMzEjZjNyguYXieiLXNEwHWMqJ12Qdwi6EThSL5grq3WoLB61G/GkL0rq7ZGWr2dY5D7OVmy/HvL/iAqQCqqJH9gqnF1UfHR6MGSk7LSZhFZCkb/S7H+AdRnkbXB6Umzs72cK1c/CqFRFyfU1fxrMCgtrb4uyaRfZvLUZCXOxI9nd62CFct5+Y1sm6pJIh7ykQNj6o8lk2LesjlAEW4DDfXyMQfA0AzdLMI2Z0yrOFU1tatc2b0YESZVHuFHh6WqLUYw75JAvaiYjC4YMf00djySiIGRoamuWpZpTsY3LxoAXQpQKGLa1y2h0HOstFFyqDqJKDII1zcyH1joYKIjwWCS2DGuUbGziRQvUNboDta1MhFHvBS0ngbgOs+0NTlHZtPyUYzKzI+loCgNo5m0Xz1E+jlGFvcXqnN/LO0AcXWK7eomuzd1Jlw1jtxVATBJLBvLzbGUblct4ETOAQ2roijxHeT+zEYjAvYSkIIhp72qSGIjWubHQFYilidVpZbpyI+YMrxv7MV+IcwK4uBTdDBEh5GL4/OwbT3dE8UCrl/SQtQtQrJy3QgBQb7o2Aoj4hNpquXEpxSgUUgASEnQLMtWVIbmQFDrS6XNv68WinZ8rmTWEed+eD5rq6QNmytwkV7lU5rgA4wKBmYyudz/pYGoKQ7wGV/8YbRg4jNhp78evYTKcwPL6mWiSvQjKEaZtyi78yuLHsaTjs3cRZs5cGqor3I2yElfFYdQjAwKbboX51TfVoKUA6fYyMshyq7t20cpvVEBS6UFguFt6cQpPUCvfxVFJiS7wvRK8BFqUR2++XLuf4JXu0O3GL0IXtGXoaWNk/A5ffflVKvhwxsNY49U6vCdy67go3SqnHBNxR2cxeZvQyPjsTFZh0HVd6kIgeVO833Ssy6TrIJQbMMiszYq4a4OyVqOECOydDDiIwaZzASuT6V45Tymdvs7S2jlHKC2AHWyc0ZD9Se4n2XNvu8w+T7gah+9EQd4750jPduYe6vR0lL8HPeXZzksTMNqBxW1Y/JsRKyHQXC+qNpG/D1rRc1GjWeWV4w0D3aYDTemdFAQXiBke+lG+oCjhCca9I5ZiEExojjIiXhMyUi3nsZDRQUtQ2S7wW3GtXpHrOQx34AkugBctDMVhFYxgLF0hG3QqQ8SV52ZRLBO+ke1w7hBk+rVJIxIGzmtlkUTSYBVSjgPIPUXnJwWSzi/GQFtMJ1oAeWk8MRtcsW7B3tvTEjgcprYL4GW0m+sORoS0k5JnhmJcaulmPHyOkNYlO9Qe+XYYKu2dGRKUDl17P2BEjsI4rESzHecysxdoVU+Ak5dksCCoylhQoU5EJTuQTjipUHiv0ElDlHyXRNKdawawWW3gVMpbSGMll6gpHglwEuUCLMJBZgoG/mOK/mjZUGqpjg3wyZ/Kz0vlaGZad7XJfLda3IpDWR2VVIl9yzUrMKvPEVOuIN4hknmTxbqaZxO4OU8KDpnFmCc5WwWDWP2UipDHIiXI2CN+sknsm0AbidJHIJmMaZPD77TytdZw4EHofCGMReP7rvtnSOeZRV9Q+yIYeAMwai7B+TThSbdBw62hTI+3FQOf6canZgvra/5MT2ianZ5BpbiWPpqlL+7fEPNhpbXAPk8UAdCuva2q5KOhm3aR6GGTROKxf1902X48JK5KZXZinuW691Ofyz6sBDgShwXrvSYMTXwar5hMrDMxXiyjnZRJnNfBiWYHwuuQdIrQnMpPUhIRI24YhTfZRL+GLgrvO4KssmjgL/wwiJ2USigdisD9XJxfenEqjDjLI3nd72WZJO71B4krDbb52zUyASuA5ERAMdF05OKRC5hZSXdBwobkK8Nlel2gS7nqxU0UJo1DiO1TPuSAVIHzErnlM4rBHybELeDmqwchfszLES18CsUdLJ2ivZYKP0O0yF9Fm0g4Jao6n3NHUfr69+ZKk2C+Vv+QL2W83dXWNUqUvpsDotHs+mRV8I+Jk62PQ39VXtKy7gc07+TzLnZtNVw1g7WkeqpKLDzp72ry/WK39WZo3VPwFVw2xIjWaoYi1ofBGRTvf0OXl5ZLSBfN9NWI0a0NNWdKc62MnYcVb1I2dfWq0c+w9ViUEmANTkhMJpGUD15UdYFT+YyzPn8Xgbcutrf8eQiRVA4Ywhe0tTzTIuNKpfXtJ2f4Ssb9i3sU4l+x5cJA8GcbX1+CNwg1GwJSk/QOaOou8r8DTyt8lvFUnpUDSWDeNO09lMVMXXEeqZRjMCRFAPSynVQRAtBTHVhJn0Pqg3mECZBgJoroIQX39vNJ/PeiWVjmJdGo/1c0Xg6E1DiPIi7HvuoxNDl7oBm/wbPmEwihl1z6X8IxJfRUNSfpW0kevyecfoFN/FNAQ07Cjrh9Kg0+QqGGSPIfD0a932hxZ1M5+K2DceZVf+8AinfGcmHcid53IqvoWWotRi2AFJaz7UOPlh2S7ocT6rrIHlBefbMbP2/a7h3jtMra5tBk/TENlhfeb5nNaug4yiuTc5Mlyui8EtF0FyOIF2dGfi0R4MTCM5/e2TuXchwCQO452oCAwq7LKlViMBD95u7WgJtvh9Q9a2lh6d29EE9Qn1KIBtMMgfdXq9N51dWuhvqVj4UyjhnqSGCTyNwvShqJRejYaQ4Pe9UGy1Gj7wAB+laU6VLTlQXvQSFJnFqNJ9BS7IofVwANSnC5UJZkpDnFWjS3NtyhRjjJ9NZlbRByXAFtbQAgVv6Z9g6FYFUsDz9xOdRMoSdFRHwTeoc1ENFposTV0dp+FzJPSbzzuHQrdDrNS63LK/dDd4mTFgEvakgUm4vEYpeh4Iuzelev0D8y5tFN0WY/Wv1ColJ5gKvDiTDqgVLQKA/l0s4q36L3us2fZfWn2Wc5kJwPsAAAAASUVORK5CYII=`,
			pagePath: `pages/market/overview`,
		},
		{
			text: Vue.prototype.$lang.TABBAR_TRADE,
			iconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEwAAABMCAQAAABtnpmgAAAAAXNSR0IArs4c6QAACg9JREFUaN7dmttTE1kexwkBFFRUvIywWKAroguuoi46g6tGvOFlXXZmdXVnZkcuchNk5J6QNP/GPM3bPPA6VVs1NVVr7a6ljgRIQjrdoXMlJoSQEFOpVCqVSp1tLt3ndCfduUHV7nZetHPo/vbvfH7XTk7O/+sBpBqZ5dncveVd/12ytluexTBAf5zPV3Zzv7PvJa7O37VUg7ytlyEB+UCKnqF+4x8Ha8JiGH4G/cZS8aF/9XxQZW/cYln4zvnP7S9sz/W3kHN1AeW6MIDNNsDz2iP24djG+Y+Kidyts1WB/pZnJLJ2o7BqhrWBo8QxvH57/7j2CHNWXbo4wMhateWfpVsjKs9W5xsEGPwsDgPWBv+sMvf7lNaR6XNAsmHFQysj6Gp7f45kC2RZD5keRVTojWjrKOcOo2te7VHnQ7YWBwBiLZdccxz1YerX1BXz+Sx9GEioGudgFAO8TwjTNSX+C6LSMRRDVrrHjCeABMrCGz3yCO0Qpnb73iyEzV/+qIjFyVq1A9GR0D0OfRhA13sV2lqAbKNeFtywfRgz/j5Ta20zNnHlhGlLMf92jOAl8bK4bHkVPx1BN1EvQ21v+QJk4qugkHoY5tjIrdA8JJ4w//cpiVP8TYxjqwa5Xr7hRlCFwmC8lFFwsHwRQmRFMFOvoQrkEqeYZ45ieJM4W/MnUbaImwEVej2qhcwEf9NtrrW0j/+9hqqt1CtnzlKt1u3MenKXvYPL1pQAW+sfUztVnIEnzl9Ab+JXvb/NxCFXkamDvfmIoZSl61hIhcp6VSnMFm39djQT0GlOClKJc6ZjK3J4GZ9KI4OQ0qLvxtgbGGqZ89PHGIskYyuMUW34Tvi9r3j+uuUhddO1P4ks4/6Fb2OItWhZ3KRd52dvY2iGW2ntiq3L4rFluMFjq82HbOIv+8xd4bXz5k5fsWhtRT1AzT59i+/SpoPOEZhq4JZYPjF8tTBAtemOps7WZIG9l7lbUGU+LyLMUh1iawXa757E7z2dC7oZi0ZVk4XIV5KJPA47Sdiy7rH3olssEnBBrrsPeqKpT5cwaej+CD1WfVbwWknY+rDP9ByV7RozVAjXW4g3useJ44lXaY7DCoz4RgiJZGxZeiKIrMC4vkEwD4A810v4fPq/CC18ledhKaN5S+jo8Wyh4RRla022Sn1BJD3N3wizF7MPvykUJpH4G7MuqNRWx1srHbZWSyhNvQj27h32F5Cvtw1iIWWqHloW/0N2bPmUZINoMjeehuQ4B7/LFxOmLoqw4ZTqBrmZs+VX4peAVDR+mf8UY+01ezVZdlgagOWPEYnZM+cDm8fWekuxxNb0juH3h5IJMzSz/qQizjFnJ3KXBoXZ0u0VZwvkag/ix8gyThdqqY7A2vQxSNrTaGvh+vl7jGdOSj8qULY8abBFF92XnMMhzDtmb8QLYAa8Dy2A16fSoHhHmb+wdqiLmNhvacuMLZBruOxTMQpIWPc6WSO7Rk0HU6lvLc9gSThTxm5x6UJ3hJZF/lWcLU09l633n0HXAxjZwOa/ENvmE89Tqo1yyNtRdjP1p9Fc+v32iQJOCotjS32By9b7zyKcuIczZROxD5KheZTiuOCMn31G8qHwug/0JoqzpbuMWiuC2SCbtNOyxcdsQ2rCHCXOYbYvHxSaTaTD1npFY+4OwO6LuAcLw5mKFAvwXHMXrGV/LBJol1tQa0WTsAUwWw+nojF9zXyxrKS2pdob6O7APmo6YS01uTsqGre4bEWxhe5JbqCyQw9TpNyy5BK3YNInnyZa88P+KMIWvYmibFm7zLzBX85CJyxjUu2kDGfd4/CyVE/CZRJHrwBbEsPFZWG2mMPVDzNfasK0tV4FysbsDcFJ0TfesaWX07/lsqU9uDDAZcu6J5GH9aYjDEimakNK4ZwYR5o0/tt3VQGkt7D1MGzp9s5W0e3M9gy2knbws6i1+DkxtWOmzDUK2WKGyu/KP/QH6eJz4elGkrO1pQo/ny1+Tkx9BE/KVgN0GDO3QLaIXiaXzN1bL6qRGc7Pu9Nhi1tvfZc/12x/YerQNv68e1KabHw6dVTfYKjV7oDnPOwj27o3IhKsLd6eFLaWNo4tdOj7pgTmxCi2NGx+ojs3dxjfCVKev1Lf8pLcVB2bkrDpa5mxxc+J61viUdi6qQd4PX4IpDC3/sfp1TFoGFscUO/fmN9DK2i+zIQtvISbE7nyAiq6mOrVf66pSSaPPEJeM1xGBixB9qZkf6IqPJ4t1Fr8eivxJ0z7Gz0qbp9t+HvxZKpzfxgwXHJteXK20MiEsrVqn6AqrIqJSozSfZjhEX5GW+4qSkIgdRNShl9KxhbqiVy2YnSrrPtU22hsdw76lJEk8rxyawdxX3du8YCgPNuRENspGr+GzUAytt7w2HIOrtfrQOLZSdXgjdanS0MhUXkxutRyjRp7NM2a4wkg8hW7+mAN/648NbYmeGx5R1+X8YfM1AFtte6Oqy+kFJcXxgJKz+jMlbhgQN2HDe/6W49EbKHQ4jy2nIMzZYKsSNT5b07pHzuHAuMhTJjAkEp3nV8HnPCyW+Ye/X57MraM+/lsIU2XSKalyrW3jc+cQ/7xxARaenkhBRTYuqHN1DfxunTilnOQqEwnV/r3UDXETfPTxZEwb0vNXXGk4ZfgSDygTCdueUdFNlGs0yqY+4SsJh6HkK0kriQws6M3kXH5OTGerTe/yuZVP4k0LI6+hEMW3YlIgnidNG4dzea1I3EO9qd0QqwRWOhs41uLy5Zub3Zs8Y/XZY5heDXHM8GFrgr0rQjdZLSIs/W6LBtZE3lkJwwdH+XWSrE3uldC7CYSnDn/L/s2k63VUlH7GEVm/rpo3nTvIFtCa8MC4omjcKvYWp3Vau+HkLxJdSftHOgs96mpyVgPtm0dW9S2uWY/cr2lIVtpBpfZrLgF2dI94bymVQm97BA94tnKRhaQvC4zdqMOFlTCKW460bnE3LWJcUuq/51jmPualrwGpBk8n+EGms0WhywVmcv61wFDm59T/gTHTddAfiZPmEs95I0p7/60IxNRPxa9u+OSczuDiMpwFkgzJMIk46cpjxx/8LYSFKT+i4S3lfgD7xi/sF4aNFRl4UHWPVRrfHHskZOtpIwef0jFidIdJWVkq0cen4HnO90Hc7I7QCFxdWU0QbVJTzrML+daZ++oz74rh2/rqG3q0qm6maa5VvNLtyJRxb8yZpKBwpzsDyBxHl5oiQj0OiG6ofUrl5WecbfCJfeMLyv9yoAqhCXuNCOYs8V5GGzmz7Y0x209wSQdo3jDEVTZeqZPgs3/LRndnly0dngU0bRF0T2kwtppuAi24gduTPI1HTM1OZ8HlamKCildfdbb5qqM4lW6llveZTpMymxtK2NRESutjNnaSJmlwle8hZYStiA9Nb1sbKa+NLdYO61dlnbLV8bmuavqE6m/MfgfO/4Dff0w2xRTQyQAAAAASUVORK5CYII=`,
			selectedIconPath: `static/img/3-on.eb299a8a.png`,
			pagePath: `pages/account/trade`,
		},
		// {
		// 	text: Vue.prototype.$lang.TABBAR_MARKET_OVERVIEW,
		// 	iconPath: `static/tarbar2.png`,
		// 	selectedIconPath: `static/tarbar2_act.png`,
		// 	pagePath: `pages/market/overview`,
		// },
		{
			text: Vue.prototype.$lang.TABBAR_ACCOUNT,
			iconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABMCAMAAADN28B/AAAAAXNSR0IArs4c6QAAAq9QTFRFAAAA////gICA////qqqq////gICA////////qqqq1dXV////kpKS29vb////39/f////4+PjzMzM5ubmoqKi6Ojo1dXV6urq2NjY6+vr7e3t3d3dr6+vz8/P7+/vtLS00tLS4eHh4+Pj19fX2dnZ29vb3Nzc6OjoxMTE2dnZ0dHRwcHBysrK09PTu7u71dXVzs7O1tbWx8fHz8/P0dHR2NjYy8vL29vb4uLi1tbW3d3dycnJ0NDQ19fX0dHRzMzM4ODgwsLCzs7O1dXVxMTE1dXV3Nzc4uLi0tLS3d3dzc3N4+Pj1NTU1dXVx8fH1tbWxcXF3d3d3t7e0dHR29vbzs7O0tLSxsbG19fX1NTU3Nzc2dnZ4eHh0dHR1dXV2dnZ3t7e4uLi0tLS3t7ezs7O19fXz8/P1NTUycnJysrK0tLSz8/P09PT19fX19fX2NjYzs7O0tLS1dXV1tbW4ODg09PT1tbW3d3d3d3d1NTU19fX0dHR1dXV1tbW0NDQ2dnZ19fX0dHRy8vL29vb3t7e39/f2NjY0NDQ2dnZ3t7e0dHR2dnZ3Nzc39/f39/f09PT1tbW3t7e1NTU3Nzc3t7e19fX4+Pj39/f2tra5OTk1tbW3d3d4uLi5eXl4ODg5eXl3t7e4+Pj4eHh4+Pj5eXl39/f4eHh4eHh4+Pj39/f6Ojo39/f5ubm3d3d5OTk6enp3Nzc5OTk5+fn6enp3t7e4ODg6enp6+vr4eHh5eXl5+fn6enp7Ozs5+fn6urq7u7u8PDw5ubm6Ojo6urq7u7u8PDw5ubm6urq7u7u8PDw5ubm6Ojo6urq7Ozs7u7u6urq7Ozs7+/v8fHx7e3t7+/v8fHx8/Pz9fX17+/v8/Pz9fX19/f3+fn58fHx8/Pz9fX19/f3+fn5+/v7/f39////sQzXUQAAAOV0Uk5TAAECAgMDBAQFBgYGBwcHCAgJCgoLCwwMDQ0ODxAQEBERERITFBUWFhobHB0dHR4eHx8gICEhIiMjJSUmJiYnKCkqKiorKywsLS0uLi8xMjI1NTY3ODk5Ojo7Ozw8PT09PT0+Pj8/QEFCQ0RFRkZHSElJSUpKS0tLTE1NTk5QUVFSU1RWVldcXV1dX19gYGFjZGRlZWVmZmdoaWpqampra2xsbW1tbm5vb3BwcXFycnJzc3NzdHR1dXZ2dnZ2d3d3eHl5eXl5enp6ent7e3t7fHx8fH19fX19fn5+fn5/f39/f39/f/qS1Y4AAAO9SURBVFjDY2AYokBz2vVtgay4ZFlDtl+fpkmKecILHj95cs4Yl7TJuSdPHi8QJsFA0+NPgCAWl3QsSPa4KQkG2p4FaUnHJZ0Okj1rS8gURl5xGPC+ANKSJ44D5IFkL3jD+dyMWIzj86zomwMFM1c9AGnZNgcH2AaSfbBqJozfW+7Gh26e66Krj5+QDR5fWeiKYhxz0cUnFIKLRcwI89hLHjyhGDwoYYcb6H7tCRXANXd49K6HBMSh2VMgYPLi2yCBjZOnYAWTN4Jkby+GSc8+BAn+9bDIdgLzbzboiPFDgRs42eTw4wA54GTjBuOK6TTcBLvIDmpgL4h3vwkpkqyISdhWSCJN90FCPVDeZhDnoBCSvPkZkFAKLgNTQLJnzJFEhA6ChDZDy44jIM4MZB2Sq4EiV+1xGWh/FSi9WhJZaAbIjCOQ8knsJIgzAUWL08YnV4u5cBnIVXz1yUYnFKEJIDNOiILZEmADJ6HqYRPhwZfveUTYUAUmgcw4KYHbQFLBqIGjBg4dA9m1hKhqoMamS4fTqGcgsz+wwfHkoQbFBnL45IeJAwu1IHAh+yQDrkfR2RcNOMsRYSBr7pXHd2epMORCKtbHjjAtHlsvXEUDF7a4EjZQdR+Q82he7W1IVTYF1qaTXYalIfB4uQJBA7WQq/wHHfBoNr6Creq8pEvQQKlFCJfcb+eHB5LqTmwG7lIhaCCjxS6YiQ9qOJBardEXMP18IYqVcCwzGu6CmleK0iZmNQhLRQNh+uxEpUORdSC3XI5kpFrWU51379GpbEYq5mXJyFxLxtHycGQYqGxtxE5NA23W3LrQzEQ9A0OPgUpsP4oNZHSpC+cEUsHnwTm6EdHCk9dDBdoybEQYyF7+4MmjparMudfB5j0KgNnjuhejtHm814GRoIFq4BJ7cf0dsJaH01mg4tIrsJWHK6QIGqh7CWz3I0gJ1ikB85PBRTJLbMn5COUP2wThgaS2C5uBu1UJR4rmRlhY3a9G7k3Hnbn/AA3cPxvNSESyMVkJMe9qGWr/3KygEhVUFZowEpUOlZaABK7Es1Mt66kDw/FaEisV8zKzV5b8aHk4rAzkPgHiTKXMwKkgM45C20J7QJwdlBm4A2TGHihnIohzL5ORfOMYM++BzJgI5YaBs+6pCA5yzeOIOA02IgzW4z8A5t5Y299FFujfcANswAH4mEIipDh98ughWQCmOwbuZO7Wh5SPVD1sQQoy0e77lJp3v1sUOVgFkvdTZt7+ZAG0iFdPnH/0Opng6NwEdUaGoQIAt8+wIfwkhFgAAAAASUVORK5CYII=`,
			selectedIconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABMCAYAAAD6BTBNAAAAAXNSR0IArs4c6QAACXdJREFUeNrtnHtMW9cZwAlJ1zy6bNmW5dG9qnTaFLWb1nZ/rEtXpKVrpi2V0i1Sm62duklbOy1R12kZUiqFLJuaVSNpkapCoEBIIYkBg/Hj+n39fuBrG9v4gQ0YbB425Q1+YMDe+aowuddPMA8D95OOhGWf853vx3nd7/vuKSighJItJ7FYbIeAUD0u7SAUHr8voHc6Bjlq2Xmr1fq5tdaNu927MZ3qT4TT7kW6Z6Vmg5qnkT+5qQBavd4viQzt1sjCfGxJuge9wToBdmKtdVdiLUU9QwPhJb1zkUhMqNeYzP39BzYNQE676llzr3M2FifzCwuxcmbTW2utu4Ld9FfQFS+mHmcA+rRpALap5L+097tDMZJUY4yra60bdJD1Ql+gTxu9rhWissc+MPBlq9t6OF3hGzSvOL39YbIh93DejUx1cy2gg6wX+gJ9ylQXbAMbwdbVBHeAp1f/htuuek9s1LHkFgOhtJo6UxWVzWQxdjv6J2amo2RDTL2uEaW1ozNd/dxKRyfoIOuFvkCfoG/p6oNtYCNPp77O02leAttzglcrYr8st3Q4+vzDkXBkLrZdJDQ3F+sdHoiA7XVi9rkVTdcGMfeKa8ATXFhcjG1XAdu7Bz2hu2Leu+jjzmzhPSgz6W9Mzs5EY5R8KsBCbjb+B/2Z+RyLhu0Z74gvTGH7rPT7h4MKq+GFjADbHVZnsgbgQIp2szm0yHZj7UpdqsLVqdoVFqNrdGoyYe5rbJYh+D5d/VwKtA06yHqhL9CnTLqRbS60bIXjHwDiBdikhVfDZjyHNouEqTsyOR6ly0Wccjb9VA2OfUtuNh9IVYxu9xcxjealLk9fwihuEHL/C9+nq59LgbZBB1kv9AX6lEl3FZv9zZucxp+3KnAxgp7AAdggRqdSAuQTGm6S+R+rZNGF6Ousz0YsrfIXyQ7StRhzzQ/SoCPZQRr6lHUjJSWF5W2N2Pj0VMIoFOg1gpT1TD0uP7mC3mUPfMCmHV6OES0y2U/Nva4AeUerYNKL1xrgh8ymYvLJAZ0Ng61y+cnltFNGox1EDolgwlkWMUoOz2fa5xr0zJArYFqla7lGaHoth9B60h9vSA86V1Wy6c+tuTMB6QBdS3phPRPqtT241Xp4uW2hdbGbzAMYAauEH8sI4kjv8GCAXKFRKtCtxJ1VyWK8aHDaxxaj0ZhnxDffKBWWMxyKz681QJoVfwj1+UPQCbo7uh3jlczWX0OfltsW2E7mAYyAVcKPFQbD0WQA70n47Ss15ujp03vPXr34nR+cf+0g+rijYP1kx/def+Wrv7r69rehDyttBGxPBhBYrQvAzS4UQAogBZACSAGkAFIAKYAUQApg3gBETe6u5jY/wZHJDq7k8WpbA3y3seYZncM6hPTMWdyu2Vo+6woFMMs4S72I9wZqP0TyNS5eu1399LYHCMEWmlx0hq4Ul94Vcf8CAer4KcsjVMXgKo9GE+NUpU0Nl7Lx7ogsxDGaVHCuWSr8A10u/v1KCtRtkoheVlosx7IJnq8LQPSTB5rlost2jzscDIch+LJIV4gtyNjH4fsmmeh6n28oaZABfv9OQ9WpTIbUC7AXhQatD8VkItBWLgXakHQQI8hV9WomiOsCEG0Gx40ux2h8nUA4FEOddN4RcxuSBZdAwFeHMrj058vKHkzX/h0p7+sIno2cMJRrvBelvVlFHR0PbzhAhgJ/yjnQH8i28zCNx6YnY61KibhByDiUafTVCZgnUFAotNphSjQSg21KyQ83HKDMZjuCd+g6sx0hvomxaL2QwyeGur6SzUJ+G+c+KrMYvasNUG03e3km7SP5sAYWyjr0zxu7uyYyQZwOBhA8rAr9uW8ZO/gullryhq2/N7QaaSbQBmxonHbl32D9zpddeOc9seD5zr6eiXTpEU1yYVVW6RFJdvmPMPqJGoz5Vr2AfTmXUsNlvVnNoT8Lp4O8Owe+XVt2DI3Ekcj8/Gc2CxQlW6gTsP4Fo4l6lMsgTTj+FNqB3Z9MTnx6TDG4HKFyVvONzQZvwwDCoXdoaOgbKFP0cpNCfL1Bwju9qhmflDeGAkgBpABSACmAFMAVSptW+kgFs/FnlcyWIp/Pt48CuIzjzcci/hmV1dzjHfHPw+MUUyNvodFoOymAmeEVfsBovGjotgdIz8axf9ZXvkp5pNHoulJfdbacRb9Zcqv8twV/fPKBeHh1AnYxSrONJHMGVHJaq7Mx5mtnf7TnfOm171+qeu8nuZQL7//7MWgrbwDibnw3S6soQz6+6JKXGWtXOYQGw3FwAiBXeunY9FRSNwo4Xq831b2eafQ2q8UvEE7b+Go4VaENlH48xVRJz+WFR5qlVD6G8oYnSNnsMeTDczGUktsQOEpmyEwwiNKHFURRSdGu9P5G4ghuImyr7Q9UdprsCofjaF54pB2evoR64JGZDQVTubZiQkM7rurqejjTNKrlM36Mpn9wtQE6vH0B6HseeKSJIyqbuTPbjsPG0aaSiuIjd2m9Oyr8u0SXbXC1Aeqd9gFcr380LzYRlkr1NJoSvng/YDKB105v8Vm3l7sb3hVjfza7u4Pw8gu0kUtBbrYomjGhFqXkYl6sgf+PXUi4z0hNek8qeAOf+BdQqLN+pWfIm63NJ2v5zPcbRFhlLqWW13bjFpd1Mpu3L9f9HAg7r97l6IkPoMPfEI/laOXX0Me9BZtINuQgTdhMTyAvdPfSmW9gdCRSL8KuZhODoADeF45Lsx+91nWhhsssLakuP045EyhvDAWQAkgB3KYAaVK+drsCBNuzBugaG9uPLu2aJVdADgHHdgXIUEq7yDyAEbBKetq39vWMkSsoOo1TBUVFu7YdPfTaP/KeJ7zzf59R8uR4PqFWJLnxIlqFtdRtxtSMHDzouyo4zRXw3Ezmge6VUKesWI2xfpfMaYlSy+ZoEuEV9Of+rQ5vfHz8CzQp7x000iLknG5gUytgv5ayshvd/mj39A0ncwagQNCiwKDx38G5hnoRR/SxkC3eSgVsQinJepRO7B8cHUl6axOwAUZp/wO4UfcmcoSmvPYJvM3gTd6KBS4dSyUzKDlUYiIuZDP/9/B1mrqpwCx139N9ARZCQlsJ77tktQ70+v2HWpVSlm98dHG7w/ONjy22ynEuMFnuTrSXp1f93e7pHUl1l9RWFrAZbOdq1f9AHx9a6XZeaHC5jgv02kvoUi8bStWd9k2Mh9HRJrIVC9gGNqptZouA0BSD7Zs1OZSS7SL/A1pd3w7JSOSjAAAAAElFTkSuQmCC`,
			pagePath: `pages/account/trade`,
		},
		{
			text: Vue.prototype.$lang.TABBAR_MARKET,
			iconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABMCAMAAADN28B/AAAAAXNSR0IArs4c6QAAAhxQTFRFAAAA////gICA////VVVVqqqq////////////1dXV////29vb////5ubmubm56Ojov7+/6urq2NjY6+vr29vb7e3tzMzM3d3dv7+/z8/P0tLS5+fn09PTysrK1dXV4ODg2dnZ29vbysrK09PT3Nzc1dXV3d3d3t7e19fX2NjYvLy80tLStra2zMzMuLi43NzcyMjIz8/P1tbW19fX2NjY0tLS2dnZ1dXV0dHRzMzMzc3Nz8/P0NDQ1dXVzMzM0dHR0tLSycnJ09PT3d3dz8/PwsLCy8vL1dXV2dnZ3t7ezMzM2tra39/fzc3NwMDA0tLS29vbysrK09PT0NDQ3d3dzc3N1dXV0tLS1tbW09PT09PT29vbysrKzc3Ny8vL2dnZz8/P0tLS09PT19fX2tray8vL0dHR1NTU0tLS1dXV29vb09PT3Nzc2tra2NjY1dXV3Nzc5+fn5OTk2tra3d3d1NTU2dnZ29vb3t7e5eXl2dnZ3t7e5ubm5OTk3d3d5+fn3d3d4uLi5eXl5+fn29vb4ODg5+fn6urq4eHh39/f4eHh3d3d39/f5ubm6enp5+fn5+fn6enp6urq6Ojo7u7u6Ojo7Ozs7u7u4uLi5OTk6Ojo6urq7Ozs7u7u8PDw6Ojo7u7u6urq7+/v7e3t7+/v8fHx8/Pz+fn57+/v8fHx8/Pz9/f3+fn58/Pz9fX19/f3+fn5+/v7/f39////4LY8rgAAALR0Uk5TAAECAgMDAwQFBgYHBwoLCwwMDQ0ODg8PEBARFRcYGBkbHB0dHR4eHyAhIiIjIyQkJSUlJicoKCssLS4wMTEyMjM0NDQ1NjY2NjY3Nzc4OTk5Ojo8PD09Pj5FRkdISElJT09RUlJTU1NVVVZXWFlbXF5eX2BiZGRkZGRlZmZnaWlqampqa2tsbG1ubm9vcnJzdXZ3eHh5eXl6enp6enp6e3t8fH19fX19fn5+fn5/f39/f39/6i0RogAAAqNJREFUWMNjYKAZEI8q6SUTlESJo5vGLF+5ZjMFYHWlPDOyeRwBUzZTCKYEcCC5L2TpZorB0hCEG1UXbKYCWKAKM4+xHcTftLI7NTaODBCb2r1yE8iENkaogRog7qYZLszkJhBmr5kgIzZqQPl5IOOXWFCS5iyXgMzIg/L6QZxSRkoMZCwFmdEP4fDMBXFcKcsWfiAz5vKA2ULzQBwtygzUA5kxTwjJQB3KDNShn4GCmiY4gDZEObuCMUJMk5+QgZL1q3HlhHVNUkAF3NELNiEVCjXCBAzMxJe5soEKdFeiiiURMLADn4E9QAWBaGKtBAxM24TbvE0ZQAUGqC7clE7AQL66hSvAYOVGmJ4NKyEiC1sEgAo4E+evRYAlXWKEYpnH1MEJBNyzoE5ZmuIOFnAwg+QDdsPg8DAYsOUlPh2yF4PduCGfjVoJ238VSHyVC9Vyis0ykPhKR6oZaDdqIK0MFE0oK4eBqjx9ig0UqV6/CQE2LlCi1ECrjagZvIJSA33RSo8GSg2UnYRa2vhTaiCzeee06TAwZ0I8G+XJhokVAVhGc8qogQOSbJjNu5AS9kTKE7bcZNSsF0SpgV7kFw424Jp+pTXVii+Z2SDxqRJUK2AZImetWjUrFKPXmohcBRiR1CRW9/ZQH3xt7FEDB6GBvPZhJAB7gk1isa6la0kASwk22jM2kTbQQLBb0UXq0AWhjk8yqQYS6poJ164maUSpllDnkYFfw4QEoME/hBM2FQcxqDjMwgXh9FFrIKgXyssFD1VZUj5UlQPlqYFqxk0z3cgfTHODDKYpw9zbDBvuiyELwIb7muGhpjKHGgOS0xURTvZZTLl5izyRgozdeRKl5k1yRhlKYJQuWk2JccsLpTGSHX9EQSN54+KNBWG8tBuwBwCicSOt58Yh2gAAAABJRU5ErkJggg==`,
			selectedIconPath: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABMCAMAAADN28B/AAAAAXNSR0IArs4c6QAAAtxQTFRFAAAA////////AFVV////////AGYzzMzM////1dXV////JElJ////////4+Pj////////0ejR////baSStsjIzN3MjriqxtXV1dXV4/Hj8fHx5PLkjKamv8y/zNnMzNnZ0dzcvNPI097ev8rK1d/fxM7OztjYoruzjK2lk7KqwtXOwdLMiKids8O+vs7Jsca7o72ysse9us7Eus7JrcC8rr6+us7GuMzEuc3Fr8LCtMfHbZKKmbOrq8G9k7Cpn7qzcZWLqcO9cpqNqsS+q8W+p8C6pLy5pbq3l7aunbmxmrWvuM3Fn7m0nbeynbiup7u4p724m7etpL21p721mLKrus3Gus3Iu83Jm7Wur8O/uMrGmbStucvHobqzqL66t8zFnbaxp725lbGrlrSupb+2t8zGo7y2pb64l7Kspr25pbu3pbu1lbOrnLawhqeeiKihsMS+tsrFmbSskK6nm7avkq+oo7q1o7q0rMK8m7Wwp764pr65qL65rcO+oru1r8S/tMnDxNTQp766qL+5uM3FxNTRq8K8nbewn7mytcnEtsrFt8vGsMXArsO+ydfTrcO+sMbBx9bSssbCscXBt8rGytfTzNrWvc/LydbTuc3IrcS+ucvGsMS/ydfUxdXRxdXRuczHv9DMwNDMwdHNwdHOw9POydfVwNHMytjUy9nVzdrWzdrXvs/Lv9DL1eHe1+He2OLf2ePg0t7b2uPhy9nW0NzZ1eDd2ePg2eTh2uXh1+Le2uTi1ODd2ePh09/d3ebk3ufl2OLg3+fl0d7a2ePg4unn1uHezNnWztvY7PHw7fLw3efl3ujm4Ojm5Ovp5u3r3ebk3ufl3+jm4enn5Ovp5ezq5u3r6O7s4+rp5ezq5uzr5+3r7vLx7/Py9Pf29fj35ezq5+3r5+7s6O7t6/Dv8PTz8/b29Pf29fj39/n49/n5+Pr5+fr6+vv7+vz7+/z8/P39/f7+/v7+////zSvNFgAAAOZ0Uk5TAAECAwMEBQUFBgYHBwgJCQoLDQ4ODxISEhISExQUFBQWFxcYGBoaHh8hKi0vLy8xMjI0NDU/P0FCQ0RGRkZHSk1NTk5PUVRVW1tgYWJjZWVlZmhoamtrbG5vb3BxcnJyc3R2d3d4enp7e3x/gIGDh4qMjpGSk5ygoKGipKWlqKirrK2vsbGzubq9wMDCxMfIyMjJyszNzc7P0NPT1NXY2drb3d3f4ODi4+Pk5Ojo7fDw8PHx8vLy8vLy8/P09PX19fb29/j4+fr6+vr7+/v7+/z8/Pz8/Pz8/f39/f39/f3+/v7+/v6bUxLAAAACpklEQVRYw2NgoBmQy+6ev2o1GWDV/K40CXTTWLRbT32mAJxq1WNFNo8/dONnCsHmeAGEeRyppz9SauCnMzEIN5of+vSZYvBpvxnMPKZpIIEPD9Z2lBaTAUrb1zwCe3AaE9RA/fsg847ncJGbQPiKTrwHGnHfEMqvBRl/I4OR/CTHGH0JZEY9lLsSxJnDRUkiZp0FMmMlhMO5E8TJoyxb5IPM2MkJZivuB3EcKDPQCWTGfkUwW/UAiGNNmYHWIDMOqNLDQCVbFxzAVg2sgNfEES7kbKlAyEDlGU9x5JpPT+fKAhWIFB58Bxf7eGeqOAEDa/DlrjqgApvLqGJVBAxcjM/A5UAFEWjFyBICBpa/xW3eu0qgAruLKGIfmggYKDb72MVLIHDzFUzPq1tggYvHFggDFQiWHX74GAYeXVgqQyiWhdyCgkEgruUaxLyzDYlggSB3SbACLvu0rEwoSPdXIT4dCvQ8B4m/6OWlVsJOuA4Sv51MtZzicx4kftWPagb6QgwMHDWQ6gbKl/RPngQFE9pMKTZQfcqT129h4M2zozqUGujxEjWDT6fUwBC00mMhpQYabEIx720KpQayu87ctnc3FOxaUcBFebJh5kYAttGcMmrggCQbqidsqmc9CgoHz3Mg8SteVCu+1LeCxLdoUq2AZcjdc+vWviQGqlUBDAwWkZFWg6+NPWrgIDRQKiCTeEBEk1hj0YXHxAMiGu3NH0gbaSDYrVhM6tgFoY5PNakGEuqaKU+8S8IQDhGdRwZpS2cXogER3dtBmbCpPojBuYPKwywMy6g8EMRQQe2hKt171BlMuwcbTGPqo85wXx9suI/BePtHKgxIbjBCBGnYkQ+UmvfxdDgLIhB4vNdTauC6KAFqDjufbNRipd7A+LzOWFHaDdgDALzXK1V/G2SDAAAAAElFTkSuQmCC`,
			pagePath: `pages/account/center`,
		},
	];

	TABBAR.forEach((item, index) => {
		uni.setTabBarItem({
			index: index,
			...item,
		})
	});
};

// 是否为小数
const hasDecimalPoint = (val) => {
	return val % 1 !== 0;
};

// 数量值 格式化
const formatNumber = (val, decimal = 0) => {
	// 处理为规范化数字类型
	val = isNaN(val) ? 0 : Number(val);
	return decimal <= 0 ? val : val.toFixed(decimal) * 1;
};

// 金额值格式化(参数：金额，小数位数)
const formatMoney = (amount, decimal = 3) => {
	// 处理传入值为数字类型
	amount = isNaN(amount) ? 0 : Number(amount);
	// console.log(`amount:`,amount);
	const curLocale = 'ja-JP';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		// 如果传入数字包含小数。则启用小数位数
		minimumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		maximumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		currency: Vue.prototype.$CURRENCY
	}).format(amount);
	// console.log('格式化：', result);
	return result;
}

// Coin格式化，数据无损输出
const formatCoin = (coin) => {
	coin = isNaN(coin) ? 0 : Number(coin);
	const curLocale = 'en-US';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		currency: Vue.prototype.$CURRENCY
	}).format(coin);
	// console.log('格式化：', result);
	return result;
};


// 日期格式化
// this.$util.formatDate(new Date())
const formatDate = (timeString, isTime = true) => {
	// console.log('原值:', timeString);
	// const curLang = uni.getStorageSync('lang');
	const curLang = Vue.prototype.$LANGCODE;
	// console.log('当前语言', curLang);
	const dateOpt = {
		year: 'numeric',
		month: 'numeric',
		day: 'numeric',
	}

	const timeOpt = {
		hour: 'numeric',
		minute: 'numeric',
		second: 'numeric',
		hour12: false, // 以24小时制处理
	};

	const opt = isTime ? {
		...dateOpt,
		...timeOpt
	} : dateOpt;

	const result = new Intl.DateTimeFormat(curLang, opt).format(new Date(timeString));
	// console.log('格式化：', result);
	return result;
};
// 返回 年月日及星期几，按照当前语言返回 ,参数:是否需要时间
const formatToday = (isTime = false) => {
	const curLang = uni.getStorageSync('lang');
	console.log('当前语言', curLang);
	const tempTime = {
		hour: 'numeric',
		minute: 'numeric',
		second: 'numeric',
		hour12: false, // 以24小时制处理
	}
	const opt = {
		year: 'numeric',
		month: 'numeric',
		day: 'numeric',
		weekday: "long"
	};
	const result = new Intl.DateTimeFormat(curLang, opt).format(new Date());
	console.log('格式化：', result);
	return result;
};


export default {
	switchTabBar,
	linkCustomerService,
	hasDecimalPoint,
	formatMoney,
	formatCoin,
	formatNumber,
	formatDate,
	formatToday,

	// 对象嵌套转数组对象。当前用于市场指标返回数据，将其从对象转为数组对象
	ObjectConvertArray: (obj) => {
		return Object.values(obj);
	},
	// 负数取绝对值
	formatMathABS: (val) => {
		return Math.abs(val);
	},

	// 邮箱验证
	checkEmail: (val) => {
		const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
		console.log('checkEmail:', !emailPattern.test(val))
		return emailPattern.test(val);
	},

	// 部分页面需要拼接股票完整LOGO的url
	setLogo: (url) => {
		// console.log('url:', url);
		return url.includes('http') ? url : Vue.prototype.$http.BASE_URL + url;
	},
	// 设置 Coin Logo
	setCoinLogo: (url) => {
		return url.includes('http') ? url :
			Vue.prototype.$http.BASE_URL + url;
	},

	// 设置交易记录中，每条数据状态
	setStatusPrimary: (code = 0) => {
		const temp = [{
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[0],
			icon: '/static/audit.png',
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[1],
			icon: '/static/success.png',
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[2],
			icon: '/static/failed.png',
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[3],
			icon: '/static/refuse.png',
		}];
		return temp[code];
	},

	// 统一处理杠杆，后端数据返回不一致。
	leverList: (val) => {
		val = val || [];
		// 如果没有数据。就返回默认杠杆 1
		if (!val || val.length <= 0) return [1];

		console.log(val);

		// 数组对象类型 
		// ganggan: [{name: "", index: ""}] 
		// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
		if (val.length > 0 && typeof(val[0]) === 'object') {
			// val[0].index && val[0].index * 1 > 0
			const tempFilter = val.filter(item => item.index * 1 > 0);
			const temp = tempFilter.map(item => item.index * 1);
			console.log('lever array object:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		} else if (Array.isArray(val)) {
			// [1, '2', '4', '5', '10']
			console.log(1, val);
			return val.map(item => item * 1);
		}

		// 字符串类型 ganggan: "2,3,4,5,6,7,8,9,10" 
		if (typeof(val) === 'string') {
			const temp = val.split(',').map(item => item * 1);
			console.log('lever string:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		}

	},
}