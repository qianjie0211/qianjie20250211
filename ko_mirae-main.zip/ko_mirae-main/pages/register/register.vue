<!-- 注册 -->
<template>
	<view >
		<view class="" style="display: flex;justify-content: center;">
			<view style="margin-top: 10px;">
				<image mode="aspectFit" src="/static/logo.jpg" :style="$util.setImageSize(400)">
				</image>
			</view>
		</view>
		<!-- <view class="text-center font-size-20" style="color: #f38121;margin-top: -40px;">미래에셋증권</view> -->
		
		<view class="padding-20" style="margin-top: -30px;">
			   <view style="background-color: #fff;border-radius: 10px;">
			   	<view class="flex" style=" justify-content: space-between;padding: 20px;">
			   		<view class="font-size-17">회원정보입력</view>
			   		<view @tap="signIn()">
			   			<view class="font-size-10" style="background-color: #f38121;border-radius: 30px;padding: 5px 10px;color: #FFF;">회원가입</view>
			   		</view>
			   	</view>
					
			   <view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">	
			   <view style="width: 85%;line-height: 20px;height: 10px;position: relative;font-size: 16px;">아이디</view>
				<input shape="" placeholder="핸드폰번호입력(01012345687)'-'는 빼고입력해주세요" color='#121212'
					placeholderStyle="font-size: 13px;color: #999999"
					prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value1" type="number"
					maxlength="11" style="margin-top:20px;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
					
			 <view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;">비밀번호</view>
				<input shape="" placeholder="비밀번호 입력" prefixIcon="lock-fill" color='#121212'
					placeholderStyle="font-size: 13px;color: #999999"
					prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value2" type="password"
					style="margin-top:60rpx;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
					
			<view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;">비밀번호 확인</view>
							<input shape="" :placeholder="$lang.PASSWORD_CONFIRM" prefixIcon="lock-fill" color='#121212'
								placeholderStyle="font-size: 13px;color: #999999"
								prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value3" type="password"
								style="margin-top:60rpx;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
			
			<view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;">참여코드 입력</view>
							<input shape="" placeholder="참여코드(필수)" prefixIcon="lock-fill" color='#121212'
								placeholderStyle="font-size: 13px;color: #999999"
								prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="code"
								style="margin-top:60rpx;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
								
								
					
				<view class="" style="padding: 20px;width: 90%;justify-content: center;align-items: center;flex-direction: column;display: flex;">
					<view class="text-center color-white" style="width: 70%;margin-top:20rpx;background-color: #f38121;padding: 10px;border-radius: 10px;" @click="gain_register">회원가입 신청</view>
				</view>
				
			</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
			};
		},
		methods: {
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					url: '/pages/signin/signin'
				});
			},
			//注册
			async gain_register() {
				if (this.value1.length < 10) {
					uni.$u.toast('정확한 전화번호를 입력해주세요.');
				} else if (this.value2 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('두 개의 비밀번호가 일치하지 않습니다');
				} else if (!this.code) {
					uni.$u.toast('인증번호를 입력해주세요');
				} else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('등록이 완료되었습니다. 로그인하세요.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/signin/signin'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},

		},

	}
</script>

<style lang="scss">

</style>