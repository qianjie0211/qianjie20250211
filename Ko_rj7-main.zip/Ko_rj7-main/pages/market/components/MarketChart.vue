<template>
	<view>
		<view style="background-color: #fff;">
			<view class="flex padding-10">
				<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
				<view class="bold margin-left-5">시장 개요</view>
			</view>
		</view>

		<template v-if="isShowKlineTwo">
			<KlineTwo :list="industryList" />
		</template>

		<view style="background-color: #fff;margin-top: 10px;">
			<view style="padding: 10px;">
				<view class="flex flex-wrap" style="background-color: #fbfbfd;">
					<block v-for="(item,index) in setTop1" :key="index">
						<view style="flex:20%;padding:10px;border-radius: 6px;line-height: 1.8;"
							@click='handleChangeType(index)'>
							<view class="text-center bold">
								<view class="font-size-12" style="color: #ccc;">
									{{item.name}}
								</view>
								<view>
									{{item.close}}
								</view>
								<view :style="$theme.setStockRiseFall(item.rate*1>0)">
									{{item.rate}}%
								</view>
							</view>
						</view>
					</block>
					<template v-if="isShowKlineTwo">
						<ChartArea :list="setTop1" />
					</template>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'MarketChart',
		data() {
			return {
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				top1: [],
				industryList: [],
				top1Names: {
					141: "코스닥",
					17470: "코스피 200",
					255: "코스피",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
			}
		},
		computed: {
			setTop1() {
				const temp = Object.values(this.top1);
				if (!temp || temp.length <= 0) return [];
				return temp.map(item => {
					return {
						...item,
						name: this.top1Names[item.stock_id]
					}
				})
			},
			// 是否显示柱状图表
			isShowKlineTwo() {
				return this.industryList.length > 0;
			},
		},
		beforeMount() {
			this.getDetail();
		},
		methods: {
			async getDetail() {
				const result = await this.$http.get(`api/goods/top1`, {
					current1: this.curTab,
					stockid: this.stockId
				});
				console.log('getData:', result);
				if (!result) return false;
				this.top1 = result.top1;
				this.industryList = result.bottom;
			},
		}
	}
</script>

<style>
</style>