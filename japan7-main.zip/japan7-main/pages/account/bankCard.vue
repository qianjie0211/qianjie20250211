<!-- 绑定银行卡 -->
<template>
	<view>
		<view
			style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
			<view style="width: 100%;justify-content: flex-end; display: flex; ">
				<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;"
					@click="handleBack()"></image>
				<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">銀行口座</view>
			</view>
		</view>
		<view>
			<view class="" style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;">
			</view>
		</view>

		<view style="display: flex;flex-direction: column;border-radius: 10px;margin-left: 10px;margin-top: -170px;">
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">銀行名</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value" type="text" :placeholder="$lang.REAL_NAME" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">支店名</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value1" type="text" :placeholder="$lang.BANK_NAME" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">支店番号</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value2" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座番号</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value3" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座種類</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value4" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座名義</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value5" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex"
				style="background-color: #F7F9FF;height: 45px;border-radius: 5px;width: 90%;margin: 10px;">
				<!-- <view style="font-size: 10px;margin-left: 5px;">口座番号</view> -->
				<!-- <text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text> -->
				<input style="margin-left: 5px; font-size: 10px;width: 100%;" v-model="value6"
					placeholder="決済時用のパスワード設定"></input>
			</view>

			<view class="flex"
				style="background-color: #F7F9FF;height: 45px;border-radius: 5px;width: 90%;margin: 10px;">
				<!-- <view style="font-size: 10px;margin-left: 5px;">口座番号</view> -->
				<!-- <text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text> -->
				<input style="margin-left: 5px; font-size: 10px;width: 100%;" v-model="value7"
					placeholder="決済時用のパスワード設定の再確認"></input>
			</view>
			<view class="flex justify-center" style="padding: 20px;">
				<view @click="replaceBank()" style="background-color:#18bfb4; border-radius: 10rpx;
				 padding: 10px;width: 80%;
				text-align: center;
				color: #fff;
				font-size: 28rpx;">
						確認
					</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: '',
				value1: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
				value6: '',
				value6: '',
				cardManagement:[]
			};
		},
		onShow() {
			this.gaint_info()
			// this.replaceBank()
	
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1,
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					bank_name: this.value,
					bank_sub_name: this.value1,
					zd_number: this.value2,
					qy_type: this.value3,
					realname: this.value4,
					card_sn: this.value5,
					pay_pass: this.value6,
					pay_pass1: this.value7,
					// realname: this.value,
					// bank_name: this.value2,
					// bank_sub_name: this.value3,
					// card_sn: this.value4,
					// qy_type: this.value5,
					// card_sn: this.value6,
					// realname: this.value7,
					// pay_pass: this.value8,
				})
				if (list.data.code == 0) {
					uni.$u.toast('キャッシュカード情報が正常に送信されました');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
			// async gaint_info() {
			// 	const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
			// 		language: this.$i18n.locale
			// 	})
			// 	this.userInfo = result.data.data;
			// 	console.log(7777,result.data.data.bank_card_info);

			// 	this.cardManagement = result.data.data.bank_card_info
			// },
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				this.info = result.data.data.bank_card_info
				this.value=this.info.bank_name
				this.value1=this.info.bank_sub_name
				this.value2=this.info.zd_number
				this.value3=this.info.qy_type
				this.value4=this.info.realname
				this.value5=this.info.card_sn
				
			},
		},
	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		// font-weight: 700;
		display: flex;
		font-size: 28rpx;
		// border-bottom: 2rpx solid #f4f4f4;


		view {
			width: 30%;
		}

		input {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>