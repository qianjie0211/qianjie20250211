<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 100%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">取引履歴</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 250px;" >
			<Tbas :btns="$util.BTNS_TRADE_LOG" @action="handleChangeTab"></Tbas>
		</view>
		</view>
		
		<view style="min-height: 60vh;margin-top: -210px;">
			<template v-if="current == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="current == 1">
				<LogDeposit></LogDeposit>
			</template>
        <view style="margin-top: 20px;">
			<template v-if="current == 2">
				<LogWithdraw></LogWithdraw>
			</template>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import LogTrade from '@/components/LogTrade.vue';
	import LogDeposit from '@/components/LogDeposit.vue';
	import LogWithdraw from '@/components/LogWithdraw.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				current: 0,
				// btns: [this.$lang.LOG_TRADE, this.$lang.LOG_DEPOSIT, this.$lang.LOG_WITHDRAW],
			};
		},
		onLoad(item) {
			console.log(item);
			this.current = Number(item.index) || 0;
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				clearInterval(this.timer);
				this.current = val;
			},
		},
	}
</script>