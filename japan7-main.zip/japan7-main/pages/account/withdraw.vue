<!-- 실시간 이체 -->
<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 90%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">出金</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;" >
		</view>
		</view>

		<view
			style="padding:20px;margin-top: -170px;position: relative;border-radius: 10px;background-color: #fff;width: 85%;margin-left: 8px;">
			<view style="text-align:center;font-size: 16px;" :style="{color:$util.THEME.TIP}"> 即時出金 </view>
			<view style="font-size: 24px;font-weight: 700;text-align: center;margin-top: 10px;">
				{{$util.formatNumber(userInfo.money)}}
			</view>

			<view style="text-align: center;margin-top: 10px;" >出金上限額</view>
			<view class="flex" style="padding: 10px 0px;margin-top: 10px;">
				<view class="">出金金額</view>
			</view>
			<view class="font-size-11" style="border-radius: 5px; background-color: #f5f5f5;padding: 6px;border: 1px #e4e5e7 solid;">
				<input v-model="amount" style="font-size: 12px;" placeholder="出金金額を入力してください" type="number"></input>
			</view>
			<view class="flex" style="padding: 10px 0px;margin-top: 10px;">
				<view class="">資金パスワード</view>
			</view>
			<view style="border-radius: 5px; background-color: #f5f5f5;padding: 6px;border: 1px #e4e5e7 solid;">
				<input v-model="password" style="font-size: 12px;" placeholder="6桁のパスワードを入力してください" type="password"></input>
			</view>
			<view class="margin-top-30 text-center radius10 padding-10 color-white" style="background-color: #18BFB4"
				@click="handleWithdraw()">
				出金
			</view>
			<view style="background-color: #fff;width: 100%;border-radius: 10px;margin: 20px 0px; ">
				<view class="flex ">
					<!-- <view class="bold">出金指示</view> -->
				</view>
				<view style="" :style="{color:$util.THEME.TIP}">
					<block v-for="(item,index) in $util.TIP_WITHDRAW_CONDITION">
						<view style="padding-bottom: 6px;" :style="{color:index!==4?$util.THEME.LABEL:$util.THEME.TIP}">
							{{item}}</view>
					</block>
				</view>
			</view>
			<!-- <view @click="handleWithdraw()" style="background-color: #24228F;color: #fff;padding: 10px 0;text-align: center;height: 30px;line-height: 30px;position: fixed;bottom: 0;width: 100%;border-top-left-radius: 10px;border-top-right-radius: 10px;">
				{{$lang.WITHDRAW}}{{$lang.CONFIRM}}
			</view> -->
			</view>
		</view>
		
		
		
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			handleAllAmount(val) {
				this.amount = val
			},
			async handleWithdraw() {
				uni.showLoading({
					title: this.$lang.TIP_WITHDRAWING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.APP_WITHDRAW, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>