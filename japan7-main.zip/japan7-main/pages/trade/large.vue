<!-- 大宗交易 -->
<template>
	<view style="background-color: #fff;"> 
		<view
			style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
			<view style="width: 90%;justify-content: flex-end; display: flex; ">
				<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;"
					@click="handleBack()"></image>
				<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">大口・OTC</view>

			</view>
		</view>
		<view>
			<view class="" style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#fff);height: 180px;">
			</view>
		</view>
		<view>
		</view>


		<view
			style="display: flex;flex-direction: column;width: 95%;border-radius: 10px;margin-top: -160px;margin-left: 10px;background-color: #fff;height: 760px;">
			
			<view style="padding: 5px 0 5px 0;background-color: #dcf5f4;border-radius: 10px 10px 0px 0px;">
				<text style="padding: 5px 30px; background-color: #38aa9a;border-radius: 10px;color: #fff;"
					@click="manages()">取引履歴</text>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>

			<block v-for="(item,index) in list" :key="index">
				<view class="" style="align-items: center;border-radius: 10px;width: 100%;margin-top: 10px;">
					<view class="flex margin-left-15">
						<view :style="{color:$util.THEME.TEXT}" style="flex:30%;margin-top: 5px;">{{item.goods.name}}
						</view>
						<view style="flex:10%;font-size: 18px;margin-top: 15px;color: #18bfb4; margin-left: 10px;">
							<!-- {{$util.formatNumber(item.price)}} -->
							{{item.goods.number_code}}
						</view>
						<view class="common_btn "
							style="flex:20%;transform: scale(0.65);margin-top: 20px;background-color: #18bfb4;color: #FFF;height: 40px;font-size: 17px;"
							@click="handleDetail(item.id)">
							{{$lang.STOCK_DETAIL}}
						</view>
					</view>
					<!-- <view style="margin-top: -5px;margin-left: 10px;">
						{{item.goods.number_code}}
					</view> -->
					<view style="border-bottom:1px solid #ccc;width: 95%;margin-left: 10px;"></view>
				</view>
			</block>
		</view>

		<template v-if="isShow">
			<view class="common_mask" >
				<view class=" common_popup"
					style="min-height:50vh;margin:auto;margin-top: 200px;background-color: #FFF;width: 100%;border-radius: 10px;">
					<view class="flex">
						<view class="padding-20" style="width: 130%;justify-content: center;display: flex;">申込の詳細
						</view>
						<image src="/static/close.png" mode="widthFix"
							style=" width: 30px;background-color: #18bfb4;border-radius: 50px;margin-right: 20px;"
							@click="handleCancel"></image>
					</view>


					<view class="flex margin-left-15">
						<view class="bold " style="margin-left: 10px;">申込株数</view>
					</view>

					<view style="margin: 20px;background-color: #F7F9FF;height: 40px;border-radius: 10px;">
						<!-- <image mode="aspectFit" src='/static/amount.png' :style="$util.calcImageSize(20)"> </image> -->
						<input v-model="quantity" placeholder="申込株数を入力してください" type="number"
							style="font-size: 14px;padding: 10px;"></input>
						<!-- <input v-model="quantity" style="font-size: 14px;padding: 10px;" type="number" :placeholder="$lang.TIP_BUY_COUNT"
							@input="sl_input" /> -->
					</view>

					<!-- <view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/leverage.png' :style="$util.calcImageSize(20)"> </image>
						<block v-for="(item,index) in leverList" :key="index">
							<text @click="handleChgangeLever(index)" style="display: inline-block;padding:0 16px;"
								:style="{borderBottom:`2px solid ${index==current? $util.THEME.PRIMARY:'transparent'}`,color:index==current?$util.THEME.PRIMARY:$util.THEME.TEXT}">{{item.name}}</text>
						</block>
					</view> -->

					<!-- <view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<view :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</view>
						<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(buyAmount)}}</view>
					</view> -->

					<!-- <view class="flex margin-left-15">
						<view class="bold " style="margin-left: 10px;">支払いパスワード</view>
					</view>

					<view style="margin: 20px;background-color: #F7F9FF;height: 40px;border-radius: 10px;">
						<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
						</image>
						<input v-model="password" :placeholder="$lang.TIP_BUY_PWD" type="password" style="font-size: 14px;padding: 10px;"></input>
					</view> -->

					<view
						style="background-color: #f8f8f8;width: 90%;margin-left: 20px;border-radius: 10px;height: 80px;">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;padding-top: 10px;">
							<text :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</text>
							<text>{{$util.formatNumber(detail.price)}}</text>
						</view>
						<view style="border: #EAEAEA 1px solid;width: 90%;margin: 10px;margin-left: 20px;"></view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<text :style="{color:$util.THEME.LABEL}">利用可能残高 </text>
							<text>{{availBal}}</text>
						</view>
					</view>


					<view style="display: flex;justify-content: space-evenly;margin:20px 0;padding-top: 30px;">
						<view class="common_btn " style="width: 80%;background-color: #18bfb4;color: #FFF;"
							@click="handleConfirm"> {{$lang.BUY}} </view>
						<!-- <view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view> -->
					</view>
					<view style="margin-top: 250px;color: #fff;">.</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				
				quantity: '100',
				errorMessage: '',
				quantity1: "",
				// password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {
			this.getList()
			this.available()
		},
		computed: {
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.quantity / Number(this.curLever.index);
			}
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChgangeLever(val) {
				this.current = val;
			},
			manages() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/trade/largeLog'
				});
			},
			sl_input(e) {
				const inputValue = e.target.value;
				// 匹配整百的数字，例如 100, 200, 300 等  
				const regex = /^(\d{1,})(00)?$/;
				const hundredRegex = new RegExp(`^${Math.floor(inputValue / 100)}00$`);

				if (hundredRegex.test(inputValue) || inputValue === "") {
					this.quantity = inputValue; // 如果输入的是整百数字或者空字符串，则保留  
					this.errorMessage = ""; // 清除错误信息  
				} else {
					let quantity = this.quantity.slice(0, -1 * (this.quantity.length - 1)); // 移除最后一个字符（通常是非法字符）
					if (this.quantity < 100) {
						// console.log(1111)
						this.$nextTick(() => {
							this.quantity = this.quantity * 100;
						})
						return
					} else {
						// console.log(2222,this.quantity.length,this.quantity,quantity)
						this.$nextTick(() => {
							this.quantity = quantity * Math.pow(10, this.quantity.length - 1);
						})
						return
					}
					// this.errorMessage = '请输入整百数字';
				}
			},

			async handleDetail(id) {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				this.isShow = true;
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_DETAIL, {
					id
				});
				console.log('result:', result);
				this.detail = result.data.data;
				uni.hideLoading();
			},

			about() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/trade/largeLog'
				});
			},
			handleCancel() {
				this.isShow = false;
				this.quantity = "";
				// this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.quantity == '') {
					uni.$u.toast(this.$lang.TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async buy() {
				const result = await this.$http.post(this.$http.API_URL.TRADE_LARGE_ORDER, {
					id: this.detail.id,
					num: this.quantity,
					// pay_pass: this.password,
					// ganggan: this.curLever.index,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.navigateTo({
						url: this.$util.PAGE_URL.TRADE_LARGE_LOG
					});
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_LIST, {})
				this.list = result.data.data
				uni.hideLoading();
			},
			async available() {
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.availBal = this.$util.formatNumber(result.data.data.money);
				this.leverList = [{
					name: 1,
					index: 1
				}, ...result.data.data.ganggan];
			},
		},
	}
</script>