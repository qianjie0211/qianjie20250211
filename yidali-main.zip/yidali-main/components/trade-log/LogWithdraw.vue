<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="margin-bottom:20px;padding:10px;border-radius: 10px;">
				<view style="text-align: right;" :style="{color:$theme.RISE}">
					{{item.desc_type}}
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="color: #cccccc;font-size: 12px;"> {{$lang.LOG_WITHDRAW_AMOUNT}} </view>
					<view>
						<view style="color: #fff;">
							{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
						</view>
						<view style="color: #AAA;font-size: 12px;text-align: right;">
							{{`$ `+$util.formatUSD(`${item.money*eurToUsd}`,3)}}
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_ORDER_SN}}</view>
					<view style="text-align: right;color: #fff;">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view style="text-align: right;color: #fff;">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_DW_DESC}}</view>
					<view style="text-align: right;color: #fff;">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<!-- <view style="flex:5%;">
						<image :src="item.icon" :style="$util.setImageSize(24)"></image>
					</view> -->
					<view style="color: #cccccc;font-size: 12px;">{{$lang.LOG_STATUS}}</view>
					<text style="white-space:pre-wrap;text-align: right;"
						:style="{color:item.color}">{{item.text}}</text>
				</view>
				<template v-if="item.status==0">
					<view class="trade_modal_btn"
						style="background-color:#03b874;height: 32px;line-height:32px;width: 100%;margin-top: 10px;text-align: center;"
						@click="handleCancel(item.id)">
						{{$lang.BTN_CANCEL}}
					</view>
				</template>
				<template v-if="item.status==2">
					<view class="trade_modal_btn"
						style="background-color: #A400DE;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;width: 100%;margin-top: 10px;"
						@click="handleService()">
						<image src="/static/service.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="padding-right: 20px;"></image>
						{{$lang.BTN_SEND_SERVICE}}
					</view>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				eurToUsd: 1, // 欧转美
			};
		},
		beforeMount() {
			this.getList();
			this.getconfig();
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},
			// 取消提现
			handleCancel(id) {
				let _this = this;
				uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					success: function(res) {
						if (res.confirm) {
							_this.qx_post(id);
						} else if (res.cancel) {}
					}
				})
			},
			async qx_post(id) {
				const result = await this.$http.post(`api/app/qx`, {
					id: id
				});
				if (!result) return false;
				this.getList();
			},
			async getList() {
				this.list = []; // 每次请求前，清空数组。
				const result = await this.$http.get(`api/user/withdraw`);
				if (!result) return false;
				this.list = result.map((item, index) => {
					return {
						...item,
						...this.$util.setWithdrawLogStatus(item.status)
					}
				});
			},

			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		}
	}
</script>

<style>

</style>