<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<!-- <HeaderSecond :title="info.title" color="#fff"></HeaderSecond> -->
		
		<view class="flex padding-20">
			<view @click="chongzhi()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.TIP_PRVITE_PACT}}</view>
		</view>

		<view style="padding: 40rpx;">
			<template v-if="info.content && info.content.length>0">
				<view v-html="info.content" style="color:#fff"></view>
			</template>
			<template v-else>
				<view style="color:#fff;text-align: center;">{{$lang.API_EMPTY_CONTENT}}</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false,
				info: {},
			};
		},
		computed: {},
		onLoad() {
			this.getData();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/article/privacy`);
				console.log('result:', result);
				if (!result) return false;
				this.info = {
					title: result.title || this.$lang.PRVITE_PACT_TITLE,
					content: result.content,
				}
			},
			chongzhi(){
				uni.navigateBack({
					delta:1,
				})
			},
		}
	}
</script>