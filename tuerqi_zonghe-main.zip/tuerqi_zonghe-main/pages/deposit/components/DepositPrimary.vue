<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<view style="padding:30px  20px 10px 20px;">
			<TitleSecond :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT"></TitleSecond>
			<view class="common_input_wrapper">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;margin: 30rpx;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
						:style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatNumber(item)}}
					</view>
				</block>
			</view>
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 28rpx;font-weight: 700;text-align: center;" :style="{color:$theme.LOG_LABEL}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-top:16rpx;line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
			</block>
		</view>

		<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
			<view class="common_btn" style="margin:60rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		// desc:入金模式 之  带有输入项提交等
		name: 'DepositPrimary',
		components: {
			TitleSecond,
			AccountAssets,
			CardItemThird,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			// 入金金额预置值
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];
			},
		},
		created() {
			this.getAccountInfo()
			this.amount = this.amountList[this.curPos];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : 'transparent',
					color: val ? '#FFFFFF' : '#A8A8A8',
					borderRadius: `16rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
				}
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					this.$util.linkCustomerService();
				}, 1000)
			},

			//个人信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log(result);
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money, // 可提
					value2: this.userInfo.freeze, // 冻结
					value3: this.userInfo.totalYingli, // 总盈利
				};
			},
		},
	}
</script>

<style>
</style>