<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color:#010101;">
			<HeaderSecond :title="$lang.ADDRESS_ADD_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="margin: 20px;padding-bottom: 100rpx;min-height: 100vh;">
			<view style="font-size: 28rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
				{{$lang.ADDRESS_CHOOSE_COIN}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;"
				@tap="chooseCoin()">
				<view>{{curCoin}}</view>
				<image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)"></image>
			</view>
			<view v-if="curCoin!='BANK'">
				<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.ADDRESS_WALLET_ADDRESS}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="address" type="text" :placeholder="$lang.ADDRESS_WALLET_ADDRESS"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;width: 100%;"></input>
				</view>
			</view>

			<view v-else>
				<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.S_K_R}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="realname" type="text" :placeholder="$lang.S_R_S_K_R"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;width: 100%;"></input>
				</view>

				<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.Y_H_Z_H}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="address" type="text" :placeholder="$lang.S_R_Y_H_Z_H"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;width: 100%;"></input>
				</view>

				<!-- 	<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.I_B_A_N}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="IBAN" type="text" :placeholder="$lang.S_R_I_B_A_N"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;"></input>
				</view> -->


				<!-- <view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.S_W_I_F_T}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="SWIFT" type="text" :placeholder="$lang.S_R_S_W_I_F_T"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;"></input>
				</view> -->


				<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.Y_H_M_C}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="bank_name" type="text" :placeholder="$lang.S_R_Y_H_M_C"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;width: 100%;"></input>
				</view>


				<!-- <view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
					{{$lang.F_H_D_M}}
				</view>
				<view class="common_input_wrapper"
					style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color:#010101;">
					<input v-model="bank_code" type="text" :placeholder="$lang.S_R_F_H_D_M"
						:placeholder-style="$theme.setPlaceholder()" style="color: #fff;"></input>
				</view> -->
			</view>
		</view>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>

		<view style="position: fixed;bottom: 60px;left: 0;right: 0;background-color: #010101;">
			<view style="display: flex;align-items: center;justify-content: center;">
				<!-- :style="{width:id!=''?`40%`:`80%`}" -->
				<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
					{{$lang.COMMON_CONFIRM}}
				</view>
				<!-- <template v-if="id!=''">
					<view class="common_btn" style="margin:40rpx auto;width: 40%;background-color: crimson;"
						@click="deladdress()">
						{{$lang.BTN_DEL}}
					</view>
				</template> -->
			</view>
		</view>
		<view style="height: 160rpx;"></view>
		<FooterSmall code="assets" />
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				curCoin: 'BANK', // 当前选中Coin
				address: '', // 钱包地址

				realname: '',
				bank_name: '',
				bank_code: '',
				SWIFT: '',
				IBAN: '',

				// id: "",
				type: 1
			};
		},
		computed: {
			coinList() {
				return ['BANK', 'ERC20-USDT', 'TRC20-USDT', 'BTC', 'ETH']
			},
		},
		onLoad(op) {
			this.id = op.id || this.id;
		},
		onShow() {
			this.isAnimat = true;
			// this.getaddress();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 選擇一種coin
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curCoin = e.value[0];
				this.address = ''; // 切换选择后，清空输入的地址
				this.isShowCoinList = false;
				if (this.curCoin != "BANK") {
					this.type = e.indexs[0] * 1 + 1;
				} else {
					this.type = 1;
				}
				console.log(this.type);
			},

			// async getaddress() {
			// 	const result = await this.$http.post(`api/user/getaddress`, {
			// 		id: this.id
			// 	});
			// 	if (!result) return false;

			// 	let index = this.coinList.indexOf(result.huobi);
			// 	this.curCoin = result.huobi
			// 	console.log(11111, result, index)
			// 	this.address = result.address
			// },
			// async deladdress() {
			// 	const result = await this.$http.post(`api/user/deladdress`, {
			// 		id: this.id
			// 	});
			// 	if (!result) return false;
			// 	console.log(result)
			// 	uni.showToast({
			// 		title: 'Successfly',
			// 		icon: 'success'
			// 	})
			// 	setTimeout(() => {
			// 		uni.navigateTo({
			// 			url: this.$CONSTANTS.ADDRESS_INDEX
			// 		});
			// 	}, 1000);
			// },
			async handleSubmit() {
				if (!this.address || this.address.length <= 0) {
					uni.showToast({
						title: this.$lang.ADDRESS_TIP_ENTER_ADDRESS,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});



				const result = await this.$http.post(`api/user/bindBankCard`, {
					address: this.address,
					type: this.type,
					name: this.curCoin, // huobi: ERC20-USDT / TRC20-USDT
					// 未用到
					realname: this.realname,
					bank_name: this.bank_name,
					SWIFT: this.SWIFT,
					IBAN: this.IBAN,
					bank_code: this.bank_code,
					id: '',
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: 'Successfly',
					icon: 'success'
				})
				setTimeout(() => {
					uni.redirectTo({
						url: this.$CONSTANTS.ADDRESS_INDEX
					});
				}, 1000);
			},
		}
	}
</script>

<style>
</style>