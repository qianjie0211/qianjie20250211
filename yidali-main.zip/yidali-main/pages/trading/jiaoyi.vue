<template>
	<view style="padding-top: 24px;">
		<view class="flex"
			style=" justify-content: space-between; text-align: center;padding: 10px 16px;background-color: #34393e;">
			<block v-for="(v,k) in tabs" :key="k">
				<view :style="{color:curTab==k?'#02B975':'#FFFFFF',
				borderBottom:curTab==k?`3px #02B975 solid`:`3px transparent solid`  }" @click="changeTab(k)">
					{{v.value}}
				</view>
			</block>
		</view>

		<view class="margin-top-10" style="padding-bottom: 200rpx;">
			<!-- 检索 -->
			<view style="border:1px solid #25262A1A;border-radius: 16rpx;padding:12rpx 24rpx;margin:24rpx;">
				<view style="display: flex;align-items: center;border-bottom: 1px #77767b solid;padding-bottom: 2px;">
					<view :style="{color:$theme.LOG_VALUE}">{{$lang.FILTER}}</view>
					<view style="padding:0 24rpx;" :style="{color:$theme.LOG_VALUE}">|</view>
					<input v-model="keyword" type="text" :placeholder="$lang.ENTER_KEYWORD"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto"></input>
					<view style="margin-left: auto;" @click="handleSearch()">
						<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
					</view>
				</view>
			</view>

			<view class="flex padding-10 flex-b" style="color: #77767b;padding: 10px 16px;">
				<view class="flex-2">{{$lang.MINGCHEN}}</view>
				<view class="flex-2 text-center">
					{{$lang.ZUIXIN_JIA}}
				</view>
				<view class="flex-1 text-right">{{$lang.ZAHNGDIE_FU}}</view>
			</view>
			<view v-for="(item,index) in setList">
				<view class="flex" style="justify-content: space-between;padding: 10px 16px;" @tap="linkDetail(item)">
					<view class="flex flex-2 gap10">
						<view class="flex justify-center align-center">
							<view style="width: 80rpx;margin:auto 0;">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
						</view>
						<view>
							<view style="color: #fff;">{{item.name}}</view>
							<view style="color: #77767b;font-size: 10px;">{{item.code}}</view>
						</view>
					</view>

					<view class="flex-2 text-center">
						<view style="color: #fff;">
							<!-- {{currencySymbol + $util.formatNumber(item.current_price)}} -->

							<template v-if="$util.isEur(item.project_type_id)">
								{{`€ `+$util.formatMoney(`${item.current_price}`)}}
							</template>
							<template v-else>
								{{`$ `+$util.formatUSD(`${item.current_price}`)}}
							</template>
						</view>
						<!-- <view style="color: #77767b;font-size: 10px;">P{{item.rate_num}}</view> -->
					</view>
					<view class="flex-1 text-right" :style="$util.setStockRiseFall(item.rate>0)">
						<template v-if="item.rate==0">
							{{item.rate}}%
						</template>
						<template v-else>
							{{`${item.rate*1>0?'+':'-'} `+ $util.formatNumber (Math.abs(item.rate))}}%
						</template>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				curTab: 0,
				list: null, // 列表数据
				socket: null, // websocket
				isConnected: false, // 是否链接socket
				keyword: '', // 检索关键词
				listFutures: null, // 期货数据
			};
		},
		computed: {
			tabs() {
				return [{
						key: 'eu',
						value: this.$lang.MARKET_STOCK_EU
					},
					{
						key: 'us',
						value: this.$lang.MARKET_STOCK_US
					},
					{
						key: 'coin',
						value: this.$lang.MARKET_COIN
					},
					{
						key: 'forex',
						value: this.$lang.MARKET_FOREX
					}
				]
			},
			gpIndex() {
				return {
					coin: 1, // coin
					futures: 2, // 期货
					forex: 3, // 外汇
					us: 7, // 美股
					eu: 6, // 欧股
				}
			},
			// 当前 tab key
			curKey() {
				return this.tabs[this.curTab].key;
			},
			// 当前是否为外汇列
			isForex() {
				return this.curKey === 'forex';
			},
			// 当前货币
			currencySymbol() {
				return this.curKey == 'eu' ? ` € ` : ` $ `;
			},

			// 根据关键字，过滤数据
			// filterList() {
			// 	if (!this.setList || this.setList.length <= 0) return [];
			// 	// 输入三个字符以上才检索
			// 	if (this.keyword.length >= 3) {
			// 		return this.setList.filter(item =>
			// 			item.name.toLowerCase().includes(this.keyword) || item.code.includes(this.keyword));
			// 	} else {
			// 		return this.setList;
			// 	}
			// },

			setList() {
				if (!this.list || Object.values(this.list).length <= 0) return []
				const temp = Object.values(this.list);
				// 外汇列
				if (this.isForex) {
					let tempFutures;
					if (this.listFutures && Object.values(this.listFutures).length >= 0) {
						tempFutures = Object.values(this.listFutures);
					} else {
						tempFutures = [];
					}
					return [...tempFutures, ...temp];
				} else {
					return temp;
				}
			}
		},
		onLoad(opt) {
			console.log(opt)
			// 避免变动错位，使用遍历查找下标 url?tag=forex
			const temp = this.tabs.findIndex(item => item.key == opt.tag);
			this.curTab = temp > -1 ? temp : 0;
		},
		onShow() {
			if (this.socket) this.disconnect();
			this.changeTab(this.curTab);
		},
		onHide() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		// 下拉刷新
		onPullDownRefresh() {
			if (this.socket) this.disconnect();
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 详情
			linkDetail(val) {
				console.log(`val:`, val.gid, val.code);
				// 股票使用股票详情
				if (this.curKey === 'us' || this.curKey === 'eu') {
					uni.navigateTo({
						url: this.$paths.STOCK_OVERVIEW + `?gid=${val.gid}`
					})
				}
				// 币和外汇，使用同一种详情
				else {
					uni.reLaunch({
						url: `/pages/contract/index?code=${val.code}`
					})
				}
			},
			handleSearch() {
				this.changeTab(this.curTab);
			},

			async getList() {
				const temp = this.tabs[this.curTab].key;
				console.log(temp, this.gpIndex[temp])
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				let tempData = {};
				tempData.gp_index = this.gpIndex[temp];
				if (this.keyword.length >= 3)
					tempData.key = this.keyword;
				console.log(this.keyword);
				const result = await this.$http.post(`api/goods/list`, tempData);
				console.log(result);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
				// 启动 websocket链接
				if (Object.values(this.list).length > 0)
					this.connect();
			},
			// 期货
			async getFutures() {
				let tempData = {};
				tempData.gp_index = 2;
				if (this.keyword.length >= 3)
					tempData.key = this.keyword;
				const result = await this.$http.post(`api/goods/list`, tempData);
				if (!result) return false;
				console.log(`getFutures:`, result);
				this.listFutures = result;
			},

			changeTab(index) {
				this.curTab = index;
				if (this.socket) this.disconnect();
				this.list = null;
				this.getList();
				if (this.isForex) {
					this.listFutures = null;
					this.getFutures();
				}
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				let tempURL = '';
				if (this.curKey == 'coin') {
					tempURL = this.$http.WS_COIN_URL;
				} else {
					tempURL = this.$http.WS_Zonghe_URL;
				}
				console.log('tempURL', tempURL);
				//创建webSocket
				this.socket = uni.connectSocket({
					url: tempURL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('success', res);
					},
					fail: (res) => {
						console.log('fail', res);
					},
					complete: (res) => {
						console.log('complete', res);
					}
				})
				console.log('ws', this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(data);
						// console.log(this.curKey);

						if (this.curKey === 'coin' && data.market && this.list[data.market] &&
							this.list[data.market].code == data.market && data.lastPrice > 0 && data.type ==
							'ticker') {
							// console.log('coin', data.market);
							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
						if (this.curKey === 'forex' && this.listFutures[data.pid] &&
							this.listFutures[data.pid].pid == data.pid && data.last > 0) {
							// console.log(`pid:`, this.listFutures[data.pid].pid);
							this.listFutures[data.pid].current_price = data.last;
							this.listFutures[data.pid].rate = data.pcp || 0;
						}
						if ((this.curKey === 'us' || this.curKey === 'eu' || this.curKey === 'forex') &&
							this.list[data.pid] && this.list[data.pid].pid == data.pid && data.last > 0) {
							// console.log(this.curKey);
							// console.log(`pid:`, this.list[data.pid].pid);
							this.list[data.pid].current_price = data.last;
							this.list[data.pid].rate = data.pcp || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			// connect() {
			// 	//创建webSocket
			// 	this.socket = uni.connectSocket({
			// 		url: this.$http.WS_COIN_URL,
			// 		header: {
			// 			'content-type': 'application/json'
			// 		},
			// 		success(res) {
			// 			console.log('成功', res);
			// 		},
			// 		fail: (res) => {
			// 			console.log('fail', res);
			// 		}
			// 	})
			// 	console.log('ws', this.socket);
			// 	// 监听WebSocket连接打开事件
			// 	this.socket.onOpen((res) => {
			// 		console.info("监听WebSocket连接打开事件", res)
			// 	});

			// 	// 监听WebSocket错误
			// 	uni.onSocketError((res) => {
			// 		console.info("监听WebSocket错误" + res)
			// 	});
			// 	// 接收websocket消息及处理
			// 	this.socket.onMessage((res) => {
			// 		const data = JSON.parse(res.data);
			// 		// console.log(data);
			// 		// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
			// 		if (this.list[data.market] && data.market && data.lastPrice > 0 && data.type == 'ticker') {
			// 			this.list[data.market].current_price = data.lastPrice;
			// 			this.list[data.market].rate = data.rate || 0;
			// 			this.list[data.market].rate_num = data.rate_num || 0;
			// 		}
			// 	});
			// },
			// connect1() {
			// 	//创建webSocket
			// 	this.socket = uni.connectSocket({
			// 		url: this.$http.WS_Zonghe_URL,
			// 		header: {
			// 			'content-type': 'application/json'
			// 		},
			// 		success(res) {
			// 			console.log('成功', res);
			// 		},
			// 		fail: (res) => {
			// 			console.log('fail', res);
			// 		}
			// 	})
			// 	console.log('ws', this.socket);
			// 	// 监听WebSocket连接打开事件
			// 	this.socket.onOpen((res) => {
			// 		console.info("监听WebSocket连接打开事件", res)
			// 	});

			// 	// 监听WebSocket错误
			// 	uni.onSocketError((res) => {
			// 		console.info("监听WebSocket错误" + res)
			// 	});
			// 	// 接收websocket消息及处理
			// 	this.socket.onMessage((res) => {
			// 		const data = JSON.parse(res.data);
			// 		// console.log(data);
			// 		// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
			// 		if (this.list[data.pid] && data.pid && data.last > 0) {
			// 			this.list[data.pid].current_price = data.last;
			// 			this.list[data.pid].rate = data.pcp || 0;
			// 			this.list[data.pid].rate_num = data.pc || 0;
			// 			// this.list[data.market].vol = data.vol || 0;
			// 		}
			// 	});
			// },
		},
	};
</script>