<template>
	<view style="padding-bottom: 160rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%">
							<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
									{{item.goods.name}}
									<text style="font-size: 20rpx;padding:20rpx;color:#999;">
										{{item.goods.code}}</text>
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_BLOCK_LOG_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_NUM}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.num}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_LEVER}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.double}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.amount)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_CREATE_TIME}}
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: "TradeBlockRecord",
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>