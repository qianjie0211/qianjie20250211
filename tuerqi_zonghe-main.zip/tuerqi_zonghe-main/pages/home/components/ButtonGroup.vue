<template>
	<view class="btns " style="">
		<block v-for="(item,index) in btnConfig" :key="index" v-if="inv==item.inv">
			<view class="item" @click="actionEvent(item.url)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(50)"></image>
				<text style="padding: 16rpx 0;font-size: 24rpx;color: #fff;text-align: center;height: 30px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: {
			// 标题
			inv: {
				type: String,
				default: ''
			},
		},
		computed: {
			btnConfig() {
				// 根据客户需求，调整位置，注释不需要要显示的项
				return [
					//现货
					{
						name: this.$lang.TRADE_DAY_TITLE, // 日内交易
						url: this.$CONSTANTS.TRADE_DAY + "?type=1",
						icon: "top4",
						inv: 0
					},
					{
						name: this.$lang.TRADE_BLOCK_TITLE, // 大宗交易
						url: this.$CONSTANTS.TRADE_BLOCK + "?type=1",
						icon: "top1",
						inv: 0
					},
					{
						name: this.$lang.X_G_S_G, // IPO
						url: this.$CONSTANTS.TRADE_IPO + "?type=1",
						icon: "top5",
						inv: 0
					},
					{
						name: this.$lang.TRADE_COPY_TITLE, // 量化交易
						url: '/pages/trade/wealth/index',
						icon: 'top2',
						inv: 0
					},
					{
						name: this.$lang.E_T_F,
						url: "/pages/trade/copy/index",
						icon: "top5",
						inv: 0
					},
					{
						name: this.$lang.DEPOSIT_TITLE, // 入金/充值
						url: this.$CONSTANTS.DEPOSIT_INDEX,
						icon: "top10",
						inv: 0
					},
					{
						name: this.$lang.WITHDRAW_TITLE, // 出金/提款
						url: this.$CONSTANTS.WITHDRAW_INDEX,
						icon: "top9",
						inv: 0
					},
					{
						name: this.$lang.TRANSFER_TITLE, // 劃轉
						url: this.$CONSTANTS.TRANSFER_INDEX,
						icon: "top7",
						inv: 0
					},
					{
						name: this.$lang.PROFILE_SERVICE, // 客服
						// url: this.$CONSTANTS.SERVICE, //
						url: 'service',
						icon: "top11",
						inv: 0
					},
					{
						name: this.$lang.COMMON_MORE, // 更多
						url: 'modal',
						icon: "user",
						inv: 0
					},
					//合约
					{
						name: this.$lang.H_Y_J_Y, // 日内交易   主力合约
						url: this.$CONSTANTS.TRADE_DAY + "?type=2",
						icon: "top4",
						inv: 1
					},
					{
						name: this.$lang.TABBAR_CONTRACT, // 合约交易
						url: '/pages/contract/index',
						icon: "top3",
						inv: 1
					},
					{
						name: "OTC", // 大宗交易
						url: this.$CONSTANTS.TRADE_BLOCK + "?type=2",
						icon: "top1",
						inv: 1
					},
					{
						name: this.$lang.TRADE_IPO_TITLE, // IPO
						url: this.$CONSTANTS.TRADE_IPO + "?type=2",
						icon: "top5",
						inv: 1
					},
					{
						name: this.$lang.K_T,
						url: "/pages/trade/kongtou/index",
						icon: "top5",
						inv: 1
					},
					{
						name: this.$lang.DEPOSIT_TITLE, // 入金/充值
						url: this.$CONSTANTS.DEPOSIT_INDEX,
						icon: "top10",
						inv: 1
					},
					{
						name: this.$lang.WITHDRAW_TITLE, // 出金/提款
						url: this.$CONSTANTS.WITHDRAW_INDEX,
						icon: "top9",
						inv: 1
					},
					{
						name: this.$lang.TRANSFER_TITLE, // 劃轉
						url: this.$CONSTANTS.TRANSFER_INDEX,
						icon: "top7",
						inv: 1
					},
					{
						name: this.$lang.PROFILE_SERVICE, // 客服
						// url: this.$CONSTANTS.SERVICE, //
						url: 'service',
						icon: "top11",
						inv: 1
					},
					{
						name: this.$lang.COMMON_MORE, // 更多
						url: 'modal',
						icon: "user",
						inv: 1
					},




					// {
					// 	name: this.$lang.Qiquan_name, // Options
					// 	url: "/pages/qiquan/index",
					// 	icon: "top6"
					// },
					// {
					// 	name: this.$lang.AUTH_TITLE, // 实名认证
					// 	url: this.$CONSTANTS.ACCOUNT_AUTH,
					// 	icon: "top6",
					// 	inv:0
					// },

					// {
					// 	name: this.$lang.TRADE_WEALTH_TITLE, // wealth
					// 	url: "/pages/trade/wealth/index",
					// 	icon: "5"
					// },

					// {
					// 	name: this.$lang.FOREX_TITLE, // forex
					// 	url: 'forex',
					// 	icon: "1"
					// },




					// {
					// 	name: this.$lang.AUTH_TITLE, // 实名认证
					// 	url: this.$CONSTANTS.ACCOUNT_AUTH,
					// 	icon: "top6",
					// 	inv:1
					// },





					// {
					// 	name: this.$lang.BORROW_TITLE, // borrow
					// 	url: "/pages/borrow/record",
					// },




				];
			}
		},

		methods: {
			actionEvent(url) {

				if (url.includes('service')) {
					this.$util.linkCustomerService();
				} else if (url.includes('forex')) {
					uni.reLaunch({
						url: this.$CONSTANTS.MARKET_INDEX + `?tag=${url}`
					})
				} else if (url.includes('contract')) {
					uni.reLaunch({
						url: url
					})
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', url);
				}
			},
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px;

		.item {
			width: 20%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #121212;
			padding: 4px 0;
		}
	}
</style>