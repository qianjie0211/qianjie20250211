<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" style="background-color: #38AA9A;">
				{{info.name}}
				<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view style="padding-bottom: 30rpx;">
				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_BLOCK_BUY_AMOUNT}}</text>
					<text :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(info.price) +` `+$lang.CURRENCY_UNIT }}</text>
				</view>
				<view class="common_input_wrapper" style="padding-left: 20px;margin:30rpx 40rpx;">
					<input v-model="amount" :placeholder="$lang.TRADE_BLOCK_TIP_BUY_COUNT" type="number"
						style="width: 80%;" :placeholder-style="$theme.setPlaceholder()"></input>
					<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
				</view>

				<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
						:style="{color:$theme.LOG_LABEL}">
						{{$lang.LEVER}}
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="setStyle(curLever==item)" @click="chgangeLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:20rpx 50rpx;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_BLOCK_BUY_TOTAL_AMOUNT}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(buyAmount) +` `+$lang.CURRENCY_UNIT }}
					</view>
				</view>

				<view class="common_input_wrapper" style="margin:30rpx 40rpx;padding-left: 20px;">
					<input v-model="password" :placeholder="$lang.TRADE_BLOCK_TIP_BUY_PWD" type="password"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<view style="display: flex;align-items: center;justify-content: flex-end;padding:20rpx 50rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
					<view :style="{color: $theme.SECOND}">{{available +` ` + $lang.CURRENCY_UNIT}}</view>
				</view>

				<view class="common_btn" @tap.stop="handleConfirm()"
					style="margin:60rpx auto;width: 80%;background-color: #1C1C1C;color:#FFF;">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeBlockBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				amount: "", // 金额
				password: '', // 支付密码
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
				available: 0,
			}
		},
		computed: {
			// 金额计算
			buyAmount() {
				return this.info.price * this.amount / this.curLever;
			},
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : 'transparent',
					color: val ? '#FFFFFF' : '#A8A8A8',
					borderRadius: `16rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
				}
			},
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 0);
			},
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},

			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_COUNT);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_PWD);
					return false;
				}
				return true;
			},
			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.info.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever,
				});
				if (!result) return false;
				this.$emit('action', 1); // 1为购买成功，通知父组件刷新
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.available = this.$util.formatNumber(result.money) || 0;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},
		}
	}
</script>