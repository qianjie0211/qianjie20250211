<template>
	<view style="padding:0 18px; padding-bottom: 100rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin-top:24rpx;">
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						status  0是未售出   1是已售出
						<view :style="setStyle(item.status)">
							{{$lang.TRADE_DAY_APPROVAL_STATUS[item.status]}}
						</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 35rpx;">
							{{(item.goods_info.name)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_PRICE}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_sell[0].price)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_NUM}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_sell[0].num)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.SHOU_XUFEI}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_sell[0].sell_fee)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_LOG_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_buy.amount*1+item.order_buy.buy_fee*1)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_HOLD_LABEL_PROFIT_RATE}}
						</view>
						<view style="font-size: 28rpx;color: #30c8b9;">
							{{$util.formatPercentage($util.formatNumber((item.order_sell[0].price * 1 - item.order_buy
							.price * 1) / item.order_buy.price * 100).toFixed(2) * 1)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_MODAL_YINGKUI}}
						</view>
						<view style="font-size: 28rpx;color: #30c8b9;">
							{{$util.formatNumber(item.order_sell[0].yingkui)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_DAY_ORDER_SN}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.order_sn)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #FFFFFF;font-size: 24rpx;">
							{{$lang.TRADE_DAY_CREATE_TIME}}
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#FFFFFF;">
							{{item.sell_time}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'TradeDayOrderList',
		components: {

		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			// 申请状态样式
			setStyle(val) {
				// 背景色
				const temp = ['#FFB044', '#03B467', '#FF2D30'];
				// 文字色
				// const tempColor = [
				// 	'#FFB044', this.$theme.PRIMARY, this.$theme.THIRD,
				// ];
				return {
					// PRIMARY
					backgroundColor: this.$theme.RGBConvertToRGBA(temp[val], 10),
					color: temp[val],
					borderRadius: `6rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
					// minWidth: `80rpx`,
					padding: `2rpx 12rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>