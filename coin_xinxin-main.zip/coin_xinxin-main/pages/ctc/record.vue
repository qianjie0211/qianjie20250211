<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;background-color: #FFFFFF;">
		<header class="common_header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.CTC_RECORD_TITLE}}</text>
			</view>
			<view class="right"> </view>
		</header>

		<view style="padding:36rpx; padding-bottom: 200rpx;">

			等待接口
			<template v-if="!list || list.length<=0">
				<EmptyData />
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">

				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [], // 
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 获取数据
			async getList() {
				// const result = await this.$http.post(`api/xxx`);
				// if (!result) return false;
				// this.list = result;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 32rpx;
		display: flex;
		align-items: center;

		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1;
			text-align: left;
		}
	}
</style>