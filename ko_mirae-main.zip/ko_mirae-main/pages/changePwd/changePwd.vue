<!-- 修改登陆密码 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<CustomHeader title="비밀번호 재설정" @action="handleBack()"></CustomHeader>

	<view style="padding:10px 30rpx;margin:0 20rpx;background-color: #fff;border-radius: 10px;">
		<view style="padding: 10px;">
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="새 비밀번호를 입력 해주세요" type="password" v-model="value"
					placeholder-style="font-size:12px"></input>
			</view>
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="새 비밀번호를 입력 해주세요" type="password" v-model="value2"
					placeholder-style="font-size:12px"></input>
			</view>
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="새 비밀번호를 다시 입력 해주세요" type="password" v-model="value3"
					placeholder-style="font-size:12px"></input>
			</view>

			<view @click="changePassword" style="background-color: #f18c36;margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;">확인</view>
		</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 顶部导航回退操作
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//修改登录密码
			async changePassword() {
				let list = await this.$http.post('api/user/updateLoginPassword', {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
	}
</script>

<style lang="scss">
	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}
</style>