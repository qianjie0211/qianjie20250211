<template>
	<view>
		<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;" @touchmove.stop>
			<block v-for="(item,index) in $lang.MARKET_HOT_TABS" :key='index'>
				<view class="btn_common" :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</scroll-view>
		<view class="flex hui1" style="margin-top: 5px;padding: 0px 10px;">
			<view style="flex: 25%;font-size: 12px;">주식명/코드</view>
			<view style="flex: 45%;font-size: 12px;text-align: center;">현재가</view>
			<view class="text-center" style="font-size: 12px;flex: 20%;">등락률</view>
		</view>

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="display: flex;align-items: center;border-bottom:1px solid #F3F3F3;padding:10px 5px;"
					@click="link(item.code)">
					<view style="text-align: center;padding-right: 20rpx;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex:1 0 20%;">
						<view class="bold" style="font-size: 28rpx;line-height: 1.4;">
							{{item.name}}
						</view>
						<view style="width: 120rpx;" :style="{color:$theme.LOG_LABEL}">{{item.code}}</view>
					</view>
					<view style="flex:1 0 40%; font-size: 30rpx;text-align: center;font-weight: 700"
						:style="$theme.setStockRiseFall(item.rate*1>0)">
						{{$util.formatMoney(item.close)}}
					</view>
					<view style="flex:1 0 20%; color:#FFFFFF;" :style="setStyle2(item.rate*1>0)">
						<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(16)" style="padding-right: 12rpx;"></image>
						{{$util.formatNumber(item.rate,2)}}%
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketHotTop',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			setStyle2(val) {
				return {
					backgroundColor: val ? '#f20206' : '#4543d1',
					borderRadius: `8rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},
			// 设置样式
			setStyle(val, w = 50) {
				return {
					minWidth: `${w}rpx`,
					margin: '8rpx',
					padding: `8rpx 12rpx`,
					// borderRadius: `16rpx`,
					// backgroundColor: val ? this.$theme.SECOND : this.$theme.TRANSPARENT,
					color: val ? '#4543d1' : '#ccc',
					textAlign: 'center',
					borderBottom: val ? '6rpx solid #4543d1' : 'none', // 添加自定义下划线
					  paddingBottom: '5rpx', // 增加与下划线的间距
				}
			},
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				this.getData();
			},
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: this.curTab
				})
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		}
	}
</script>
<style lang="scss" scoped>
	.btn_common {
		padding: 6rpx 12rpx;
		font-size: 28rpx;
		text-align: center;
		margin-right: 12rpx;
		display: inline-block;
	}
</style>