<template>
	<view>
		<view style="display: flex;align-items: center;padding:0 36rpx 0 36rpx;">
			<view style="width: 8rpx;height: 28rpx;" :style="{backgroundColor:$theme.PRIMARY}"></view>
			<view style="font-size: 28rpx;font-weight: 700;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_MONTH_PL}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<canvas canvas-id="month" id="month" class="charts"></canvas>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {
		columnChartMonth
	} from '@/common/customUChart.js';
	export default {
		// month 月度表现。正负柱(宽) Profit And Loss
		name: 'ChartMonthProfitLoss',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
				chart: null,
			}
		},
		computed: {
			monthData() {
				// console.log(`month:`, this.list);
				//  "year": 2023, "month": 11, "total_dayshouyi": 1017090
				const temp = this.list.map(item => {
					return {
						timestamp: new Date(`${item.year}/${item.month}`).getTime(),
						value: item.total_dayshouyi
					}
				});
				// console.log(temp);
				const tempSort = temp.sort((a, b) => a.timestamp - b.timestamp);

				let tempCategories = []; // 存储时轴
				// let tempSeries = []; // 存储数据
				let series1 = [];
				let series2 = [];
				// 决定时轴显示及空字符间隙
				const divisor = parseInt(temp.length / 10);

				tempSort.forEach((item, index) => {
					// if (divisor > 0) {
					// 	if (index % divisor === 0) {
					// 		tempCategories.push(item.timestamp);
					// 		tempSeries.push(item.value);
					// 	}
					// } else {
					tempCategories.push(this.$util.formatMonth(item.timestamp));
					series1.push(item.value > 0 ? item.value : 0);
					series2.push(item.value < 0 ? item.value : 0);
					// }
				})
				return {
					categories: tempCategories,
					series: [{
						name: 'Profit',
						data: series1,
						color: this.$theme.RISE
					}, {
						name: 'Loss',
						data: series2,
						color: this.$theme.FALL
					}],
				}
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			genCharts() {
				const ctx = uni.createCanvasContext("month", this);
				this.chart = new uCharts(columnChartMonth(ctx,
					this.monthData,
					this.cWidth,
					this.cHeight))
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>