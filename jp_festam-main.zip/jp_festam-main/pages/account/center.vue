<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view>
			<view class="flex" style="padding:30px  20px;">
				<view class="flex-1" style="background-color: #fff;border-radius: 20px;padding: 5px 10px;">
					<view class="flex" @click="shouye()">
						<image src="/static/search_dark.png" mode="widthFix" style="width: 15px;"></image>
						<view style="margin-left: 5px;font-size: 10px;color: #999;">銘柄名/コードを入力してください</view>
					</view>
					
				</view>
				<view>
					<image src="/static/service.png" mode="widthFix" style="width: 25px;margin-left: 20px;" @click="kefu()"></image>
				</view>
			</view>
			
			<view class="flex" style="padding: 0px 10px;" >
				<view class="flex-1">
					<view class="bold font-size-20 padding-10" style="color:#f3b05f ;">Hi、ようこそ</view>
					<view class="bold font-size-16 " style="background-color: #fff;padding: 0px 10px;width: 55%;border-radius: 30px;color: #e49d74;">口座資金の安全保護</view>
				</view>
				<view>
					<image src="/static/dun.png" mode="widthFix" style="width: 90px;"></image>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;margin-top: -15px;">
				<view class="common_card_bg card_bg_5" style="width: 90%;height: 260rpx;">
					<Profile :info="userInfo"></Profile>
					<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
				</view>
			</view>
		</view>
		<view class="flex" style="font-weight: 500;color: #f0a03a;  justify-content: space-between;padding: 5px 15px;" >
			<view class="flex" style="background-color: #fff7ee;padding: 10px 38px;border-radius: 10px;" @click="linkWithdraw()">
				<image src="/static/centet_deposit.png" mode="widthFix" style="width: 50px;"></image>
				<view class="bold" style="border-radius: 30px;font-size: 16px;margin-left: 10px;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<view class="flex" style="background-color: #fff7ee;padding: 10px 38px;border-radius: 10px;" @click="linkDeposit()">
				<image src="/static/centet_withdraw.png" mode="widthFix" style="width: 50px;"></image>
				<view class="bold" style="border-radius: 30px;font-size: 16px;margin-left: 10px;" >
						{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>
			</view>

		

		<view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx;border: 1px #e3e3e3 solid;">
			<!-- <view class="bold"
				style="padding: 10px 20px;font-size: 16px;"
				:style="{color:$theme.SECOND}">
				{{$lang.ACCOUNT_MORE_FEATURES}}
			</view> -->
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>
		</view>
		<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
			<SignOut></SignOut>
		</view>


	</view>
</template>

<script>
	// import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			// HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemPrimary
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			shouye() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan|| 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.dongjie || 0,
				};
			},
		},
	}
</script>


<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/bg_1.png);
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 500rpx;
		position: relative;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-top: 30px;

		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 700;
			// flex: 70%;
			text-align: center;
		}
	}
</style>