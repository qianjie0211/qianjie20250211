<!-- 国内库存余额/盈亏 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<!-- <Header :title="$lang.POSITION"></Header> -->
		<view class="flex" style="justify-content: space-between;padding:0px 15px;padding-top: 25px;">
			<image src="../../static/sy_logo.png" mode="widthFix" style="width: 35px;"></image>
			<view class="flex" style="background-color: #fff;padding: 5px 10px;border-radius: 30px;">
				<view class="common_header_right" @click="$u.route({url:'/pages/service/service'});">
					<image mode="aspectFit" src="/static/sy_kf.png" :style="$util.calcImageSize(20)"></image>
				</view>
				<view class="common_header_right margin-left-10" @click="$u.route({url:'/pages/email/email'});">
					<image mode="aspectFit" src="/static/sy_tz.png" :style="$util.calcImageSize(20)"></image>
				</view>
			</view>
		</view>

		<!-- <view class="" >
			<view class="flex">
				<view class="margin-left-10 bold font-size-16">205-01-{{userInformation.uid}}</view>
								<view class="margin-left-5 hui font-size-10 ">[CMA]{{userInformation.real_name}}</view>
				<view class="left-auto margin-right-10 flex gap5" @click="gp_show=true">
					{{gp_select[0][gp_index]}}
					<u-icon name="arrow-down" :bold="true"></u-icon>
				</view>
			</view>
			<view class="flex flex-b padding-10 gap10">
				
				<view class="text-center padding-10"
					style="background-color: rgb(24 191 180 / 35%);width: 100%;border-radius: 6px;">
					예수금
					{{$util.formatNumber(userInformation.money )}}
				</view>
				
				<view class="text-center padding-10 color-white"
					style="background-color:#18BFB4;width: 100%;border-radius: 6px;" @click="duihuan">출금</view>
			</view>
		</view> -->
		<view class="padding-15">
			<view class="cc_bg padding-15" style="border-radius: 10px;">
				<view class="font-size-16">총자산</view>
				<view class="font-size-18 margin-top-10">{{$util.formatNumber(userInformation.totalZichan)}}</view>
				<view class="flex margin-top-10" style="color: #999;">
					<view>총수익:</view>
					<view class="margin-left-10">{{$util.formatNumber(userInformation.totalYingli)}}</view>
				</view>
			</view>
		</view>
		
        <view style="padding: 0px 15px;">
		<view class="sc_bg" style="padding: 10px;border-radius: 10px;">
			<view style="border-bottom:1px solid #ccc;display: flex;align-items: center;">
				<!-- 持股状态 -->
				<view :class="Inv==0?'with-bottom-line':''" @click="qiehuan(0)" style="flex:40%;text-align: center;">
					종목 보유 현황
				</view>
				<!-- 销售历史 -->
				<view :class="Inv==1?'with-bottom-line':''" @click="qiehuan(1)" style="flex:40%;text-align: center;">
					매매 내역
				</view>
				<!-- 刷新 새로고침 --> <!-- 投资业绩 투자성과 -->
				<view @click="shuaxin" style="flex:20%;text-align: center;">
					<image src="/static/refresh.png" style="width: 18px;height: 18px;"></image>
				</view>
			</view>
			<!-- 总购量 -->
			<view style="display: flex;align-items: center;padding:6px 16px 6px 16px;">
				<text style="flex:30%;">총매입</text>
				<text style="flex:70%;text-align:right;">{{$util.formatNumber(userInformation.frozen )}}</text>
			</view>
			<!-- 估值损益 -->
			<view style="display: flex;align-items: center;padding:6px 16px 6px 16px;background-color: #dee2ff;border-radius: 10px;">
				<text style="flex:30%;">평가손익</text>
				<text style="flex:70%;text-align:right;"
					:style="{color:userInformation.holdYingli>0?'red':'green'}">{{$util.formatNumber(userInformation.holdYingli )}}</text>
			</view>
			<!-- 评价金额 -->
			<view style="display: flex;align-items: center;padding:6px 16px 6px 16px;">
				<text style="flex:30%;">평가금액</text>
				<text style="flex:70%;text-align:right;">{{$util.formatNumber(userInformation.guzhi )}}</text>
			</view>
			<!-- 回报率 -->
			<!-- <view style="display: flex;align-items: center;padding:6px 16px 6px 16px;background-color: #dee2ff;border-radius: 10px;">
				<text style="flex:30%;">수익률</text>
				<text style="flex:70%;text-align:right;"
					:style="{color:userInformation.holdYingli>0?'red':'green'}">{{userInformation.huibao}}%</text>
			</view> -->
			<!-- 估计资产 -->
			<!-- <view style="display: flex;align-items: center;padding:6px 16px 6px 16px;">
				<text style="flex:30%;">추정자산</text>
				<text style="flex:70%;text-align:right;">{{$util.formatNumber(userInformation.totalZichan )}}</text>
			</view> -->
			<!-- 回报率 -->
			<!-- <view style="display: flex;align-items: center;padding:6px 16px 6px 16px;background-color: #f0f3fa;">
				<text style="flex:30%;">실현손익</text>
				<text style="flex:70%;text-align:right;"
					:style="{color:userInformation.totalYingli>0?'red':'green'}">{{$util.formatNumber(userInformation.totalYingli )}}</text>
			</view> -->
			</view>
		</view>
		<view class="common_block" style="padding: 6px 0;margin-top:30rpx;">
			<!-- 列表说明 -->
			<view style="display: flex;align-items: center;padding:12rpx 0;background-color: transparent;color:#999">
				<view style="flex:25%;text-align: center;">
					구분
				</view>
				<view style="flex:30%;">
					<view style="text-align: center;">평가손익</view>
					<view style="text-align: center;">수익률</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: center;">잔고수량</view>
					<view style="text-align: center;">평가금액</view>
				</view>
				<view style="flex:25%;">
					<view style="text-align: right;padding-right: 4px;">평균매입가</view>
					<view style="text-align: right;padding-right: 4px;">현재가</view>
				</view>
			</view>

			<!-- 列表数据 -->
			<block v-for="(item,index) in storehouse" :key="index">
				<view style="padding: 5px 10px;">
				<view
					style="display: flex;align-items: center;padding:12rpx;background-color: #eaeafe;color:#121212;border-radius: 10px;"
					:style="{backgroundColor:index%2==0?'#eaeafe':'#eaeafe'}" @tap="sell(item)">
					<view style="flex:25%;">
						{{item.goods_info.name}}
					</view>

					<view style="flex:30%;">
						<view style="text-align: center;" v-if="Inv==0"
							:style="{color:item.order_buy.float_yingkui>0?'red':'#18BFB4'}">
							{{$util.formatNumber(item.order_buy.yingkui )}}
						</view>
						<view style="text-align: center;" v-if="Inv==1"
							:style="{color:item.order_sell.yingkui>0?'red':'#18BFB4'}">
							{{$util.formatNumber(item.order_sell.yingkui )}}
						</view>
						<view style="text-align: center;" v-if="Inv==0"
							:style="{color:item.order_buy.float_yingkui>0?'red':'#18BFB4'}">
							<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
							{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
						</view>
						<view style="text-align: center;" v-if="Inv==1"
							:style="{color:item.order_sell.yingkui>0?'red':'#18BFB4'}">
							<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
							{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
						</view>
					</view>

					<view style="flex:25%;">
						<view style="flex:25%;text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.order_buy.num )}}
						</view>
						<view style="text-align: right;padding-right: 4px;" v-if="Inv==0">
							{{$util.formatNumber((item.goods_info.current_price*1*item.order_buy.num) )}}
						</view>
						<view style="text-align: right;padding-right: 4px;" v-if="Inv==1">
							{{$util.formatNumber((item.order_sell.price*1*item.order_buy.num) )}}
						</view>
					</view>

					<view style="flex:25%;">
						<view style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.order_buy.price) }}
						</view>
						<view style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(Inv==0?item.goods_info.current_price:item.order_sell.price)}}
						</view>
					</view>
				</view>
				</view>
			</block>
			
		</view>

		<u-picker :show="gp_show" :columns="gp_select" cancelText="취소" confirmText="확인" :closeOnClickOverlay="true"
			@close="gp_show=false" @cancel="gp_show=false" @confirm="gp_changes"></u-picker>



		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view
			style="position: fixed;width: 90%;margin-left: 5%;border-radius: 20px;background-color: #6562d6;top: 20%;z-index: 9999;"
			v-if="item_show">
			<view class="color-white  padding-10 flex ">
				<view class="text-center justify-center width100 font-size-16">세부</view>

				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="sc_kxbg2" style="border-radius:0px 0px 10px 10px;">
			<view class="flex flex-b padding-10 " style="">
				<view class="flex flex-b flex-1 ">
					<view class="flex-1 bold">종목</view>
					<view class="flex-1">{{info.goods_info.name}}</view>
				</view>

			</view>
			<template v-if="Inv==0">
				<view class="flex flex-b padding-10" >
					<view class="flex flex-b flex-1">
						<view class="flex-1 bold">매수시간</view>
						<view class="flex-1">{{info.order_buy.created_at}}</view>
					</view>
				</view>
			</template>
			<view class="flex flex-b padding-10"  v-if="Inv==1">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매도시간</view>
					<view class="flex-1">{{info.order_sell.created_at}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">현재손익</view>
					<view class="flex-1" v-if="Inv==0">{{$util.formatNumber(info.order_buy.float_yingkui )}}</view>
					<view class="flex-1" v-if="Inv==1">{{$util.formatNumber(info.order_sell.float_yingkui )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">레버리지</view>
					<view class="flex-1">X{{info.order_buy.double}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">손익총액</view>
					<view class="flex-1" v-if="Inv==0">{{$util.formatNumber(info.order_buy.yingkui )}}</view>
					<view class="flex-1" v-if="Inv==1">{{$util.formatNumber(info.order_sell.yingkui )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매수가격</view>
					<view class="flex-1">{{$util.formatNumber(info.order_buy.price )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수량</view>
					<view class="flex-1">{{$util.formatNumber(info.order_buy.num )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1  bold">수수료</view>
					<view class="flex-1" v-if="Inv==0">{{$util.formatNumber(info.order_buy.buy_fee )}}</view>
					<view class="flex-1" v-if="Inv==1">{{$util.formatNumber(info.order_sell.sell_fee )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" >
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총매수가</view>
					<view class="flex-1">{{$util.formatNumber(info.order_buy.amount )}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목코드</view>
					<view class="flex-1">{{info.goods_info.number_code}}</view>
				</view>
			</view>
			<view class="text-center padding-20"
				style="border-radius: 0 0 20px 20px;display: flex;justify-content: center;color: #fff;">
				<view
					style="width: 40%;background-color:#6562d6;height: 30px;text-align: center;margin:0 10px;line-height: 30px;border-radius: 16rpx;"
					v-if="Inv==0" @tap="productDetails(info.goods_info.number_code)">매수</view>

				<view
					style="width:40%;background-color: #e82d28;height: 30px;text-align: center;margin:0 10px;line-height: 30px;border-radius: 16rpx;"
					v-if="Inv==0" @tap="position(info.id)">매도</view>
			</view>
			</view>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	export default {
		components: {
			Header
		},
		data() {
			return {
				gp_select: [
					["국내", "해외"]
				],
				gp_index: 0,
				gp_show: false,

				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['종목 보유 현황', '매매 내역',
					// '보유수량', '매매내역'
				],
				show: false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				timerId: null,
				info: [],
				item_show: false
			}
		},
		// watch: {
		// 	Inv: 'position'
		// },


		methods: {
			sell(item) {
				this.info = item
				this.item_show = true;
			},
			gp_changes(index) {
				console.log(index)
				this.gp_index = index.indexs[0]
				this.gp_show = false

				this.storehouse = ""

				this.shuaxin()
			},
			qiehuan(index) {
				this.Inv = index
				this.shuaxin()
			},
			shuaxin() {
				this.storehouse = ""
				uni.showLoading({
					mask: true
				})
				if (this.Inv == 1) {
					this.flat()
				} else {
					this.hold();
				}
			},
			// 平仓
			position(id) {
				this.item_show = false
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: `/pages/productDetails/productDetails?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor'
				});
			},
			// 银转证
			silver() {
				if (this.userInformation.bank_card_info && this.userInformation.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/capitalDetails?index=1'
					});
				} else if (this.userInformation.bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInformation.idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings(e) {
				let list = await this.$http.post('api/user/sg-order', {
					gp_index: this.gp_index
				})
				this.luckyNumber = list.data.data
			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index: this.gp_index
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},

			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');
			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index: this.gp_index
				})
				// this.storehouses = list.data.data
				this.storehouse = list.data.data
				uni.hideLoading()
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {

					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('위치요청');

					this.shuaxin()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求

			},

			duihuan() {
				uni.navigateTo({
					url: "/pages/prove"
				});
			}
		},

		onShow() {
			this.is_token()
			this.gaint_info()
			// this.flat()
			this.shuaxin()
			// this.startTimer()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	.with-bottom-line {
		color: #18BFB4;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #18BFB4;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}

	.bglan {
		background-color: #EEF4FF;
	}

	.bgyellow {
		background-color: #F8F8F8;
	}

	/* 遮罩层 */
	.overlay {
		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>