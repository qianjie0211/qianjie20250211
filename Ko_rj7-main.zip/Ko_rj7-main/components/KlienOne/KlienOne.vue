<template>
	<view>
		<view class="chart" id="kline-area" style="width: 100%;height: 300rpx;"> </view>
	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';
	export default {
		name: "KlienOne",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				klineArea: null,
			}
		},
		computed: {
			// 处理图表数据
			chartData() {
				// console.log(`computed`, this.list);
				return this.list;
			}
		},
		created() {

		},
		beforeMount() {
			// console.log(`beforeMount`, this.list);

		},
		mounted() {
			this.renderInit();
		},
		deactivated() {
			dispose("kline-area");
		},
		methods: {
			clearData() {
				if (this.klineAmount) this.klineAmount.clearData();
			},
			renderInit() {
				setTimeout(() => {
					this.genKline();
				}, 1000)
			},
			genKline() {
				if (!this.klineArea) {
					this.klineArea = init('kline-area')
				}
				this.klineArea.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						}
					},
				});
				this.klineArea.applyNewData(this.chartData)
			},
		},
	}
</script>

<style>

</style>