<template>
	<view>
		<view>
			<view class="flex padding-20">
				<view @click="$util.goBack()">
					<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.TIKUAN}}</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;line-height: 1.8;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
				<!-- <image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: 10px;">
				</image> -->
			</view>
			<template v-if="userInfo">
				<view class="flex  justify-center" style="">
					<view style="font-size: 44rpx;font-weight: 700;color:#FFFFFF;text-align: center;line-height: 1.8;">
						{{$util.formatMoney(`${userInfo.qianbao[0].money}`,3)}}
					</view>
					<view style="color: #fff;margin-left: 5px;">EUR</view>
				</view>

				<view class="flex  justify-center" style="">
					<view style="font-size: 32rpx;color: #AAA;">
						<!-- {{$util.formatUSD(`${userInfo.money*eurToUsd}`,3)}} -->
						{{$util.formatUSD(`${userInfo.qianbao[0].money*eurToUsd}`,3)}}
					</view>
					<view style="padding-left: 10rpx;color: #AAA;">USD</view>
				</view>
			</template>
		</view>
		<view style="padding:20px;">
			<template>
				<view></view>
			  <view  >
			    <view style="color: #fff;padding: 10px 0px;">{{$lang.XUAN_ZE_DIZHI}}</view>
			    <view style="margin-bottom: 20px; font-size: 16px;background-color: #202328;padding: 10px;color: #FFF;border-radius: 5px;" @click="show = true">
					<view style="margin-left: 20px;">{{ selectedItem }}</view>
			      
			    </view>
			
			    <!-- 弹窗选择器 -->
			    <u-picker
			      :show="show"
			      :columns="columns"
			      @confirm="onConfirm"
			      @cancel="show = false"
				  :cancelText="$lang.COMMON_CANCEL" 
				   :confirmText="$lang.COMMON_CONFIRM"
			    ></u-picker>
			  </view>
			</template>
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;" v-if="type ==1">
				{{$lang.CHOOSE_BANK_CARD}}
			</view>
			<!-- @click="showBankList=true" -->
			<view class="common_input_wrapper"
				style="background-color: #202328;border: 1px solid #3b3f44;padding-left: 30px;">
				<view style="flex: auto;width: 100%; max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" :style="{color:curBank==''?`#AAA`:'#FFF'}" >
					{{!curBank?$lang.CHOOSE_BANK_CARD:curBank.name_address}}
				</view>
				<!-- 	<input v-model="curBank" :placeholder="$lang.CHOOSE_BANK_CARD" type="text"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;color:#fff;" disabled></input> -->
				<!-- <image src="/static/arrow_down_solid.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image> -->
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="background-color: #202328;border: 1px solid #3b3f44;padding-left: 30px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number" autocomplete="off"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;color:#fff;"></input>
				<view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view>
			</view>
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff; ">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper"
				style="background-color: #202328;border: 1px solid #3b3f44;margin-bottom: 30px;padding-left: 30px;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password" autocomplete="off"
					:placeholder-style="$util.setPlaceholder()" style="color:#fff;"></input>
			</view>

			<view class="text-center padding-10 "
				style="margin:20px auto; width: 90%;background-color: #03b874;border-radius: 10px;color:#FFF;"
				@click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>

			<!-- <view style=" padding: 10px;" :style="{color:$theme.TITLE}">
				<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
					<view style="padding-bottom: 6px;" :style="{color:index==5?'#03b874' :$theme.TITLE}">
						{{item}}
					</view>
				</block>
			</view> -->
		</view>

		<!-- Bank  選擇器 -->
		<!-- <u-picker :show="showBankList" :columns="[bankList]" @change="changeBank" @cancel="showBankList=false"
			@confirm="confirmBank" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="name"
			visibleItemCount="9"></u-picker> -->
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				show: false,
				password: '',
				selectedContent: 'content1',
				userInfo: null,
				assets: "",
				columns: [
				                    
				                ],
								selectedItem: 'Card', 

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧

				showBankList: false,
				curBank: null,
				bankList: [],
				type:1,
			};
		},
		onShow() {
			this.getAccountInfo();
			this.getconfig();
		},
		methods: {
			changeBank() {},
			confirmBank(e) {
				this.curBank = this.bankList[e.indexs[0]];
				this.showBankList = false;
			},
			  onConfirm(e) {
			       // 获取选择的值
			       this.selectedItem = e.value[0];
				   console.log(e,33333444445)
				   this.curBank = this.bankList[e.indexs[0]]
				   this.type = this.curBank.type
				   console.log('33333444',this.curBank)
				   // this.selectedAddress = e.value[0].
			       this.show = false; // 关闭弹窗
			     },
			
			

			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;

				this.$forceUpdate()
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			showContent(content) {
				this.selectedContent = content;
			},

			linkRecord() {
				uni.navigateTo({
					url: '/pages/account/tradeLog'
				})
			},
			async handleWithdraw() {
				let type = this.selectedItem == 'Card' ? 1 : 2
				const result = await this.$http.post(`api/app/withdraw`, {
					type: type,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (!result) return false;
				this.getAccountInfo()
				setTimeout(() => {
					this.linkRecord();
				}, 500)

			},
			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/fastInfo`, {
					type: 2
				});
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				this.bankList = result.bank_card_info;
				this.columns = [this.bankList.map(item=>item.huobi)]
			
			}
		},
	}
</script>