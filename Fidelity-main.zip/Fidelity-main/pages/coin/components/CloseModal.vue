<template>
	<view>
		<view class="mask" @click="handleClose()"></view>
		<view class="modal_wrapper">
			<view
				style="background-color: #151517;border-radius: 44rpx 44rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
				<view style="text-align: center;font-size: 32rpx;font-weight: 700;color:#FFFFFF;">
					{{$lang.CONTRACT_HOLD_BTN_CLOSE}}
				</view>
				<view style="padding: 40rpx;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 10rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
							{{info.name}}
						</view>
						<view
							style="background-color: #25262a;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:$theme.FALL}">
							{{info.lever+` X`}}
						</view>
						<view
							style="background-color: #25262a;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:info.fx==1?'#6D41FF':$theme.SECOND}">
							{{info.fxText}}
						</view>
						<view style="margin-left: auto;">
							<view :style="setStyle(info.direct)">
								{{info.directText}}
							</view>
						</view>
					</view>

					<!-- 市價 or  限價 -->
					<view style="margin:40rpx 0;">
						<u-radio-group v-model="radiovalue1" placement="row" @change="groupChange">
							<u-radio :customStyle="{marginRight: '24rpx'}" v-for="(item, index) in radioList"
								:key="index" :label="item.name" :name="item.name" @change="radioChange"
								:activeColor="$theme.RISE" labelSize="28rpx"
								:labelColor="item.name==radiovalue1?$theme.RISE:'#CFCFCF' ">
							</u-radio>
						</u-radio-group>
					</view>

					<template v-if="isMarket">
						<view class="common_input_wrapper"
							style="background-color:#25262a;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:0 20rpx 20rpx 0;">
							<input v-model="amount" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_PRICE"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</template>
					<template v-else>
						<view class="common_input_wrapper"
							style="background-color:#25262a;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:0 20rpx 20rpx 0;"
							:style="{color:$theme.LOG_LABEL}">
							{{info.curPrice}}
						</view>
					</template>

					<view style="color:#FFFFFF;">{{$lang.CONTRACT_CLOSE_QTY}}</view>

					<view class="common_input_wrapper"
						style="background-color:#25262a;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 20rpx 20rpx 0;">
						<input v-model="quantity" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_QTY"
							:placeholder-style="$theme.setPlaceholder()" style="color: #fff;"></input>
					</view>

					<view style="margin-right: 20rpx; background-color:#25262a;border-radius: 4rpx;">
						<view style="display: flex;align-items: center;line-height: 1.8;">
							<block v-for="(item,index) in percentList" :key="index">
								<view :style="setStylePercent(item==curPercent)" @click="changePercent(item)">
									{{item*100+` %`}}
								</view>
							</block>
						</view>
					</view>

					<view
						style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.8;margin-top: 20rpx;"
						:style="{color:$theme.LOG_LABEL}">
						{{$lang.COIN_BUY_BALANCE}}{{`: ${userInfo.money*1} USDT`}}
					</view>

					<!-- <view
						style="font-size: 24rpx;line-height: 1.8;margin-top: 20rpx;text-align: right;padding-right: 20rpx;"
						:style="{color:$theme.LOG_LABEL}">
						{{`可平 ${info.quantity} 張`}}
					</view> -->
				</view>

				<view
					style="margin:28rpx auto;width: 80%;border-radius:50rpx;background-color:#16E2E2;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
					@tap="handleSubmit()">
					{{$lang.COMMON_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CloseModal',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				isShow: false,
				radiovalue1: this.$lang.COIN_PRICE_TYPE_MARKET,
				quantity: '', // 数量输入框
				curPercent: -1, // 當前選中 百分比
				amount: '', // 限价模式 输入金额
				userInfo: {}, // 合約資產
				curLever: 1, // 杠桿
			}
		},
		computed: {
			// 单选项的选项组
			radioList() {
				return [{
					name: this.$lang.COIN_PRICE_TYPE_MARKET,
					disabled: false
				}, {
					name: this.$lang.COIN_PRICE_TYPE_LIMIT,
					disabled: false
				}];
			},
			// 可用餘額的百分之多少
			percentList() {
				return [0.25, 0.50, 0.75, 1]
			},
			// 当前交易模式
			isMarket() {
				return this.radiovalue1 == this.radioList[1].name;
			},
			// // 當前最大可買或可買數量
			// curMaxQTY() {
			// 	// 市價模式： 餘額/單價。 限價模式：餘額/輸入值
			// 	if (this.info) {
			// 		// info.quantity 

			// 		// 市價或限價模式下的單價
			// 		const temp = this.isMarket ? this.amount : this.info.curPrice;
			// 		// console.log(`curMaxQty:`, temp);
			// 		return temp * 1 > 0 ? this.$util.formatNumber(this.userInfo.money * this.curLever / temp, 4) : '';
			// 	}
			// },
		},
		created() {
			this.getAccountAssets();
		},
		methods: {
			// 模式
			groupChange(n) {
				console.log('groupChange', n);
				this.radiovalue1 = n;
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1 = n;
			},

			handleClose() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			// 選擇輸入值的百分比
			changePercent(val) {
				// 選中值與當前值相同，是爲取選。
				if (this.curPercent == val) {
					this.curPercent = -1;
					return false;
				}
				this.curPercent = val;

				if (this.curPercent > 0) {
					console.log(this.info.quantity, this.curPercent);
					this.quantity = this.$util.formatNumber(this.info.quantity * this.curPercent, 4);
					console.log(this.quantity);
					// // 市價或限價模式下的單價
					// // const temp = this.isMarket ? this.amount : this.info.curPrice;
					// // console.log(`curMaxQty:`, temp);
					// // 余额*杠杆/实时价*百分比
					// // console.log(`?`, this.quantity * 1, this.curPercent);
					// this.quantity = this.$util.formatNumber(this.quantity * 1 * this.curPercent, 4);

					// // this.quantity = temp * 1 > 0 ?
					// // 	this.$util.formatNumber(this.userInfo.money * this.curLever / temp * this.curPercent, 4) : '';
				}
			},
			// 設置百分比的選中樣式
			setStylePercent(val) {
				return {
					width: `50%`,
					textAlign: `center`,
					backgroundColor: val ? this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20) : this.$theme.TRANSPARENT,
					color: val ? this.$theme.RISE : '#999999'
				}
			},

			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
			async handleSubmit() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.CONTRACT_CLOSE_QTY,
						icon: 'none'
					});
					return false;
				}
				if (!this.$util.checkInputNumber(this.quantity)) return false;

				// const temp = this.quantity.toString();
				// if (temp.includes('.')) {
				// 	if (temp.split('.')[1].length > 4) {
				// 		uni.showToast({
				// 			title: this.$lang.COMMON_TIP_ENTER_POINT_PREFIX + defaultPoint + this.$lang
				// 				.COMMON_TIP_ENTER_POINT_SUFFIX,
				// 			icon: 'none'
				// 		});
				// 		return false;
				// 	}
				// }
				let formData = {
					num: this.quantity,
					code: this.info.code,
					fx: this.isMarket ? 2 : 1, // 1市价 2限价
					// direct: 1, // direct   1买多    2卖少
					// ganggan: this.curLever, // 杠桿
					
				}
				if (this.isMarket) {
					formData.price = this.amount;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/user/sell_bi`, formData);
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.$emit('action', 1);
				}, 1000);

			},

			// 获取账户 資產 信息 (每次切換買賣時，都調用一次該函數)
			async getAccountAssets() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 1, // 合約賬戶
					name: 'USDT',
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.userInfo = result;
			},
		}
	}
</script>

<style lang="scss" scoped>
	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>