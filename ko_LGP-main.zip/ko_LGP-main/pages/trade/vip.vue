<template>
	<view class="common_page_bg">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-20 color-white flex-1">VIP 러시</view>
		</view>
		
		<view class="" style="min-height: 68vh;padding-top: 10rpx;">
			<!-- <view class="take-notes">
			<view class="name">고객명</view>
			<view class="up-down">
				<view class="price">우대 가격</view>
				<view class="downRange">변경 사항</view>
			</view>
			<view class="" style="width: 20%;"></view>
		</view> -->
			<EmptyData v-if="list.length<=0"></EmptyData>
			<view class="science sc_kxbg" v-for="(item,index) in list" :key="index" style="padding: 10px;border-radius: 10px;">
				<view class="flex" style="margin: 20rpx 0;">
					<view>
						<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
					</view>
					<view class="margin-left-10 flex-1">
						<view class="corporation">{{item.goods.name}}</view>
						<view class="area" >
							<view class="deep">{{item.goods.locate}}</view>
							<view class="deep-number">{{item.goods.code}}</view>
						</view>
					</view>
					<view class="detailed" @tap="goBuy(item)">
						구입하다
					</view>
				</view>
				<view class="flex" style="justify-content: space-between;">
					<view class="">
						증가량
					</view>
					<view class="price">
						{{item.goods.current_price}} 원
					</view>
					
				</view>
				<view class="flex" style="justify-content: space-between;margin-top: 5px;">
					<view class="">
						증가율
					</view>
					<view class="price">
						{{item.goods.rate}}%
					</view>
					
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				list: []
			}
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			//去到购买
			goBuy(item) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/placeOrder/placeOrder' +
						`?item=${encodeURIComponent(JSON.stringify(item))}`

				});
				// console.log(item, '=========抛出去');
			},
			//列表
			async scramble(item) {
				let list = await this.$http.get('api/goods/goodsvipscramble', {
					page: 1,
					limit: 500,
				})
				this.list = list.data.data
			},
		},
		mounted() {
			this.scramble()
		},
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: center;
			align-items: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;

			.up-down {
				width: 40%;
				display: flex;
				justify-content: space-between;
				align-items: center;
			}

			.name {
				width: 30%;
			}

			.price {
				width: 100%;
			}

			.downRange {
				width: 100%;
			}

		}

	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #333;

		}

		.price {
			color: #f85252;
			font-size: 26rpx;
		}

		.detailed {
			background-color: #1e12c0;
			color: #fff;
			border-radius: 10rpx;
			padding: 10rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}
	}
</style>