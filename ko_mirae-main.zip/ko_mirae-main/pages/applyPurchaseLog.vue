<template>
	<view>
		<CustomHeader title="기관 거래 우선가" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view v-for="(item,index) in list" :key="index">
				<view style="margin: 30rpx; word-wrap:break-word;">
					<view class="display">
						<view class="">
							<view class="did-not">
								{{item.goods.name}} <text>{{item.message}}</text>
								<!-- 		<text v-if="item.status==0">未中签</text>
										<text v-if="item.status==1">申购中</text>
										<text v-if="item.status==2">申购中签</text>
										<text v-if="item.status==3">已
			구독하다金额</text>
										<text v-if="item.status==4">中签弃奖</text>
										<text v-if="item.status==5">已上市</text> -->
							</view>

						</view>
						<view class="did-not">
							청약 금액 <text>{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}}</text>
						</view>
					</view>
					<u-divider></u-divider>
					<view class="display quantity">
						<view class="display">
							<view class="">청약 수량</view>
							<view class="red-mark">
								{{item.apply_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
						<view class="display">
							<view class="">청약 총금액</view>
							<view class="red-mark">{{item.apply_num_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}}</view>
						</view>
					</view>
					<view class="quantity">
						<view class="">매입 시간</view>
						<view class="">{{item.created_at}}</view>
					</view>
					<view class="quantity">
						<view class="">거래 코드</view>
						<view class="">{{item.order_sn}}</view>
					</view>
				</view>
				<view style=" height: 4rpx;width: 100%;background: #f5f5f5;"></view>
			</view>

		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				list: [],
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			onLoad(option) {
				this.shengou()
			},
			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

		},

	}
</script>

<style>
</style>