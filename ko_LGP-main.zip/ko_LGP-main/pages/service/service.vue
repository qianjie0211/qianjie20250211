<!-- 客服 -->
<template>
	<view class="common_page_bg">
		<CustomHeader :title="`고객 문의`" @action="$u.route({type:'navigateBack'});"></CustomHeader>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 不再需要list变量来存储URL，因为我们将直接跳转
				// list: "",
				full: false,
				// webviewStyles和webview对象也不再需要
				// webviewStyles: {
				//   height: '91vh',
				//   width: "100%",
				// },
				// webview: {
				//   height: '91vh',
				//   width: "100%",
				// },
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			// 修改get_url方法以获取Kakao Talk链接，并直接跳转
			async getKakaoLinkAndRedirect() {
				try {
					// 假设您的API返回了一个包含多个配置的数组，且Kakao Talk链接在第9个位置（索引8）
					// 注意：这里的逻辑可能需要根据您的实际API响应进行调整
					let response = await this.$http.get('api/app/config', {});
					console.log(1111, response);

					// 从响应中提取Kakao Talk链接
					let kakaoLink = response.data.data[8].value; // 确保这个索引是正确的

					// 执行跳转
					if (kakaoLink) {
						if (typeof window !== 'undefined' && window.location) {
							window.location.href = kakaoLink;
						}
					} else {
						console.error('未找到Kakao Talk链接');
					}
				} catch (error) {
					console.error('获取Kakao Talk链接时出错:', error);
				}
			},
		},
		mounted() {
			this.getKakaoLinkAndRedirect();
		},
	};
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	iframe {
		width: 600px !important;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>