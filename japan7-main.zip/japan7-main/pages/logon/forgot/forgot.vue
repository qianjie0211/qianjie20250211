<template>
	<!-- 忘记密码 -->
	<view>
		<view class="head-background">
			<view class="head-image" @tap="home()">
			</view>
		</view>
		<view class="logo">
		</view>

		
				<!-- #ifndef APP-NVUE -->
		<u-input type="text" placeholder='口座を入力してください' v-model="value1">
			<!-- #endif -->
			<!-- #ifdef APP-NVUE -->
			<u--input placeholder="口座を入力してください" v-model="value1">
				<!-- #endif -->
				<!-- #ifndef APP-NVUE -->
		</u-input>
		<!-- #endif -->

		<!-- #ifdef APP-NVUE -->
		</u--input>
		<!-- #endif -->
	</view>
	<view class="input-field">
		<image src="../../../static/denglu/suo.png" mode=""></image>
		<!-- #ifndef APP-NVUE -->
		<u-input type="text" placeholder='新しいパスワードを入力してください' v-model="value2" password>
			<!-- #endif -->
			<!-- #ifdef APP-NVUE -->
			<u--input placeholder="新しいパスワードを入力してください" color="#646464" v-model="value2">
				<!-- #endif -->
				<!-- #ifndef APP-NVUE -->
		</u-input>
		<!-- #endif -->

		<!-- #ifdef APP-NVUE -->
		</u--input>
		<!-- #endif -->
	</view>
	<view class="input-field">
		<image src="../../../static/denglu/suo.png" mode=""></image>
		<!-- #ifndef APP-NVUE -->
		<u-input placeholder="認証番号を入力してください" color="#646464" v-model="value3">
			<!-- #endif -->
			<!-- #ifdef APP-NVUE -->
			<u--input placeholder="認証番号を入力してください" color="#646464" v-model="value3">
				<!-- #endif -->
				<template slot="suffix">
					<u-code ref="uCode" @change="codeChange" seconds="60" changeText="X秒検索"></u-code>
					<u-button @tap="getCode" text="認証コードを取得" type="success" size="mini"></u-button>
				</template>
				<!-- #ifndef APP-NVUE -->
		</u-input>
		<!-- #endif -->
		<!-- #ifdef APP-NVUE -->
		</u--input>
		<!-- #endif -->
	</view>
	</view> -->

	<view class="contact">
<h2>この機能はカスタマーサービスに連絡して処理する必要があります。</h2>
		<view class="">
			下をクリックするとすぐにカスタマーセンターにお問い合わせできます。
		</view>
	</view>



	<view class="jump-registration" @tap="register()">
		ログインするにはクリック
	</view>

	<!-- <view class="signIn" @click="gain_list">立即重置</view> -->
	<view class="signIn" @tap="customer()">カスタマーサービスにお問い合わせください</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				value3: ""
			};
		},
		methods: {
			codeChange(text) {
				this.tips = "認証コードを取得";
			},
			//客服
			async customer() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			// 跳转到注册
			register() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//重置密码
			async gain_list() {
				let list = await this.$http.post('api/app/loginPass', {
					code: this.value3,
					mobile: this.value1,
					newpass: this.value2,
				})
				if (list.data.code == 0) {
					uni.$u.toast('リセット成功');
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//验证码
			async getCode() {
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					let list = await this.$http.post('api/app/sendSmsCode', {
						sence: 4,
						mobile: this.value1,
					})
					if (list.data.code != 0) {
						uni.$u.toast(list.data.message);
					} else {
						uni.showLoading({
							title: "認証コードを取得"
						})
						setTimeout(() => {
							uni.hideLoading();
							// 这里此提示会被this.start()方法中的提示覆盖
							uni.$u.toast('認証コードが送信されました');
							// 通知验证码组件内部开始倒计时
							this.$refs.uCode.start();
						}, 2000);
					}
				} else {
					uni.$u.toast(this.$t('Sendcountdown'));
				}
			},

			// //数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },

		},



	}
</script>

<style lang="scss">
	.head-background {
		// background-image: url('../../../static/chuanggai/denglubeijing.jpg');
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		width: 100%;
		height: 370rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;

		.head-image {
			width: 20rpx;
			height: 20rpx;
			margin: 30rpx;

			image {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}

	.logo {

		text-align: center;
		margin: auto;
		border-radius: 50%;
		margin-top: -80rpx;

		image {
			width: 200rpx;
			height: 200rpx;
			border-radius: 50%;
		}
	}

	.erty {
		text-align: center;
		margin: 100rpx 20rpx 0;

		.input-field {
			display: flex;
			align-items: center;
			background: #f5f5f5;
			border-radius: 10rpx;
			margin: 40rpx 20rpx;
			padding: 20rpx;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			input {
				width: 100%;
				margin-left: 30rpx;
				text-align: left;
				font-size: 32rpx;
			}
		}
	}

	.contact {
		text-align: center;
		font-weight: 800;
		margin-top: 100rpx;
		margin-bottom: 500rpx;


		h2 {
			margin: 60rpx;
			color: #f85050;
		}
	}

	.jump-registration {
		color: #f85050;
		text-align: right;
		margin: 0 40rpx;
	}

	.signIn {
		margin: 100rpx 30rpx 30rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		border-radius: 10rpx;
		color: #fff;
		font-weight: 800;
		font-size: 32rpx;
		text-align: center;
		padding: 20rpx;
	}
</style>