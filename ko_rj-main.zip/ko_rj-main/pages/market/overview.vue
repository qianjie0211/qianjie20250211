<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<!-- 	<HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->

		<header style="padding: 40rpx 20rpx 20rpx 20rpx;background-color: #F8C351;">
			<view style="display: flex;text-align: center;">
				<block v-for="(item,index) in $lang.MARKET_TABS" :key='index'>
					<view :style="setStyle(curTab ==index)" @click="changeTab(index)" class="flex-1 radius10">
						{{item}}
					</view>
				</block>
			</view>
		</header>


		<view style="padding-bottom: 20px;">
			<template v-if="curTab==0">
				<TabOne ref="tab0" @action="handleChangeTab"></TabOne>
			</template>
			<template v-if="curTab==1">
				<MarketHot></MarketHot>
			</template>
			<template v-if="curTab==2">
				<MarketKPI></MarketKPI>
			</template>

			<template v-if="curTab==3">
				<MarketNews></MarketNews>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabOne from './components/TabOne.vue'
	import MarketHot from './components/MarketHot.vue'
	import MarketKPI from './components/MarketKPI.vue'
	import MarketNews from './components/MarketNews.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TabOne,
			MarketHot,
			MarketKPI,
			MarketNews,
			EmptyData
		},



		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				// timer: null,
				hotNewList: [], //热点新闻
			}
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;

				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			this.isAnimat = true;
			// console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.formattedDate = this.getCurrentDate();
			this.changeTab(this.curTab);
		},
		onReady() {
			// console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			this.isAnimat = false;
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},



		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {
			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
			},

			// TabOne条状到新闻
			handleChangeTab(val) {
				this.changeTab(val);
			},

			// 获取市场top数据
			async getMarketTop() {
	
				
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: 0
				});
				if (!result) return false;
				this.marketList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},

			getCurrentDate() {
				const now = new Date();
				const year = now.getFullYear();
				const month = String(now.getMonth() + 1).padStart(2, '0'); // 月份从0开始，所以要加1
				const day = String(now.getDate()).padStart(2, '0');
				console.log('onHide', `${year}-${month}-${day}`);
				return `${year}-${month}-${day}`;

			},

			// 设置样式
			setStyle(val) {
				return {
					padding: `12rpx 24rpx`,
					color: val ? '#121212' : '#232323',
					background: val ? '#FFFFFF6A' : '',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: val ? '700' : '100',
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.swiper-item {
		display: flex;
		justify-content: center;
		/* 水平居中内容 */
		align-items: center;
		/* 垂直居中内容 */
		height: 100%;
		/* 交换元素的高度与 swiper 相同 */
	}
</style>