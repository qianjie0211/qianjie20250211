<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color:#010101;min-height: 100vh;">
		<HeaderSecond :title="setTitle" :color="$theme.SECOND"></HeaderSecond>

		<view style="margin: 20px;padding: 20px;">
			<TitlePrimary :title="$lang.PASSWORD_OLD"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<!-- <image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image> -->
				<input v-model="oldPassword" :password="!isShow" :placeholder="$lang.PASSWORD_ENTER_OLD"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.PASSWORD_NEW"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<input v-model="newPassword" :password="!isShow" :placeholder="$lang.PASSWORD_ENTER_NEW"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>

				<image :src="`/static/${isShow?'show':'hide'}.png`" mode="aspectFit" :style="$theme.setImageSize(32)"
					@click="toggleShow">
				</image>
			</view>

			<TitlePrimary :title="$lang.PASSWORD_VERIFY"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<input v-model="newPassword2" :password="!isShow" :placeholder="$lang.PASSWORD_ENTER_VERIFY"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				<image :src="`/static/${isShow?'show':'hide'}.png`" mode="aspectFit" :style="$theme.setImageSize(32)"
					@click="toggleShow">
				</image>
			</view>
		</view>
		<view style="position: fixed;bottom: 60px;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>
		<view style="height: 160rpx;"></view>
		<FooterSmall code="assets" />
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			HeaderSecond,
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: uni.getStorageSync('show') || false, // 密码显隐
				oldPassword: "", // 旧密码
				newPassword: "", // 新密码
				newPassword2: "", // 验证新密码
				role: '', // 根据当前角色，处理逻辑。
			};
		},
		computed: {
			// 当前页面用于:role=pay视为变更支付密码，否则视为变更登入密码
			isPay() {
				return this.role == 'pay';
			},
			// 当前页面header标题
			setTitle() {
				return this.isPay ? this.$lang.PROFILE_PAY_PASSWORD :
					this.$lang.PROFILE_SIGN_IN_PASSWORD;
			}
		},
		onLoad(opt) {
			console.log(opt.role);
			this.role = opt.role || '';
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// 检查表单
			checkForm() {
				if (this.oldPassword == '') {
					uni.showToast({
						title: this.$lang.PASSWORD_ENTER_OLD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword == '') {
					uni.showToast({
						title: this.$lang.PASSWORD_ENTER_NEW,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword2 == '') {
					uni.showToast({
						title: this.$lang.PASSWORD_ENTER_VERIFY,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword != this.newPassword2) {
					uni.showToast({
						title: this.$lang.PASSWORD_TIP_VERIFY_FAIL,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (!this.checkForm()) return false;
				this.updateLoginPwd();
			},
			// 修改支付密码
			async updateLoginPwd() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const result = await this.$http.post(`api/user/updateLoginPassword`, {
					oldpass: this.oldPassword,
					newpass: this.newPassword,
					confirmpass: this.newPassword2,
				});
				if (!result) return false;
				this.updatePayPassword();
			},

			//修改密码
			async updatePayPassword() {
				const result = await this.$http.post(`api/user/updatePayPassword`, {
					oldpass: this.oldPassword,
					newpass: this.newPassword,
					confirmpass: this.newPassword2,
				});
				if (!result) return false;
				console.log(result);
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$CONSTANTS.ASSETS_INDEX
					});
				}, 1000)
			},
		}
	}
</script>

<style>
</style>