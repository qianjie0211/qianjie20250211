<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;height: 90rpx;">
							<view>
								{{$lang.TRADE_DAY_ORDER_STATUS}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								Geçti
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;height: 90rpx;">
							<view>
								{{$lang.TRADE_DAY_BUY_PRICE}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.price)}}
							</view>
						</view>
					</view>


					<view style="display: flex;align-items: center;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view>
								{{$lang.TRADE_DAY_BUY_AMOUNT}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.money)}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view>
								{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.success)}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;line-height: 1.8;">
						<view style="flex: 1 0 45%;">
							<view>
								{{$lang.TRADE_DAY_ORDER_SN}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.ordersn}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%;">
							<view>
								{{$lang.TRADE_DAY_CREATE_TIME}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDaySuccessList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 申请列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/order-list`);
				this.list = !result || result.length <= 0 ? [] : result;
			},
		}
	}
</script>

<style>
</style>