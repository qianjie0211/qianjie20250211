<template>
	<view>
		<view class="flex " style=" justify-content: space-between;padding: 20px 10px;">
			<view class="flex" style="padding: 8px;" @click="chaxuan()">
				<view class="flex" @click="chaxuan()">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 240px;35px"></image>
				</view>
			</view>
			<view class="flex" style="background-color: #feedde;padding: 5px 15px;border-radius: 30px;">
				<!-- <image src="/static/sandian.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;"
					@click="$util.linkCustomerService()"></image> -->
				<!-- <image src="/static/shuxian.png" mode="widthFix" style="width:2rpx;"></image> -->
				<image src="/static/notify.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 10px;"
					@click="xiaoxi()">
				</image>
			</view>
			<!-- <image src="/static/sykefu.png" mode="widthFix" style="width: 25px;height: 25px;" @click="$util.linkCustomerService()"></image>
			<image src="/static/notify.png" mode="widthFix" style="width: 25px;height: 25px;" @click="xiaoxi()"></image> -->
		</view>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg"
				style="width: 640rpx;background-image: url(/static/user_top.png);height: 85px;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>
		<view style="padding: 5px 10px;background-color: #fff9f1;border-radius: 10px 10px 0px 0px;">
			<view style="margin-top: 10px;">

				<view class="flex  gap10">
					<view style="flex: 45%;">
						<view class="flex" style="background-color: #f9e5c5;padding: 15px 10px;border-radius: 5px;">
							<image src="/static/qq.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
							<view style="margin-left: 10px;">
								<view class="font-size-13" style="color: #666;">{{$lang.TRADE_TOTAL_BUY_AMOUNT}}</view>
								<view style="color: #ef8217;">{{$util.formatMoney(userInfo.frozen)}}</view>
							</view>
						</view>
					</view>

					<view style="flex: 45%;">
						<view class="flex" style="background-color: #f9e5c5;padding: 15px 10px;border-radius: 5px;">
							<image src="/static/www.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
							<view style="margin-left: 10px;">
								<view class="font-size-13" style="color: #666;">{{$lang.TRADE_VALUATION_GAIN_LOSS}}
								</view>
								<view style="color: #ef8217;">{{$util.formatMoney(userInfo.holdYingli)}}</view>
							</view>
						</view>
					</view>
				</view>
				<view class="flex  gap10" style="padding: 10px 0px;">
					<view style="flex: 45%;">
						<view class="flex" style="background-color: #f9e5c5;padding: 15px 10px;border-radius: 5px;">
							<image src="/static/eee.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
							<view style="margin-left: 10px;">
								<view class="font-size-13" style="color: #666;">{{$lang.ACCOUNT_AMOUNT_TOTAL}}</view>
								<view style="color: #ef8217;">{{$util.formatMoney(userInfo.totalZichan)}}</view>
							</view>
						</view>
					</view>

					<view style="flex: 45%;">
						<view class="flex" style="background-color: #f9e5c5;padding: 15px 10px;border-radius: 5px;">
							<image src="/static/rrr.png" mode="widthFix" style="width: 40px;height: 30px;"></image>
							<view style="margin-left: 10px;">
								<view class="font-size-13" style="color: #666;">{{$lang.TRADE_TOTAL_GAIN}}</view>
								<view style="color: #ef8217;">{{$util.formatMoney(userInfo.totalYingli)}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'AccountTradeInfo',
		components: {
			CardItemThird,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				cardData: {}, // 资产相关数据
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT
				];
			},
			// 是否显示饼图
			isPieChart() {
				return this.cardData && Object.keys(this.cardData).length > 0;
			}
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			// 入金 提款 按钮样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#F8F8F8' : this.$theme.SECOND,
					borderRadius: `24rpx`,
					padding: `24rpx 0`,
					width: `280rpx`,
				}
			},
			chaxuan() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			xiaoxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan * 1, // 
					value2: this.userInfo.money, // 
					value3: this.userInfo.freeze, // 
				};
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>