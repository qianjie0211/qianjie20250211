<!-- 日内交易 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-20 color-white flex-1"> AI스마트거래</view>
		</view>
		<view class="common_block sc_kxbg" style="padding: 6px;min-height: 68vh;">
			<view style="display: flex;align-items: center;justify-content: space-around;margin:20px 0;">
				<view style="border-radius: 4px; padding: 4px 10px;" @click="handleChangeTab(0)"
					:style="{color:current==0?'#FFF':'#121212',backgroundColor:current==0?'#190cbf':'#FFF'}">AI스마트거래
				</view>
				<view style="border-radius: 4px; padding: 4px 10px;" @click="handleChangeTab(1)"
					:style="{color:current==1?'#FFF':'#121212',backgroundColor:current==1?'#190cbf':'#FFF'}">신청내역</view>
				<view style="border-radius: 4px; padding:4px 10px;" @click="handleChangeTab(2)"
					:style="{color:current==2?'#FFF':'#121212',backgroundColor:current==2?'#190cbf':'#FFF'}">매매내역</view>
			</view>
			<view v-if="current==0" style="justify-content: center;display: flex;width: 100%;">
				<image src="/static/waitu.gif" mode="widthFix" style="width: 50%;"></image>
			</view>
			
			<template v-if="current==0">
				<view style="padding:20px;">
					<view class="font-size-15 margin-top-10">금액을 입력하세요</view>
					 <view class="input-container">
					    <!-- 输入框 -->
					    <u-input
					      v-model="amount"
					      placeholder="금액을 입력하세요"
					      type="number"
					      placeholderStyle="font-size: 10px; color: #999"
					      style="background-color: rgba(255, 255, 255, 0.75); padding-right: 60px;"
					    ></u-input>
					
					    <!-- 嵌入的按钮 -->
					    <view class="input-button" @click="whole(tixian_money1())">전액자금</view>
					  </view>
					
						
				</view>
				
				<view class="flex" style=" justify-content: flex-end; margin-right: 20px;">
					<view style="margin-right: 5px;color: #999;">사용 가능한 잔액:</view>
					<view style="margin-right: 10px;">{{$util.formatNumber(userInformation.money)}}</view>
					<view style="color: #190cbf;" @click="rujin()">입금</view>
				</view>
				
				<view class="purchase" @click="handleBuy()"
					style="background-color:#190cbf;margin: 30rpx; border-radius: 20rpx; padding: 20rpx 0; text-align: center; color: #fff; font-weight: 600;">
					매입</view>

				<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#999;">
					<view style="padding-bottom: 6px;">가이드:</view>
					<view style="padding-bottom: 6px;">AI스마트거래 투자자들이 당일 주식을 매매하고 거래 차익에 따라 정산하는 매매기법입니다.</view>
					<view style="padding-bottom: 6px;">투자자는 AI를 통해 특정종목을 일률적으로 매수하고 매도시기에 정산을 진행합니다.</view>
					<view style="padding-bottom: 6px;">매수후 이익이 발생하면 "매매내역"에 바로 표시가되며 매도를 통해 즉시 수익실현이 가능합니다.</view>
					<view style="padding-bottom: 6px;">당일거래 종목의 기밀유지 및 수익을 위해 매수 신청 이후 일정시간 동안 주식코드 및 세부 정보는 제공되지 않습니다.</view>
				</view>
			</template>

			<template v-else-if="current==1">
				<view style="display: flex;align-items: center;padding:10px;">
					<view style="flex: 40%;">금액</view>
					<view style="flex: 30%;">통과금액</view>
					<view style="flex: 30%;text-align: right;">상태</view>
				</view>
				<view>
					<block v-for="(item,index) in list" :key="index">
						<view
							style="display: flex;align-items: center;border-bottom:1px solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
							<view style="flex: 40%;">{{$util.formatNumber(item.money)}}</view>
							<view style="flex: 30%;color:#18BFB4;font-size: 16px;">{{$util.formatNumber(item.success)}}
							</view>
							<view style="flex: 30%;font-size:24rpx;text-align: right;color: #190cbf;">{{item.zt}}</view>
						</view>
					</block>
				</view>
			</template>
			<template v-else-if="current==2">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-top:1px solid #e0e0e0;margin-top:10px;padding:10px 0;">
						<view style="display: flex;align-items: center;">
							<view style="flex:15%;color:#959393;">금액</view>
							<view style="flex:35%;text-align: right;padding-right: 16px;">
								{{$util.formatNumber(item.money)}}
							</view>
							<view style="flex:15%;color:#959393;">유효량</view>
							<view style="flex:35%;color:#18BFB4;font-size: 16px;text-align: right;">
								{{$util.formatNumber(item.success)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#959393;">주문 번호</view>
							<view style="flex:70%;font-size: 12px;text-align: right;color:#959393;">{{item.ordersn}}
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#959393;">날짜 시간</view>
							<view style="flex:70%;font-size: 12px;text-align: right;color:#959393;">{{item.created_at}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' content='클릭하여 작업을 확인하세요.' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				options: {},
				current: 0,
				userInformation: '',
				amount: '',
				list: [],
				showBuyConfirm: false,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {},
		onShow() {
			this.gaint_info()
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
		    rujin(){
				uni.navigateTo({
					url:'/pages/certificateBank/silver'
				})
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getSQList();
				} else if (this.current == 2) {
					this.getOrderList();
				}
			},
			whole(money) {
				this.amount = money
				// console.log(this.value1, '123');
			},
			tixian_money1() {
				let money = this.userInformation.money;
				return money < 0 ? 0 : money
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast('금액을 입력해주세요');
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await this.$http.post('api/rinei/buy', {
					money: this.amount,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.amount = '';
					this.handleChangeTab(1);
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},

			// 申请列表
			async getSQList() {
				const result = await this.$http.get('api/rinei/sq-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 持仓列表
			async getOrderList() {
				const result = await this.$http.get('api/rinei/order-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>
<style scoped>
/* 容器，使用相对定位 */
.input-container {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
}

/* 按钮样式，使用绝对定位 */
.input-button {
  position: absolute;
  right: 5px; /* 右侧留出一些间距 */
  padding: 5px 10px;
  /* background-color: #f6d0ab; */
  color: #190cbf;
  border: none;
  border-radius: 5px;
  font-size: 12px;
  cursor: pointer;
}
</style>