<template>
	<view class="pb-30">
		<u-navbar title="Trung tâm trợ giúp"></u-navbar>
		<view class="m-30">
			<view class="" style="color: #ccc;">
				<text class="title" style="color: #ccc;">1. Quản lý tài chính là gì?</text>
				<text>Quản lý tài chính tài chính là một loại sản phẩm tài chính không được bảo đảm gốc với lợi nhuận thả nổi liên quan đến hai loại tiền mã hoá. Nhà đầu tư có thể sử dụng bất kỳ loại tiền kỹ thuật số nào được quy định trong hợp đồng để mua kiểu sản phẩm tài chính, thanh toán khi đáo hạn tiền mã hoá được xác định bởi giá thanh toán khi đáo hạn và xác định theo giá tham chiếu.
</text>
				<text>Tỷ lệ hoàn vốn do quản lý tài chính mang lại thay đổi theo thị trường, nhưng tỷ lệ hoàn vốn được cố định sau khi nhà đầu tư xác nhận giao dịch mua. Sau khi đăng ký thành công, đơn đặt hàng không thể bị hủy và việc mua lại sớm không được hỗ trợ trước khi hết hạn. Sau khi mua, khi đến thời hạn thanh toán, nhà đầu tư có thể được đảm bảo nhận được khoản lãi cố định được đảm bảo từ loại tiền đầu tư ban đầu, nhưng loại tiền đầu tư cũng có thể được chuyển đổi sang loại tiền khác do biến động của thị trường. Đây cũng là lý do khiến quản lý tài chính thu hút. Tính năng lớn nhất của nhà đầu tư.
</text>
				<text>*Hãy đảm bảo rằng bạn đã hiểu rõ về sản phẩm và rủi ro trước khi đầu tư vào quản lý tài chính. </text>
			</view>
			<view class="mt-50" style="color: #ccc;">
				<text class="title">2. Cách tính thu nhập của bạn?</text>
				<text class="title-2"><strong>Ví dụ 1: Lấy việc đầu tư vào BTC để mua các sản phẩm tài chính BTC_USDT làm ví dụ:</strong></text>
				<text>Người dùng A mua 1 BTC, một sản phẩm tài chính có giá tham chiếu 20.000 USDT và khi đến ngày 1 tháng 2 năm 2021 sản phẩm hết hạn: 
</text>
				<text>Tình huống 1: Giá thanh toán BTC_USDT <20.000USDT, thanh toán hoàn trả bằng BTC, số tiền hoàn trả = 1BTC (1+100%/365*311-1: 0849BTC
</text>
				<text>Tình huống 2: Giá thanh toán của BTCUSDT là 20.000USDT và khoản thanh toán được thanh toán bằng USDT, số tiền hoàn trả-1BTC•20.000
(1+100%/365 31=21698,63 USDT
</text>
                <text>Lấy việc đầu tư vào USDT để mua các sản phẩm tài chính BTC_USDT làm ví dụ: 
Người dùng B mua các sản phẩm trên với giá 20.000 USDT và giá tham chiếu cố định là 20.000 USDT. Khi sản phẩm hết hạn và được giao vào ngày 1 tháng 2 năm 2021: 
Tình huống 1: Thanh toán BTCUSDT giá 20.000 USDT, thanh toán hoàn trả bằng BTC, số tiền hoàn trả = 20.000USDT/20.000
(1+100%/365 31=1,0849 BTC
</text>
             <text>Tình huống 2: Giá thanh toán BTCUSDT > 20.000USDT, thanh toán hoàn trả bằng USDT, số tiền hoàn trả - 20.000ÚDT*
(1+100%/365 31-21.698.63.USDT
</text>
              <text>Tóm lại, sản phẩm được thanh toán khi đáo hạn, người dùng có thể nhận được khoản hoàn trả 108,49%. Tuy nhiên, do sự liên quan về con số giữa giá thanh toán và giá liên kết, nên có sự khác biệt về loại tiền hoàn trả mà người dùng cuối cùng nhận được.
</text>
				<text class="title-2">3. FAQ/ Câu hỏi thường gặp </text>
				<text>1. Làm thế nào để kiểm tra sản phẩm đã mua?
Bạn có thể xem danh sách thông tin sản phẩm đã mua thông qua góc trên bên phải của mục "Quản lý tài chính" phần " Tài chính của tôi" 
</text>
				<text>2.Việc mua hàng có thể bị hủy bỏ không?
Không hỗ trợ huỷ bỏ sau khi mua hàng thành công và việc giải quyết hoàn tiền sẽ được thực hiện tự động khi sản phẩm hết hạn và được giao.
</text>
				<text>3. Sau khi mua thành công có hỗ trợ đổi sớm không?
Sau khi mua thành công, không hỗ trợ việc đổi trả sớm và việc thanh toán sẽ được tự động thực hiện khi sản phẩm hết hạn và được giao.
</text>
          <text>4. Làm thế nào để nhận được thanh toán?
Sau khi giao dịch mua thành công, bạn sẽ tự động nhận được tiền gốc và lãi sau khi đáo hạn và số tiền hoàn trả sẽ được chuyển vào tài khoản giao ngay của bạn mà không cần thao tác thủ công.
</text>
           <text>5. Tại sao đồng tiền đầu tư và đồng tiền hoàn trả nhận được không đồng nhất?
Loại tiền được sử dụng để thanh toán phụ thuộc vào sự so sánh bằng số giữa giá tiền tệ của loại tiền được liên kết và giá được liên kết khi sản phẩm hết hạn, đầu tư vào BTC để thu mua.
Lấy sản phẩm tài chính BTC USDT làm ví dụ: Khi giá thanh toán < giá liên kết, tiền gốc và thu nhập sẽ được thanh toán và hoàn trả bằng BTC: Khi giá thanh toán được liên kết với giá, tiền gốc và thu nhập sẽ được thanh toán và hoàn trả bằng USDT.
</text>
             <text>6. Rủi ro trong quản lý tài chính là gì?
Theo quy định của sản phẩm, đồng tiền thanh toán sẽ được xác định bằng cách so sánh giữa giá liên kết và giá đồng tiền liên kết tại thời điểm đáo hạn. Khi thị trường biến động lớn, rất khó dự đoán việc thanh toán. giá khi đáo hạn và mối quan hệ của nó với giá liên kết, do mối quan hệ giữa chúng, đối với người sử dụng đầu tư dựa trên tiền tệ, sẽ có rủi ro đầu tư về việc đồng tiền được đầu tư hoặc được chuyển đổi. Đồng thời, các sản phẩm quản lý tài sản tài chính cũng cung cấp tỷ lệ hoàn vốn cho rủi ro chuyển đổi tiền tệ. Khi xác suất chuyển đổi cao hơn, tỷ lệ hoàn vốn của các sản phẩm quản lý tài sản tài chính cũng cao hơn.
</text>
			</view>
			<view class="mt-50" style="color: #ccc;">
				<text class="title">4. Giải thích thuật ngữ </text>
				<text class="title-2">Tỷ suất lợi nhuận hàng năm</text>
				<text>Tỷ suất lợi nhuận hàng năm sẽ thay đổi theo biến động thời gian thực của thị trường và tỷ suất lợi nhuận hàng năm thực tế sẽ được xác định vào thời điểm giao dịch mua thành công.
Tỷ lệ lợi nhuận hàng năm/thời gian vị thế*365*100% 
Thời gian vị thế=ngày hết hạn-ngày mua
</text>
				<text class="title-2">Giá tham chiếu được chốt</text>
				<text>Giá tham chiếu được chốt là giá chuẩn, được so sánh với giá của đồng tiền được chốt khi hết hạn để xác định loại tiền tệ và số lượng hoàn trả gốc và thu nhập. Lấy vùng BTC làm ví dụ, chốt với giá của BTCUSDT.. Bạn có thể chọn sản phẩm phù hợp với mình dựa trên mong đợi của bạn đối với thị trường.
</text>
				<text class="title-2">Ngày hết hạn</text>
				<text>Ngày sản phẩm đầu tư kết thúc, sản phẩm sẽ được giao và thanh toán vào lúc 16:00 cùng ngày, lợi nhuận và tiền gốc sẽ được tự động thanh toán vào tài khoản giao ngay sau khi hết hạn thanh toán.
</text>
				<text class="title-2">Đồng tiền đầu tư</text>
				<text>Đồng tiền đầu tư dựa loại tiền thực tế bạn sử dụng để mua sản phẩm. Lấy khu vực BTC làm ví dụ, chốt với giá BTCUSDT, hiện tại hỗ trợ đầu tư bằng tiền tệ BTC hoặc USDT.
</text>
				<text class="title-2">Đồng tiền thanh toán</text>
				<text>Đồng tiền thanh toán là loại tiền thực tế nhận được khi sản phẩm được thanh toán khi đến kì đáo hạn kết thúc. Đồng tiền được sử dụng để thanh toán phụ thuộc vào sự so sánh bằng số giữa giá của đồng tiền được liên kết và giá được liên kết khi sản phẩm hết hạn và được giao. Lấy khu vực BTC và đầu tư vào BTC làm ví dụ. Loại tiền thanh toán bạn có thể nhận được là BTC hoặc USDT.
</text>
				<text class="title-2">Giá thanh toán</text>
				<text>Giá thanh toán là giá tiêu chuẩn của nền tảng quyền chọn Deribit lúc 16:00 chiều vào ngày hết hạn của sản phẩm.
</text>
			</view>
			<!-- <view class="mt-50">
				<text class="title">四、名词解释</text>
				<text class="title-2">年化收益率</text>
				<text>年化收益率会随着市场实时变动，实际年化收益率需以购买成功时为准。</text>
				<text>年化收益率=收益率/持仓期限* 365*100%</text>
				<text>持仓期限=到期日-购买日</text>
				
				<text class="title-2">挂钩参考价</text>
				<text>挂钩参考价是一个基准价格，在到期时会与挂钩币种价格进行对比，从而确定本金及收益的回款币种及数量，以 BTC 专区为例，与 BTC_USDT 价格挂钩。不同产品的挂钩参考价不同，您可根据自己对市场的预期情况选择适合自己的产品。</text>
				<text class="title-2">到期日</text>
				<text>投资产品结束的日期，产品将在到期日当天16:00进行交割结算，收益以及本金回款将在到期结算后自动发放至现货账户。</text>
				<text class="title-2">投资币种</text>
				<text>投资币种为您实际以何种币种购买产品，以 BTC 专区为例，与 BTC_USDT 价格挂钩，现支持以 BTC 或 USDT 币种进行投资。</text>
				<text class="title-2">结算币种</text>
				<text>结算币种为产品到期交割结算时实际收到的回款币种。以何种币种进行结算取决于产品到期交割时挂钩币种价格与挂钩价之间的数值对比结果。以 BTC 专区，投资 BTC 为例，可能收到的结算币种为 BTC 或 USDT。</text>
				<text class="title-2">结算价格</text>
				<text>结算价格为产品到期日下午 16:00Deribit 期权平台标的结算价。</text>
			</view>	 -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss" scoped>
	text {
		display: block;
		margin: 20rpx 0;
	}

	.title {
		font-size: 32rpx;
		font-weight: bold;
	}
	
	.title-2{
		font-weight: bold;
	}
</style>
