<template>
	<view style="background-color: #ffffff;">
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 20px;">
		<view class="bold" style="font-size: 18px;">お気に入り</view>
		<view class=""  style="width: 65%;justify-content: flex-end; display: flex; " >
		<image src="/static/sousuo.png" mode="widthFix" style="width: 20px;height: 20px;" @click="dianji()"></image>
		</view>
		</view>
		
		
		<view class="flex" style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#fff);height: 180px;">
		</view>
		
			
			<view style="background-color: #fff;border-radius: 10px;margin: 10px;margin-top: -180px;height: 750px;">
				<view style="width: 100%;">
					<view style="display: flex;align-items: center;padding:6px 10px;background-color: #d5f3f1;border-radius: 10px 10px 0 0;">
						<view style="flex:25%;">{{$lang.CODE}}/{{$lang.STOCK}}</view>
						<!-- <view style="flex:32%;"></view> -->
						<view style="flex:25%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_AMOUNT}}</view>
						<view style="flex:15%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_RATE}}</view>
						<view style="flex:5%;"></view>
					</view>
				<block v-for="(item,index) in list" :key="index">
					<view @click="productDetails(item.goods.code,item.id)"
						style="">
						
						<view class="flex" style="border-radius: 10px;padding: 0px 20px;height: 60px;">
							<view class="flex-4">
							<view style="width: 150%;" :style="{color:$util.THEME.TEXT}">
								{{item.goods.name}}
							</view>
							<view style="font-weight: 900;padding-right: 16px;"
								:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view>
								</view>				
						<view style="flex:25%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{$util.formatNumber(item.goods.current_price)}}
						</view>
						<view style="flex:15%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{item.goods.rate}}%
						</view>
						<view style="">
							<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(15)"
								@click.stop="handleClickDelProduct(item.goods.gid)"></image>
						</view>
						</view>
					</view>
				</block>
				<EmptyData v-if="list.length<=0"></EmptyData>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
				
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			productDetails(code,id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&id=${id}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},
			home2() {
						uni.navigateBack({
								delta: 2, //返回层数，2则上上页
							});
						},
			dianji() {
				uni.navigateTo({
					url:'/pages/search',
				})
			},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (this.list.length <= 0 || result.data.code == 0) {
					uni.hideLoading();
				}
				this.list = result.data.data.list;
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>