<template>
	<view>
		<template v-if="list && list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<view style="margin-top: 5px; ">
			<block v-for="(item,index) in list" :key="index">
				<view style="padding: 5px 10px;" @tap="handleShowModal(item)">
				<view class="" style="padding:15rpx;background-color: #fff;border-radius: 10px;">
					<view class="flex bold">
						<!-- <image src="../../../static/dd_tb.png" mode="widthFix" style="width: 25px;height: 25px;"></image> -->
						<view class="font-size-15 margin-left-5">{{item.name}}</view>
						<view class="margin-left-5">({{item.code}})</view>
					</view>
					
					
					<view class="flex gap10" style="font-weight: 550;margin-top: 8px; padding: 0px 5px;">
						<view style="flex: 50%;line-height: 2;">
							<view class="flex">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_PROFIT_RATE}}</view>
								<view class="font-size-13" :style="$theme.setStockRiseFall(item.profitRate*1>0)">{{$util.formatNumber(item.profitRate,2)}}%</view>
							</view>
							<view class="flex ">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_BUY_AMOUNT}}</view>
								<view class="font-size-13">{{$util.formatNumber(item.buyNum)+` ${$lang.QUANTITY_UNIT}`}}</view>
							</view>
							<view class="flex">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_BUY_PRICE}}</view>
								<view class="font-size-13">{{$util.formatMoney(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}</view>
							</view>
							
						</view>
						
						<view style="flex: 50%;line-height: 2;">
							<view class="flex">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_PROFIT_AMOUNT}}</view>
								<view class="font-size-13" :style="$theme.setStockRiseFall(item.profitRate*1>0)">{{$util.formatMoney(item.profit*1)+` ${$lang.CURRENCY_UNIT}`}}</view>
							</view>
							<view class="flex">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_TOTAL_PRICE}}</view>
								<view class="font-size-13" :style="$theme.setStockRiseFall(item.profitRate*1>0)">{{$util.formatMoney(item.totalPrice)+` ${$lang.CURRENCY_UNIT}`}}</view>
							</view>
							<view class="flex">
								<view class="flex-1 font-size-13 hui1">{{$lang.TRADE_SELL_LABEL_SELL_PRICE}}</view>
								<view class="font-size-13" :style="$theme.setStockRiseFall(item.profitRate*1>0)">{{$util.formatMoney(item.sellPrice)+` ${$lang.CURRENCY_UNIT}`}}</view>
							</view>
							<!-- <view class="flex">
								<view class="flex-1 font-size-10 hui1">매수시간</view>
								<view class="font-size-10">{{item.buyCreateTime}}</view>
							</view> -->
						</view>
					</view>
					<view class="flex" style="line-height: 2;padding: 0px 5px;">
						<view class="flex-1 font-size-13 hui1">매수시간</view>
						<view class="font-size-13">{{item.buyCreateTime}}</view>
					</view>
					<view style="border-top: 1px #ccc solid;"></view>
					<view class="flex flex-b" style="padding: 10px 5px;">
						<view>
							<view class="hui1 font-size-13">주문 번호</view>
							<view style="margin-top: 5px;">{{item.order_sn}}</view>
						</view>
						<!-- <view class="bold" style="border: 1px #ccc solid;border-radius: 5px;padding:8px 10px;color: #e1b680;" @tap="handleShowModal(item)">세부</view> -->
					</view>
				</view>
				
				</view>
			</block>
			</view>
			<view style="padding: 20px;color: #fff;">.</view>
		</template>
		<template v-if="isShow">
			<AccountTradeSellInfo :info="itemInfo" @action="handleClose"></AccountTradeSellInfo>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import AccountTradeSellInfo from './AccountTradeSellInfo.vue';
	export default {
		name: 'AccountTradeSellList',
		components: {
			CustomTitle,
			EmptyData,
			AccountTradeSellInfo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
				curPage: 1, // 当前页码
				maxPage: 1, // 最大页码
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleShowModal(item) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.itemInfo = item;
				console.log(this.itemInfo);
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar
				this.curPage = 1;
				this.list = [];
				this.getList();
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/order`, {
					page: this.curPage,
					status: 2, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				console.log(`hold result:`, result);
				this.maxPage = result.last_page; // 記錄最大頁碼
				// 过滤保留合法数据
				const temp = !result || result.length <= 0 ? [] :
					result.filter(item => item.order_buy && item.order_buy.id > 0 &&
						item.order_sell && item.order_sell.id > 0);

				console.log('filter:', temp);
				const tempList = temp.length <= 0 ? [] : temp.map(item => {
					return {
						name: item.goods_info.name,
						// 盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% 
						profitRate: (item.order_sell.price * 1-item.order_buy.price* 1 ) / item.order_buy.price * 100,
						profit: item.order_sell.yingkui, // 盈利额
						buyNum: item.order_buy.num, // 购买数量

						totalPrice: item.order_sell.price * 1 * item.order_buy.num, // 

						totalPrice: item.goods_info.current_price * 1 * item.order_buy.num, // 购买总价
						buyPrice: item.order_buy.price, // 买入单价
						sellPrice: item.order_sell.price, // 卖出单价

						// currentPrice: item.goods_info.current_price, // 最新价格
						// 弹层所需数据
						buyCreateTime: item.order_buy.created_at,
						double: item.order_buy.double,
						sellFee: item.order_sell.sell_fee,
						amount: item.order_buy.amount,
						code: item.goods_info.number_code,
						id: item.id,
						order_sn:item.order_sn,
						// typeId: item.goods_info.project_type_id,
						sellCreateTime: item.order_sell.created_at,
						floatProfit: item.order_sell.float_yingkui * 1, // 浮动盈亏
					}
				})
				if (tempList.length > 0) {
					this.list.push(...tempList);
				}
				console.log(this.list, this.list.length);
			},
		},
	}
</script>

<style>
</style>