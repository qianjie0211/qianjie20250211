<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/zuofanhui.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">Aumento di capitale riservato</text>
			</view>
			<view style="color:#FFFFFF;font-size: 12px;" @click="linkRecord()">{{$lang.LISHI_JILV}}</view>
		</header>

		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;display: flex;align-items: center;border: 1px #ccc solid;border-radius: 10px;">
					<!-- <view style="flex:0 0 6%">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view> -->
					<view style="flex:94%;">
						<view style="display: flex;align-items: center;">
							<view style="padding-left: 20rpx;font-size: 32rpx;font-weight: 700;color:#fff;">
								{{item.goods.name}}
							</view>
							<view style="margin-left: auto;">
								<view :style="setStyle()" @click="handleDetail(item)">
									{{$lang.BTN_BUY}}
								</view>
							</view>
						</view>
						<view style="display: flex;align-items: center;padding:0 20rpx;">
							<view style="font-size: 28rpx;padding-right:80rpx;" :style="{color:$theme.LOG_LABEL}">
								{{item.goods.code}}
							</view>
							<view style="padding-right:80rpx;">
								<view>
									<view :style="{color:$theme.PRIMARY}">
										{{`€ `+$util.formatMoney(`${(item.price||0)*1}`,3)}}
									</view>
									<view style="color: #AAA;font-size: 12px;">
										{{`$ `+$util.formatUSD(`${(item.price||0)*eurToUsd}`,3)}}
									</view>
								</view>
							</view>
							<view style="font-size: 28rpx;text-align: center;"
								:style="$theme.setStockRiseFall(item.goods.rate>0)">
								{{$util.formatNumber(item.min_num)}}
							</view>

							<view style="margin-left: auto;" :style="$theme.setStockRiseFall(item.goods.rate>0)">
								{{item.goods.rate>0?'+':'-'}} {{($util.formatNumber(Math.abs(item.goods.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>
			<template v-if="isShow">
				<view class="common_mask" @click="handleClose()"></view>
				<view class="common_popup" style="min-height:35vh;margin:auto;background-color: #202328;">
					<view class="popup_header" style="background-color: #202328;color: #fff;"
						:style="$theme.LG_PRIMARY">
						{{info.name}}
						<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="handleClose()">
						</image>
					</view>
					<view style="padding-bottom: 30rpx;">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
							<text style="color: #ccc;">{{$lang.MAIRU_JIAGE}}</text>
							<view>
								<view :style="{color:$theme.PRIMARY}">
									{{`€ `+$util.formatMoney(`${(info.price||0)*1}`,3)}}
								</view>
								<view style="color: #AAA;font-size: 12px;">
									{{`$ `+$util.formatUSD(`${(info.price||0)*eurToUsd}`,3)}}
								</view>
							</view>
						</view>
						<view class=""
							style="padding-left: 20px;margin:30rpx 40rpx;background-color: #202328;padding: 15px;border: 1px #00aa98 solid ;border-radius: 10px;">
							<input v-model="amount" :placeholder="$lang.QINGSHU_RUSHU" type="number"
								style="width: 80%;color: #fff;"></input>
							<!-- <view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view> -->
						</view>

						<!-- <view class=""
							style="padding-left: 20px;margin:30rpx 40rpx;background-color: #202328;padding: 15px;border: 1px #00aa98 solid ;border-radius: 10px;">
							<input v-model="password" :placeholder="$lang.VERIFY_PASSWORD" type="password"
								style="width: 80%;color: #fff;"></input>
						</view> -->

						<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
						<!-- <template v-if="leverList.length>1">
							<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;">
								{{$lang.GANGGAN}}
							</view>
				
							<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
								<block v-for="(item,index) in leverList" :key="index">
									<view
										style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
										:style="setStyle(curLever==item)" @click="chgangeLever(item)">
										{{item}}
									</view>
								</block>
							</view>
						</template> -->

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:20rpx 50rpx;">
							<view style="color: #ccc;">{{$lang.MAIRU_ZONGE}}</view>
							<view>
								<view style="color: #fff;">
									{{`€ `+$util.formatMoney(`${(buyAmount||0)*1}`,3)}}
								</view>
								<view style="color: #AAA;font-size: 12px;text-align: right;">
									{{`$ `+$util.formatUSD(`${(buyAmount||0)*eurToUsd}`,3)}}
								</view>
							</view>
						</view>

						<!-- <view class="common_input_wrapper" style="margin:30rpx 40rpx;padding-left: 20px;">
							<input v-model="password" :placeholder="$lang.TRADE_LARGE_TIP_BUY_PWD" type="password"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view> -->

						<!-- <view style="display: flex;align-items: center;justify-content: flex-end;padding:20rpx 50rpx;"
							:style="{color:$theme.LOG_LABEL}">
							<view style="padding-right: 10px;">{{$lang.KEYONG_YUE}}:</view>
							<view>{{available}}</view>
						</view> -->

						<view class="bold text-center" @tap.stop="handleConfirm()"
							style="margin:60rpx auto;width: 80%;background-color: #03b874;padding: 10px;border-radius: 10px;color: #fff;font-size: 18px;">
							{{$lang.QUEREN}}
						</view>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 是否显示弹层
				list: [], // 持有列表
				info: null, //
				eurToUsd: 1, // 欧转美
				amount: "", // 金额
				password: '', // 支付密码
				curLever: 1, // 当前杠杆值
			}
		},
		computed: {
			// 金额计算
			buyAmount() {
				return (this.info.price || 0) * this.amount / this.curLever;
			},
		},
		onShow() {
			this.getList();
			this.isAnimat = true;
			this.getConfig(); // 每次重新请求汇率
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			this.getConfig(); // 每次重新请求汇率
			uni.stopPullDownRefresh();
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: '/pages/daytrading/vip/recording'
				})
			},
			handleDetail(val) {
				this.isShow = true;
				this.info = val;
			},
			// 关闭弹层
			handleClose() {
				this.isShow = false;
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async handleConfirm() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const result = await this.$http.post(`api/Product/buy_scramble`, {
					id: this.info.id,
					num: this.amount,
					// pay_pass: this.password,
					// ganggan: this.curLever,
				});
				if (!result) return false;
				this.handleClose();

				uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
				})
				setTimeout(() => {
					this.linkRecord();
				}, 1000);
			},
			async getList() {
				const result = await this.$http.get('api/goods/goodsvipscramble');
				if (!result) return false;
				console.log(result);
				this.list = result;
			},
			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
			setStyle() {
				return {
					backgroundColor: '#03b774',
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		},
	}
</script>
<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>