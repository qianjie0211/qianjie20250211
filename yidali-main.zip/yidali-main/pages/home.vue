<template>
	<view>
		<!-- <image src="/static/home_banner.png" mode="widthFix" style="width: 100%;"></image> -->
		<view class="">
			<HeaderPrimary :title="$lang.TABBAR_HOME" isSearch></HeaderPrimary>
		</view>

		<view class="home_header_bg" style="border-radius: 12rpx;margin:0 24rpx;"></view>

		<view style="margin-top: -50px;padding:20px;">
			<view class="flex" style="background-color: #34393e;border-radius: 10px;">
				<block v-for="(item,index) in listinfo" :key="index" v-if="index==0||index==15||index==7">
					<view class="" style="padding: 15px;border-radius: 10px;">
						<view class="font-size-15 color-white">{{item.name}}</view>
						<view style="color: #02B975;" :style="$util.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
						<view style="color: #02B975;font-size: 18px;" :style="$util.setStockRiseFall(item.rate>0)">
							{{item.current_price}}
						</view>
					</view>
				</block>
			</view>

		</view>


		<view class="flex" style=" justify-content: space-between;padding: 10px;">
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradejiaoyi()">
				<image src="/static/top3.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.GUPIAO}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradegendan()">
				<image src="/static/top2.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.WAIHUI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTrabibi()">
				<image src="/static/top9.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.BIBI_JIAOYI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradaikuan()">
				<image src="/static/top10.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.DAIKUAN}}</view>
			</view> -->

		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;">
			<view style="flex:0 0 25%;" @tap="linkrinei()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test6.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.RINEI_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeipo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/i2.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.IPO}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekeieo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test5.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.LIANGHUA_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeotc()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test3.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.DAZONG_JIAOYI}}</view>
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;margin-top: 0;">
			<view style="flex:0 0 25%;" @click="show_passwd=true">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test4.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">ACR</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/i3.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.AUTH_TITLE}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkMarket()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test1.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;">{{$lang.MARKET_STOCK_EU}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekefu()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/bottom/test7.svg" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view style="color: #fff;margin-top: 5px;text-align: center;word-break: break-word;">{{$lang.KEFU}}
					</view>
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: center;padding:8px 16px;" @click="linkTradejiaoyi()">
			<view style="background-color: #fff;width: 3px; height: 15px;color: #fff;"></view>
			<view style="margin-left: 5px;font-size: 16px;color: #fff;">{{$lang.XIANGMU_HUIBAOLV}}</view>
			<view style="margin-left: auto;">
				<image src="/static/baijiantou.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
			</view>
		</view>

		<view style="padding:20rpx 5rpx;">
			<view>
				<scroll-view class="scroll-view_H " scroll-x="false" @scroll="scroll()">
					<view class="flex" style="color: #00AA98;justify-content: space-between;padding: 10px;">
						<view class="flex-2">{{$lang.MINGCHEN}}</view>
						<view class="text-center flex-1">{{$lang.ZUIXIN_JIA}}</view>
						<view class="flex-1" style="text-align: right;">{{$lang.ZAHNGDIE_FU}}</view>
					</view>
					<view>
						<template v-if="listinfo && listinfo.length<=0">
							<view style="padding: 40rpx;text-align: center;">
								<image src="/static/empty_data.png" mode="aspectFit" :style="$theme.setImageSize(400)">
								</image>
								<view style="font-size: 32rpx;color:#CBCBCF">{{$lang.EMPTY_DATA}}</view>
							</view>
						</template>
						<template v-else>
							<block v-for="(item,index) in listinfo" :key="index">
								<view class="flex"
									style="justify-content: space-between;padding: 10px;border-bottom: 1px #ccc solid;"
									@tap="linkDetail(item)">
									<view class="flex-2" style="color: #fff;">
										<view>{{item.name}}</view>
										<view style="color: #566872;">{{item.number_code}}</view>
									</view>
									<view class="text-center flex-1" style="color: #fff;">
										<view>{{item.current_price}}</view>
										<view style="color: #566872;">{{item.rate_num}}</view>
									</view>
									<view class="flex-1" style="color: #fff;">
										<view :style="$util.setStockRiseFall(item.rate>0)" style="text-align: right;">
											{{item.rate}}%
										</view>
									</view>

								</view>
							</block>
						</template>
					</view>
				</scroll-view>
			</view>
		</view>

		<view class="flex" style="padding:0px 10px;margin-top: 20px;">
			<view style="background-color: #fff;width: 3px; height: 15px;color: #fff;"></view>
			<view style="margin-left: 5px;font-size: 16px;color: #fff;">{{$lang.XINWEN}}</view>
			<view style="margin-left: 20px;">
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;margin-top: 5px;"></image>
			</view>
		</view>
		<template>
			<view class="mask" @click="handleClose()" v-if="isShow">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 20vh;" @click="handleClose()">
					<image src="/static/close_light.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:30vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad">
						<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
						</view>
			        <view style="color: #fff;font-size: 20px;">Avviso Importante</view>
						  <view style="color: #fff;padding: 10px;font-size: 18px;text-align: center;">Le funzionalità del tuo conto FDI saranno limitate. Ti invitiamo a procedere immediatamente al saldo della commissione di gestione e a ritirare i fondi dal conto.</view>
					</view>
				</view>
			</view>
		</template>
		
		
		<!-- <template>
			<view class="mask" @click="handleClose()" v-if="isShow">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;" @click="handleClose()">
					<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad">
						<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
						</view>
			
						
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
								{{info.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
								{{info.code}}
							</view>
			
							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_QTY}}</view>
								<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
									{{$util.formatNumber(info.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;align-items: center;justify-content: space-between;padding:10px 0px;">
								<view class="font-size-19">总金额</view>
								<text
									style="font-weight: 700;color:#ddd;font-size: 14px;">{{msg}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1.2;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:30px 40px;"
								@click="linkIPOSuccessLog()">{{$lang.COMMON_CONFIRM}}</view>
						</view>
					</view>
				</view>
			</view>
		</template> -->
		
		
		<!-- <u-modal :show="show" title="Non approvato" :content='content' :showCancelButton='true' :confirmText="$lang.AUTH_TITLE" :cancelText="$lang.COMMON_CANCEL" @cancel='show=false' @close='show=false' @confirm="$u.route({url:'/pages/Introduction/auth'});"></u-modal> -->
		
		<view style="padding:0rpx 5rpx;">
			<view>
				<scroll-view class=" " scroll-x="false" @scroll="scroll()" @click="home()">
					<view>
						<block v-for="(item, index) in levelinfo" :key="index">
							<view @click="open(item.url)"
								style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;padding: 10px;border-bottom: 1px #ccc solid;">
								<template v-if="curTab==0">
									<view style="flex:60%;padding-right: 30px;padding-top: 10px;color: #fff;">
										<view>{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;color: #fff;"><text
												style="padding: 4px 0;">{{item.updated_at}}</text>
										</view>
									</view> 
									<image :src="item.pic" :style="$theme.setImageSize(220,150)" mode="scaleToFill"
										style="border-radius: 10px;"></image>
								</template>
								<template v-else>
									<view style="flex:100%">
										<view style="color: #fff;">{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;text-align: right;color: #fff;">
											{{item.updated_at}}
										</view>
									</view>
								</template>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>
		
		<u-modal :show="show_passwd" :showCancelButton='true' :confirmText="$lang.AUTH_TITLE" :cancelText="$lang.COMMON_CANCEL" @cancel='show_passwd=false' @close='show_passwd=false' @confirm="linkqianggou">
			<view class="slot-content" style="width: 100%;border: #999999 1px solid;">
				<u--input v-model="password" :placeholder="$lang.VERIFY_PASSWORD" type="password"
					:customStyle="{border: '#999999 1px solid'}"></u--input>
			</view>
		</u-modal>
				
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import index from 'uview-ui';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'MarketNews',
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			TabsFifth,
			CustomTitle,
			EmptyData,

		},
		data() {
			return {
				show_passwd:false,
				password:"",
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				info: {}, // 基本信息
				scrollTop: 0,
				selectedContent: 0,
				message: [],
				listinfo: [],
				isShow: false,
				 
				listinfo2: [],
				list: [],
				curTab: 0,
				levelinfo: [],
				AccountInfo: [],
				old: {
					scrollTop: 0
				},
				show:false
			}
		},

		onShow() {
			this.getLevelInfo();
			this.getList()
			// this.getList2()
			

		},
		onLoad() {
			// this.getAccountInfo();
		},

		onHide() {
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},
		created() {
			this.ipoSuccess();
		},

		methods: {
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.show = result.is_check==2?true:false;
			},
			open(url) {
				window.open(url)
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw',
				})
			},


			// 跳转到交易的股票分栏
			linkTradejiaoyi() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=0`,

				})
			},
			linkAuth() {
				uni.navigateTo({
					url: `/pages/Introduction/auth`
				})
			},
			linkTradegendan() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=1`,

				})
			},
			linkTragensui() {
				uni.navigateTo({
					url: '/pages/trade/copy/index',

				})
			},

			linkTradekeieo() {
				uni.navigateTo({
					url: '/pages/trade/wealth/index'
				})
			},
			linkrinei() {
				
				uni.navigateTo({
					url: '/pages/daytrading/day/index'
				})
			},
			linkTradaikuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},
			// 弹层关闭
			handleClose() {
				this.isShow = false;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO + `?type=2`,
				})
			},
			
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get(`api/app/renjiaoStatus`);
				console.log(22222,result);
				// if (result.code == 0) {
				if (result.status==1) {
						this.msg=result.msg
						this.isShow = true;
					}
				else {
					uni.$u.toast("");
				}
			},
			linkTradekefu() {
				// uni.navigateTo({
				// 	url: '/pages/service'
				// })
				this.$util.linkService()
			},
			// linkTradeheyue() {
			// 	uni.navigateTo({
			// 		url: '/pages/transfer/index'
			// 	})
			// },
			linkTradeipo() {
				uni.navigateTo({
					url: '/pages/trade/ipo/index'
				})
			},
			linkTradeotc() {
				uni.navigateTo({
					url: '/pages/trade/large/index'
				})
			},


			licai() {
				uni.switchTab({
					url: "/pages/trade/wealth/index"
				})
			},
			tongzhi() {
				uni.navigateTo({
					url: "/pages/tongzhi"
				})
			},
			async linkqianggou() {
				const result = await this.$http.get(`api/app/config`);
				console.log(result[44].value);
				if(result[44].value==this.password){
					uni.navigateTo({
						url: '/pages/daytrading/vip/index'
					})
				}else{
					uni.showToast({
						icon: "none",
						title: "La password non è corretta."
					})
				}
				
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			// 跳转到市场
			linkMarket() {
				uni.switchTab({
					url: this.$paths.MARKET,
				})
			},

			home() {
				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},

			closeAll() {
				if (this.$refs.goods) this.$refs.goods.disconnect();
			},
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				// uni.showToast({
				// 	icon: "none",
				// 	title: "纵向滚动 scrollTop 值已被修改为 0"
				// })
			},
			// 
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?gid=${val.gid}`
				})
			},

			async getList() {
				const result = await this.$http.post(`api/goods/zhishu`, {});
				console.log(result);
				if (!result) return false;
				this.listinfo = result;
				console.log(this.listinfo);
				this.connect1()
			},

			async getList2() {
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: 8
				});
				console.log(result);
				if (!result) return false;
				this.listinfo2 = result;
				console.log(this.listinfo2);
			},


			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0 && data.type == 'ticker') {
						console.log(data);
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].rate_num = data.rate_num || 0;
					}

				});
			},
			connect1() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.listinfo[data.pid] && data.pid && data.last > 0) {
						// console.log(data);
						this.listinfo[data.pid].current_price = data.last;
						this.listinfo[data.pid].rate = data.pcp || 0;
						this.listinfo[data.pid].rate_num = data.pc || 0;
						// this.list[data.market].vol = data.vol || 0;
					}

				});
			},

			async getLevelInfo() {
				const result = await this.$http.get(`api/article/list`, {
					type: 11
				});
				if (!result) return false;
				this.levelinfo = result;
			},
		},

	}
</script>

<style>
	.scroll-Y {
		height: 300rpx;
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}
	
	.bg_ad {
		/* background-image: url(/static/dialog_bg_ipo_success.png); */
		background-color: #2d3535;
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 27vh;
		width: 80vw;
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		align-items: center;
		border-radius: 20px;
		padding: 20px 0;
	}

	.scroll-view-item_H {
		display: inline-block;
		border-radius: 10px;
		width: 80%;
		/* height: 300rpx; */
		/* line-height: 60rpx; */
		/* text-align: center; */
		font-size: 36rpx;
	}
</style>