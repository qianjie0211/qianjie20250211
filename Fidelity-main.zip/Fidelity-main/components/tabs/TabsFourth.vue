<template>
	<view class="flex text-center justify-center"  style="padding:  20px 0;">
		<view style="background-color: #424445;border-radius: 20px;" class="flex ">
		<block v-for="(item,index) in tabs" :key='index'>
			
			<view style="color: #fff;border-radius: 20px;padding:5px 20px;" @click="handleChange(index)" :style="setActiveStyle(acitve ==index)">{{item}}</view>
				
		</block>
		
		</view>
		
	</view>
</template>

<script>
	import theme from '@/common/theme.js';
	export default {
		name: 'TabsFourth',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			handleChange(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
			setActiveStyle(val) {
				return {
					backgroundColor: val ? '#10df95' : '',
					fontWeight: val ? '900' : '500',
					
				}
			},
		}
	}
</script>

<style>
</style>