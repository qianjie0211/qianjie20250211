<template>
	<view style="margin-top: 80px;">
		<view class="flex flex-b hui1 padding-10">
			<view>이름</view>
			<view>매수수량</view>
			<view>매수가격</view>
			<view>주문상태</view>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="background-color: #fff;min-height: 100vh; ">
				<block v-for="(item,index) in list" :key="index">
					<view class="flex padding-10" style="border-bottom: 1px #ccc solid;">
						<view style="flex: 10%;">{{item.goods.name}}</view>
						<view style="flex: 20%;text-align: center;">{{item.num}}</view>
						<view style="flex: 30%;text-align: center;">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
						<view :style="{backgroundColor:transStatus2(item.admin_status)}"
							style="padding:3px 5px;border-radius: 5px;color: #fff;font-size: 12px;flex: 10%;text-align: center;">
							{{transStatus(item.admin_status)}}
						</view>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeRecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
			transStatus(admin_status) {
				if (admin_status == 0) {
					return '검토중'
				} else if (admin_status == 1) {

					return '신청 성공'
				} else if (admin_status == 2) {

					return '신청 실패'
				}

			},
			transStatus2(admin_status) {
				if (admin_status == 0) {

					return this.admin_statusbackgroundcolor = '#ffcf47'
				} else if (admin_status == 1) {

					return this.admin_statusColor = "#34d66a"
				} else if (admin_status == 2) {

					return this.admin_statusColor = "red"
				}

			},


		},
	}
</script>