<template>
	<view style="padding:18px;padding-bottom: 200rpx;">
		<view style="background-color: #010101;border-radius: 32rpx;padding:24rpx;">
			<view style="text-align: center;margin-bottom: 30px;">
				<image src="/static/trade_day.png" mode="aspectFit"></image>
			</view>
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.TRADE_DAY_TIP_INPUT_AMOUNT}}
			</view>

			<view class="common_input_wrapper"
				style="padding-left: 20px;background-color: transparent;border-bottom:1px solid #EEE;border-radius: 0;">
				<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
					:placeholder-style="$theme.setPlaceholder()" style="flex: 1;color: #fff;"></input>
				<view style="color:#fff">{{$lang.CURRENCY_UNIT}}</view>
				<view style="margin-left: auto;">
					<view style="display: flex;align-items: center;justify-content: space-between;flex-wrap: nowrap;">
						<view>{{code==1?'TRY':'USDT'}}</view>
						<text style="padding: 0 4px;">|</text>
						<view @click="maxQty()" :style="{color:$theme.PRIMARY}">
							{{$lang.SEARCH_TAB_ALL }}
						</view>
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: start;" :style="{color:$theme.LOG_LABEL}">
				<view style="padding-right: 10px;">{{$lang.TRADE_DAY_BALANCE}}:</view>
				<view :style="{color:$theme.LOG_VALUE}">{{$util.formatMoney(available)}} {{code==1?'TRY':'USDT'}}
				</view>
				<!-- <view style="padding-left: 10px;" :style="{color:$theme.PRIMARY}" @click="linkDeposit">
					{{$lang.DEPOSIT_TITLE}}
				</view> -->
			</view>
			<view class="common_btn"
				style="margin:30rpx auto;background-color: #1C1C1C;color:#FFF;background-color: #018ef8;"
				@click="handleBuy()">
				{{$lang.TRADE_DAY_BUY}}
			</view>
		</view>

		<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;" :style="{color:$theme.LOG_VALUE}">
			<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
			<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;font-size: 13px;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeDayBuy',
		props: {
			code: {
				type: [Number, String],
				default: 1
			}
		},
		data() {
			return {
				amount: '',
				available: '',

			}
		},


		created() {
			this.getAccountInfo();
		},
		methods: {
			maxQty() {
				this.amount = this.$util.formatNumber(this.available * 1, 4);
			},
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: this.$CONSTANTS.DEPOSIT_INDEX
				})
			},

			// 购买
			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TRADE_DAY_TIP_INPUT_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				// 弹层
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},

			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
					type: this.code
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {

					// this.amount = '';
					// 1 为驱动父组件，实现切换Tab效果
					this.$emit('record_click');
				}, 1000);
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/assets`, {
					type: this.code * 1 == 1 ? 3 : 2,
					name: this.code * 1 == 1 ? "TRY" : "USDT",
				});
				if (!result) return false;
				console.log(result);
				this.available = result[0].money || 0;
			},
		}
	}
</script>