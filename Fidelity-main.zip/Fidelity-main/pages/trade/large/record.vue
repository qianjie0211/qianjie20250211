<template>
	<view :class="isAnimat?'fade_in':'fade_out'" >
		<view class="flex" style="padding: 20px;">
			<view @click="lishi()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-1 text-center font-size-18" style="color: #fff;">{{$lang.LISHI_JILV}}</view>
		</view>
		<!-- <HeaderSecond :title="$lang.TRADE_LARGE_RECORD" color="#FFFFFF"></HeaderSecond> -->
		<view style="padding:20rpx 32rpx; min-height: 96vh;width: 85%;border-radius: 10px;margin-left: 10px;">
			<TradeLargeRecord></TradeLargeRecord>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TradeLargeRecord from './components/TradeLargeRecord.vue';
	export default {
		components: {
			HeaderSecond,
			TradeLargeRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			lishi(){
				uni.navigateBack({
					delta:1,
				})
			},
		},
	}
</script>

<style>
</style>