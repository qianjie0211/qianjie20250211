<template>
	<view style="padding: 10px 0;">
		<view
			style="display: flex;align-items: center;flex-wrap: wrap; margin-bottom: 6rpx;line-height:1.8;margin: 6px 0;">

			<block v-for="(item,index) in $lang.STOCK_BASE_INFO" :key="index">
				<view style="flex:40%;margin:0 6px;padding-top:10px;">
					<view :style="{textAlign:index%2==0?'left':'right',color:$theme.LOG_LABEL }">{{item}}</view>
					<view style="color:"
						:style="{color:setStyle[index]!=''? setStyle[index]:$theme.LOG_VALUE,textAlign:index%2==0?'left':'right' }">
						{{setData[index]}}
					</view>
				</view>

			</block>
		</view>

		<!-- 股票 概况 数值 布局 之 一行一项 -->
		<!-- <view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[0]}}</view>
			<view style="flex:70%;text-align: right;">{{$lang.STOCK_BASE_INFO[1]}}<text style="padding:0 0 0 10px;"
					:style="{color:$theme.PRIMARY}">{{info.marketcap_rank}}</text></view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[2]}}</view>
			<view style="flex:70%;text-align: right;"><text
					style="padding:0 0 0 10px;">{{$util.formatNumber(info.marketcap)}}</text></view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[3]}}</view>
			<view style="flex:70%;text-align: right;"><text
					style="padding:0 10px;">{{$util.formatNumber(info.sharesout)}}</text>{{$lang.QUANTITY_UNIT}}
			</view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[4]}}</view>
			<view style="flex:70%;text-align: right;"><text
					style="padding:0 10px;">{{$util.formatNumber(info.foreigners_pie)}}</text>%
			</view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[5]}}</view>
			<view style="flex:30%;text-align: right;">{{info.sector}}
			</view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[6]}}</view>
			<view style="flex:20%;text-align: right;">{{info.industry}}</view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[7]}}</view>
			<view style="flex:30%;text-align: right;" :style="{color:'red'}">
				{{$util.formatNumber(info.year_high)}}
			</view>
		</view>
		<view style="display:flex;align-items: center;padding:4px 0;">
			<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[8]}}</view>
			<view style="flex:30%;text-align: right;" :style="{color:$theme.PRIMARY}">
				{{$util.formatNumber(info.year_low)}}
			</view>
		</view> -->

		<!-- 布局 之 一行两项 -->
		<!-- <view style="background-color: #FFFFFF;padding:6px;border-radius: 6px;">
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999">{{$lang.STOCK_BASE_INFO[0]}}</view>
					<view>
						{{$lang.STOCK_BASE_INFO[1]}}<text style="padding:0 0 0 10px;"
							:style="{color:$theme.PRIMARY}">{{info.marketcap_rank}}</text>
					</view>
				</view>
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[2]}}</view>
					<view style="color:#e48a88;">
						{{$util.formatNumber(info.marketcap)}}
					</view>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[3]}}</view>
					<view style="color:#666;">
						{{$util.formatNumber(info.sharesout)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[4]}}</view>
					<view style="color:#666;">
						{{$util.formatNumber(info.foreigners_pie)}}%
					</view>
				</view>
			</view>

			<view
				style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;margin: 6px 0;">
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[5]}}</view>
					<view style="color:#666;">
						{{info.sector}}
					</view>
				</view>
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[6]}}</view>
					<view style="color:#666;">
						{{info.industry}}
					</view>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;margin: 6px 0;">
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[7]}}</view>
					<view style="color:#666;">
						{{$util.formatNumber(info.year_high)}}
					</view>
				</view>
				<view
					style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
					<view style="color:#999;">{{$lang.STOCK_BASE_INFO[8]}}</view>
					<view style="color:#666;" :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(info.year_low)}}
					</view>
				</view>
			</view>
		</view> -->
	</view>
</template>

<script>
	export default {
		name: 'StockInfoBase',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		computed: {
			// 数据可能需要不同的颜色,数据返回太慢，分开写
			setStyle() {
				return [this.$theme.PRIMARY, '#e48a88', '', '', '', '', this.$theme.RISE, this.$theme.FALL];
			},

			setData() {
				return [
					`${this.$lang.STOCK_KOSDAQ} ${this.info.marketcap_rank}`,
					this.$util.formatNumber(this.info.marketcap),
					this.$util.formatNumber(this.info.sharesout) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.foreigners_pie) + `%`,
					this.info.sector,
					this.info.industry,
					this.$util.formatNumber(this.info.year_high),
					this.$util.formatNumber(this.info.year_low)
				];
			},
		}
	}
</script>

<style>
</style>