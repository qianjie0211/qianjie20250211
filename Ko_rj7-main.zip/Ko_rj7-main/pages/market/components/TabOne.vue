<template>
	<view style="padding:10px;background-color: #fff;">



		<!-- <TabsFifth :tabs="$lang.MARKET_OVERVIEW_SELF_TABS" @action="changeTab" :acitve="curTab"></TabsFifth> -->
        <!-- <view class="flex" style="padding: 10px 0px;">
			<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
			 <view class="bold margin-left-5">주요인기주식</view>
		 </view> -->
	
		
		<!-- <CustomTitle title="주요인기주식"></CustomTitle> -->
		
		
		<!-- <view class="flex flex-wrap gap10" style="padding: 10px 0px;">
			<block v-for="(item,index) in top1" :key="index" >
				
				<view
					style="flex:20%;padding:10px;border-radius: 6px;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
					:style="{ backgroundImage: `url(${item.rate > 0 ? '/static/zhishu_z.png' : '/static/zhishu-d.png'})`, backgroundSize: 'cover', backgroundPosition: 'center' }"  @click='handleChangeType(index)'>
					<view class="text-center bold">
						<view class="font-size-16" style="color: #000;">
							{{top111[index]}}
						</view>
						<view :class="item.rate>0?'red':'green'">
							{{item.close}}
						</view>
						<view :class="item.rate>0?'red':'green'" style="margin-bottom: 40px;">
							{{item.rate}}
						</view>
					</view>
				</view>
			</block>
		</view> -->
		
		<!-- <view style="padding:10px 0px;">
			<view class="flex padding-10" style="background-color: #F8F9FB;border-radius: 10px;line-height: 1.8;">
				<view style="flex: 30%;text-align: center;" @click="rinei()">
					<image src="/static/sc_ee.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view>단타 급등주</view>
				</view>
				<view style="flex: 30%;text-align: center;" @click="xingu()">
					<image src="/static/sc_rr.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view>공모주</view>
				</view>
				<view style="flex: 30%;text-align: center;" @click="dazong()">
					<image src="/static/sc_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view>블록딜</view>
				</view>
				<view style="flex: 30%;text-align: center;" @click="tikuan()">
					<image src="/static/sc_qq.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view>입금</view>
				</view>
			</view>
		</view> -->
		
		
		<view class="flex" style="padding: 10px 0px;">
					<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
					 <view class="bold margin-left-5">특징종목</view>
		</view>

		<!-- <CustomTitle :title="$lang.MARKET_TABS[1]"></CustomTitle> -->

		<MarketHotTop></MarketHotTop>

		<!-- <view style="margin-top:10px;padding:10px 0;">
			<view style="font-size:14px;display: flex;align-items: center;justify-content: center;padding: 10px;"
				@click="handleHot()" >
				<view>{{$lang.MARKET_MORE_HOT_TITLE}}</view>
				<view class="arrow rotate_45" style="border-color:#D7D7D7" :style="$theme.setImageSize(12)"></view>
			</view>
		</view> -->

		<!-- <CustomTitle :title="$lang.MARKET_TABS[3]">
			<view style="font-size: 13px;" @click="linkMarketNews()">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
			</view>
		</CustomTitle>

		<view style="display: flex;align-items: center;flex-wrap: wrap;">
			<block v-for="(item,index) in article" v-if="index<=3" :key="index">
				<view @click="open(item.url)" style="flex: 40%;height: 150px;margin: 10px;position: relative;">
					<image :src="item.pic" mode="aspectFill" style="border-radius: 8px;width: 100%;height: 130px;">
					</image>
					<view
						style="position: absolute;bottom:20px;left:0;width: 100%;background-color: rgba(0, 0, 0, 0.5);border-radius: 0 0 8px 8px;">
						<view style="margin:4px 6px;color: #FFFFFF;">{{item.title}}</view>
					</view>

					<view style="padding-left: 10px;" :style="{color:$theme.LOG_VALUE}">
						{{item.created_at}}
					</view>
				</view>
			</block>
		</view>

		<CustomTitle :title="$lang.MARKET_NEWS_TABS[3]"></CustomTitle>

		<view>
			<block v-for="(item,index) in industryList" :key="index">
				<view style="display: flex;align-items: center;line-height: 1.8;padding:10px;">
					<view style="font-size: 28rpx;width: 100px;" :style="{color:$theme.LOG_VALUE}">{{item.name}}</view>

					<view style="text-align: center;" class="flex justify-center">
						<view style="width: 150px;height: 20px;border-radius: 5px;" :style="barStyle(item.avg_returns)">
						</view>
					</view>
					<view style="font-size: 24rpx;text-align: right;margin-left: auto;"
						:style="$theme.setStockRiseFall(item.avg_returns*1>0)">
						{{item.avg_returns}}%
					</view>
				</view>
			</block>
		</view> -->
		<view style="height: 50px;"></view>
	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';
	import uCharts from '@/common/u-charts.js';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import TabsSecond from '@/components/tabs/TabsSecond.vue'
	import CustomTitle from '@/components/CustomTitle.vue';
	import MarketHotTop from './MarketHotTop.vue';
	var uChartsInstance = {};
	export default {
		name: 'TabOne',
		components: {
			TabsFifth,
			TabsSecond,
			CustomTitle,
			MarketHotTop
		},
		data() {
			return {
				timer: null,
				curTab: 0, // 国内走势ITEM 
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				top111: {
					141: "코스닥",
					17470: "코스피 200",
					255: "코스피",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kLineChart: null,
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				industryList: [],
			}
		},
		created() {
			// this.getData();
		},
		mounted() {
			// console.log('child mounted', this.timer);
			// this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},

		methods: {
			barStyle(value) {
				value = value * 2 * 10
				let percentage = Math.min(Math.abs(value), 100); // 确保百分比限制在 0 到 100 之间
				if (value > 0) {
					// 正数时，从中间往右显示红色，左边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #DA7437 50%, #DA7437 ${50 + (percentage / 2)}%, #e9e9ea ${50 + (percentage / 2)}%)`,
					};
				} else if (value < 0) {
					// 负数时，从中间往左显示绿色，右边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea ${50 - (percentage / 2)}%, #37DCCF ${50 - (percentage / 2)}%, #37DCCF 50%, #e9e9ea 50%)`,
					};
				} else {
					// 值为 0 时，保持全灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #e9e9ea 50%)`,
					};
				}
			},
			rinei(){
				uni.navigateTo({
					url:'/pages/trade/day/index'
				})
			},
			dazong(){
				uni.navigateTo({
					url:'/pages/trade/large/index'
				})
			},
			xingu(){
				uni.navigateTo({
					url:'/pages/trade/ipo/index'
				})
			},
			tikuan(){
				uni.navigateTo({
					url:'/pages/deposit/index'
				})
			},
			

			// onSetTimeout() {
			// 	this.timer = setInterval(() => {
			// 		console.log("setInterval");
			// 		this.getData();
			// 	}, 5000);
			// },
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			changeTab(val) {
				this.current1 = val;
				this.curTab = val;
				this.getData()
			},
			handleChangeTabHot(val) {
				console.log('top:', val);
				this.current2 = val;
				this.top_two()
			},
			handleChangeType(val) {
				this.stockId = val;
				this.getData()
			},

			open(url) {
				window.open(url)
			},

			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`,
				})
			},

			handleHot() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=3`,
				})
			},

			// async getData() {
			// 	// uni.showLoading({
			// 	// 	title: this.$lang.REQUEST_DATA,
			// 	// });
			// 	const result = await this.$http.get(`api/goods/top1`, {
			// 		current2: this.current2,
			// 		stockid: this.stockId
			// 	});
			// 	console.log('getData:', result);
			// 	if (!result) return false;
			// 	this.top1 = result.top1
			// 	this.article = result.article;
			// 	this.industryList = result.bottom;

			// 	if (!this.kLineChart) {
			// 		this.kLineChart = init('chart-type-k-line')
			// 		this.kLineChart.setStyles({
			// 			"candle": {
			// 				"type": "area",
			// 				"tooltip": {
			// 					"showRule": "none",
			// 				}
			// 			},
			// 		});
			// 	}
			// 	this.kLineChart.applyNewData(result.kline)
			// },
		},
	}
</script>

<style lang="scss">
	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.yinying-blue {
		box-shadow: #d1e0ff 0px 1px 6px 0px;
	}

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	.charts {
		width: 100%;
		height: 200px;
		margin: 10px;

	}




	.more {
		padding: 10px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}



	.lists {
		padding: 0 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}
</style>