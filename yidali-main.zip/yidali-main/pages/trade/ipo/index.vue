<!-- 新股申购 -->
<template>
	<view>
		<view>
			<view class="flex" style="padding: 20px;">
				<view @click="$util.goBack()">
					<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
				</view>

				<view class="flex-1 text-center" style="color: #fff;font-size: 18px;">{{$lang.IPO}}</view>
			</view>
			<!-- <HeaderSecond :title="$lang.PAGE_TITLE_TRADE_IPO"></HeaderSecond> -->
		</view>

		<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab ==0">
			<view style="padding: 10px;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="margin-bottom: 20px;border-radius: 8px;padding: 10px;border: 1px #00aa98 solid;">
						<view style="font-size: 36rpx;font-weight: 700;" :style="{color:$theme.PRIMARY}">
							{{item.goods.name}}
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<text style="font-size: 28rpx;color: #ccc;">{{item.goods.code}}</text>
							<view
								style="color:#fff;padding:4px 10px; border-radius: 20px;width: 160rpx;text-align: center;background-color: #02b975;"
								@click="handleBuy(item.id)">
								{{$lang.BTN_BUY}}
							</view>
						</view>
						<template v-if="item.price">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<text style="color: #AAA;font-size: 12px;">{{$lang.SHENGOU_JIA}}</text>
								<view>
									<view style="color: #fff;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.price*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.price*1}`,0)}}
										</template>
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.price*eurToUsd}`,0)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.price*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>
						</template>
						<template v-if="item.fa_amount">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<text style="color: #AAA;font-size: 12px;">{{$lang.TRADE_IPO_POST_QTY}}</text>
								<view>
									<view style="color: #fff;text-align: right;">
										{{$util.formatMoney(`${item.fa_amount*1}`)}}
									</view>
									
								</view>
							</view>
						</template>
						<template v-if="item.fa_muji_zijin">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<text style="color: #AAA;font-size: 12px;">{{$lang.TRADE_IPO_RAISE_MONEY}}</text>
								<view>
									<view style="color: #fff;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.fa_muji_zijin*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.fa_muji_zijin*1}`,0)}}
										</template>
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.fa_muji_zijin*eurToUsd}`,0)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.fa_muji_zijin*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>
						</template>
						<template v-if="item.shengou_date">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">{{$lang.SHENGOU_RIQI}}</view>
								<view style="color: #fff;">{{item.shengou_date}}</view>
							</view>
						</template>
						<template v-if="item.shengou_date">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">{{$lang.RENJIAO_RIQI}}</view>
								<view style="color: #fff;">{{item.rj_date}}</view>
							</view>
						</template>
						<template v-if="item.shengou_date">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">{{$lang.GONGBU_RIQI}}</view>
								<view style="color: #fff;">{{item.gb_date}}</view>
							</view>
						</template>
						<template v-if="item.shengou_date">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">{{$lang.SHANGSHI_RIQI}}</view>
								<view style="color: #fff;">{{item.online_date}}</view>
							</view>
						</template>
					</view>
				</block>
			</view>
		</template>

		<template v-else>
			<template v-if="!setList || setList.length<=0">
				<view class="" style="padding:10px;margin-bottom: 20px;">
					<EmptyData></EmptyData>
				</view>
			</template>
			<template v-else>
				<block v-for="(item,index) in setList" :key="index">
					<view
						style="margin: 10rpx; word-wrap:break-word;padding: 10px;border: 1px #00aa98 solid;border-radius: 10px;margin-top: 10px;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">{{item.goods.name}}</view>
							<template v-if="curTab==1">
								<view style="color:#fff;padding:2px 4px;border: 1px #00aa98 solid;border-radius: 5px;">
									{{item.message}}
								</view>
							</template>
						</view>
						<view style="font-size: 28rpx;color: #ccc;">{{item.goods.code}} </view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.TRADE_IPO_LOG_LABELS[0]}}</view>
							<view>
								<view style="color: #fff;text-align: right;">
									<template v-if="$util.isEur(item.goods.project_type_id)">
										{{`€ `+$util.formatMoney(`${item.price*1}`,3)}}
									</template>
									<template v-else>
										{{`$ `+$util.formatUSD(`${item.price*1}`,0)}}
									</template>
								</view>
								<view style="color: #AAA;font-size: 12px;text-align: right;">
									<template v-if="$util.isEur(item.goods.project_type_id)">
										{{`$ `+$util.formatUSD(`${item.price*eurToUsd}`,0)}}
									</template>
									<template v-else>
										{{`€ `+$util.formatMoney(`${item.price*usdToEur}`,3)}}
									</template>
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.SHENGOU_SHULIANG}}</view>
							<view>
								<view style="color: #fff;text-align: right;">
										{{$util.formatMoney(`${item.apply_amount*1}`)}}
								</view>
								
							</view>
						</view>
						<template v-if="curTab==2">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">{{$lang.ZHONGQIAN_JINE}}</view>
								<view style="text-align: right;">
									<view style="color: #fff;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.success_num_amount*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.success_num_amount*1}`,0)}}
										</template>
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.success_num_amount*eurToUsd}`,)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.success_num_amount*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>
						</template>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.ZHONGQAIN_SHULIANG}}</view>
							<view>
								<view style="color: #fff;text-align: right;">
						
									{{$util.formatUSD(`${item.success*1}`,0)}}
								</view>
								
							</view>
						</view>
						
						
						
						
						<template v-if="curTab==2">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">Importo sottoscritto</view>
								<view>
									<view style="color: #fff;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.freeze*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.freeze*1}`,0)}}
										</template>
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.freeze*eurToUsd}`,0)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.freeze*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>
						</template>
						
						
						<template v-if="curTab==2">
							<view 
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #AAA;font-size: 12px;">Importo non sottoscritto </view>
								<view>
									<view style="color: #fff;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.success_num_amount*1-item.freeze*1>0?item.success_num_amount*1-item.freeze*1:0}`,3)}}
										</template>
										<template v-else>
											
											{{`$ `+$util.formatUSD(`${(item.success_num_amount*1-item.freeze*1)>0?(item.success_num_amount*1-item.freeze*1):0}`,3)}}
										</template>
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										<template v-if="$util.isEur(item.goods.project_type_id)">
											{{`$ `+$util.formatUSD(`${(item.success_num_amount*1-item.freeze)*eurToUsd>0?(item.success_num_amount*1-item.freeze)*eurToUsd:0}`,3)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${(item.success_num_amount*1-item.freeze)*usdToEur>0?(item.success_num_amount*1-item.freeze)*usdToEur:0}`,3)}}
										</template>
									</view>
								</view>
							</view>
							
						</template>
						
						
						
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.SHENGOU_RIQI}}</view>
							<view style="color: #fff;">{{item.created_at}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.DINGDAN_HAO}}</view>
							<view style="color: #fff;">{{item.order_sn}}</view>
						</view>
					</view>
				</block>
			</template>
		</template>

		<u-modal :show="show" :title="$lang.TRADE_IPO_MODAL_TITLE" @cancel="cancel" @confirm="confirm()"
			:showCancelButton='true' :content='$lang.TRADE_IPO_MODAL_CONTENT' :cancelText="$lang.BTN_CANCEL"
			:confirmText="$lang.BTN_CONFIRM">
		</u-modal>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';

	export default {
		components: {
			HeaderSecond,
			EmptyData,
			TabsPrimary,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
				list: [],
				curId: '', // 当前选中数据的ID值
				show: false, // 购买前二次确认的弹层
				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
				recordList: [], // 申请记录
				successList: [], // 中签记录
			};
		},
		computed: {
			setList() {
				if (this.curTab == 0) return [];
				if (this.curTab > 0) {
					return this.curTab == 1 ? this.recordList : this.successList;
				}
			}
		},
		onShow() {
			this.changeTab(this.curTab);
		},
		onHide() {},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				this.getConfig(); // 每次重新请求汇率
				if (this.curTab == 0) this.getList();
				if (this.curTab == 1) this.getRecordList();
				if (this.curTab == 2) this.getSuccessList();
			},

			// 不跳页面，按钮弹层，二次确认购买
			handleBuy(val) {
				console.log('val:', val);
				this.curId = val;
				this.show = true;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase()
				this.show = false;
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.curId,
					// price: this.price
				})
				if (!result) return false;
				setTimeout(() => {
					this.changeTab(1);
				}, 1000)
			},

			async getList() {
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: this.curTab + 1, // 传参 1或2
				});
				if (!result) return false;
				this.list = result;
			},

			// 申请记录
			async getRecordList() {
				const result = await this.$http.get(`api/goods-shengou/user-order-log`);
				if (!result) return false;
				this.recordList = result;
			},
			// 申购成功
			async getSuccessList() {
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				if (!result) return false;
				this.successList = result;
			},
			// 
			// async subscription(item) {
			// 	const result = await this.$http.post(`api/goods-shengou/pay`, {
			// 		id: item.id
			// 	})
			// 	if (result.success == 0) {
			// 		setTimeout(() => {
			// 			this.$util.linkCustomerService();
			// 		}, 500)
			// 	} else {
			// 		this.changeTab(this.curTab);
			// 	}
			// },

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		}
	}
</script>