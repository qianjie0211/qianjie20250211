<!-- 新股配售 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-20 color-white flex-1">신주 청약</view>
		</view>
		<view class="flex" style="padding: 0px 50px; justify-content: space-between; ">
			<view class=" font-size-12 text-center" style="color: #fff;background-color: #1b0ec0;padding:10px 30px;border-radius: 30px;">거래내역</view>
			<view class=" font-size-12 text-center" style="color: #fff;background-color:#534ed0;padding:10px 30px;border-radius: 30px;" @click="jilu()">거래내역</view>
		</view>
		
		<view class="" style="margin-top: 30rpx;min-height: 30vh;padding: 12rpx;">
			<!-- <TradeHeader :title="``" icon="block_trade" @action="handlePayHistory()"></TradeHeader> -->
			<view style="margin-top: 10px;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<view style="padding: 0px 10px;">
				<view v-for="(item,index) in list" :key="index" class="sc_kxbg2"
					style="padding: 10px;border-radius: 10px;">
					<view class="display " style="margin: 20rpx 0;">
						
						<view class="flex">
							<view>
								<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
							</view>
							<view class="margin-left-10 flex-1">
								<view class="corporation">{{item.goods.name}}</view>
								<view style="color: #888;">{{item.goods.code}}</view>
							</view>
							<view class="purchase" @tap="purchase(item.id,item.peishou_price)">
								요청서
							</view>

						</view>
					</view>

					<view class="display">
						<view class="display flex">
							<view class="flex-1">
								발행 가격</view>
							<view>{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}/공유하다</view>
						</view>
						<view class="display flex margin-top-10">
							<view class="flex-1">
								배치 가격</view>
							<view>{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
import EmptyData from '@/components/EmptyData.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,EmptyData,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				options: {},
				list: [],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
			this.scramble()
		},

		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			jilu() {
				uni.navigateTo({
					url: '/pages/trade/saleLog'
				});
			},
			handlePayHistory(){
				return false;
			},
			// 기록 보관
			ration() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/ration'
				});
			},
			// 우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.list = list.data.data
				// console.log(this.funding, '99999999');
			},
		},
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 35rpx;
		font-weight: 600;
		color: #333;

	}

	.purchase {
		background-color: #1b0ec0;
		color: #fff;
		border-radius: 10rpx;
		padding: 10rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}
</style>