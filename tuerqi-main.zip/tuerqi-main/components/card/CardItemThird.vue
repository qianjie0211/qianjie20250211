<template>
	<view>
		<view style="">
			<view>
				<view style="display: flex;line-height: 1.1;">
					<view style="color:#fff;font-size: 32rpx;">
						{{labels[0]}}
					</view>
					<!-- <image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
						@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
					</image> -->
				</view>
				<view style="padding: 10px 0px;">
					<view style="font-size: 48rpx;font-weight: 500;line-height: 1.6; color: #000;background-color: #fff;border-radius: 5px;padding:0px 5px;font-size: 20px;">
						{{showAmount?$util.formatMoney(info.value1):hideAmount}}
					</view>
				</view>
				
			</view>
			<view class="flex flex-b">
				<view class="color-white">{{labels[1]}}</view>
				<view style="color: #fff;">{{showAmount?$util.formatMoney(info.value2):hideAmount}}</view>
			</view>
		</view>
		<!-- <view style="display: flex;align-items: center;font-size: 28rpx;margin-top: 10rpx;">
			<view style="flex:1 0 50%;">
				<view class="color-black">{{labels[1]}}</view>
				<view style="color: #be8450;">{{showAmount?$util.formatMoney(info.value2):hideAmount}}</view>
			</view>
			<view style="flex:1 0 50%;text-align: right;">
				<view class="color-black">{{labels[2]}}</view>
				<view style="color: #be8450;">{{showAmount?$util.formatMoney(info.value3):hideAmount}}</view>
			</view>
		</view> -->
	</view>
</template>

<script>
	export default {
		name: 'CardItemThird',
		props: {
			info: {
				type: Object,
				default: {}
			},
			// label。单独分开，否则会因数据请求慢，导致label未加载
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: true, // 显示金额
				hideAmount: '****', // 隐藏金额
			}
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
		}
	}
</script>

<style>
</style>