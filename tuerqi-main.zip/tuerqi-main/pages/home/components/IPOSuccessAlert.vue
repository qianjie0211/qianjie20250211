<template>
	<view class="mask" @click="handleClose()" v-if="isShow">
		<!-- <view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;" @click="handleClose()">
			<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
		</view> -->
		<view style="position: fixed;top:15vh;left: 50%;transform: translateX(-50%);">
			<view class="bg_ad" style="padding: 36px 20px;">
				<view style="font-size: 16px;font-weight: 900;color: #121212;padding-top: 40px;text-align: center;">
					Tebrikler, orijinal hisse senetlerine başarıyla abone oldunuz!
				</view>
				<!-- <image src="/static/dialog_icon.png" mode="aspectFit" :style="$theme.setImageSize(480,320)">
				</image> -->
				<view style="width: 98%;border-radius: 6px;text-align: center;padding:30px 0 0 0;margin-top: 0px;">
					<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
						{{info.name}}
					</view>
					<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
						Hisse Senedi Kodu:{{info.code}}
					</view>

					<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
						{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
					</view>
					<view
						style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
						<view>Abonelik Miktarı:</view>
						<text style="font-weight: 700;color:#ff3636;font-size: 16px;padding-left: 20px;">
							{{$util.formatNumber(info.success)}}</text>
					</view>
					<view
						style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
						<view>Abonelik Fiyatı:</view>
						<text style="font-weight: 700;color:#ff3636;font-size: 16px;padding-left: 20px;">
							{{$util.formatNumber(info.price)}}</text>
					</view>
					<view
						style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
						<view>Toplam Abonelik Tutarı:</view>
						<text
							style="font-weight: 700;color:#ff3636;font-size: 16px;padding-left: 20px;">{{$util.formatNumber(info.total)}}</text>
					</view>
					<view style="font-size: 12px;text-align: left;padding: 24px 0;">Karınızı garanti altına almak için, ödeme yapmadan önce hesabınızda yeterli bakiye bulunduğundan emin olun. Yatırımınızda başarılar dileriz!</view>
					<view
						style="padding: 10px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:10px 30px;"
						@click="isShow=false">Kapat</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'IPOSuccessAlert',
		data() {
			return {
				isShow: false,
				info: {}, // 
			}
		},
		beforeMount() {
			this.ipoSuccess();
		},
		methods: {
			// 弹层关闭
			handleClose() {
				this.isShow = false;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO + `?type=2`,
				})
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get(`api/goods-shengou/tanchuang`);
				if (!result) return false;
				console.log(result);
				if (result.length > 0) {
					this.info = {
						code: result[0].goods.code, // BAKAB
						name: result[0].goods.name, // Ambalaj
						success: result[0].success, // 100
						price: result[0].price, // 100
						total: result[0].success_num_amount, // success_num_amount
					};
					this.isShow = true;
				}
				// this.info = {
				// 	code: 'BAKAB',
				// 	name: 'Ambalaj', // 
				// 	success: 100, // 
				// 	price: 20,
				// 	total: 2000,
				// };
			},
		}
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		min-height: 50vh;
		width: 80vw;
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		align-items: center;
		border-radius: 20px;
		padding: 20px 0;
	}
</style>