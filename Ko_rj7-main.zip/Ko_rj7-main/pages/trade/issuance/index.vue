<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderSecond title="기관배정" :color="$theme.SECOND"></HeaderSecond> -->
		<view class="flex padding-20" style="background-color: #4644d1;">
			<view @click="fanhui()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
			</view>
			<view class="text-center flex-1 color-white bold font-size-16">기관배정</view>
		</view>
		
		<view style="position: relative;">
			<image src="/static/dz_bg.png" mode="widthFix" style="width: 100%;height: 130px;"></image>
		</view>
		
		<view style="padding:0px 10px;margin-top: -20px; position: absolute;width: 95%;">
			<view class="flex flex-b" style="background-color: #fff;padding:15px 80px;border-radius: 10px;border: 1px #33d669 solid;" >
				<view @click="changeTab(0)">
					<image src="/static/tb_oo.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">종목</view>
				</view>
				<!-- <view @click="changeTab(1)">
					<image src="/static/tb_qq.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">신청상태</view>
				</view> -->
				<view @click="changeTab(2)">
					<image src="/static/tb_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
					<view class="text-center font-size-12 margin-top-5">청약기록</view>
				</view>
			</view>
		</view>

		<!-- <TabsPrimary :tabs="$lang.TRADE_DAY_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary> -->

		<template v-if="curTab==0">
			<TradeIssuanceList @action="changeTab"></TradeIssuanceList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIssuanceLog></TradeIssuanceLog>
		</template>
		<template v-else>
			<TradeIssuanceSuccessLog></TradeIssuanceSuccessLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIssuanceList from './components/TradeIssuanceList.vue';
	import TradeIssuanceLog from './components/TradeIssuanceLog.vue';
	import TradeIssuanceSuccessLog from './components/TradeIssuanceSuccessLog.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIssuanceList,
			TradeIssuanceLog,
			TradeIssuanceSuccessLog,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
			fanhui(){
				uni.switchTab({
					url:'/pages/home/index'
				})
			},
		},
	}
</script>

<style>
</style>