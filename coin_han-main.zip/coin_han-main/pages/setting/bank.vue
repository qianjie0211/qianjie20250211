<template>
	<view class="">
		<u-navbar :title="i18n.addBank"></u-navbar>
		<view class="mx-30 mt-30 box-shadow  bg-black p-30 border-radius-20 text-white">
			<!-- 真实姓名 -->
			<view class="login-input-group mt-0">
				<text class="label">{{i18n.real_name}}</text>
				<input type="text" v-model="real_name" class="login-input">
			</view>

			<!-- 银行名称 -->
			<view class="login-input-group">
				<text class="label">{{i18n.bank_name}}</text>
				<input type="text" v-model="bank_name" class="login-input">
			</view>

			<!-- 开户省市 -->
			<view class="login-input-group">
				<text class="label">{{i18n.bank_dizhi}}</text>
				<input type="text" v-model="bank_dizhi" class="login-input">
			</view>

			<!-- 银行卡号 -->
			<view class="login-input-group">
				<text class="label">{{i18n.bank_account}}</text>
				<template v-if="isInput">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<input type="text" class="login-input" v-model="bank_account">
					</view>
				</template>
				<template v-else>
					<view style="display: flex;align-items: center;justify-content: space-between;"
						@click="handleInput()">
						<view class="login-input">{{maskString(bank_account)}}</view>
					</view>
				</template>
			</view>

			<!-- 地址 -->
			<!-- <view class="login-input-group">
				<text class="label">{{i18n.address}}</text>
				<input type="text" v-model="personal_address" class="login-input">
			</view> -->
		</view>
		<view class="m-30">
			<button class="warning-button py-0" @click="submit">{{$t("common.confirm")}}</button>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				real_name: '',
				bank_name: '',
				bank_account: '',
				bank_dizhi: '',
				alipay_account: '',
				wechat_nickname: '',
				wechat_account: '',
				isInput: false, // 
			};
		},
		onShow() {
			this.getCard()
		},
		methods: {
			handleInput() {
				this.isInput = true;
			},
			maskString(str) {
				// 格式化显示值逻辑
				if (!str || str.length <= 6) {
					return str; // 如果长度小于等于6，直接显示
				} else {
					const start = str.slice(0, 3); // 取前三位
					const end = str.slice(-3); // 取后三位
					return `${start}***${end}`; // 格式化后的值
				}
			},
			getCard() {
				this.$u.api.setting.getCard().then(({
					message
				}) => {
					this.real_name = message.real_name || '';
					this.bank_name = message.bank_name || '';
					this.bank_account = message.bank_account || '';
					this.bank_dizhi = message.bank_dizhi || '';
					this.alipay_account = message.alipay_account || '';
					this.wechat_account = message.wechat_account || '';
					this.wechat_nickname = message.wechat_nickname || '';
				})
			},
			submit() {
				let {
					i18n,
					real_name,
					bank_name,
					bank_account,
					bank_dizhi,
					alipay_account,
					wechat_account,
					wechat_nickname
				} = this;

				console.log(real_name, bank_name, bank_account, bank_dizhi);

				if (real_name.length > 0 && bank_name.length > 0 && bank_account.length > 0 && bank_dizhi.length > 0) {
					this.$u.api.setting.saveCard({
						real_name,
						bank_name,
						bank_account,
						bank_dizhi,
						alipay_account,
						wechat_account,
						wechat_nickname
					}).then(res => {
						this.$utils.showToast(res.message)
					})
				} else {
					this.$utils.showToast(i18n.allNeed)
				}
			},

		},
		computed: {
			i18n() {
				return this.$t("setting")
			},
		}
	}
</script>

<style lang="scss" scoped>

</style>