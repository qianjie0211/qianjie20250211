<!-- 用户基本信息 -->
<template>
	<view style="padding:0px 20rpx;margin-top: -45px;">
		<view class="" style="width: 100%;">
			<view style="width: 100%;justify-content: center;display: flex;">
				<image style="border-radius: 100px;background-color: #FFFFFF;" mode="scaleToFill" :src="avatar" :style="$theme.setImageSize(200)">
				</image>
			</view>
			<view style="width: 100%;line-height: 1.8;text-align: center;padding: 10px 0px;">
				<view class="flex">
					<view class="bold flex-1" style="padding:0 20rpx;font-size: 15px;">HI,{{info.nick_name}}</view>
				<!-- 	<image src="../../static/kefu_tbp.png" mode="widthFix" style="width: 25px;height: 25px;" @click="$util.linkCustomerService()"></image> -->
				</view>
				<view style="padding:0 20rpx;">
					<view style="font-size: 20rpx;color:#999;">
						ID : {{info.p_mobile}}
					</view>
				</view>
			</view>
		</view>
		<!-- <view style="padding: 20px 0px;">
			<view style="background-color:#FFFBEC;border-radius: 10px;padding: 8px;">
				<view class="flex flex-b">
					<image src="../../static/wd_tbs.png" mode="widthFix" style="width: 30px;"></image>
					<view class="bold font-size-12" style="color: #FED326;" v-if="info.is_check == 1"> 실명확인됨</view>
					<view class="bold font-size-12" style="color: #FED326;" v-if="info.is_check == -1">실명이 확인되지 않음</view>
				</view>
				<view class="flex">
					<view style="border-top: 4px #FED326 solid;width: 90%;border-radius: 30px;"></view>
					<view style="border: 4px #FED326 solid;border-radius: 30px;"></view>
					<view style="border-top: 4px #ccc solid;width: 10%;border-radius: 30px;"></view>
				</view>
			</view>
		</view> -->

		<view style="background-color: #FFFFFF;border-radius: 10px;">
			<view class="flex flex-b padding-20">
				<view>
					<view class="flex" style="width: 100%;justify-content: center;display: flex;">
						<view class="text-center hui1">총 자산</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
							@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
						</image>
					</view>
					<view class=" font-size-18 bold" style="color: #000;">
						{{showAmount?$util.formatMoney(info.totalZichan):hideAmount}}</view>
				</view>
				<view class="text-center">
					<view class="hui1">운용 자금</view>
					<view class="bold font-size-18">{{showAmount?$util.formatMoney(info.money):hideAmount}}</view>
				</view>
			</view>
			<view class="flex flex-b" style="background-color: #d7d7ff;padding: 10px 20px;border-radius: 5px;">
				<view class="hui1">총 평가금</view>
				<view class="bold" style="color: #f20206;">{{showAmount?$util.formatMoney(info.totalZichan-info.money):hideAmount}}</view>
			</view>
		<view>
			
			<view class="flex flex-b" style="padding: 20px 30px;">
				<view class="text-center" @click="$util.linkCustomerService()">
					<image src="/static/wd_xx.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
					<view>{{$lang.DEPOSIT_TITLE}}</view>
				</view>
				<view class="text-center" @click="linkWithdraw()">
					<image src="/static/wd_cc.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
					<view>{{$lang.WITHDRAW_TITLE}}</view>
				</view>
				<view class="text-center" @click="$util.linkCustomerService()">
					<image src="/static/wd_zz.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
					<view>고객센터</view>
				</view>
			</view>
			
			
		</view>

		<!-- <view style="align-items: center;background-image: url(/static/user_top.png);padding: 10px;background-size: cover;">
			<view class="flex">
				<view style="background-color: transparent;">
					<image style="border-radius: 100px;" mode="scaleToFill" :src="avatar" :style="$theme.setImageSize(100)">
					</image>
				</view>
				<view>
					<view style="display: flex;align-items: center;justify-content: center; padding:0 20rpx;">
						<view style="font-size: 32rpx;text-align: left;color:#121212;padding-right: 30rpx;">
							{{info.p_mobile}}
						</view>
					</view>
				</view>
			</view>
			
			
			<view style="display: flex;align-items: center;">
				<view class="flex flex-b" style="width: 100%; background-color: #CEB494;padding: 5px;border-radius: 10px;opacity: 0.7;">
					<view style="display: flex;align-items: center;line-height: 1.6;">
						<view style="color:#000;font-size: 32rpx;font-weight: 700;">
							총 자산
						</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
							@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
						</image>
					</view>
					<view style="font-size: 36rpx;font-weight: 700;line-height: 1.6;color: #be844f;">
						{{showAmount?$util.formatMoney(info.totalZichan):hideAmount}}
					</view>
				</view>
			</view>
		
			<view style="display: flex;align-items: center;font-size: 28rpx;padding: 5px;margin-top: 5px;">
				<view style="flex:1 0 50%;">
					<view style="color:#666666;">사용 가능한 금액</view>
					<view :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.money):hideAmount}}</view>
				</view> -->
		<!-- <view style="flex:1 0 50%;text-align: right;">
					<view style="color:#666666;">꼭 매달리게 하다</view>
					<view :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.freeze):hideAmount}}</view>
				</view> -->
	</view>
	</view>

	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: {
			info: {
				type: Object,
				default: {}
			},
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				is_check: '', // 默认未验证
				
			}
		},
		computed: {
			
			// 处理显示姓名或昵称
			showName() {
				return this.info.real_name ?
					this.info.real_name : this.info.nick_name ?
					this.info.nick_name : ''
			},
			// 处理显示头像
			avatar() {
				return this.info.avatar ? this.info.avatar : '/static/app_logo.png';
			},
		},

		methods: {
			// 进入信息修改页面
			handleLink() {
				// uni.navigateTo({
				// 	url: this.$paths.ACCOUNT_AVATAR,
				// })
			},
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
		}
	}
</script>

<style>

</style>