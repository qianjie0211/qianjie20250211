<template>
	<view>
		<view class="flex" style="padding: 30px 20px;">
			<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;" @click="$util.goBack()"></image>
			<view class="color-white font-size-16 flex-1 text-center">{{$lang.BIANJI_GERENZILIAO}}</view>
		</view>
		<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view>

		<view style="padding: 0px 20px;">
			<view class="color-white font-size-10 margin-bottom-10">{{$lang.SHEZHI_WODETOUXIANG}}</view>
			<!-- <image :src="userInfo.avatar?userInfo.avatar:'/static/logo.jpg'"  style="width: 50px;border-radius: 50%;height: 50px;" @click="selectImg"></image>border: 1px solid #16c0c1; -->
			<view style="border-radius: 100%;margin-bottom: 10px;background-color: #264543;"
				:style="$theme.setImageSize(120)">
				<u-avatar :src="userInfo.avatar" default-url="/static/avatar.png" size="60"
					@click="selectImg"></u-avatar>
			</view>
		</view>

		<view style="padding:20px;">
			<view class="color-white font-size-10">{{$lang.SHEZHI_WODENICHEN}}</view>
			<input :placeholder="$lang.QINGSHU_RUNICHEN"
				style="background-color: #202328;border: #31353a 1px solid;padding: 15px;margin-top: 10px;border-radius: 10px;font-size: 15px;color: #AEAEAE;"
				v-model="userInfo.nick_name" />
		</view>

		<view style="padding:5px 20px;">
			<view class="color-white font-size-10">{{$lang.YOUXIANG}}</view>
			<input placeholder=""
				style="background-color: #202328;border: #31353a 1px solid;padding: 15px;margin-top: 10px;border-radius: 10px;font-size: 15px;color: #AEAEAE;"
				disabled="" v-model="userInfo.mobile" />
		</view>

		<!-- <view style="padding:20px;">
			<view class="color-white font-size-10">{{$lang.SHOUJI_HAO}}</view>
			<input :placeholder="$lang.QINGSHU_RUYOUXIANGDIZHI" style="background-color: #1c1c1f;padding: 15px;margin-top: 10px;border-radius: 10px;font-size: 15px;" v-model="userInfo.email"/>
		</view>
		 -->
		<view class="color-white text-center"
			style="border-radius: 10px;background-color: #02b975;padding: 10px;margin: 30px 20px;" @click="xiugai">
			{{$lang.QUEREN}}
		</view>

	</view>
</template>

<script>
</script>

<script>
	import md5 from 'js-md5';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {

		data() {
			return {
				userInfo: ""
			}
		},
		onLoad() {
			this.getAccountInfo();
		},
		methods: {
			// 	//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			},
			async xiugai() {
				const result = await this.$http.post(`api/user/updateAvatar`, {
					avatar: this.userInfo.avatar,
					nick_name: this.userInfo.nick_name,
					email: this.userInfo.email,
				});
				console.log('info result：', result);
				if (!result) return false;

				uni.$u.toast('success');
				this.getAccountInfo()
			},
			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);


				this.upimg(imageFile.path)


			},
			// 上传图片
			async upimg(tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);

					this.userInfo.avatar = temp[0].url;

				}
				this.setStorageData();
			},
		},

	}
</script>