import Vue from 'vue';
// trade copy mock data
import {
	genRandomNumber,
	genDate24H,
	genWeekThree,
	genMonthOne,
	genMonthThree,
	genMonthSix,
	genYears,
} from '@/common/mock.js';



// generate charts 
// https://juejin.cn/post/7121733653121466405#heading-2

// 总收益， 面图 ChartTotalReturns
export const ChartDataTotalReturns = (val) => {
	console.log(`chart:`, val);
	let genData = [];
	for (let i = 0; i < 7; i++) {
		genData.push(genRandomNumber(1000, 99999, true));
	}
	console.log(`gendData:`, genData);

	const result = {
		categories: [],
		series: [{
			name: '', // 必须要有
			data: [],
			color: Vue.prototype.$theme.RISE,
		}]
	};
	switch (val) {
		case 0: // 7天
			result.categories = genWeekThree();
			result.series[0].data = [6474.34, 92164.99, 42104.09, 40378.34, 69950.01, 59278.02, 76651.38];
			break;

		case 1: //30天
			result.categories = genMonthOne();
			result.series[0].data = [1338.94, 62028.32, 10008.11, 57635.57, 48670.07, 49722.95, 92493.39];
			break;

		case 2: // 90天
			result.categories = genMonthThree();
			result.series[0].data = [48306.01, 36305.25, 2902.02, 36593.75, 15962.5, 81299.64, 95047.44];
			break;

		case 3: // 180 天
			result.categories = genMonthSix();
			result.series[0].data = [21942.2, 4345.76, 43800.54, 60618.42, 36694.27, 55897.5, 65963.45];
			break;

		case 4: // all
			result.categories = genYears();
			result.series[0].data = [5322.45, 63462.39, 22550.36, 46205.92, 21745.08, 77003.07, 90099.56];
			break;
	}

	return result;


	// return {
	// 	categories: genWeekThree(),
	// 	series: [{
	// 		name: '',
	// 		data: [6474.34, 92164.99, 42104.09, 40378.34, 69950.01, 59278.02, 76651.38],

	// 	}],
	// 	// series: [{
	// 	// 	name: '盈利',
	// 	// 	data: [13, 15, 17, 19],
	// 	// 	color: this.$theme.RISE,
	// 	// }, {
	// 	// 	name: '亏损',
	// 	// 	data: [31, 33, 35, 37, 39],
	// 	// 	color: this.$theme.FALL,
	// 	// }],
	// }
};

// 持仓时间 散点 Hold Profit And Loss "Scatter":


const temp3 = {
	"series": [{
		"name": "散点一",
		"data": [
			[10.0, 8.04],
			[8.07, 6.95],
			[13.0, 7.58],
			[9.05, 8.81],
			[11.0, 8.33],
			[14.0, 7.66],
			[13.4, 6.81],
			[10.0, 6.33],
			[14.0, 8.96],
			[12.5, 6.82]
		]
	}, {
		"name": "散点二",
		"data": [
			[9.15, 7.20],
			[11.5, 7.20],
			[3.03, 4.23],
			[12.2, 7.83],
			[2.02, 4.47],
			[1.05, 3.33],
			[4.05, 4.96],
			[6.03, 7.24],
			[12.0, 6.26],
			[12.0, 8.84],
			[7.08, 5.82],
			[5.02, 5.68]
		]
	}]
};

// 交易量  柱状图 Trading volume ChartTradeVolume

export const ChartDataTradeVolume = (val) => {
	console.log(`chart:`, val);
	let genData = [];
	for (let i = 0; i < 7; i++) {
		genData.push(genRandomNumber(1000, 99999, true));
	}
	console.log(`gendData:`, genData);

	const result = {
		categories: genWeekThree(),
		series: [{
			name: '', // 必须要有
			data: [11, 13, 15, 17, 19, 31, 33],
			color: Vue.prototype.$theme.RISE,
		}, {
			name: '', // 必须要有
			data: [18, 16, 14, 12, 10, 13, 17],
			color: Vue.prototype.$theme.RISE,
		}, {
			name: '', // 必须要有
			data: [11, 13, 15, 17, 19, 31, 33],
			color: Vue.prototype.$theme.RISE,
		}, {
			name: '', // 必须要有
			data: [18, 16, 14, 12, 10, 13, 57],
			color: Vue.prototype.$theme.RISE,
		}, {
			name: '', // 必须要有
			data: [11, 13, 15, 17, 19, 31, 33],
			color: Vue.prototype.$theme.RISE,
		}, {
			name: '', // 必须要有
			data: [18, 16, 14, 12, 10, 13, 17],
			color: Vue.prototype.$theme.RISE,
		}]
	};
	return result;

	// const result = {
	// 	categories: [],
	// 	series: [{
	// 		name: '', // 必须要有
	// 		data: [],
	// 		color: Vue.prototype.$theme.RISE,
	// 	}]
	// };
	// switch (val) {
	// 	case 0: // 7天
	// 		result.categories = genWeekThree();
	// 		result.series[0].data = [6474.34, 92164.99, 42104.09, 40378.34, 69950.01, 59278.02, 76651.38];
	// 		break;

	// 	case 1: //30天
	// 		result.categories = genMonthOne();
	// 		result.series[0].data = [1338.94, 62028.32, 10008.11, 57635.57, 48670.07, 49722.95, 92493.39];
	// 		break;

	// 	case 2: // 90天
	// 		result.categories = genMonthThree();
	// 		result.series[0].data = [48306.01, 36305.25, 2902.02, 36593.75, 15962.5, 81299.64, 95047.44];
	// 		break;

	// 	case 3: // 180 天
	// 		result.categories = genMonthSix();
	// 		result.series[0].data = [21942.2, 4345.76, 43800.54, 60618.42, 36694.27, 55897.5, 65963.45];
	// 		break;

	// 	case 4: // all
	// 		result.categories = genYears();
	// 		result.series[0].data = [5322.45, 63462.39, 22550.36, 46205.92, 21745.08, 77003.07, 90099.56];
	// 		break;
	// }

	// return result;

};

