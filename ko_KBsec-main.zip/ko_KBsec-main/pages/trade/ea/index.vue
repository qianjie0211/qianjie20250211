<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">스마트 주문</text>
			</view>
		</header>

		<view style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;
			justify-content:space-around;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in [`주문`,`구매내역`]" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#1C1C1C`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<!-- <template v-if="curTab ==0">
			<EaIntroduce></EaIntroduce>
		</template> -->

		<template v-if="curTab==0">
			<EaMarket></EaMarket>
		</template>
		<template v-else>
			<EaOrder></EaOrder>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import EaIntroduce from './components/EaIntroduce.vue';
	import EaMarket from './components/EaMarket.vue';
	import EaOrder from './components/EaOrder.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			EaIntroduce,
			EaMarket,
			EaOrder,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>