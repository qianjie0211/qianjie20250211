<template>
	<scroll-view :scroll-x="true" style="" scroll-left="10" @touchmove.stop>
		<template v-if="article && article.length>0">
		<view style="background-color: #fff;">
			<view class="flex padding-20">
				<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
				<view class="bold margin-left-5 flex-1">시장이슈</view>
			</view>
			<block v-for="(item,index) in article" :key="index">
				<view class="flex flex-b"
					style="padding: 5px 15px;border-bottom: 1px #ccc solid;"
					@click="open(item.url)">
					
					<view style="">
						<image :src="item.pic" mode="scaleToFill" style="border-radius:  20rpx;"
							:style="$theme.setImageSize(200,150)">
						</image>
					</view>
					<view style="width: 68%;"
						:style="{color:'#000'}">
						{{item.title}}
					</view>
					<!-- <view style="padding-right: 10px;color:#999;text-align: right;">
						{{item.created_at}}
					</view> -->
				</view>
			</block>
			</view>
		</template>
	</scroll-view>
</template>

<script>
	export default {
		name: 'MarketNewsTop',
		data() {
			return {
				article: []
			}
		},
		created() {
			this.getData();
		},
		methods: {
			open(url) {
				window.open(url)
			},
			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 13 ? val : val.slice(0, 10) + '...'
			},

			async getData() {
				const result = await this.$http.get(`api/goods/top1`);
				this.article = result.article || [];
			},
		}
	}
</script>