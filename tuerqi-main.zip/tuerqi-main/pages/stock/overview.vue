<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond :title="stockTitle" :color="$theme.SECOND"></HeaderSecond>

		<view style="padding-bottom: 20px;">
			<template v-if="stockInfo">
				<StockInfoPrimary :info="stockInfo"  ref="stockref"></StockInfoPrimary>

				<view class="common_block" style="padding:10px;box-shadow: none;">
					<!-- <TabsFourth :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"></TabsFourth> -->

					<view :style="{display:curTab==0?'block':'none' }" style="margin-top: 30rpx;">
						<view
							style="display: flex;align-items: center;justify-content: space-around;border-radius: 6rpx;">
							<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key="index">
								<view :style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
									{{item}}
								</view>
							</block>
						</view>
						<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
						</view>
					</view>

					<template v-if="curTab==0">
						<!-- <StockKline :code='code' :id='stockInfo.stock_id' :type="stockInfo.project_type_id" ref="stockLine">
					</StockKline> -->
						<view class="common_btn" @click="linkBuy" style="margin: 20rpx auto;background-color: #ff8600;">
							{{$lang.BTN_BUY}}
						</view>
					</template>

					<template v-if="curTab==1">
						<StockDetail :code='code' :id='stockInfo.stock_id'></StockDetail>
					</template>

					<template v-if="curTab==2">
						<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
					</template>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import StockDetail from './components/StockDetail.vue'
	import StockNews from './components/StockNews.vue';
	import StockInfoPrimary from './components/StockInfoPrimary.vue';

	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TabsFourth,
			StockDetail,
			StockNews,
			StockInfoPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 3, // 当前显示的Kline数据图标
				timer: null,
				kline_data:null,
				infos:[],
				isConnected: false, // 是否链接socket
				socket: null,
			};
		},
		computed: {
			stockTitle() {
				return this.stockInfo && this.stockInfo.name ?
					this.stockInfo.name : this.$lang.STOCK_OVERVIEW_TITLE
			}
		},

		onLoad(option) {
			this.code = option.code;
			this.product();
		},
		onShow() {
			this.isAnimat = true;
			console.log('stock onShow:', this.curTab)
			this.connect()
			if (this.curTab == 0) {
				this.onSetTimeout()
			}
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
			if (this.socket) this.disconnect();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
			if (this.socket) this.disconnect();
		},

		
		
		methods: {
			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			
			setStyle(val) {
				return {
					padding: `12rpx 32rpx`,
					borderRadius: `16rpx`,
					backgroundColor: val ? '#ff8600' : '#14102B1B',
					color: val ? '#fff' : '#000',
				}
			},
			changeTab(val) {
				this.clearTimer();
				console.log('val:', val);
				this.curTab = val;
				if (this.curTab == 0) {
					this.onSetTimeout();
				}
			},
			onSetTimeout() {
				// this.timer = setInterval(() => {
				// 	console.log("setInterval");
				// 	this.genKLineData();
				// }, 10000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				this.curKLine = val;
				this.product();
			},
			
			connect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
				console.log(5555555,this.$http.WS_Zonghe_URL);

				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});
			
					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					this.socket.onMessage((res) => {
						const datas = JSON.parse(res.data);
					
						// console.log(datas);


						if (this.stockInfo.pid == datas.pid && datas.last > 0) {
							console.log(`pid:`, this.stockInfo, datas);
							this.stockInfo.current_price = datas.last;
							this.stockInfo.rate = datas.pcp || 0;
							this.stockInfo.rate_num = datas.pc || 0;
							// }
							// // 	当前k线在分钟走势图，且当前回执数据type='kline'时， 执行以下逻辑
							// if (this.curKLine == 0 && data.type == "kline" && this.info.pid == data.pid) {
							console.log('data:', datas);
			
							// 获取图标上的数据
							const dataList = this.kLineChart.getDataList();
							// 数据数组的最后一个元素
							const lastData = dataList[dataList.length - 1];
							console.log(`lastData:`, lastData);
							// 建新数据
							const newData = {
								...lastData
							}
							// console.log('timestamp:', data.timestamp * 1000, newData.timestamp, data.timestamp *
							// 	1000 - newData.timestamp);
			
							newData.close = datas.last;
							newData.high = datas.high;
							newData.low = datas.low;
							// newData.volume = data.vol;
							newData.open = datas.low;
							// 当前ws时间戳 - 最后一个元素时间戳，>指定秒数，追加一根蜡烛
							if (datas.timestamp * 1000 - newData.timestamp > 60000)
								newData.timestamp = datas.timestamp * 1000;
							this.kLineChart.updateData(newData);
				
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			
			
			
			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: '#ff8600',
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#f4dfa5'
							}, {
								offset: 1,
								color: '#f2db9a',
							}]
						},
						bar: {
							upColor: '#228b22',
							downColor: '#f96405',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#228b22',
							downBorderColor: '#f96405',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#228b22',
							downWickColor: '#f96405',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},

			// 买入
			linkBuy() {
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?code=${this.code}`
				});
			},

			// 产品详情
			async product() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				console.log(result);
				if (!result) return false;
				this.stockInfo = result[0];
				// 延时,等DOM渲染
				setTimeout(() => {
					if (!this.kLineChart) {
						this.kLineChart = init('chart-type-k-line');
						this.kLineInit(); // 初始化Kline
					}
					this.genKLineData(); // 获取并生成KLine数据	
				}, 50);
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				console.log('k data:', result);
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "area" : "candle_solid",
					},
				});
				
				let leng=result.length-1;
				console.log(3333,result[leng]);
				
				this.infos.open=result[leng].open
				this.infos.close=result[leng].close
				this.infos.high=result[leng].high
				this.infos.low=result[leng].low
				this.infos.prev_close=result[leng-1].close
				this.$refs.stockref.openMsg(this.infos)
				
				this.kLineChart.setPriceVolumePrecision(2, 0)
				this.kLineChart.applyNewData(result)
			},
		},
	}
</script>