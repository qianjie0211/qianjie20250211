<template>
	<view>
		<view class="block">
			<view class="head">
				<img @click="$u.route({type:'navigateBack'});" :src="$icon.zjt" class="back">
				<view class="title left_in" style="margin-left: 0px;">AIアルゴリズム取引</view>
				<view class="back"></view>
			</view>
		</view>
		<view class="nav-box">
			<view class="nav-item" :class="inv==0?'active':''" @click="qiehuan(0)">株式</view>
			<view class="nav-item" :class="inv==1?'active':''" @click="qiehuan(1)">注文</view>
		</view>

		<!-- 韩国似乎没有EA介绍 -->
		<!-- <TabsPrimary :tabs="$lang.TRADE_EA_TABS.slice(1,3)" @action="changeTab" :acitve="curTab"></TabsPrimary> -->

		<!-- <template v-if="curTab ==0">
			<EaIntroduce></EaIntroduce>
		</template> -->

		<template v-if="inv==0">
			<EaMarket ref="liebiao"></EaMarket>
		</template>
		<template v-else>
			<EaOrder></EaOrder>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import EaIntroduce from './components/EaIntroduce.vue';
	import EaMarket from './components/EaMarket.vue';
	import EaOrder from './components/EaOrder.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			EaIntroduce,
			EaMarket,
			EaOrder,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				inv: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
			// this.$refs.liebiao.getlist()
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			qiehuan(num){
				this.inv=num;
				
			},
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>
<style type="text/css">
	@charset "UTF-8";

	/* uni.scss */
	.pop {
		background: #12132d;
		padding: 10px 10px 41px 10px
	}

	.pop .pop-title {
		height: 41px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-size: 14px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #fff
	}

	.pop .pop-list {
		height: 36px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-size: 14px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #a4a4af
	}

	.pop .pop-list span {
		font-size: 14px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #fff;
		padding-left: 15px
	}

	.pop .pop-num {
		height: 41px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-size: 14px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #a4a4af
	}

	.pop .pop-num uni-input {
		width: 100%;
		border: 0;
		background: #1f2039;
		height: 36px;
		line-height: 36px;
		padding: 0 10px;
		margin-left: 15px
	}

	.pop .pop-blue {
		height: 45px;
		background: #4c3d89;
		border-radius: 22px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-size: 16px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #fff;
		margin-top: 34px
	}

	.nav-box {
		height: 49px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
		background: #f7f9f8;
		box-sizing: border-box
	}

	.nav-box .nav-item {
		width: calc(50% - 22px);
		margin: 0 11px;
		height: 28px;
		background: #fff;
		border-radius: 5px;
		border: 1px solid #013f9c;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 500;
		font-size: 11px;
		color: #013f9c
	}

	.nav-box .active {
		background: #013f9c;
		color: #fff
	}


	.width-100 {
		width: 100%
	}

	.width-20 {
		width: 20%
	}

	.width-33 {
		width: 33.3333333333%
	}

	.btn-blue {
		background: #f0c680;
		border-radius: 26px
	}

	.uni-input-input {
		font-size: 14px;
		font-family: FZLanTingHeiT-R-GB;
		font-weight: 400;
		color: #fff
	}
</style>