<template>
	<view>
		<view class="flex padding-20" >
			<view @click="fanhui()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center">
				{{$lang.LOANS_DAIKUAN_CONTACT_US}}
				</view>
		</view>
		<view style="justify-content: center;display: flex;padding: 40px 0px;">
			<image src="/static/DK.png" mode="widthFix" style="width: 250px;"></image>
		</view>
		
		<view style="padding: 10px 20px;" @click="kefu()">
			<view class="flex" style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<image src="/static/kf.png" mode="widthFix" style="width: 25px;"></image>
				<view class="flex-1 margin-left-20">
					{{$lang.LOANS_DAIKUAN_CONTACT_US}}
					</view>
				<image src="/static/youjiantou.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view>
		
		<!-- <view style="padding:0px 20px;" @click="kefu()">
			<view class="flex" style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<image src="/static/feiji.png" mode="widthFix" style="width: 25px;"></image>
				<view class="flex-1 margin-left-20">Telegram</view>
				<image src="/static/youjiantou.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view>
		
		<view style="padding: 10px 20px;" @click="kefu()">
			<view class="flex" style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<image src="/static/wps.png" mode="widthFix" style="width: 25px;"></image>
				<view class="flex-1 margin-left-20">Whatsapp</view>
				<image src="/static/youjiantou.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view>
		
		<view style="padding:0px 20px;" @click="kefu()">
			<view class="flex" style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<image src="/static/zyuan.png" mode="widthFix" style="width: 25px;"></image>
				<view class="flex-1 margin-left-20">Loan Specialist</view>
				<image src="/static/youjiantou.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view>
		
		<view style="padding:10px 20px;" @click="kefu()">
			<view class="flex" style="background-color: #fff;padding: 20px;border-radius: 10px;">
				<image src="/static/zjia.png" mode="widthFix" style="width: 25px;"></image>
				<view class="flex-1 margin-left-20">Repayment Specialist</view>
				<image src="/static/youjiantou.png" mode="widthFix" style="width: 20px;"></image>
			</view>
		</view> -->
		
	</view>
</template>

<script>
export default {
		data() {
			return {
				
			}
		},
		methods: {
			kefu(){
				uni.navigateTo({
					url:'/pages/service'
				})
			},
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},
			
		}
	}
</script>

<style>
</style>