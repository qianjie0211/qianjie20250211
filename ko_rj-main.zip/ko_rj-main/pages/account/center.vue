<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`300px`)">
		<!-- <HeaderPrimary isSearch :color="$theme.SECOND"></HeaderPrimary> -->
		<header style="padding: 40rpx 40rpx 20rpx 20rpx;
		display: flex;
		align-items: center;justify-content: space-between;">
			<view style="flex: 0 10%">
				<!-- <image src="/static/logo.png" mode="widthFix" :style="$theme.setImageSize(60)"></image> -->
			</view>
			<view style="flex:1 0 50%; font-size: 36rpx;color: #0A2448;text-align: center;">
				{{$lang.TABBAR_ACCOUNT}}
			</view>
			<view style="margin-left:auto;">
				<image src="/static/search.svg" mode="widthFix" style="margin-right: 8px;"
					:style="$theme.setImageSize(40)" @click="linkSearch()"></image>
				<image src="/static/news.svg" mode="widthFix" :style="$theme.setImageSize(40)"
					@click="$util.linkCustomerService()"></image>
			</view>
		</header>
		<!-- <Profile :info="userInfo"></Profile> -->
		<view>
			<view></view>

		</view>

		<view style="display: flex;align-items: center; margin: 0px 16px; padding-top: 24px;">
			<view>
				<image :src="!userInfo||!userInfo.avatar?`../../static/avatar.png`:userInfo.avatar" mode="heightFix"
					:style="$theme.setImageSize(100)"></image>
			</view>
			<view style="padding-left: 16rpx;">
				<view style="font-size: 18px;font-weight: bold;">
					{{userInfo.nick_name}}
				</view>
				<view style="padding-top: 8px;font-size: 12px;font-weight:lighter;"
					:style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">
					{{userInfo.mobile}}
				</view>
			</view>
			<view style="margin-left: auto;">
				<image src="/static/dun.png" mode="heightFix" :style="$theme.setImageSize(200)"></image>
			</view>

		</view>

		<view
			style="margin: -4px 14px 14px 14px;background-color: white;border-radius: 6px;border: 1px solid #FB4735;box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">
			<view style="background-color: #F7FAFF;margin:16px;padding:16px;border-radius: 6px;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 12px;">
					<view :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">
						<text style="padding-right: 8px;"> 내 자산</text>
						<image :src="`/static/${showAmount?'show':'hide'}_dark.png`" @click="showAmount=!showAmount"
							mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
					</view>
					<view style="font-size: 20px;">{{ showAmount?$util.formatMoney( userInfo.money*1) :hideAmount }}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">가용 자금 </view>
						<view>{{showAmount?$util.formatMoney( userInfo.freeze*1) :hideAmount}}</view>
					</view>
					<view>
						<!-- <view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">인출 가능
						</view>
						<view style="text-align: right;">
							{{showAmount?$util.formatMoney( userInfo.holdYingli*1) :hideAmount}}
						</view> -->
						<view>
							<view :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">이익</view>
							<view>{{showAmount?$util.formatMoney( userInfo.totalYingli*1) :hideAmount}}</view>
						</view>
					</view>
				</view>

			<!-- 	<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">이익</view>
						<view>{{showAmount?$util.formatMoney( userInfo.totalYingli*1) :hideAmount}}</view>
					</view>
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">보유 자금
						</view>
						<view style="text-align: right;">
							{{showAmount?$util.formatMoney( userInfo.totalZichan*1) :hideAmount}}
						</view>
					</view>
				</view> -->



			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding:0px 16px 16px 16px;">
				<view
					style="background-color: #FF0000;width: 48%;line-height: 2.4;border-radius: 24px;text-align: center;font-size: 16px;color: white;"
					@click="linkService()()">
					송금</view>
				<view
					style="background-color: #1E90FF;width: 48%;line-height: 2.4;border-radius: 24px;text-align: center;font-size: 16px;color: white;"
					@click="linkWithdraw()">
					{{$lang.WITHDRAW_TITLE}}</view>
			</view>
			<view>
			</view>
		</view>

		<view
			style="display: flex;align-items: center;justify-content:space-between;flex-wrap: wrap;padding:12px 20px;">
			<view style="width:33.33%;text-align: center;padding-bottom: 20px;  " @click="linkAuth()">
				<view>
					<image src="/static/auth.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.AUTH_TITLE}}</view>
			</view>
			<view style="width: 33.33%;text-align: center;padding-bottom: 20px;" @click="linkpassword()">
				<view>
					<image src="/static/changepassword.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.CHANGE_PASSWORD}}</view>
			</view>
			<view style="width:33.33%;text-align: center;padding-bottom: 20px;" @click="linkaboutus()">
				<view>
					<image src="/static/aboutus.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.ABOUT_US_TITLE}}</view>
			</view>
			<view style="width:33.33%;text-align: center;" @click="linkService()">
				<view>
					<image src="/static/rechargehistory.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.DEPOSIT_TITLE_B}}</view>
			</view>
			<view style="width:33.33%;text-align: center;" @click="linkFlow(`withdraw`)">
				<view>
					<image src="/static/withdrawhistory.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.WITHDRAW_TITLE}}</view>
			</view>
			<view style="width:33.33%;text-align: center;" @click="linkService()">
				<view>
					<image src="/static/centerservice.svg" :style="$theme.setImageSize(80)">
					</image>
				</view>
				<view style="color: #0A2348;">{{$lang.ACCOUNT_SERVICE}}</view>
			</view>






		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding: 16px 16px;">
			<image mode="widthFix" src="/static/centerbanner.png" style="flex: 1;"></image>
		</view>

		<!-- 	<view style="display: flex;align-items: center;padding:20rpx 30rpx;" class="gap10">
			<view @click="linkDeposit()" class="flex-1 flex gap10 text-center justify-center" style="background-color: #fff7ee;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;margin-top: 10px;">
					<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 36rpx;color:#DA7437;font-weight: 700;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>
			
			
			<view @click="linkWithdraw()" class="flex-1 flex gap10 text-center justify-center" style="background-color: #fff7ee;border-radius: 10px;">
				<view style="align-items: center;justify-content: center;margin-top: 10px;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 36rpx;color:#DA7437;font-weight: 700;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			
		
		</view> -->



		<view style="margin:20rpx;border-radius: 32rpx 32rpx 0 0;">

			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view>
		</view>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemThird
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 跳转到 资金流水
			linkFlow(val) {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG + `?tag=${val}`
				})
			},

			// 搜索
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//修改密码
			linkpassword() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PASSWORD
				})
			},
			//关于我们
			linkaboutus() {
				uni.navigateTo({
					url: this.$paths.ABOUT_US
				})
			},
			//历史记录
			linkhistory() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>