<template>
	<view style="background-color: #000;">

		<HeaderPrimary :title="setToday" @action="handleProfile" @actinv="setinv" style="padding: 30px;"> </HeaderPrimary>
			
		<view style="padding: 0 10px;">
			<u-swiper :list="lunbo" style="border-radius: 7px;"></u-swiper>
		</view>	
		<!-- <view class="flex" style="border: 1px #488ce8 solid;border-radius: 20px;margin: 10px 50px;">
			<view class="text-center flex-1" style="padding: 10px;border-radius: 20px 0 20px 20px;" :style="inv==0?'background-color: #488ce8;':''" @click="inv=0">{{$lang.FOREX_TITLE}}</view>
			<view class="text-center flex-1" style="padding: 10px;border-radius: 0px 20px 20px 20px;" :style="inv==1?'background-color: #488ce8;':''" @click="inv=1">{{$lang.MARKET_INDEX_TAB_COIN}}</view>
		</view> -->
			
		<!-- <view class="flex flex-b padding-20 margin-top-10">
			<view @click="$u.route({url:'/pages/trade/block/index?type=1'});">
				<view class="text-center">
					<image src="/static/home/bi.png" mode="widthFix" style="width: 25px;height: 20px;"></image>
				</view>
				<view style="">{{$lang.TRADE_BLOCK_TITLE}}</view>
			</view>
			
			<view @click="$u.route({url:'/pages/trade/day/index?type=1'});">
				<view class="text-center">
					<image src="/static/home/GUPIAO.png" mode="widthFix" style="width: 25px;height: 20px;"></image>
				</view>
				<view>{{$lang.TRADE_DAY_TITLE}}</view>
			</view>
			
			<view @click="$u.route({url:'/pages/trade/ipo/index?type=1'});">
				<view class="text-center">
					<image src="/static/home/IPO.png" mode="widthFix" style="width: 25px;height: 20px;"></image>
				</view>
				<view style="">{{$lang.X_G_S_G}}</view>
			</view>
			<view @click="$u.route({url:'/pages/trade/copy/index'});">
				<view>
					<image src="/static/home/ETF.png" mode="widthFix" style="width: 25px;height: 20px;"></image>
				</view>
				<view style="">{{$lang.E_T_F}}</view>
			</view>
			
			<view @click="$u.route({url:'/pages/trade/kongtou/index'});">
				<view class="text-center">
					<image src="/static/home/IEO.png" mode="widthFix" style="width: 25px;height: 20px;"></image>
				</view>
				<view style="">{{$lang.K_T}}</view>
			</view>
		</view> -->

		<!-- <view>
			<NotifyPrimary ref="notify"></NotifyPrimary>
		</view> -->
		<view style="margin-top: 20px;">
			<ButtonGroup @action="handleProfile" :inv='inv'></ButtonGroup>
		</view>
		<view class="flex gap5" style="padding: 0px 10px 10px 10px;" v-if="inv==0">
			<view style="background-color: #1f1f1f;" class="radius10 flex-1 padding-10" v-for="(item,index) in zhishu">
				<view class="flex gap5">
					<view class="font-size-12">{{item.name}}</view>
					<view class="font-size-12" :style="$theme.setStockRiseFall(item.rate>0)">{{$util.formatPercentage(item.rate)}}</view>
				</view>
				<view class="margin-top-10 font-size-16" style="z-index: 9999;">{{item.current_price}}</view>
				<view>
					<image :src="item.rate>0?'/static/zhang.png':'/static/die.png'" mode="widthFix" style="width: 100%;height: 40px;"></image>
				</view>
			</view>
		</view>
		<view style="padding:0 10px;" v-if="inv==0">
			<!-- <image src="/static/banner-3.png" mode="widthFix" style="width: 100%;height: 90px;"></image> -->
		</view>

		<!-- <scroll-view class='scrollContainer' scroll-x>
			
			
			<view class='scrollitem' @click="$u.route({type:'switchTab',url:'/pages/market/index'});">
				<image class="scrollimage" :src="'/static/home/0.png'" mode="widthFix"></image>
			</view>
			<view class='scrollitem' @click="$u.route({type:'switchTab',url:'/pages/market/index'});">
				<image class="scrollimage" :src="'/static/home/1.png'" mode="widthFix"></image>
			</view>
			<view class='scrollitem' @click="$u.route({url:'/pages/coin/index'});">
				<image class="scrollimage" :src="'/static/home/2.png'" mode="widthFix"></image>
			</view>
		</scroll-view> -->
		<!-- <view style="margin:0 40rpx;">
			<TitlePrimary :title="$lang.MARKET_NEWS_TITLE">
				<view style="font-size: 13px;margin-left: auto;" @click="linkMarketNews()"
					:style="{color:$theme.SECOND}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view> -->
		
			<IPOSuccessAlert ref="tanchuang"></IPOSuccessAlert>





		<CoinList ref="coin" :inv='inv'></CoinList>

		<!-- account center modal -->
		<template v-if="isShowModal">
			<ProfileModal @action="handleClose"></ProfileModal>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from './components/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import NotifyPrimary from '../notify/components/NotifyPrimary.vue';
	import CoinList from './components/CoinList.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	// import Xau from './components/Xau.vue';
	import ProfileModal from '../profile/components/ProfileModal.vue';
	export default {
		components: {
			HeaderPrimary,
			ButtonGroup,
			NotifyPrimary,
			IPOSuccessAlert,
			CoinList,
			ProfileModal,
			// Xau,
		},
		data() {
			return {
				isAnimat: false, // 页面动画	
				// cardInfo: {}, // 资产卡
				isShowModal: false, // 显示账户信息
				inv:0,
				lunbo:[
					'/static/home/banner-1.png',
					'/static/home/banner-2.png',
					'/static/home/banner-3.png',
				],
				zhishu:''
			}
		},
		computed: {
			// cardLabels() {
			// 	return [this.$lang.CARD_ASSETS_TOTAL,
			// 		this.$lang.CARD_ASSETS_AVAIL,
			// 		this.$lang.CARD_ASSETS_FREEZE
			// 	]
			// },
			// 今日
			setToday() {
				return this.$util.formatToday(new Date());
			}
		},

		onLoad() {
			this.$util.setAppLang();
			this.$util.switchTabBar();
		},
		onShow() {
			// this.getAccountInfo();
			this.isAnimat = true;
			// console.log(this.cardLabels);
			if (this.$refs.coin) this.$refs.coin.getList();
			if(this.$refs.tanchuang) this.$refs.tanchuang.ipoSuccess();
			if (this.$refs.notify) this.$refs.notify.getList();
			uni.showTabBar(); // 显示tabBar
		},
		onReady() {
			this.getData()
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			async getData() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/top1`, {
					current: 0,
					stockid: this.stockId
				});
				console.log('getData:', result);
				if (!result) return false;
				this.zhishu = result.zhishu
				// this.article = result.article;
				// this.industryList = result.bottom;
			
				
			},
			setinv(index){
				this.inv=index;
				this.$forceUpdate()
			},
			// 打开 profile
			handleProfile(val) {
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowModal = true;
			},
			// 
			handleClose() {
				this.isShowModal = false;
				uni.showTabBar(); // 显示tabBar
			},

			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$CONSTANTS.MARKET_INDEX + `?type=0`,
				})
			},
		},
	}
</script>
<style>
	.scrollContainer {
		width: 100%;
		white-space: nowrap;
	}

	// 容器项
	.scrollitem {
		display: inline-block;
		margin-left: 20rpx;
		height: 234rpx;
	}
	.scrollitem:last-child {
		display: inline-block;
		margin-left: 20rpx;
		margin-right: 30rpx;
		height: 234rpx;
	}
	

	.scrollimage {
		width: 160px;
		height: 110px;
	}

	.recommandItemText {
		width: 270rpx;
		text-align: center;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}

	.EmptyData {
		text-align: center;
		margin-top: 50rpx;
	}
</style>