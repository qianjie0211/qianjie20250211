# coin_99
fork coin_baxi

coin_baxi 加入 以下功能

## trade/copy 
- UI调整完成
- API。暂时使用`跟单`的API数据。

## 外汇交易（Forex Trading）


# TODO:
总费用修改为：跟单交易记录（就是可以显示客户的每一笔跟单的交易记录）Copy trading history
30天获胜修改为：申请跟单结果，并且客户绑定成功之后，可以随时有按钮可以自行取消绑定
Subscription status


api/GentouEa/orderlist
api/GentouEa/sell