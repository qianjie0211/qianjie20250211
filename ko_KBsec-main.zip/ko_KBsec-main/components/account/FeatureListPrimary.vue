<template>
	<view style="display: flex;flex-wrap: wrap;justify-content: space-between;margin: 10rpx 0rpx;">
		<block v-for="(item,index) in list" :key="index">
			<view style="width: 50%;">
				<view
					style="display: flex;align-items: center;margin:10rpx;padding:20rpx 16rpx;border-radius: 8rpx;background-color: #F8F8F8;"
					@click="actionEvent(item,index)">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(80)"></image>
					<text style="font-size: 28rpx;color: #666666;padding:0 16rpx;">{{item.name}}</text>
					<view class="arrow" style="border-color: #666666;" :style="setStyle">
					</view>
				</view>
			</view>
		</block>
		<view style="width: 50%;">
			<view
				style="display: flex;align-items: center;margin:10rpx;padding:20rpx 16rpx;border-radius: 8rpx;background-color: #F8F8F8;"
				@click="signout()">
				<image mode="aspectFit" :src="`/static/account_sign_out.png`" :style="$theme.setImageSize(80)"></image>
				<text style="font-size: 28rpx;color: #666666;padding:0 16rpx;">{{$lang.BTN_SIMGN_OUT}}</text>
				<view class="arrow" style="border-color: #666666;" :style="setStyle">
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_AUTH
	} from '../../common/paths';
	export default {
		// 功能列表：一行一项 [icon title arrow] 支持RTL模式
		name: 'FeatureListPrimary',
		props: {
			code: {
				type: Number,
				default: 1
			}
		},
		data() {
			return {};
		},

		computed: {
			// 设置箭头的样式 兼容 RTL模式
			setStyle() {
				const temp = 'marginLeft';
				return {
					...this.$theme.setImageSize(12),
					[`${temp}`]: 'auto',
					transform: `rotate(${45 }deg)`,
				}
			},

			// 功能列表
			list() {
				const temp = this.$lang.ACCOUNT_AUTH_STATUS.map((item, index) => {
					return {
						name: item,
						url: this.$CONSTANTS.ACCOUNT_AUTH,
						icon: 'authentication',
						code: index == 0 ? -1 : index == 1 ? 0 : 2,
					}
				}).filter(item => item.code == this.code);
				console.log(temp);

				return [...temp, {
						name: this.$lang.SIGNIN_PASSWORD_TITLE,
						url: this.$CONSTANTS.ACCOUNT_PASSWORD,
						icon: 'account_signin_pwd',
						mode: 'link',
					},
					{
						name: this.$lang.BIND_BANK_CARD_TITLE,
						url: this.$CONSTANTS.ACCOUNT_BANK_CARD,
						icon: 'account_bank_card',
						mode: 'link',
					},
					{
						name: this.$lang.PAY_PASSWORD_TITLE,
						url: this.$CONSTANTS.ACCOUNT_PASSWORD + `?role=pay`,
						icon: 'account_pay_pwd',
						mode: 'link',
					}, {
						name: this.$lang.FLOW_INDEX_TITLE,
						url: this.$CONSTANTS.FLOW_INDEX,
						icon: 'account_capital_deatil',
						mode: 'link',
					},
					// {
					// 	name: this.$lang.AUTH_TITLE,
					// 	url: this.$CONSTANTS.ACCOUNT_AUTH,
					// 	icon: 'account_auth',
					// 	mode: 'link'
					// },
					// {
					// 	name: this.$lang.PRVITE_PACT_TITLE,
					// 	url: this.$CONSTANTS.PRVITE_PACT,
					// 	icon: 'account_pact',
					// 	mode: 'link',
					// },
					{
						name: this.$lang.ABOUT_US_TITLE,
						url: this.$CONSTANTS.ABOUTUS,
						icon: 'about',
						mode: 'link',
					},
				];
			},
		},

		methods: {
			actionEvent(item, index) {
				uni.navigateTo({
					url: item.url,
				})
			},
			signout() {
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version);
				} catch (e) {
					// error
				}
				uni.showToast({
					title: this.$lang.TIP_SIGN_OUT_SUCCESS,
					icon: 'success'
				})
				setTimeout(() => {
					uni.navigateTo({
						url: this.$CONSTANTS.ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>
</style>