<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		
		<HeaderSecond :title="$lang.DEPOSIT_TITLE" :color="$theme.SECOND"></HeaderSecond>
		

		<DepositPrimary></DepositPrimary>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import DepositPrimary from './components/DepositPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			DepositPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
	}
</script>