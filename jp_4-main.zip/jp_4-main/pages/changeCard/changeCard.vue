<!-- 绑定银行卡 -->
<template>
	<view >
		<CustomHeader :title="$t('index.gxqdxm')" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view class="bank-name">
				<view class="">銀行名: </view> <input placeholder="" v-model="value"> </input>
			</view>
			<view class="bank-name">
				<view class="">支店名: </view> <input placeholder="" v-model="value2"> </input>
			</view>
			<view class="bank-name">
				<view class="">支店番号: </view> <input placeholder="" v-model="value3"> </input>
			</view>
			<view class="bank-name">
				<view class="">取引種類: </view> <input placeholder="" v-model="value4"> </input>
			</view>
			<view class="bank-name">
				<view class="">口座名義:  </view> <input placeholder="" v-model="value5"> </input>
			</view>
			<view class="bank-name">
				<view class="">口座番号:</view> <input placeholder="" v-model="value6"> </input>
			</view>
			<view class="bank-name">
				<view class="">決済時用のパスワード設定: </view> <input placeholder="" v-model="value7"> </input>
			</view>
			<view class="bank-name">
				<view class="">決済時用のパスワード設定の再確認: </view> <input placeholder="" v-model="value8"> </input>
			</view>
			<view @click="replaceBank()" style="background-color:#4b5fcc; margin: 50rpx 30rpx;border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;">
				確認
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
				value6: '',
				value7: '',
				value8: '',

			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					
					bank_name: this.value,
					bank_sub_name: this.value2,
					zd_number: this.value3,
					qy_type: this.value4,
					realname: this.value5,
					card_sn: this.value6,
					pay_pass: this.value7,
					pay_pass1: this.value8,
					// realname: this.value,
					// bank_name: this.value2,
					// bank_sub_name: this.value3,
					// card_sn: this.value4,
					// qy_type: this.value5,
					// card_sn: this.value6,
					// realname: this.value7,
					// pay_pass: this.value8,
				})
				if (list.data.code == 0) {
					uni.$u.toast(this.$t('index.yhkcgtj'));
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		// font-weight: 700;
		display: flex;
		font-size: 28rpx;
		border-bottom: 2rpx solid #f4f4f4;

		view {
			width: 30%;
		}

		input {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>