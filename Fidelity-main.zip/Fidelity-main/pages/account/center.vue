<template>
	<view style="padding:40px 10px;">


		<view class="flex padding-10">
			<template v-if="userInfo">
				<u-avatar :src="userInfo.avatar" default-url='/static/logo.jpg' size="60"></u-avatar>
				<view class="color-white flex-1 margin-left-20">
					<view class="flex">
						<view class="font-size-18 bold" style="color: #10DF95;">{{userInfo.mobile}}</view>
						<image src="/static/jiahao.png" mode="widthFix" style="width: 12px;margin-left: 10px;"
							@click="bianji()"></image>
					</view>
					<view class="flex gap5">
						<image src="/static/anquan.png" mode="widthFix"
							style="width: 12px;height: 12px;text-align: center;"></image>
						<view class="font-size-10">{{curAuth}}</view>
					</view>
					<!-- <view class="flex">
					<view class="font-size-10" style="color: #5f5e62;">信用分:100</view>
					<view class="margin-left-10 font-size-12" style="color: #16c0c1;">{{$lang.FUZHI}}</view>
				</view> -->
				</view>

				<view>
					<image src="/static/yuyan.png" :style="$util.setImageSize(40)" @click="showLangList=true"
						style="margin-left:20px;"></image>
				</view>
			</template>
		</view>

		<view
			style="padding:10px;background-image: url(/static/info_bg.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat">
			<view>
				<image :src="showAmount?'/static/hide.png':'/static/show.png'" mode="widthFix" style="width: 20px;height: 20px;" @click="handleShowAmount"></image>
			</view>
			<view class="flex flex-b color-white margin-top-10">
				<view>{{$lang.ZHANGHU_YUE}}</view>
				<view>
					<view style="font-weight: 500;">
						{{showAmount?$util.formatMoney(`${userInfo.totalZichan}`,4):hideAmount}} €
					</view>
					<view style="font-weight: 500;">
						{{ showAmount?$util.formatUSD(userInfo.totalZichan*eurToUsd,4):hideAmount}} $
					</view>
				</view>

			</view>
			<view class="radius10 margin-top-10 text-center bold" style="background-color: #10df95;padding: 5px 10px;"
				@tap="linkDeposit()">
				{{$lang.CHONGZHI}}
			</view>
			
				<view class="flex flex-b color-white margin-top-10">
					<view>{{$lang.KEYONG,$lang.REBATES_TIP}}</view>
					<view>
						<view style="font-weight: 500;">
						
							{{showAmount?$util.formatMoney(`${assets[0].money}`,4):hideAmount}} €
						</view>
						<view style="font-weight: 500;">
							{{showAmount?$util.formatMoney(`${assets[0].money*eurToUsd}`,4):hideAmount}} $
						</view>
					</view>

				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>{{$lang.REBATES_TIP}}</view>
					<view>
						<view style="font-weight: 500;">
						
							{{showAmount?$util.formatMoney(`${assets[1].money}`,4):hideAmount}} €
						</view>
						<view style="font-weight: 500;">
							{{showAmount?$util.formatMoney(`${assets[1].money*eurToUsd}`,4):hideAmount}} $
						</view>
					</view>
				
				</view>
			

		</view>


		<view
			style="color:#FFF;background-color: #1a1e2a;border-radius: 6px;padding:15px;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(255, 255, 255, 0.25) 0px 0px 0px 1px;margin-top: 15px;">
			<view class="flex" @click="pwd()" style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/user/1.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GENGGAI_DENGLUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>

			<view class="flex margin-top-15" @click="zhifu()"
				style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/user/1.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GENGGAI_ZHIFUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>

			<view class="flex margin-top-15" @click="linkWithdraw()"
				style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/tb.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.TIKUAN}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>

			<view class="flex margin-top-15" @click="linkTrajiaoyi()"
				style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/user/2.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.JIAOYI_JILU}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>


			<view class="flex margin-top-15" @click="tixian()"
				style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/user/bangka.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GUANLI_TIXIANDIZHI}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>

			<view class="flex justify-between margin-top-15" @click="shiming()"
				style="border-bottom: 1px solid #dadbe2;padding-bottom: 15px;">
				<image src="/static/user/3.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1 margin-left-10">{{$lang.SHIMING_RENZHENG}}</view>
				<view class="margin-right-10 font-size-12" :style="setStyle()">
					<template v-if="userInfo">
						{{curAuth}}
					</template>
				</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>

			<view class="flex justify-between margin-top-10" @tap="$util.linkCustomerService()">
				<image src="/static/user/service.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view class="flex-1 margin-left-10">{{$lang.KEFU}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;"></image>
			</view>
		</view>

		<view class="flex flex justify-center"
			style="border-radius: 10px;background-color: #10df95;padding: 10px;margin: 10px 0;">
			<view class="margin-left-10" style="color: #000;" @click="handleSignOut()">{{$lang.TUICHU_DENGLU}}
			</view>
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="showLangList" :columns="[Object.values(langList)]" @change="changeLang"
			@cancel="showLangList=false" @confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL"
			:confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"
			keyName="lang" visibleItemCount="9"></u-picker>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import localize from '@/common/localize.js';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
		},
		data() {
			return {
				showLangList: false, // 是否显示语言选择器
				showAmount: true, // 显示金额
				yan_show: true,
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				selectedContent: 1,
				log_list: "",
				goods: "",
				info: "",
				assets: "",
				curTab: 0, //
				orderlist: "",
				order: "",

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
			}
		},
		computed: {
			langList() {
				return localize
			},
			curAuth() {
				if (this.userInfo) {
					console.log(`?`, this.userInfo);
					// 实名验证：-1未提交 0未审核  1通过 2未通过
					return [
						this.$lang.PROFILE_AUTH_UNSUBMIT,
						this.$lang.PROFILE_AUTH_UNAPPLY,
						this.$lang.PROFILE_AUTH_VERIFIED,
						this.$lang.PROFILE_AUTH_UNVERIFIED
					][!this.userInfo.is_check ? 0 : this.userInfo.is_check + 1]
				}
			},
		},
		onLoad(opt) {
			this.selectedContent = opt.tag && opt.tag.length > 0 ? 4 : this.selectedContent;
		},

		onShow() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo()
		},

		//下拉刷新
		onPullDownRefresh() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				this.showLangList = false;
				uni.setStorageSync('lang', e.value[0].code);
				this.$util.setLang();
				this.$util.switchTabBar();
				uni.reLaunch({
					url: this.$paths.LAUNCH,
				})
			},
			setStyle() {
				const temp = this.userInfo && this.userInfo.is_check == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			// gbp转 gbp_usd
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`config:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.curTab == 1) {
				// 	this.isHold = false;
				// } else {
				// 	this.isHold = true;
				// }
				// this.getList();
			},
			bianji() {
				uni.navigateTo({
					url: '/pages/Introduction/EditProfile'
				})
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw'
				})
			},
			linkDeposit() {
				uni.showToast({
					title: 'Per il deposito dei fondi, contatta il servizio clienti per ottenere il conto fiduciario.',
					icon:'none'
					})

			},
			huazhuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},

			linkTrajiaoyi() {
				uni.navigateTo({
					url: '/pages/account/tradeLog'
				})
			},

			linkService() {
				this.$util.linkCustomerService();
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			pwd() {
				uni.navigateTo({
					url: '/pages/account/pwd'
				})
			},
			zhifu() {
				uni.navigateTo({
					url: '/pages/Introduction/Paymentpwd'
				})
			},
			tixian() {
				uni.navigateTo({
					url: '/pages/account/bangkAdd'
				})
			},
			shiming() {
				uni.navigateTo({
					url: '/pages/Introduction/auth'
				})
			},
			yonghu() {
				uni.navigateTo({
					url: '/pages/about'
				})
			},
			yinshi() {
				uni.navigateTo({
					url: '/pages/account/pact'
				})
			},
			linkPassword(val = '') {
				this.handleClose();
				const temp = val.length > 0 ? `?role=${val}` : '';
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PASSWORD + temp
				});
			},

			// 登出
			handleSignOut() {
				uni.removeStorageSync('token');
				
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
				}, 500)
			},


			showContent(content) {
				this.selectedContent = content;
				this.getassets()

			},

			async getassets() {
				const result = await this.$http.get(`api/user/assets`, {
					type: 2
				});
				console.log('info result：', result);
				if (!result) return false;
				this.assets = result.filter(item => item.name != 'USD').slice(0, 2);

				// this.typelog();
			},

			// async typelog() {
			// 	const result = await this.$http.get(`api/user/typelog`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.log_list = result;
			// },

			// async getEafof() {
			// 	const result = await this.$http.get(`api/jijin/order`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.order = result;
			// },


			// async getGentouEa() {
			// 	const result = await this.$http.get(`api/Gentouea/orderlist`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.orderlist = result;
			// },

			// async getMoneychange() {
			// 	const result = await this.$http.get(`api/user/moneychange`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.info = result;
			// 	console.log(this.info.userlevel);
			// },


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>
<style>
	page {
		background-image: url(/static/user_bg.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		width: 100%;
	}
</style>