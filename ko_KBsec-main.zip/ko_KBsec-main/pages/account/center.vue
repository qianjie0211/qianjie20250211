<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #2E363B;min-height: 100vh;">
		<header class="header">
			<view class="left">
				<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<!-- <text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text> -->
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<Profile :info="userInfo"></Profile>

		<view style="display: flex;align-items: center;justify-content: space-between;padding:40rpx 90rpx;">
			<view @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFF;margin-top: 20rpx;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top5.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFF;margin-top: 20rpx;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<view @click="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top6.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFF;margin-top: 20rpx;">
					{{$lang.AUTH_TITLE}}
				</view>
			</view>

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top7.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFF;margin-top: 20rpx;">
					{{$lang.ACCOUNT_SERVICE}}
				</view>
			</view>
		</view>

		<view style="padding:24rpx 0;border-radius: 16rpx 16rpx 0 0;background-color: #EBEDF2;min-height:100vh;">

			<template v-if="info">
				<AssetsCard :info="info" />
			</template>


			<view style="margin:40rpx 36rpx;">
				<TitleThird :title="$lang.ACCOUNT_MORE_FEATURES"></TitleThird>

				<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

				<!-- <view style="margin-top: 60rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view> -->
			</view>

		</view>

	</view>
</template>

<script>
	import TitleThird from '@/components/title/TitleThird.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			TitleThird,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemPrimary
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				userInfo: {}, // 基本信息
				info: null, //
			}
		},
		computed: {
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			linkSearch() {
				uni.navigateTo({
					url: this.$CONSTANTS.SEARCH
				})
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$CONSTANTS.WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$CONSTANTS.DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$CONSTANTS.ACCOUNT_AUTH
				})
			},
			linkService() {
		       this.$util.linkCustomerService()	
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.info = {
					total: result.totalZichan * 1, // 总资产
					money: result.money * 1, // 可提
					freeze: result.frozen * 1, // 冻结
					totalProfit: result.totalYingli * 1, // 总盈利
					holdProfit: result.holdYingli * 1, // 持仓盈利
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>