<template>
	<view>
		<view class="flex" style="line-height: 3;background-color: #424242;margin: 6px 0;justify-content: space-between;border-radius: 6px;padding:  0  10px;">
			<view class="flex-1" style="font-size: 26rpx;">{{$lang.BORROW_TITLE}}</view>
			<view>100</view>
		</view>
		<block v-for="(item,index) in list" :key="index">
			<view style="display: flex;align-items: center;line-height: 3; background-color: #424242;margin: 6px 0;justify-content: space-between;border-radius: 6px;" @click="actionEvent(item)">
				<!-- <image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(40)"></image> -->
				<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">{{item.name}}</view>
				<image  src="/static/arrow_right.png" mode="aspectFit" style="margin-left: 10px;margin-right: 10px;"
					:style="$theme.setImageSize(20)"></image>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'ServiceList',

		computed: {
			list() {
				return [
					
					{
					name: this.$lang.DAI_KUAN,
					icon: `profile_5`,
					url: '/pages/Loans',
				}, 
				// {
				// 	name: this.$lang.Baipi,
				// 	icon: `profile_9`,
				// 	url: '/pages/whitePaper',
				// },
				{
					name: this.$lang.PROFILE_PACT,
					icon: `profile_6`,
					url: this.$CONSTANTS.PRVITE_PACT,
				}, {
					name: this.$lang.PROFILE_SHARE, 
					icon: `profile_7`,
					url: this.$CONSTANTS.SHARE,
				},
				// {
				// 	name: this.$lang.PROFILE_SERVICE,
				// 	icon: `profile_8`,
				// 	url: this.$CONSTANTS.SERVICE,
				// },
				{
					name: this.$lang.PROFILE_ABOUT,
					icon: `profile_9`,
					url: this.$CONSTANTS.ABOUT_US,
				}]
			}
		},
		methods: {
			actionEvent(item) {
				let url=item.url
				
				if (url.includes('service')) {
					this.$util.linkCustomerService();
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
					this.$emit(`action`, 1);
				} 
				
			},
		}
	}
</script>

<style>
</style>