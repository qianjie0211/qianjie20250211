<template>
	<view style="min-height: 100vh;background-color: #010101;">
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx; " v-if="!top_show">
			<view class="" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<text class="flex-1 text-center" style="color:#fff;">{{$lang.TRADE_COPY_TITLE}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$theme.setImageSize(40)"></image>
			</view>
		</view>
		<header style="padding-top: 60rpx;" v-if="top_show">
			<view class="left" @click="$u.route({type:'switchTab',url:'/pages/home/index'});"
				style="position: absolute;top: 75rpx;left: 5px;">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view style="margin-left: 30px;">
				<scroll-view :scroll-x="true" style="white-space: nowrap;" :scroll-left="300" @touchmove.stop
					:scroll-with-animation="true">
					<view style="display: flex;margin:0 10rpx;" class="align-center">


						<block v-for="(item,index) in $util.TABS()" :key='index'>
							<view :style="$util.setStyle1(3 ==index)" @click="$util.changeTab1(item.url)">
								{{item.value}}
							</view>
						</block>
					</view>
				</scroll-view>
			</view>

		</header>


		<view style="padding: 0px 15px;padding-bottom: 200rpx;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;background-color: #1c1c1c;margin:30rpx 0;border-radius:24rpx;">
						<!-- <view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;color:#121212;font-size: 36rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
							<view style="font-size: 16px;line-height: 1.2;margin-right: 20px;">{{item.name}}</view>
							<view
								style="color:#09bdab;font-size: 28rpx;background-color: #1677e7;padding: 3px 0;border-radius: 8px;color: #fff;min-width: 60px;text-align: center; "
								@click="handleInfo(item)">{{$lang.BTN_BUY}}</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding: 10px 0px;">
							<view style="color:#CCC;">{{$lang.FUNDS_PERIOD}}</view>
							<view style="color:#CCC;font-size: 28rpx;">{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}
							</view>
						</view>

						<view class="flex"
							style="border: 2px #97bcd1 solid;border-radius: 10px;background: linear-gradient(-50deg, white 50%, #1678e7 50%);">
							<view
								style="align-items: center;justify-content: space-between;line-height: 1.5;padding: 0px 40px;">
								<view class="text-center" style="color:#fff;">{{$util.formatCoin(item.min_price)}}
								</view>
								<view class="text-center" style="color:#fff;font-size: 28rpx;">
									{{$lang.LICAI_ZUIDIMAIRU}}
								</view>
							</view>
							<view
								style="align-items: center;justify-content: space-between;line-height: 1.5;margin-left: 50px;">
								<view class="text-center" style="color:#666666;">{{$util.formatPercentage(item.fudu)}}</view>
								<view class="text-center" style="color:#333333;font-size: 28rpx;">{{$lang.FUNDS_RATE}}
								</view>
							</view>
						</view>

					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<WealthBuy :info="detail" @action="handleClose"></WealthBuy>
		</template>

		<view style="height: 200rpx;"></view>
		<FooterSmall code="stock" />
	</view>
</template>

<script>
	import WealthBuy from './components/WealthBuy.vue';
	export default {
		components: {

			WealthBuy,
		},
		data() {
			return {
				list: [],
				isShow: false,
				detail: {}, // 选中一条数据
				top_show: false
			};
		},
		computed: {},
		onShow() {
			this.getList();
		},
		onLoad(op) {
			if (op.type) {
				this.type = op.type
			}
			if (op.top1 == 1) {
				this.top_show = true
			}
		},
		methods: {
			linkDesc() {
				uni.navigateTo({
					url: this.$CONSTANTS.LEVEL_DESC
				})
			},

			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose(val) {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.detail = item;
				this.isShow = true;
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			}
		}
	}
</script>

<style>
	.gradient-background {
		width: 100%;
		/* 可根据需要调整宽度 */
		height: 300px;
		/* 可根据需要调整高度 */
		background: linear-gradient(-135deg, white 50%, blue 50%);
		/* 使用斜切渐变 */
	}
</style>