<template>
	<view style="background-color: #fff;min-height: 100vh;margin-top: 90px;">
		<view style="padding: 10px;">
			<template v-if="!list|| list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="margin:20rpx 10rpx;padding: 20rpx;border-radius: 10px;border: 1px #34d66a solid;" @click="handleDetail(item)">
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<view style="">
								<view class="bold" style="font-size: 30rpx;color:#121212;">
									{{item.name}}
								</view>
								
							</view>
							<!-- <view class="common_btn" @click="handleDetail(item)"
								style="padding:4rpx 16rpx;margin:0;font-size: 24rpx;">
								购买
							</view> -->
						</view>
						<view class="flex">
							<view class="flex-1 hui1">수익률</view>
							<view class="bold">{{item.syl+' '+ '%'}}</view>
						</view>
						<view class="flex">
							<view class="flex-1 hui1">주기</view>
							<view class="bold">{{item.zhouqi+' '+'Day'}}</view>
						</view>
						<view class="flex">
							<view class="flex-1 hui1">최소 구매 금액</view>
							<view class="bold">{{item.min_price}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<template v-if="isShow">
			<EaBuy :info="itemInfo" @action="handleClose"></EaBuy>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import EaBuy from './EaBuy.vue';
	export default {
		name: 'EaMarket',
		components: {
			EmptyData,
			EaBuy,
		},
		data() {
			return {
				list: [],
				jj_list:[],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleDetail(val) {
				console.log('val:', val);
				this.isShow = true;
				this.itemInfo = val;
				// this.curId = val;
				// this.show = true;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/jijin/list`);
				console.log(result,55558555);
				this.list = result.jj_list;
			},
		}
	}
</script>

<style>
</style>