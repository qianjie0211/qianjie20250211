<template>
	<view>
		<template v-if="logo && logo != ''">
			<image :src="setLogo" mode="aspectFit" :style="$theme.setImageSize(size)" style="border-radius:100%;">
			</image>
		</template>
		<template v-else>
			<!-- line-height: 80rpx; -->
			<view :style="{lineHeight:size+`rpx`, ...$theme.setImageSize(size)}"
				style="background-color:#3d8337;text-align: center;color: #FFFFFF;border-radius: 100%;font-size: 16px;">
				{{setLogo}}
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'CustomLogo',
		props: {
			logo: {
				type: String,
				default: '',
			},
			// 股票名字，用于切出第一个字符作为LOGO
			name: {
				type: String,
				default: '',
			},
			size: {
				type: Number,
				default: 80
			}
		},
		computed: {
			setLogo() {
				if (this.logo && this.logo != '') {
					return this.$util.setLogo(this.logo);
				} else {
					return this.name && this.name.length > 0 ? this.name[0] : '';
				}
			},
		}
	}
</script>

<style>
</style>