<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="border-bottom: 1px solid #E5E5E5;padding-top: 28rpx;box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;padding: 15px;font-size: 14px;">
					<view style="display: flex;align-items: center;line-height: 1.8;margin-top: 10px;" class="gap10">
						<!-- <template v-if="item.status==2">
							<view :style="setStyle()" @click="subscription(item.id)">{{$lang.TRADE_IPO_SUCCESS_SUB}}
							</view>
						</template> -->
						<view class="bold">{{item.goods.name}}</view>
					</view>

					<view class="flex flex-b" style="margin-top: 10px;">
						<view>申込単価</view>
						<view>{{$util.formatMoney(item.price)}}</view>
					</view>
					<view class="flex flex-b" style="margin-top: 10px;">
						<view>申込株数</view>
						<view>{{$util.formatMoney(item.success)}}</view>
					</view>

					<view class="flex flex-b" style="margin-top: 10px;">
						<view>購入金額合計</view>
						<view>{{$util.formatMoney(item.success_num_amount/item.double)}}</view>
					</view>
					<view class="flex flex-b" style="margin-top: 10px;">
						<view>現在の資金残高</view>
						<view>{{available}}</view>
					</view>
					<view class="flex flex-b" style="margin-top: 10px;">
						<view>資金補填締切日</view>
						<view>{{item.online_date}}</view>
					</view>
					<view class="flex flex-b" style="margin-top: 10px;">
						<view>確定額</view>
						<view>{{$util.formatMoney(item.freeze)}}</view>
					</view>
					<view class="flex flex-b" style="margin-top: 10px;">
						<view style="flex: 30%;">不足額</view>
						<view style="color: #ec4d78;flex: 30%;">
							{{$util.formatMoney(item.success_num_amount-item.freeze)}}</view>
						<view v-if="item.status==2"
							style="background-color: #013f9c;padding: 3px 5px;color: #fff;border-radius: 5px;"
							@click="subscription(item.id)">追納</view>
					</view>

					<view class="" style="margin-top: 10px;font-size: 10px;">
						<view>提示:</view>
						<view>購入を完了するには、以下の方法で不足額を補填してください。</view>
						<view>資金補填後、再度以下のボタンをクリックして購入を完了してください。</view>
					</view>

					<view class="flex flex-b" style="margin-top: 10px;">
						<view>注文番号</view>
						<view>{{item.order_sn}}</view>
					</view>

					<view class="flex flex-b" style="margin-top: 10px;">
						<view>{{$lang.TRADE_IPO_SUCCESS_CT}}</view>
						<view>{{item.created_at}}</view>
					</view>

				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'SuccessRecord',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				available: 0,
			};
		},
		created(option) {
			this.getList()
			this.getAccountInfo()
		},
		methods: {
			setStyle() {
				return {
					...this.$theme.LG_PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `8rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},


			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				console.log(result);
				this.list = result || [];
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.available = this.$util.formatMoney(result.money) || 0;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},

			async subscription(id) {
				const result = await this.$http.post(`api/goods-shengou/renjiao`, {
					id
				});
				console.log('result:', result);
				if (result.code == 0) {
					uni.$u.toast(result.message);

				} else {
					uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				}
				this.getList();
			},
		},
	}
</script>