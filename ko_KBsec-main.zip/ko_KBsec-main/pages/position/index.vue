<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<!-- <header class="header">
			<view class="left">
				<image src="/static/logo_name.png" mode="aspectFit" :style="$theme.setImageSize(220,60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text>
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header> -->

		<view style="height: 24px;"></view>
		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?'#121212':`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<template v-if="info">
				<AssetsCard :info="info" />
			</template>

			<view style="margin:36rpx;">
				<TitleThird :title="$lang.TRADE_TITLE">
					<view style="font-size: 13px;margin-left: auto;" @click="changeTab(1)"
						:style="{color:$theme.PRIMARY}">
						{{$lang.MORE}}
						<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
					</view>
				</TitleThird>
			</view>
		</template>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<!-- 持仓与历史 共用 -->
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<!-- border-radius: 8rpx;margin:0 20rpx 20rpx 20rpx; -->
				<view @tap="handleShowModal(item)" class="common_block" style="padding:20rpx 36rpx;line-height: 1.6;">
					<view :style="{color:$theme.LOG_VALUE}" style="font-size: 28rpx;line-height: 1.6;font-weight: 700;">
						{{item.name}}
					</view>
					<view style="display: flex;align-items: center;line-height: 1.4;">
						<view style="flex: 1 0 40%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{item.status==1? $lang.TRADE_HOLD_LABEL_PROFIT_RATE
									:$lang.TRADE_SELL_LABEL_PROFIT_RATE}}
								</view>
								<template v-if="item.status==1">
									<view :style="$theme.setStockRiseFall(item.buyProfitRate*1>0)">
										{{$util.formatNumber(item.buyProfitRate)}}%
									</view>
								</template>
								<template v-if="item.status==2">
									<view :style="$theme.setStockRiseFall(item.sellProfitRate*1>0)">
										{{$util.formatNumber(item.sellProfitRate)}}%
									</view>
								</template>
							</view>
						</view>
						<view style="flex:1 0 6%;"></view>
						<view style="flex: 1 0 54%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<template v-if="item.status==1">
									<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
										{{$lang.TRADE_MODAL_YINGKUI}}
									</view>
									<view :style="$theme.setStockRiseFall(item.buyFloatProfit*1>0)">
										{{(item.buyFloatProfit*1>0?'+':'')+`${$util.formatNumber(item.buyFloatProfit)} ${$lang.CURRENCY_UNIT}`}}
									</view>
								</template>
								<template v-if="item.status==2">
									<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
										{{$lang.TRADE_SELL_LABEL_PROFIT_AMOUNT}}
									</view>
									<view :style="$theme.setStockRiseFall(item.sellProfitRate*1>0)">
										{{(item.sellProfit*1>0?'+':'')+`${$util.formatNumber(item.sellProfit)} ${$lang.CURRENCY_UNIT}`}}
									</view>
								</template>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;line-height: 1.4;">
						<view style="flex: 1 0 40%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_HOLD_LABEL_BUY_AMOUNT}}
								</view>
								<text :style="{color:$theme.LOG_VALUE}">
									{{$util.formatNumber(item.buyQTY)+` ${$lang.QUANTITY_UNIT}`}}</text>
							</view>
						</view>
						<view style="flex:1 0 6%;"></view>
						<view style="flex: 1 0 54%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_HOLD_LABEL_TOTAL_PRICE}}
								</view>
								<view :style="{color:$theme.LOG_VALUE}">
									<template v-if="item.status==1">
										{{$util.formatNumber(item.buyTotal)+` ${$lang.CURRENCY_UNIT}`}}
									</template>
									<template v-if="item.status==2">
										{{$util.formatNumber(item.sellTotal)+` ${$lang.CURRENCY_UNIT}`}}
									</template>
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;line-height: 1.4;">
						<view style="flex: 1 0 40%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_HOLD_LABEL_BUY_PRICE}}
								</view>
								<view :style="{color:$theme.LOG_VALUE}">
									{{$util.formatNumber(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
								</view>
							</view>
						</view>
						<view style="flex:1 0 6%;"></view>
						<view style="flex: 1 0 54%;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{item.status==1?$lang.TRADE_HOLD_LABEL_CUR_PRICE:$lang.TRADE_SELL_LABEL_SELL_PRICE}}
								</view>
								<template v-if="item.status==1">
									<view :style="{color:$theme.LOG_VALUE}">
										{{$util.formatNumber(item.currentPrice)+` ${$lang.CURRENCY_UNIT}`}}
									</view>
								</template>
								<template v-if="item.status==2">
									<view :style="{color:$theme.LOG_VALUE}">
										{{$util.formatNumber(item.sellPrice)+` ${$lang.CURRENCY_UNIT}`}}
									</view>
								</template>
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>

		<!-- 弹层 -->
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;padding-bottom: 80rpx;">
				<view class="popup_header"
					style="display: flex;align-items: center;justify-content:space-between;background-color: #38AA9A;">
					<text :style="{color:$theme.STOCK_NAME}"
						style="font-size: 36rpx;text-align: center;flex:1 0 90%;">{{detail.name}}</text>
					<image src="/static/close.png" :style="$theme.setImageSize(40)" @click="handleClose()"></image>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_TIME}}</view>
					<view :style="{color:$theme.LOG_VALUE}">{{detail.buyCT}}</view>
				</view>
				<template v-if="detail.status==2">
					<view class="item">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_SELL_TIME}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{detail.sellCT}}
						</view>
					</view>
				</template>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FLOAT_PROFIT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyFloatProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellFloatProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>

				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_PROFIT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellProfit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_PRICE}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}
					</view>
				</view>

				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_QTY}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyQTY)+` ${$lang.QUANTITY_UNIT}`}}
					</view>
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LEVER}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{detail.lever}}
					</view>
				</view>
				<view class="item">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FEE}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="detail.status==1">
							{{$util.formatNumber(detail.buyFee)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
						<template v-if="detail.status==2">
							{{$util.formatNumber(detail.sellFee)+` ${$lang.CURRENCY_UNIT}`}}
						</template>
					</view>
				</view>
				<view class="item">
					<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_BUY_AMOUNT}}
					</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(detail.buyAmont)+` ${$lang.CURRENCY_UNIT}`}}
					</view>
				</view>
				<template v-if="detail.status==1">
					<view style="display: flex;justify-content: space-around;margin:30rpx 60rpx;">
						<view class="common_btn" style="margin:24rpx;width: 80%;border:1px solid #1C1C1C;color:#1C1C1C;"
							@tap="linkStockInfo(detail.code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="common_btn"
							style="margin:24rpx;width: 80%;border:1px solid #1C1C1C;background-color: #1C1C1C;color:#FFF;"
							@tap.stop="handleSell(detail.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</template>
			</view>
		</template>

	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import TitleThird from '@/components/title/TitleThird.vue';

	export default {
		components: {
			EmptyData,
			TitleThird,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				userInfo: {},
				isMask: null, // 掩码
				info: null, //
				hideValue: '****', // 隐藏金额
				list: [],
				curPage: 1, // 当前页码
				maxPage: 1, // 最大页码
				isShow: false, // 是否显示弹层
				detail: null, // 单条数据详情
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
			this.isMask = uni.getStorageSync('mask');
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		// 觸底加載
		onReachBottom() {
			console.log(`onReachBottom`)
			if (this.curPage < this.maxPage) {
				this.curPage++;
				this.getList();
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo();
			this.curPage = 1;
			this.list = [];
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				this.curPage = 1;
				this.list = [];
				this.getList();
			},
			handleShowModal(item) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.detail = item;
				console.log(this.detail);

			},
			// 关闭弹层
			handleClose() {
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	
			},
			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id
				});
				console.log(result);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	
				this.curPage = 1;
				this.list = [];
				this.curTab = 2;
				this.changeTab(this.curTab);
			},

			// 跳转到股票详情
			linkStockInfo(code) {
				this.handleClose();
				uni.navigateTo({
					url: `${this.$CONSTANTS.STOCK_OVERVIEW}?code=${code}`
				});
			},
			// 获取持有及历史数据
			async getList() {
				console.log(`curPage:`, this.curPage);
				const result = await this.$http.post(`api/user/order`, {
					page: this.curPage,
					status: this.curTab == 2 ? 2 : 1, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				console.log(`list result:`, result);
				this.maxPage = result.last_page; // 記錄最大頁碼
				let filterData = [];
				if (this.curTab == 0 || this.curTab == 1) {
					filterData = result.data.filter(item => item.goods_info && item.order_buy);
				} else {
					filterData = result.data.filter(item => item.goods_info && item.order_buy && item.order_sell);
				}
				console.log(`filterData`, filterData);
				const temp = filterData.map(item => {
					return {
						id: item.id,
						typeId: item.goods_info.project_type_id,
						code: item.goods_info.number_code,
						status: item.status, // 1买 2卖
						name: item.goods_info.name, // 名称
						// 持仓盈利率 =（最终价 - 买入价） / 买入价 *100%
						buyProfitRate: ((item.goods_info.current_price * 1 - item.order_buy.price * 1) /
							(item.order_buy.price * 1) * 100).toFixed(2) * 1,
						// 卖出盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% 
						sellProfitRate: item.status == 2 ? ((item.order_sell.price * 1 - item.order_buy
							.price * 1) / item.order_buy.price * 100).toFixed(2) * 1 : '',
						buyPrice: item.order_buy.price, // 买入价
						sellPrice: item.status == 2 ? item.order_sell.price : '', // 卖出价
						currentPrice: item.goods_info.current_price, // 最新价
						buyQTY: item.order_buy.num, // 买入数量
						sellQTY: item.status == 2 ? item.order_sell.num : '', // 卖出数量
						buyProfit: item.order_buy.yingkui * 1, // 买入盈亏额
						sellProfit: item.status == 2 ? item.order_sell.yingkui : '', // 卖出盈亏额
						buyAmont: item.order_buy.amount,
						lastPrice: item.goods_info.last_price,
						// 个股买入总金额
						buyTotal: item.order_buy.num * 1 * (item.order_buy.price * 1),
						// 个股卖出总金额
						sellTotal: item.status == 2 ? item.order_sell.num * 1 * (item.order_buy.price * 1) :
							'',
						buyFee: item.order_buy.buy_fee, // 买入手续费
						sellFee: item.status == 2 ? item.order_sell.sell_fee : '', // 卖出手续费
						lever: item.order_buy.double, // 杠杆
						buyCT: item.order_buy.created_at, // 买入时间
						sellCT: item.status == 2 ? item.order_sell.created_at : '', // 卖出时间
						buyFloatProfit: item.order_buy.float_yingkui * 1, // 买入浮动盈亏
						// 卖出浮动盈亏
						sellFloatProfit: item.status == 2 ? item.order_sell.float_yingkui * 1 : '',
					}
				});
				if (this.list.length > 0) {
					this.list.push(...temp);
				} else {
					this.list = temp;
				}
				console.log(this.list, this.list.length);
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.info = {
					total: result.totalZichan * 1, // 总资产
					money: result.money * 1, // 可提
					freeze: result.frozen * 1, // 冻结
					totalProfit: result.totalYingli * 1, // 总盈利
					holdProfit: result.holdYingli * 1, // 持仓盈利
				}
			},

			// 设置样式
			setStyleTab(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 12rpx;
		margin: 0 20rpx;
		line-height: 1.8;
	}

	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>