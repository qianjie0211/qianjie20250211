<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 90%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">購入記録</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;" >
		</view>
		</view>
		
		<view style="width: 100%;height: 30px;border-radius: 10px;margin-top: -200px;"></view>
		<view>
			<view v-for="(item,index) in list" :key="index">
				<view
					style="background-color: #fff;width: 95%; margin-left: 10px;border-radius: 10px;margin-top: 10px;">
					
					<view class="flex" style="justify-content: space-between;padding:  10px; ">
						
							<view class="flex">
								<view class="bold font-size-15"  style="color: #000;">{{item.goods.name}}</view>
								<view style="color: #ea3544;"> 申込済み</view>
							</view>
							<view class="flex ">
								<view  style="color: #000;">価格</view>
								<view style="margin-left: 5px;color: #ea3544;">{{item.price}}</view>
							</view>
						
					</view>
					
					<view class="flex" style="justify-content: space-between;padding: 0px 10px">
						
							<view class="flex">
								<view  style="color: #000;">申込株数</view>
								<view style="margin-left: 50px;color: #ea3544;">{{item.num}}</view>
							</view>
							<view class="flex ">
								<view  style="color: #000;">買付代金</view>
								<view style="margin-left: 25px;color: #ea3544;">{{item.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							</view>
						
					</view>
					
					<view class="flex" style="justify-content: space-between;padding: 10px 10px">
						<view>注文状况</view>
						<view style="color: #ea3544;">{{item.admin_status==0 ?'審査待ち' : '約定'}}</view>
					</view>
					
					<view class="flex" style="justify-content: space-between;padding: 0px 10px">
						<view>受付時間</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="margin-top: 0px;color: #fff;">.</view>
					
					<!-- <view>
						<view class="flex margin-left-10 margin-top-5">
							<view style="flex: 90%;color: #8F8F8F;">レバレッジ</view>
							<view style="flex: 10%;">X{{item.double}}</view>
						</view>
					</view> -->
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				list: [],
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-log', {
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>