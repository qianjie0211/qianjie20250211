<template>
	<view style="background-color: #fff;margin-top: 90px;min-height: 65vh;">
		<view style="padding:10px;">
			<view style="text-align: center;margin-bottom: 10px;">
				<!-- <image src="/static/trade_day.png" mode="aspectFit" :style="$theme.setImageSize(300)"></image> -->
			</view>
			
			<view class="flex">
				<image src="/static/rn_tubiao.png" mode="widthFix" style="width: 20px;"></image>
				<view style="padding-left: 10px;font-size: 14px;font-weight: 500;color: #33d669;">
					데이 트레이딩 애플리케이션
				</view>
			</view>

			<view class="flex" style="padding: 20px 0px;">
				<view style="background-color: #cdefd7;padding: 10px 50px;border-radius: 10px;">수량</view>
				<view class="margin-left-10">
					<view class="flex padding-10" style="padding-left: 20px;border: 1px #ccc solid;border-radius: 10px;">
						<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
							 style="width: 100%;color: #000;font-size: 13px;"></input>
						<view style="color:#000;margin-left: 10px;">{{$lang.CURRENCY_UNIT}}</view>
					</view>
				</view>
				
			</view>

			
			
			<view style="display: flex;align-items: center;padding: 0px 10px;"
				:style="{color:$theme.LOG_LABEL}">
				<view class="flex-1" >{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}</view>
				<view :style="{color:$theme.LOG_VALUE}">{{available}} [{{$lang.CURRENCY_UNIT}}]</view>
				<view style="padding-left: 10px;color: #33d669;" @click="linkDeposit">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>
		</view>
		<view style="left: 0;right: 0;">
			<view class="common_btn" style="margin:60rpx auto;width: 85%;background-color: #33d669;" @click="handleBuy()">
				{{$lang.TRADE_DAY_BUY}}
			</view>
		</view>

		<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;" :style="{color:$theme.LOG_VALUE}">
			<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
			<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;">{{item}}</view>
			</block>
		</view>

		
	</view>
</template>

<script>
	export default {
		name: 'TradeDayBuy',
		data() {
			return {
				amount: '',
				available: '',
			}
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			// 购买
			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TRADE_DAY_TIP_INPUT_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				// 弹层
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},

			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					// 1 为驱动父组件，实现切换Tab效果
					this.$emit('action', 1);
				}, 1000);
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				console.log(result);
				this.available = this.$util.formatNumber(result.money) || 0;
			},
		}
	}
</script>