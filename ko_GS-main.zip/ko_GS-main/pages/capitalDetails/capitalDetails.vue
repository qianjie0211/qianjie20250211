<!-- 资金明细 -->
<template>
	<view class="common_page_bg2" style="min-height: 100vh;">
		<CustomHeader :title="$lang.CAPITAL_DETAIL" @action="handleBack()"></CustomHeader>

		<view class="common_block" style="background-color: rgba(255,255,255,0.95);margin:30rpx;padding: 30rpx;">

			<u-tabs lineColor="#1508bd" :current="current" :list="list1" @click="select" :activeStyle="{color: '#1508bd'}"
				:inactiveStyle="{color: '#666'}"></u-tabs>

			<view v-if="current == 0">
				<view class="" v-for="(item,index) in fundDetails" :key="index"
					style="margin-top: 10px;padding:0 6px 10px 6px;border-bottom: 1px solid #ccc;line-height: 1.8;">
					<!-- 平衡 -->
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<text style="color:#999;">잔액</text>
						<text style="color:#121212;">{{$util.formatNumber(item.after)}}원</text>
						<!-- 审核中 -->
						<text v-if="item.status==0" style="color: #d50000;">검토중</text>
						<!-- 储值成功 -->
						<text v-if="item.status==1" style="color: #5AC725;">재충전 성공</text>
						<!-- 充值失败，联系客服 -->
						<text v-if="item.status==2" style="color: #F9AE3D;">충전에 실패했습니다. 고객센터에 문의하세요.</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<text style="color:#999;">입금：</text>
						<text style="color:#121212;">{{$util.formatNumber(item.desc)}}원</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<text style="color:#999;">거래전 잔액: </text>
						<text style="color:#121212;">{{$util.formatNumber(item.before)}}원</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<text style="color:#999;">날짜 시간 :</text>
						<text style="color:#121212;">{{`${item.time1} ${item.time2}`}}</text>
					</view>
				</view>
			</view>
			<view v-if="current == 1">
				<view v-for="(item,index) in rechargeRecord" :key="index"
					style="margin-top: 10px;padding:0 6px 10px 6px;border-bottom: 1px solid #ccc;">
					<view class="takeNotes">
						<view class="display">
							<view class="business">
								<view class="corporate">{{item.desc_type}}</view>
								<view class="recharge">입금</view>
								<view class="money">{{$util.formatNumber(item.money)}}
								</view>
							</view>

							<view class="underReview" v-if="item.status==0">
								<u-icon name="clock" color='#d50000' size="12"></u-icon>검토중
							</view>
							<view class="underReview_b" v-if="item.status==1">
								<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>이체 완료
							</view>
							<view class="underReview_c" v-if="item.status==2">
								<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>충전에 실패했습니다. 고객센터에 문의하세요.
							</view>
						</view>
						<view class="order">
							<view class=""> 주문 번호:<text>{{item.order_sn}}</text> </view>
							<view class=""> 시간:<text>{{item.created_at}}</text> </view>
						</view>
					</view>
				</view>


			</view>
			<view v-if="current == 2">
				<view v-for="(item,index) in withdrawalRecords" :key="index"
					style="margin-top: 10px;padding:0 6px 10px 6px;border-bottom: 1px solid #ccc;line-height: 1.8;">
					<view class="takeNotes">
						<view class="display">
							<view class="business">
								<view class="corporate">{{item.desc_type}}</view>
							</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color:#999;"> 출금</view>
						<view style="color:#121212;">{{$util.formatNumber(item.money,2)}} </view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color:#999;"> 주문 번호</view>
						<view style="color:#121212;">{{item.order_sn}} </view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color:#999;"> 시간 </view>
						<view style="color:#121212;"> {{item.created_at}} </view>
					</view>
					<template v-if="item.status==2">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color:red;"> 거부 이유 </view>
							<view style="color:#121212;"> {{item.reason}} </view>
						</view>
					</template>

					<view class="underReview" v-if="item.status==0" style="display: flex;align-items: center;">
						<u-icon name="clock" color='#d50000' size="12" style="padding-right: 30rpx;"></u-icon>검토중
					</view>
					<view class="underReview_b" v-if="item.status==1" style="display: flex;align-items: center;">
						<u-icon name="checkmark-circle" color='#5AC725' size="12"
							style="padding-right: 30rpx;"></u-icon>성공적으로 출금됨
					</view>
					<view class="underReview_c" v-if="item.status==2" style="display: flex;align-items: center;">
						<u-icon name="close-circle" color='#F9AE3D' size="12" style="padding-right: 30rpx;"></u-icon>출금에
						실패했습니다. 고객센터에 문의하세요.
					</view>

					<view class="underReview_c" v-if="item.status==3" style="display: flex;align-items: center;">
						<u-icon name="close-circle" color='#F9AE3D' size="12" style="padding-right: 30rpx;"></u-icon>취소
						된
					</view>
					<template v-if="item.status==0">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<u-button text="취소" type="error" @click="qx(item.id)"></u-button>
						</view>
					</template>
				</view>
			</view>

		</view>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				current: 0,
				list1: [{
						name: '입출금 세부 내역'
					},
					{
						name: '입금 내역'
					},
					{
						name: '출금 내역'
					},
				],
				fundDetails: [],
				rechargeRecord: [],
				withdrawalRecords: ['']
			};
		},
		onLoad(item) {
			this.current = Number(item.index);
		},
		methods: {
			async qx(id) {
				const result = await uni.showModal({
					title: "정말로 인출을 취소하시겠습니까?",
					cancelText: "취소",
					confirmText: "확인",
				});
				if (result[1].confirm) {
					this.qx_post(id);
				}
			},
			async qx_post(id) {
				let list = await this.$http.post('api/app/qx', {
					id: id
				});
				console.log(list)
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.withdrawal()
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			select(item) {
				// console.log(item);
				this.current = item.index;
				// console.log(this.current, '9989999999');
			},
			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				// console.log(this.fundDetails);
			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {})
				this.withdrawalRecords = list.data.data
			},

		},
		mounted() {
			this.fund()
			this.recharge()
			this.withdrawal()
		},
	}
</script>

<style lang="scss">
	.college-bg {

		padding: 20rpx;

		height: 80rpx;

		background-color: #212265;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>