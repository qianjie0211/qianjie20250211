<template>
	<view>
		<view style="height: 0;"></view>
		<!-- <view class="flex">
			<view class="flex-1">
				<HeaderPrimary :title="$lang.TABBAR_HOME"></HeaderPrimary>
			</view>
			<view style="margin-right: 20px;margin-top: 10px;"> </view>

		</view> -->

		<view class="flex" style="margin:10px 28rpx;padding:24rpx;margin-top: 24px;">
			<template v-if="userInfo">
				<!-- border: 1px solid #16c0c1; -->
				<view style="border-radius: 100%;margin-bottom: 10px;background-color: #264543;"
					:style="$theme.setImageSize(120)" @click="bianji()">
					<u-avatar :src="userInfo.avatar" default-url='/static/avatar.png' size="60"></u-avatar>
				</view>
				<view class="color-white flex-1 margin-left-20">
					<view class="flex">
						<view class="font-size-16">{{userInfo.mobile}}</view>
						<image src="/static/jiahao.png" mode="widthFix" style="width: 12px;margin-left: 10px;"
							@click="bianji()"></image>
					</view>
					<view class="font-size-10">{{userInfo.real_name}}</view>
					<!-- <view class="flex">
					<view class="font-size-10" style="color: #5f5e62;">信用分:100</view>
					<view class="margin-left-10 font-size-12" style="color: #16c0c1;">{{$lang.FUZHI}}</view>
				</view> -->
				</view>
				<view class="margin-right-10 font-size-12" style="padding:0 6rpx;" :style="setStyle()">
					<template v-if="userInfo">
						{{curAuth}}
					</template>
				</view>
				<view>
					<image src="/static/yuyan.png" :style="$util.setImageSize(40)" @click="showLangList=true"
						style="margin-left:20px;"></image>
				</view>
			</template>
		</view>

		<view
			style="border-top: 2px solid #2b2f34;color:#FFF;background-color: #202938;margin:10px 28rpx;border-radius: 6px;padding:24rpx;line-height: 1.8;">


			<view class="flex" style="padding:0px 15px; justify-content: space-between;width: 90%;color: #77767b;">
				<view class="flex">
					<view>{{$lang.ZHANGHU_YUE}}(EUR)</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
				</view>
				<!-- <view style="color:#15a1a2;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;"
					@click="linkTradRecord()">
					{{$lang.JILV}}
				</view> -->
			</view>

			<!-- <template v-if="showAmount"> -->
			<view class="flex">
				<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
					<view style="font-size: 48rpx;font-weight: 500;">
						{{showAmount?$util.formatMoney(`${userInfo.totalZichan}`,3):hideAmount}}
					</view>
					<!-- <view class="margin-left-10">EUR</view> -->
				</view>
			</view>
			<view class="flex">
				<view style="color:#AAA;padding:0px 40rpx;display: flex;align-items: center;">
					<view style="font-size: 32rpx;font-weight: 500;">
						{{ showAmount?$util.formatUSD(userInfo.totalZichan*eurToUsd,3):hideAmount}}
					</view>
					<view class="margin-left-10">USD</view>
				</view>
			</view>

			<!-- </template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}}</view>
			</template> -->

			<view style="background-color:#3f6969;border-radius: 6px;padding:24rpx;">
				<view style="display: flex;align-items: center;justify-content: space-between;flex-wrap: wrap;">
					<block v-for="(v,k) in assets" :key="k">
						<view style="flex:0 0 90%;">
							<view style="color:#E56A5B;font-size:30rpx;font-weight: 700;">
								{{[$lang.KEYONG,$lang.REBATES_TIP][k]}}
							</view>
							<view>
								<!-- :style="{textAlign:k%2==0?``:`right`}" -->
								<view class="color-white" style="font-size: 32rpx;">
									{{showAmount?` € `+$util.formatMoney(`${v.money}`,3):hideAmount}}
								</view>
								<view style="color:#AAA;">
									{{showAmount?` $ `+$util.formatUSD(`${v.money*eurToUsd}`,3):hideAmount}}
								</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>

		<view class="flex"
			style=" justify-content: space-between;padding: 10px;margin-top: 10px;align-items: flex-start;">
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkWithdraw()">
				<image src="/static/withdraw.svg" mode="aspectFill" :style="$theme.setImageSize(96)"></image>
				<view style="color: #fff;margin-top: 10px;">{{$lang.TIKUAN}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkDeposit()">
				<image src="/static/deposit.svg" mode="aspectFill" :style="$theme.setImageSize(96)"></image>
				<view style="color: #fff;margin-top: 10px;">{{$lang.CHONGZHI}}</view>
			</view>
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="huazhuan()">
				<image src="/static/daikuan.png" mode="widthFix" style="width: 40px;"></image>
				<view style="color: #fff;margin-top: 10px;">{{$lang.DAIKUAN}}</view>
			</view> -->
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTrajiaoyi()">
				<image src="/static/flow.svg" mode="aspectFill" :style="$theme.setImageSize(96)"></image>
				<view style="color: #fff;margin-top: 10px;">{{$lang.JIAOYI_JILU}}</view>
			</view>
		</view>

		<view
			style="border-top: 2px solid #2b2f34;color:#FFF;background-color: #202938;margin:10px 28rpx;border-radius: 6px;padding:24rpx;line-height: 1.8;">
			<view class="flex" @click="pwd()">
				<image src="/static/denglu.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GENGGAI_DENGLUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;height: 6px;"></image>
			</view>

			<view class="flex margin-top-20" @click="zhifu()">
				<image src="/static/zhifu.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GENGGAI_ZHIFUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;height: 6px;"></image>
			</view>

			<view class="flex margin-top-20" @click="tixian()">
				<image src="/static/bangka.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				<view class="flex-1" style="margin-left: 10px;">{{$lang.GUANLI_TIXIANDIZHI}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;height: 6px;"></image>
			</view>

			<view class="flex justify-between margin-top-20" @click="shiming()">
				<image src="/static/renzheng.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				<view class="flex-1 margin-left-10">{{$lang.SHIMING_RENZHENG}}</view>
				<view class="margin-right-10 font-size-12" :style="setStyle()">
					<template v-if="userInfo">
						{{curAuth}}
					</template>
				</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;height: 6px;"></image>
			</view>

			<view class="flex justify-between margin-top-20" @tap="$util.linkService()">
				<image src="/static/service.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				<view class="flex-1 margin-left-10">{{$lang.KEFU}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;height: 6px;"></image>
			</view>
		</view>

		<view class="flex flex justify-center"
			style="border-radius: 10px;background-color: #35383d;padding: 10px;margin: 30px 20px;">
			<image src="/static/tuichu.png" mode="widthFix" style="width: 20px;"></image>
			<view class="margin-left-10" style="color: #02B975;" @click="handleSignOut()">{{$lang.TUICHU_DENGLU}}
			</view>
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="showLangList" :columns="[Object.values(langList)]" @change="changeLang"
			@cancel="showLangList=false" @confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL"
			:confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"
			keyName="lang" visibleItemCount="9"></u-picker>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import localize from '@/common/localize.js';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
		},
		data() {
			return {
				showLangList: false, // 是否显示语言选择器
				showAmount: false, // 显示金额
				yan_show: true,
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				selectedContent: 1,
				log_list: "",
				goods: "",
				info: "",
				assets: "",
				curTab: 0, //
				orderlist: "",
				order: "",

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
			}
		},
		computed: {
			langList() {
				return localize
			},
			curAuth() {
				if (this.userInfo) {
					console.log(`?`, this.userInfo);
					// 实名验证：-1未提交 0未审核  1通过 2未通过
					return [
						this.$lang.PROFILE_AUTH_UNSUBMIT,
						this.$lang.PROFILE_AUTH_UNAPPLY,
						this.$lang.PROFILE_AUTH_VERIFIED,
						this.$lang.PROFILE_AUTH_UNVERIFIED
					][!this.userInfo.is_check ? 0 : this.userInfo.is_check + 1]
				}
			},
		},
		onLoad(opt) {
			this.selectedContent = opt.tag && opt.tag.length > 0 ? 4 : this.selectedContent;
		},

		onShow() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo()
		},

		//下拉刷新
		onPullDownRefresh() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				this.showLangList = false;
				uni.setStorageSync('lang', e.value[0].code);
				this.$util.setLang();
				this.$util.switchTabBar();
				uni.reLaunch({
					url: this.$paths.LAUNCH,
				})
			},
			setStyle() {
				const temp = this.userInfo && this.userInfo.is_check == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			// gbp转 gbp_usd
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`config:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.curTab == 1) {
				// 	this.isHold = false;
				// } else {
				// 	this.isHold = true;
				// }
				// this.getList();
			},
			bianji() {
				uni.navigateTo({
					url: '/pages/Introduction/EditProfile'
				})
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw'
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			huazhuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},

			linkTrajiaoyi() {
				uni.navigateTo({
					url: '/pages/account/tradeLog'
				})
			},

			linkService() {
				this.$util.linkCustomerService();
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			pwd() {
				uni.navigateTo({
					url: '/pages/account/pwd'
				})
			},
			zhifu() {
				uni.navigateTo({
					url: '/pages/Introduction/Paymentpwd'
				})
			},
			tixian() {
				uni.navigateTo({
					url: '/pages/account/bangkAdd'
				})
			},
			shiming() {
				uni.navigateTo({
					url: '/pages/Introduction/auth'
				})
			},
			yonghu() {
				uni.navigateTo({
					url: '/pages/about'
				})
			},
			yinshi() {
				uni.navigateTo({
					url: '/pages/account/pact'
				})
			},
			linkPassword(val = '') {
				this.handleClose();
				const temp = val.length > 0 ? `?role=${val}` : '';
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PASSWORD + temp
				});
			},

			// 登出
			handleSignOut() {
				uni.removeStorageSync('token');
				try {
					let version = uni.getStorageSync('version')
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
				}, 500)
			},


			showContent(content) {
				this.selectedContent = content;
				this.getassets()

			},

			async getassets() {
				const result = await this.$http.get(`api/user/assets`, {
					type: 2
				});
				console.log('info result：', result);
				if (!result) return false;
				this.assets = result.filter(item => item.name != 'USD').slice(0, 2);

				// this.typelog();
			},

			// async typelog() {
			// 	const result = await this.$http.get(`api/user/typelog`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.log_list = result;
			// },

			// async getEafof() {
			// 	const result = await this.$http.get(`api/jijin/order`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.order = result;
			// },


			// async getGentouEa() {
			// 	const result = await this.$http.get(`api/Gentouea/orderlist`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.orderlist = result;
			// },

			// async getMoneychange() {
			// 	const result = await this.$http.get(`api/user/moneychange`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.info = result;
			// 	console.log(this.info.userlevel);
			// },


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>