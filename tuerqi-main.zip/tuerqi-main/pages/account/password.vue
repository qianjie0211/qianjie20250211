<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond :title="setTitle" :color="$theme.SECOND"></HeaderSecond>
<!-- 
		<view class="flex justify-center margin-top-20">
			<image src="/static/pass_top.png" mode="widthFix" style="width: 100px;"></image>
		</view> -->
		<view style="padding: 20px;">
			<TitlePrimary :title="$lang.ENTER_OLD_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;background-color: #fff;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="oldPassword" type="text" :placeholder="$lang.ENTER_OLD_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="oldPassword" type="password" :placeholder="$lang.ENTER_OLD_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitlePrimary :title="$lang.ENTER_NEW_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;background-color: #fff;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="newPassword" type="text" :placeholder="$lang.ENTER_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="newPassword" type="password" :placeholder="$lang.ENTER_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitlePrimary :title="$lang.ENTER_VERIFY_NEW_PASSWORD"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;background-color: #fff;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="newPassword2" type="text" :placeholder="$lang.ENTER_VERIFY_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="newPassword2" type="password" :placeholder="$lang.ENTER_VERIFY_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
		</view>
		<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
			<view class="common_btn" style="margin:60rpx auto;width: 80%;background-color: #ff8500;" @click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			HeaderSecond,
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				oldPassword: "", // 旧密码
				newPassword: "", // 新密码
				newPassword2: "", // 验证新密码
				role: '', // 根据当前角色，处理逻辑。
			};
		},
		computed: {
			// 当前页面用于:role=pay视为变更支付密码，否则视为变更登入密码
			isPay() {
				return this.role == 'pay';
			},
			// 当前页面header标题
			setTitle() {
				return this.isPay ? this.$lang.PAY_PASSWORD_TITLE : this.$lang.SIGNIN_PASSWORD_TITLE
			}
		},
		onLoad(opt) {
			console.log(opt.role);
			this.role = opt.role || '';
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 检查表单
			checkForm() {
				if (this.oldPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_OLD_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword2 == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword != this.newPassword2) {
					uni.showToast({
						title: this.$lang.ENTER_VERIFY_FAIL,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.updatePassword();
				}
			},
			//修改密码
			async updatePassword() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const temp = this.isPay ? `updatePayPassword` : `updateLoginPassword`
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPassword,
					newpass: this.newPassword,
					confirmpass: this.newPassword2,
				});
				console.log(result);
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000)
			},
		}
	}
</script>

<style>
</style>