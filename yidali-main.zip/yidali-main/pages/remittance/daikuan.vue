<template>
	<view>
		<view class="flex" style="padding:20px;">
			<view @click="fanhui()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.JIEKUAN_JILV}}</view>
		</view>
		
		<block v-for="(item,index) in list" :key="index">
		<view style="padding: 10px 20px; ">
			<view class="flex" style="justify-content: space-between;">
				<view style="color: #909192;">{{$lang.DAIKUAN_JINE}}</view>
				<view style="color: #fff;">{{item.money}}</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.ZHUANGTAI}}</view>
				<view style="color: #02aacd;">{{transStatus(item.status)}}</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.HUANKUAN_ZHOUQI}}</view>
				<view style="color: #fff;">{{item.zhouqi}}{{$lang.TIAN}}</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.RILI_LV}}</view>
				<view style="color: #fff;">0.16%</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.LIXI}}</view>
				<view style="color: #fff;">{{item.lixi}} USDT</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.HUANKUAN_FANGSHI}}</view>
				<view style="color: #fff;">{{$lang.DAOQI_YICI}}</view>
			</view>
			<view class="flex" style="justify-content: space-between;margin-top: 10px;">
				<view style="color: #909192;">{{$lang.FANGKUAN_JIGOU}}</view>
				<view style="color: #fff;">Binance</view>
			</view>
		</view>
		<view style="border-top: 1px #34393e solid;color: #202328;">.</view>
		</block>
	</view>
</template>
<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
				list: {},
			}
		},
		onShow() {
			this.getLoanlog();
		},
		computed: {
			
		},
		created() {
			
		},
		methods: {
		fanhui(){
			uni.navigateBack({
				delta:1,
			})
		},
		transStatus(status){
			if(status==0){
				return this.$lang.DAISHEN_HE
			}else if (status==1){
				return this.$lang.TONGGUO
			}else if (status==2){
				return this.$lang.WEITONG_GUO
			}
			
		},
		async getLoanlog() {
			const result = await this.$http.get(`api/app/loanlog`);
			// console.log('info result�, result);
			if (!result) return false;
			this.list = result;
			console.log(this.list.userlevel);
		},
		
		},
	}
</script>

<style>
</style>