<template>
	<view class="padding-top-10">
	<view class="flex" style="justify-content: space-between;padding: 15px;">
		<!-- <text class="common_header_left">{{title}}</text> -->
		<!-- <view>
			<image src="../static/sy_logo.png" mode="widthFix" style="width: 35px;margin-top: 5px;"></image>
		</view> -->
		<view  class="flex" @click="$u.route({url:'/pages/searchFor/searchFor'});" style="background-color: #fff;padding: 6px 8px;border-radius: 30px;width: 70%;">
			<image mode="aspectFit" src="/static/search_dark.png" :style="$util.calcImageSize(20)"></image>
			<view class="margin-left-5 font-size-13" style="color: #999;">검색하고 싶은 내용을 입력해주세요</view>
		</view>
		
		<view class="flex" style="background-color: #fff;padding: 5px 10px;border-radius: 30px;">
			<view class="common_header_right" @click="kefu()">
				<image mode="aspectFit" src="/static/sy_kf.png" :style="$util.calcImageSize(20)"></image>
			</view>
			<view class="common_header_right margin-left-10" @click="$u.route({url:'/pages/email/email'});">
				<image mode="aspectFit" src="/static/sy_tz.png" :style="$util.calcImageSize(20)"></image>
			</view>
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		props: ["title"],
		data() {
			return {};
		},
		
		methods: {
			kefu() {
			    uni.navigateTo({
			    	url: `/pages/service/service`,
			    	
			    })
			}

		}
	}
</script>
