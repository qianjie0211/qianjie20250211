<template>
	<view :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/shichang.png);background-size: contain;background-repeat: no-repeat;background-size: 100% 0%;">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<view class="flex " style=" justify-content: space-between;padding: 20px 10px;">
			<view class="flex" style="padding: 8px;" @click="chaxuan()">
				<view class="flex" @click="chaxuan()">
					<image src="/static/sousuo.png" mode="widthFix" style="width: 240px;35px"></image>
				</view>
			</view>
			<view class="flex" style="background-color: #feedde;padding: 5px 15px;border-radius: 30px;">
				<!-- <image src="/static/sandian.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;"
					@click="$util.linkCustomerService()"></image> -->
				<!-- <image src="/static/shuxian.png" mode="widthFix" style="width:2rpx;"></image> -->
				<image src="/static/notify.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 10px;"
					@click="xiaoxi()">
				</image>
			</view>
			<!-- <image src="/static/sykefu.png" mode="widthFix" style="width: 25px;height: 25px;" @click="$util.linkCustomerService()"></image>
			<image src="/static/notify.png" mode="widthFix" style="width: 25px;height: 25px;" @click="xiaoxi()"></image> -->
		</view>

		<view style="padding:0px 10px">
			<image src="/static/sc_bg.png" mode="widthFix" style="width: 100%;"></image>
			<!-- <view style="width: 250px;height: 150px; position: absolute;bottom: -55%;left: 40px; ">
				<view class="font-size-18">{{$lang.API_UFAS_CVDSVSD}}</view>
				<view class="font-size-16 margin-top-5">{{$lang.API_UFBFDBG}}</view>
			</view> -->
		</view>

		<!-- <header style="padding: 15rpx 20rpx 0 20rpx;" >
			<view style="display: flex;text-align: center;">
				<block v-for="(item,index) in $lang.MARKET_TABS" :key='index' >
					<view :style="setStyle(curTab ==index)" @click="changeTab(index)" class="flex-1 radius10">
						{{item}}
					</view>
				</block>
			</view>
		</header> -->

		<view style="margin-top: 10px;">
			<TabOne v-if="curTab==0" ref="tab0"></TabOne>
			<MarketHot v-if="curTab==1"></MarketHot>
			<MarketKPI v-if="curTab==2"></MarketKPI>
			<MarketNews v-if="curTab==3"></MarketNews>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabOne from './components/TabOne.vue'
	import MarketHot from './components/MarketHot.vue'
	import MarketKPI from './components/MarketKPI.vue'
	import MarketNews from './components/MarketNews.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TabOne,
			MarketHot,
			MarketKPI,
			MarketNews
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				// timer: null,
			}
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			this.isAnimat = true;
			console.log('onShow', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.onSetTimeout();
			}
			this.changeTab(this.curTab);
		},
		onReady() {
			console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			this.isAnimat = false;
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {

			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
			},
			chaxuan() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/service'
				})
			},
			xiaoxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},
			// 设置样式
			setStyle(val) {
				return {
					padding: `12rpx 24rpx`,
					color: val ? '#000' : '#232323',
					background: val ? '#f7be64' : '',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: val ? '700' : '100',
				}
			},
		},
	}
</script>