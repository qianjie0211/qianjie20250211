<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 100%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">ログインパスワードの変更</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;" >
		</view>
		</view>
		<view style="width: 100%;height: 30px;border-radius: 10px;margin-top: -200px;"></view>

		<view
			style="display: flex;flex-direction: column;width: 100%;margin-left: 10px;">
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 5px; width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">現在のパスワード</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value" maxlength="" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 5px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">新しいパスワード</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value2" maxlength="" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 5px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">新しいパスワードを再入力</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value3" maxlength="" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex justify-center" style="width:85%;margin: 20px;background-color: #18bfb4;color: #fff;height: 45px;border-radius: 5px;" @click="changePassword">確認</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(this.$http.API_URL.SIGNIN_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('修正されました.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>