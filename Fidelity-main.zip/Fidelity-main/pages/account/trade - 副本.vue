<template>
	<view>
		<HeaderPrimary :title="$lang.TABBAR_TRADE" isSearch></HeaderPrimary>


		<!-- <view style="position: absolute; right: 30px;top: 30px;" @click="shuaxin">
			<u-icon name="reload" color="#2979ff" size="28"></u-icon>
		</view> -->
		<!-- <CustomTitle :title="$lang.TRADE_TITLE"></CustomTitle> -->

		<TabsFourth :tabs="$lang.TRADE_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>
		<view class="flex gap5 padding-10" style="line-height: 1.8;">
			<view
				style="background-image: url(/static/chicang1.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat"
				class="flex-1 padding-10">
				<view style="color: #10DF95;font-weight: 700;font-size: 12px;">
					{{$lang.POSITION_PROFIT}}
				</view>
				<view style="color: #fff;font-size: 14px;font-weight: 700;">
					{{$util.formatMoney(`${!userInfo?'0.000':userInfo.totalYingli*1}`,3)}} €
				</view>
				<view
					style="color: #fff;font-size: 14px;background-color: #10df95;border-radius: 10px;padding: 1px 10px;margin-bottom: 10px;">
					{{$util.formatMoney(`${!userInfo?'0.0000':userInfo.totalYingli*eurToUsd}`,4)}} $
				</view>
			</view>
			<view
				style="background-image: url(/static/chicang1.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat"
				class="flex-1 padding-10">
				<view style="color: #10DF95;font-weight: 700;font-size: 12px;">
					{{$lang.POSITION_TOTAL_VALUE}}
				</view>
				<view style="color: #fff;font-size: 14px;font-weight: 700;">
					{{$util.formatMoney(`${!userInfo?'0.000':userInfo.chicangguzhi*1}`,3)}} €
				</view>
				<view
					style="color: #fff;font-size: 14px;background-color: #10df95;border-radius: 10px;padding: 1px 10px;margin-bottom: 10px;">
					{{$util.formatMoney(`${!userInfo?'0.0000':userInfo.chicangguzhi*eurToUsd}`,4)}} $
				</view>
			</view>
		</view>
		<template v-if="curTab==0">
			<!-- <TradeHoldList></TradeHoldList> -->
			<view style="padding: 10px;">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>

				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view
							style="padding:10px;border-radius:24rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(255, 255, 255, 0.25) 0px 0px 0px 1px;background: #1a1e2a;margin-top: 10px;"
							@tap.stop="handleSell(item.id)">
							<view style="display: flex;align-items: center;" class="gap5">
								<view
									style="background-color: #f71919;padding: 1px 8px;color: #fff;border-radius: 10px;">
									{{item.goods_info.project_type_id==6?'EU':(item.goods_info.project_type_id==7?'EU':'COIN')}}
								</view>
								<view style="flex:auto;color:#fff;font-size: 16px;">
									{{item.goods_info.name}}
								</view>
								<view style="margin-left: auto;">
									<view
										style="color:#00AA98;padding:2px 6px;background-color: #00AA983A; border-radius: 6px;text-align: center;">
										{{item.order_buy.direct==1? $lang.POSIZIONE_LONG:$lang.POSIZIONE_SHORT}}
									</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
								<view>
									<view style="color:#fff;font-size: 28rpx;text-align: right;">

										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.price}`,3)}}
										</template>

										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.price}`,4)}}
										</template>
									</view>
									<view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.price*eurToUsd}`,4)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.price*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
								<view style="color:#fff;font-size: 28rpx;">{{item.order_buy.num}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_PAY_PRICE}}</view>
								<view>
									<view style="color:#fff;font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay}`,4)}}
										</template>
									</view>
									<view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay*eurToUsd}`,4)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>



							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.yingkui*1>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.yingkui}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.yingkui}`,4)}}
										</template>
									</view>
									<view style="font-size: 24rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.yingkui*1>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.yingkui*eurToUsd}`,4)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.yingkui*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>


							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_RATE}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.rate>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{
												$util.formatMoney(`${item.order_buy.rate}`,2)
											}}%
										</template>
										<template v-else>
											{{
												$util.formatUSD(`${item.order_buy.rate}`,2)
											}}%
										</template>
									</view>
								</view>
							</view>


							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
								<view style="color:#fff;font-size: 28rpx;text-align: right;">{{item.order_sn}}</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_CRETIME}}</view>
								<view style="color:#fff;font-size: 28rpx;text-align: right;">{{item.created_at}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center; justify-content: center;border-radius: 5px;background: #10df95;color:#000;margin-top: 10px;padding: 5px;">
								{{$lang.BTN_SELL}}
							</view>
						</view>
					</block>
				</template>
			</view>
		</template>
		<template v-else>
			<!-- <TradeSellList></TradeSellList> -->
			<view style="padding: 10px;">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>

				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view
							style="padding:10px;border-radius:24rpx;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(255, 255, 255, 0.25) 0px 0px 0px 1px;background: #1a1e2a;margin-top: 10px;"
							@tap.stop="handleSell(item.id)">
							<view style="display: flex;align-items: center;" class="gap5">
								<view
									style="background-color: #f71919;padding: 1px 8px;color: #fff;border-radius: 10px;">
									{{item.goods_info.project_type_id==6?'EU':(item.goods_info.project_type_id==7?'EU':'COIN')}}
								</view>
								<view style="flex:auto;color:#fff;font-size: 16px;">
									{{item.goods_info.name}}
								</view>
								<view style="margin-left: auto;">
									<view
										style="color:#00AA98;padding:2px 6px;background-color: #00AA983A; border-radius: 6px;text-align: center;">
										{{item.order_buy.direct==1? $lang.POSIZIONE_LONG:$lang.POSIZIONE_SHORT}}
									</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
								<view>
									<view style="color:#fff;font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.price}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.price}`,4)}}
										</template>
									</view>
									<view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.price*eurToUsd}`,4)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.price*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_SELL_PRICE}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<view style="color:#fff;font-size: 28rpx;text-align: right;">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`€ `+$util.formatMoney(`${item.order_sell[0].price*1}`,3)}}
											</template>

											<template v-else>
												{{`$ `+$util.formatUSD(`${item.order_sell[0].price*1}`,4)}}
											</template>
										</view>
										<view style="color:#AAA;font-size: 24rpx;text-align: right;">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`$ `+$util.formatUSD(`${item.order_sell[0].price*eurToUsd}`,4)}}
											</template>
											<template v-else>
												{{`€ `+$util.formatMoney(`${item.order_sell[0].price*usdToEur}`,3)}}
											</template>
										</view>
									</template>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
								<view style="color:#fff;font-size: 28rpx;">{{item.order_buy.num}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.ZHIFU_JINE}} </view>
								<view>
									<view style="color:#fff;font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay*1}`,4)}}
										</template>
									</view>
									<view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay*eurToUsd}`,4)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay*usdToEur}`,3)}}
										</template>
									</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<view style="font-size: 28rpx;text-align: right;"
											:style="$theme.setStockRiseFall(item.order_sell[0].yingkui*1>0)">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`€ `+$util.formatMoney(`${item.order_sell[0].yingkui}`,3)}}
											</template>
											<template v-else>
												{{`$ `+$util.formatUSD(`${item.order_sell[0].yingkui}`,4)}}
											</template>
										</view>
										<view style="font-size: 24rpx;text-align: right;"
											:style="$theme.setStockRiseFall(item.order_sell[0].yingkui*1>0)">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`$ `+$util.formatUSD(`${item.order_sell[0].yingkui*eurToUsd}`,4)}}
											</template>
											<template v-else>
												{{`€ `+$util.formatMoney(`${item.order_sell[0].yingkui*usdToEur}`,3)}}
											</template>
										</view>
									</template>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_RATE}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<!-- float_yingkui/order_buy.price -->
										<!-- <view style="font-size: 28rpx;text-align: right;"
											:style="$theme.setStockRiseFall((item.order_sell[0].float_yingkui*1)/(item.order_buy.price*1)>0)">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{ $util.formatMoney(`${(item.order_sell[0].float_yingkui*1)/item.order_buy.price}`,2) }}%
											</template>
											<template v-else>
												{{ $util.formatUSD(`${(item.order_sell[0].float_yingkui*1)/item.order_buy.price}`,2) }}%
											</template>
										</view> -->

										<!-- 做多（卖出-买入）/买入， -->
										<template v-if="item.order_sell[0].direct==1">
											<view style="font-size: 28rpx;text-align: right;"
												:style="$theme.setStockRiseFall((item.order_sell[0].price*1 - item.order_buy.price*1)/(item.order_buy.price*1)>0)">
												<template v-if="$util.isEur(item.goods_info.project_type_id)">
													{{ $util.formatMoney(`${(item.order_sell[0].price*1 - item.order_buy.price*1)/item.order_buy.price*100}`,2) }}%
												</template>
												<template v-else>
													{{ $util.formatUSD(`${(item.order_sell[0].price*1 - item.order_buy.price*1)/item.order_buy.price*100}`,2) }}%
												</template>
											</view>
										</template>
										<!-- 做空  （买入-平仓卖出价格）/买入 -->
										<template v-if="item.order_sell[0].direct==2">
											<view style="font-size: 28rpx;text-align: right;"
												:style="$theme.setStockRiseFall((item.order_buy.price*1-item.order_sell[0].price*1 )/(item.order_buy.price*1)>0)">
												<template v-if="$util.isEur(item.goods_info.project_type_id)">
													{{ $util.formatMoney(`${(item.order_buy.price*1-item.order_sell[0].price*1 )/item.order_buy.price*100}`,2) }}%
												</template>
												<template v-else>
													{{ $util.formatUSD(`${(item.order_buy.price*1-item.order_sell[0].price*1 )/item.order_buy.price*100}`,2) }}%
												</template>
											</view>
										</template>
									</template>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
								<view style="color:#fff;font-size: 28rpx;text-align: right;">{{item.order_sn}}</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#cccccc;">{{$lang.SELL_TIME}}</view>
								<view style="color:#fff;font-size: 28rpx;text-align: right;">{{item.sell_time}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</template>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.ACCESS_TEXT}"
							style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.created_at}}
						</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}
						</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}
						</view>
						<view style="flex: 20%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.double}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="trade_modal_btn" style="background-color: #FF6700;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="trade_modal_btn" style="background-color:#00aa99;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import CustomTitle from '@/components/CustomTitle.vue';

	// import TradeHoldList from "@/components/trade/TradeHoldList.vue";
	// import TradeSellList from "@/components/trade/TradeSellList.vue";

	export default {
		components: {
			HeaderPrimary,
			TradeInfo,
			EmptyData,
			TabsFourth,
			CustomTitle,
			// TradeHoldList,
			// TradeSellList,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: null, // 交易信息
				curTab: 0, // 

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
				timer: null,
				page: 1,
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},
		onLoad() {},
		onShow() {
			this.page = 1;
			this.getconfig();
			this.getAccountInfo();
			// if (this.timer) this.clearTimer();
			if (this.curTab == 0) {
				this.getHolderList();
				// this.onSetTimeout();
			}
			if (this.curTab == 1) this.getHistoryList();
		},
		//下拉刷新
		onPullDownRefresh() {
			this.shuaxin()
			uni.stopPullDownRefresh();
		},
		onUnload() {
			// if (this.timer) this.clearTimer();
		},
		onHide() {
			// if (this.timer) this.clearTimer();
		},
		deactivated() {
			// console.log('deactivated', this.timer);
			// if (this.timer) this.clearTimer();
		},
		onReachBottom() {
			this.page = this.page + 1
			if (this.curTab == 0) this.getHolderList();
			if (this.curTab == 1) this.getHistoryList();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				this.page = 1; // 从第一页重新开始
				this.list = []; // 清空所有翻页后内中数据
				// if (this.timer) this.clearTimer();
				if (this.curTab == 0) {
					this.getHolderList();
					// this.onSetTimeout();
				}
				if (this.curTab == 1) this.getHistoryList();
			},

			shuaxin() {
				this.page = 1;
				this.list = []; // 清空所有翻页后内中数据
				if (this.curTab == 0) this.getHolderList();
				if (this.curTab == 1) this.getHistoryList();
			},
			// onSetTimeout() {
			// 	this.timer = setInterval(() => {
			// 		console.log("setInterval");
			// 		if (this.curTab == 0) this.getHolderList();
			// 	}, 3000);
			// },
			// clearTimer() {
			// 	if (this.timer) {
			// 		clearInterval(this.timer);
			// 		this.timer = null;
			// 		console.log('clearTimer', this.timer);
			// 	}
			// },
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},

			// 平仓/卖出
			async handleSell(id) {
				console.log(`id:`, id);
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id: id,
				});
				if (!result) return false;
				uni.showToast({
					title: '',
					icon: 'success'
				})
				this.getAccountInfo()
				setTimeout(() => {
					this.changeTab(this.curTab);
				}, 1000)

			},

			// 获取历史列表数据
			async getHistoryList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 2, // 1持仓，2历史
					gp_index: 0,
					page: this.page
				});
				console.log(`result:`, result);
				if (!result) return false;
				// check data
				const temp = result.data.filter(item => item.goods_info && item.order_buy && item.order_sell && item
					.order_sell.length > 0);
				this.list = this.list.concat(temp);

			},
			// 获取持有列表数据
			async getHolderList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 1, // 1持仓，2历史
					gp_index: 0,
					page: this.page
				});
				console.log(`result:`, result);

				if (!result) return false;
				// check data
				const temp = result.data.filter(item => item.goods_info && item.order_buy);
				// this.list = this.list.concat(temp);
				// 获取当前list中的所有id
				const ids = this.list.map(item => item.id);
				// 过滤 添加不重复的对象到新数组中
				const uniqueItems = temp.filter(item => !ids.includes(item.id));
				// // 获取 this.list 中不重复的对象
				// const uniqueItemsFromArray2 = this.list.filter(item => !temp.some(i => i.id === item.id));

				this.list = [...this.list, ...uniqueItems];
				console.log(this.list.length);
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			// handleShowModal(item) {
			// 	this.isShow = true;
			// 	this.info = item
			// },

			// // 平仓/卖出
			// handleSell(id) {
			// 	const _this = this;
			// 	uni.showModal({
			// 		title: this.$lang.SELL_TIP,
			// 		cancelText: this.$lang.BTN_CANCEL,
			// 		confirmText: this.$lang.BTN_CONFIRM,
			// 		success: function(res) {
			// 			this.isShow = false;
			// 			if (res.confirm) {
			// 				_this.confirmSell(id);
			// 			} else if (res.cancel) {}
			// 		}
			// 	})
			// },


			//用户信息
			async getAccountInfo() {
				// const result = await this.$http.get(`api/user/assets`, {
				// 	type: 2
				// });
				// console.log('info result：', result);
				// if (!result) return false;
				// this.userInfo = result;
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			},

			// // 平仓功能
			// async confirmSell(id) {
			// 	const result = await this.$http.post(`api/user/sell`, {
			// 		id
			// 	});
			// 	if (!result) return false;
			// 	this.getData();
			// },

			// handleStockDetail(code) {
			// 	uni.navigateTo({
			// 		url: `${this.$paths.COIN_OVERVIEW}?code=${code}`
			// 	});
			// },


		},
	}
</script>