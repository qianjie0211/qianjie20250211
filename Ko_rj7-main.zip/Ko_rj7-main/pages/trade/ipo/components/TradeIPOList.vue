<template>
	<view style="margin-top: 90px;">
		<view style="padding: 5px;background-color: #FFFFFF;min-height: 70vh;">
			<view class="flex padding-10">
				<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
				<view style="color: #000;margin-left: 5px;"> IPO/공모</view>
			</view>
			<view class="flex hui1 flex-b padding-10" style="border-bottom: 1px #ccc solid;">
				<view class="flex">
					<view class="font-size-10">종류</view>
					<view class="font-size-10 margin-left-30">종목명 코드</view>
				</view>
				<view class="font-size-10">발행 가격</view>
				<view class="font-size-10 margin-right-10">청약일정</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class="flex" style="border-bottom:1px #ccc solid ;padding: 5px 0px;" @click="handleDetail(item)">
					<view style="flex: 10%;text-align: center;margin-left: 5px;">{{(index+1)}}</view>
					<view style="flex: 30%;text-align: center;">
						<view class="bold">{{item.name}}</view>
						<view class="hui1 font-size-10">{{item.code}}</view>
					</view>
					<view class="bold" style="flex: 40%;text-align: center;">{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
					<view class="hui1" style="flex: 25%;text-align: center;">{{item.shengou_date}}</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.itemInfo=val;
				this.handleShowModal();
			},
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: this.$lang.TRADE_IPO_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.purchase();
				}
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.itemInfo.id,
					// price: this.price
				})
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
						// rate: item.goods.rate,
						// rate_num: item.goods.rate_num,
					}
				})
			},
		}

	}
</script>

<style>
</style>