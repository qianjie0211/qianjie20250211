<template>
	<view
		style="margin:20rpx 30rpx;border-radius: 4px;display: flex;align-items: center;background-color: #FFFFFF;padding:0 20px;">
		<image src="/static/horn.png" mode="aspectFit" :style="$util.setImageSize(30)"></image>
		<u-notice-bar :text="text1" speed="80" :url="linkNotify" :color="$theme.PRIMARY" bgColor="#FFFFFF"
			icon=""></u-notice-bar>
		<!-- <image src="/static/close.png" mode="aspectFit" :style="$util.setImageSize(30)" @click="actionEvent()"></image> -->
	</view>
</template>

<script>
	import {
		NOTIFICATION
	} from '@/common/paths.js';
	export default {
		name: 'NotifyPrimary',
		data() {
			return {
				// 此处可以是软件相关的通知
				text1: this.$lang.LAUNCH_TITLE,
			}
		},
		computed: {
			linkNotify() {
				return NOTIFICATION
			}
		},
		methods: {
			// actionEvent() {
			// 	this.$emit('action', 1);
			// }
		}
	}
</script>

<style>
</style>