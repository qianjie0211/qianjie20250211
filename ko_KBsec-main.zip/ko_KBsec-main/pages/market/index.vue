<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left">
				<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<!-- <text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text> -->
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?$theme.PRIMARY:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<view :class="setClass" style="padding-top:0; margin:20rpx;">
			<template v-if="curTab==0">
				<MarketTrack :list="trackList" @action="handleUntrack" @actevent="linkStock"></MarketTrack>
			</template>
			<template v-else-if="curTab==1">
				<MarketStockList :list="allList"></MarketStockList>
			</template>
			<template v-else-if="curTab==2">
				<MarketHot :list="hotList" @action="handleHotList" @actfollow="handleFollow"></MarketHot>
			</template>
			<template v-else>
				<MarketKPI :list="kpiList" @action="handleKpiList"></MarketKPI>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList,
			MarketHot,
			MarketKPI
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在track
				trackList: [], // 关注
				allList: [], // 全部
				hotList: [], // 热门
				kpiList: [], // 指标
				curHotTab: 0, // 热门 当前tab
				curKpiTab: 0, // 指标 当前tab
			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					this.$lang.MARKET_INDEX_TAB_MARKET,
					this.$lang.MARKET_INDEX_TAB_HOP,
					this.$lang.MARKET_INDEX_TAB_KPI
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) this.curTab = Number(op.type) || 0;
		},
		onShow() {
			this.isAnimat = true;
			if (this.curTab == 0) this.getTrackList();
			if (this.curTab == 1) this.getAllList();
			if (this.curTab == 2) this.getHotList();
			if (this.curTab == 3) this.getKpiList();
		},
		onHide() {
			this.isAnimat = false;
		},

		methods: {
			linkSearch() {
				uni.navigateTo({
					url: this.$CONSTANTS.SEARCH
				})
			},
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getTrackList();
				if (this.curTab == 1) this.getAllList();
				if (this.curTab == 2) this.getHotList();
				if (this.curTab == 3) this.getKpiList();
			},

			handleHotList(val) {
				this.curHotTab = val;
				if (this.curTab == 2) this.getHotList();
			},
			handleKpiList(val) {
				this.curKpiTab = val;
				if (this.curTab == 3) this.getKpiList();
			},

			// 从关注列表跳转到市场
			linkStock() {
				this.changeTab(1);
			},

			// 在操作取关之后，刷新关注列表
			handleUntrack(val) {
				if (this.curTab == 0) this.getTrackList();
			},

			// 关注
			async handleFollow(id) {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					if (this.curTab == 1) this.getAllList();
					if (this.curTab == 2) this.getHotList();
				}, 1000);
			},

			// market track list
			async getTrackList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/collect_list`);
				if (!result) return false;
				console.log('result:', result);
				this.trackList = result.list.map(item => {
					return {
						gid: item.gid,
						logo: item.goods.logo || '',
						name: item.goods.name || '',
						code: item.goods.code || '',
						price: item.goods.current_price || 0,
						rate: item.goods.rate || 0,
					}
				});
			},

			// stock all
			async getAllList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/list`);
				if (!result) return false;
				console.log('result:', result);
				const temp = result.length <= 0 ? [] : result.filter(item => item.stock_id && item
					.stock_id > 0);
				this.allList = !temp || temp.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code || '',
						price: item.close || 0,
						rate: item.returns || 0,
						type_id: item.project_type_id || 0,
					}
				});
			},

			// 热门
			async getHotList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/paihang`, {
					current: this.curHotTab
				})
				if (!result) return false;
				console.log(result);
				this.hotList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code,
						price: item.close || 0,
						rate: item.returns || 0,
						follow: item.sc,
						gid: item.gid,
					}
				});
			},

			// 指标
			async getKpiList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/zhibiao`, {
					current: this.curKpiTab
				})
				// console.log('result, result);
				if (!result) return false;
				this.kpiList = Object.values(result).map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>