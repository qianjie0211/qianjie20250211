// 自定义的u-chart 写在这里，外部调用。
import Vue from 'vue';

// https://github.com/chunyang3/uCharts/blob/master/example/uni-app/pages/ucharts-demo/index.vue
// https://www.ucharts.cn/v2/#/document/index
// https://github.com/SIT-kite/kite-microapp

// 细柱 每周 盈亏 WeekProfitLoss
export const columnChartWeek = (ctx, data, cWidth, cHeight, minValue) => {
	return {
		type: "column",
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		fontSize: 11,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		dataLabel: false, // 图表区域内数据点上方的数据
		legend: {
			show: true,
			position: "top",
			// lineHeight: 25,
			float: "center",
			// padding: 5,
			// margin: 5,
			// backgroundColor: "rgba(0,0,0,0)",
			// borderColor: "rgba(0,0,0,0)",
			// borderWidth: 0,
			// fontSize: 10,
			// fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			// hiddenColor: "#CECECE",
			// itemGap: 10
		},
		// 横向虚线
		xAxis: {
			// type: 'grid',
			gridColor: 'rgba(0,0,0,0)',
			// gridColor: '#302F31',
			// gridType: 'dash', // 虚线(dash) 实线(solid)
			// dashLength: 8,
			disableGrid: true,
			type: 'calibration',
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			// data: data.series,
		},
		yAxis: {
			// gridType: 'dash',
			gridColor: '#302F31',
			// dashLength: 18, // 线段宽度
			// splitNumber: 4, // 水平分割
			data: [{
				min: minValue > 0 ? 0 : minValue,
				// max: 5
				// min:Math.min(...data.series[1].data),
			}],
		},
		extra: {
			column: {
				// type: 'group', // 分组柱状图
				// 每根柱状的宽度
				width: cWidth * 0.2 / data.categories.length,
				barBorderCircle: true, // 顶部半圆
				// linearType: "custom"
				seriesGap: 3, // 每柱宽度
				// labelPosition: "insideTop", // 内顶部
			},
		},
	}
};

// 区域图 type: 'area',
export const areaChart = (ctx, data, cWidth, cHeight) => {
	return {
		type: 'area',
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		fontSize: 11,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		dataLabel: false,
		dataPointShape: false,

		// background: "#FFFFFF",
		// color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
		// 	"#ea7ccc"
		// ],
		// padding: [5, 5, 5, 5],
		// dataPointShapeType: "solid",
		// touchMoveLimit: 60,
		// enableScroll: false,
		// enableMarkLine: false,
		// 标题
		legend: {
			show: false,
			position: "top",
			lineHeight: 25,
			float: "left",
			padding: 5,
			margin: 5,
			backgroundColor: "rgba(0,0,0,0)",
			borderColor: "rgba(0,0,0,0)",
			borderWidth: 0,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			hiddenColor: "#CECECE",
			itemGap: 10
		},
		xAxis: {
			// type: 'grid',
			// gridColor: 'rgba(0,0,0,0)',
			// gridType: 'solid', // 虚线(dash) 实线(solid)
			// dashLength: 8
			disableGrid: true,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		},
		yAxis: {
			gridType: 'solid',
			gridColor: '#302F31',
			dashLength: 8,
			splitNumber: 5,
			data: [{
				// min: 0,
				// max: 180,
			}]
		},
		extra: {
			area: {
				type: 'straight', // 曲线(curve) // straight
				opacity: 0.2,
				addLine: true,
				width: 1,
			}
		},
	}
};

export const columnChartVolume = (ctx, data, cWidth, cHeight) => {
	return {
		type: "column",
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		fontSize: 11,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		dataLabel: false, // 图表区域内数据点上方的数据
		extra: {
			column: {
				type: 'group', // 分组柱状图
				// 每根柱状的宽度
				width: cWidth * 0.1 / data.categories.length,
				barBorderCircle: true, // 顶部半圆
				// linearType: "custom"
				seriesGap: 2.8, // 每柱宽度
				// labelPosition: "insideTop", // 内顶部
			},
		},
		legend: {
			show: false,
			position: "top",
			lineHeight: 25,
			float: "center",
			padding: 5,
			margin: 5,
			backgroundColor: "rgba(0,0,0,0)",
			borderColor: "rgba(0,0,0,0)",
			borderWidth: 0,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			hiddenColor: "#CECECE",
			itemGap: 10
		},
		// 横向虚线
		xAxis: {
			type: 'grid',
			gridColor: 'rgba(0,0,0,0)',
			gridType: 'dash', // 虚线(dash) 实线(solid)
			dashLength: 8,
			disableGrid: true,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		},
		yAxis: {
			gridType: 'dash',
			gridColor: '#302F31',
			dashLength: 18, // 线段宽度
			splitNumber: 4, // 水平分割
			data: [{
				min: 0,
				// max: 10
			}]
		},
	}
};
// 柱状图 月度盈亏
export const columnChartMonth = (ctx, data, cWidth, cHeight) => {
	return {
		type: "column",
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		fontSize: 11,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		dataLabel: false, // 图表区域内数据点上方的数据
		extra: {
			column: {
				// type: 'group', // 分组柱状图
				// 每根柱状的宽度
				width: cWidth * 0.45 / data.categories.length,
				barBorderCircle: true, // 顶部半圆
				// linearType: "custom"
				// seriesGap: 2.8, // 每柱宽度
			},
		},
		legend: {
			show: true,
			position: "top",
			lineHeight: 25,
			float: "center",
			padding: 5,
			margin: 5,
			backgroundColor: "rgba(0,0,0,0)",
			borderColor: "rgba(0,0,0,0)",
			borderWidth: 0,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			hiddenColor: "#CECECE",
			itemGap: 10
		},
		// 横向虚线
		xAxis: {
			type: 'grid',
			gridColor: 'rgba(0,0,0,0)',
			gridType: 'dash', // 虚线(dash) 实线(solid)
			dashLength: 8,
			disableGrid: true,
			fontSize: 10,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		},
		yAxis: {
			gridType: 'dash',
			gridColor: '#302F31',
			dashLength: 18, // 线段宽度
			splitNumber: 4, // 水平分割
			data: [{
				min: Math.min(...data.series[1].data),
				// max: 5
			}],
			// format:(val){}
		},
	}
};

// 饼图
export const pieChart = (ctx, data, cWidth, cHeight) => {
	return {
		type: "ring",
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		rotate: false,
		rotateLock: false,
		background: "rgba(0,0,0,0)",
		color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
			"#ea7ccc"
		],
		padding: [5, 5, 5, 5],
		fontSize: 13,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		dataLabel: true,
		dataPointShape: true,
		dataPointShapeType: "solid",
		touchMoveLimit: 60,
		enableScroll: false,
		enableMarkLine: false,
		legend: {
			show: false, // 标识
			position: "top",
			lineHeight: 25,
			float: "left",
			padding: 5,
			margin: 5,
			backgroundColor: "rgba(0,0,0,0)",
			borderColor: "rgba(0,0,0,0)",
			borderWidth: 0,
			fontSize: 13,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			hiddenColor: "#CECECE",
			itemGap: 10
		},
		// title: {
		//   name: "2,515억",
		//   fontSize: 15,
		//   color: "#666666",
		//   offsetX: 0,
		//   offsetY: 0
		// },
		// subtitle: {
		//   name: "자산총계",
		//   fontSize: 25,
		//   color: "#7cb5ec",
		//   offsetX: 0,
		//   offsetY: 0
		// },
		extra: {
			ring: {
				ringWidth: 30,
				activeOpacity: 0.5,
				activeRadius: 10,
				offsetAngle: 0,
				labelWidth: 15,
				border: true,
				borderWidth: 3,
				borderColor: "#FFF",
				centerColor: "#FFF",
				customRadius: 0,
				linearType: "none"
			},
			tooltip: {
				showBox: true,
				showArrow: true,
				showCategory: false,
				borderWidth: 0,
				borderRadius: 0,
				borderColor: "#000000",
				borderOpacity: 0.7,
				bgColor: "#000000",
				bgOpacity: 0.7,
				gridType: "solid",
				dashLength: 4,
				gridColor: "#CCCCCC",
				boxPadding: 3,
				fontSize: 13,
				lineHeight: 20,
				fontColor: "#FFFFFF",
				legendShow: true,
				legendShape: "auto",
				splitLine: true,
				horizentalLine: false,
				xAxisLabel: false,
				yAxisLabel: false,
				labelBgColor: "#FFFFFF",
				labelBgOpacity: 0.7,
				labelFontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			}
		}
	}
};
// 线图
export const lineChart = (ctx, data, cWidth, cHeight) => {
	return {
		type: "line",
		context: ctx,
		width: cWidth,
		height: cHeight,
		categories: data.categories,
		series: data.series,
		animation: true,
		timing: "easeOut",
		duration: 1000,
		rotate: false,
		rotateLock: false,
		background: "#FFFFFF",
		color: ["#01B4D5", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
			"#ea7ccc"
		],
		padding: [15, 10, 0, 15],
		fontSize: 13,
		fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
		dataLabel: true,
		dataPointShape: true,
		dataPointShapeType: "solid",
		touchMoveLimit: 60,
		enableScroll: false,
		enableMarkLine: false,
		legend: {
			show: false,
			position: "bottom",
			float: "center",
			padding: 5,
			margin: 5,
			backgroundColor: "rgba(0,0,0,0)",
			borderColor: "rgba(0,0,0,0)",
			borderWidth: 0,
			fontSize: 13,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			lineHeight: 11,
			hiddenColor: "#CECECE",
			itemGap: 10
		},
		xAxis: {
			disableGrid: true,
			disabled: false,
			axisLine: true,
			axisLineColor: "#CCCCCC",
			calibration: false,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			fontSize: 13,
			lineHeight: 20,
			marginTop: 0,
			rotateLabel: false,
			rotateAngle: 45,
			itemCount: 5,
			boundaryGap: "center",
			splitNumber: 5,
			gridColor: "#CCCCCC",
			gridType: "solid",
			dashLength: 4,
			gridEval: 1,
			scrollShow: false,
			scrollAlign: "left",
			scrollColor: "#A6A6A6",
			scrollBackgroundColor: "#EFEBEF",
			title: "",
			titleFontSize: 13,
			titleOffsetY: 0,
			titleOffsetX: 0,
			titleFontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			formatter: ""
		},
		yAxis: {
			position: 'right',
			gridType: "dash",
			dashLength: 2,
			disabled: false,
			disableGrid: false,
			splitNumber: 5,
			gridColor: "#CCCCCC",
			padding: 10,
			showTitle: false,
			data: []
		},
		extra: {
			line: {
				type: "straight",
				width: 2,
				activeType: "hollow",
				linearType: "none",
				onShadow: false,
				animation: "vertical"
			},
			tooltip: {
				showBox: true,
				showArrow: true,
				showCategory: false,
				borderWidth: 0,
				borderRadius: 0,
				borderColor: "#000000",
				borderOpacity: 0.7,
				bgColor: "#000000",
				bgOpacity: 0.7,
				gridType: "solid",
				dashLength: 4,
				gridColor: "#CCCCCC",
				boxPadding: 3,
				fontSize: 13,
				lineHeight: 20,
				fontColor: "#FFFFFF",
				legendShow: true,
				legendShape: "auto",
				splitLine: true,
				horizentalLine: false,
				xAxisLabel: false,
				yAxisLabel: false,
				labelBgColor: "#FFFFFF",
				labelBgOpacity: 0.7,
				labelFontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			},
			markLine: {
				type: "solid",
				dashLength: 4,
				data: []
			}
		}
	};
};

export default {

	// 散点图 extra.scatter
	scatterChart: (ctx, data, cWidth, cHeight) => {
		return {
			type: "circle",
			context: ctx,
			width: cWidth,
			height: cHeight,
			categories: data.categories,
			series: data.series,
			fontSize: 11,
			fontColor: Vue.prototype.$theme.CHART_TEXT_COLOR,
			animation: true,
			timing: "easeOut",
			duration: 1000,
			extra: {
				scatter: {
					// type: 'group', // 分组柱状图
					// // 每根柱状的宽度
					// width: cWidth * 0.1 / data.categories.length,
					// barBorderCircle: true, // 顶部半圆
					// // linearType: "custom"
					// seriesGap: 0.5, // 每柱宽度
					// labelPosition: "insideTop", // 内顶部
				},
			},
		}
	},



}

// function Charts(ctx,data,cWidth,cHeight) {
// 	return {
// 		type: "line",
// 		context: ctx,
// 		width: cWidth,
// 		height: cHeight,
// 		categories: data.categories,
// 		series: data.series,
// 		animation: true,
// 		timing: "easeOut",
// 		duration: 1000,
// 		rotate: false,
// 		rotateLock: false,
// 		background: "#FFFFFF",
// 		color: ["#01B4D5", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
// 			"#ea7ccc"
// 		],
// 		padding: [15, 10, 0, 15],
// 		fontSize: 13,
// 		fontColor: "#666666",
// 		dataLabel: true,
// 		dataPointShape: true,
// 		dataPointShapeType: "solid",
// 		touchMoveLimit: 60,
// 		enableScroll: false,
// 		enableMarkLine: false,
// 		legend: {
// 			show: false,
// 			position: "bottom",
// 			float: "center",
// 			padding: 5,
// 			margin: 5,
// 			backgroundColor: "rgba(0,0,0,0)",
// 			borderColor: "rgba(0,0,0,0)",
// 			borderWidth: 0,
// 			fontSize: 13,
// 			fontColor: "#666666",
// 			lineHeight: 11,
// 			hiddenColor: "#CECECE",
// 			itemGap: 10
// 		},
// 		xAxis: {
// 			disableGrid: true,
// 			disabled: false,
// 			axisLine: true,
// 			axisLineColor: "#CCCCCC",
// 			calibration: false,
// 			fontColor: "#666666",
// 			fontSize: 13,
// 			lineHeight: 20,
// 			marginTop: 0,
// 			rotateLabel: false,
// 			rotateAngle: 45,
// 			itemCount: 5,
// 			boundaryGap: "center",
// 			splitNumber: 5,
// 			gridColor: "#CCCCCC",
// 			gridType: "solid",
// 			dashLength: 4,
// 			gridEval: 1,
// 			scrollShow: false,
// 			scrollAlign: "left",
// 			scrollColor: "#A6A6A6",
// 			scrollBackgroundColor: "#EFEBEF",
// 			title: "",
// 			titleFontSize: 13,
// 			titleOffsetY: 0,
// 			titleOffsetX: 0,
// 			titleFontColor: "#666666",
// 			formatter: ""
// 		},
// 		yAxis: {
// 			gridType: "dash",
// 			dashLength: 2,
// 			disabled: false,
// 			disableGrid: false,
// 			splitNumber: 5,
// 			gridColor: "#CCCCCC",
// 			padding: 10,
// 			showTitle: false,
// 			data: []
// 		},
// 		extra: {
// 			line: {
// 				type: "straight",
// 				width: 2,
// 				activeType: "hollow",
// 				linearType: "none",
// 				onShadow: false,
// 				animation: "vertical"
// 			},
// 			tooltip: {
// 				showBox: true,
// 				showArrow: true,
// 				showCategory: false,
// 				borderWidth: 0,
// 				borderRadius: 0,
// 				borderColor: "#000000",
// 				borderOpacity: 0.7,
// 				bgColor: "#000000",
// 				bgOpacity: 0.7,
// 				gridType: "solid",
// 				dashLength: 4,
// 				gridColor: "#CCCCCC",
// 				boxPadding: 3,
// 				fontSize: 13,
// 				lineHeight: 20,
// 				fontColor: "#FFFFFF",
// 				legendShow: true,
// 				legendShape: "auto",
// 				splitLine: true,
// 				horizentalLine: false,
// 				xAxisLabel: false,
// 				yAxisLabel: false,
// 				labelBgColor: "#FFFFFF",
// 				labelBgOpacity: 0.7,
// 				labelFontColor: "#666666"
// 			},
// 			markLine: {
// 				type: "solid",
// 				dashLength: 4,
// 				data: []
// 			}
// 		}
// 	};
// }