<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/zuofanhui.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.RINEI_JIAOYI}}</text>
			</view>
		</header>

		<view
			style="margin-top:36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #34393e;padding:0 12rpx;margin-bottom: 0;">
			<block v-for="(item,index) in $lang.TRADE_DAY_TABS" :key='index'>
				<view style="font-size: 28rpx;text-align: center;padding:12rpx;"
					:style="{color:curTab==index?`#fff`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<view style="text-align: center;margin: 0;">
				<image src='/static/trade_day_header.jpg' mode="widthFix" style="width: 100%;"></image>
			</view>
			<view style="padding:18px;padding-bottom: 200rpx;padding-top: 0;">
				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
					{{$lang.TRADE_DAY_TIP_INPUT_AMOUNT}}
				</view>
				<view style="padding:24rpx;">
					<view class="access_input_wrapper"
						style="background-color: transparent;padding:12rpx;border:1px solid #666;">
						<view style="padding-right: 12rpx;" :style="{color:$theme.PRIMARY}">EUR</view>
						<input v-model="amount" type="digit" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
							:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					</view>
					<template v-if="amount>0">
						<view style="padding-left: 12rpx;color:#AAA;"> USD {{$util.formatUSD(`${amount/usdToEur}`,3)}}
						</view>
					</template>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="available && available>0">
							<view class="margin-top-10 color-white" style="text-align: right;">
								{{` € `+$util.formatMoney(`${available}`,3)}}
							</view>
							<view style="color:#AAA;text-align: right;">
								{{` $ `+$util.formatUSD(`${available/usdToEur}`,3)}}
							</view>
						</template>
						<view style="text-align: right;" :style="{color:$theme.PRIMARY}" @click="linkDeposit">
							{{$lang.DEPOSIT_TITLE}}
						</view>
					</view>
				</view>
				<view style="padding-bottom: 24rpx;">
					<view class="common_btn"
						style="margin:0 auto;background-color: #03b774;color:#FFF;border-radius: 30px;width: 90%;"
						@click="handleBuy()">
						{{$lang.TRADE_DAY_BUY}}
					</view>
				</view>

				<view style="margin-top:20px;line-height: 1.5;padding:10px 0;" :style="{color:$theme.LOG_VALUE}">
					<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}</view>
					<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
						<view style="padding-bottom: 6px;font-size: 12px;">{{item}}</view>
					</block>
				</view>
			</view>
		</template>

		<!-- 申请记录和审批记录 -->
		<template v-else>
			<view style="padding:0 18px; padding-bottom: 100rpx;">
				<template v-if="!setList || setList.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(item,index) in setList" :key="index">
						<view
							style=" padding:20rpx 30rpx;border-radius: 8rpx;margin-top:24rpx;border: 1px #00a997 solid; border-radius: 10px;">
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #ccc;font-size: 12px;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
								<view :style="{color:colors[item.status]}"> {{$lang.TRADE_DAY_STATUS_APPROVAL[item.status]}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #ccc;font-size:12px;">
									{{$lang.TRADE_DAY_BUY_AMOUNT}}
								</view>
								<view>
									<view style="color: #fff;">
										{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										{{`$ `+$util.formatUSD(`${item.money/usdToEur}`,3)}}
									</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #ccc;font-size: 12px;">
									{{$lang.TRADE_DAY_SUCCESS}}
								</view>
								<view>
									<view style="color: #fff;">
										{{`€ `+$util.formatMoney(`${(item.success||0)*1}`,3)}}
									</view>
									<view style="color: #AAA;font-size: 12px;text-align: right;">
										{{`$ `+$util.formatUSD(`${(item.success||0)/usdToEur}`,3)}}
									</view>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #ccc;font-size: 12px;">
									{{$lang.TRADE_DAY_ORDER_SN}}
								</view>
								<view style="font-size: 28rpx;color: #fff;">
									{{item.ordersn}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
								<view style="color: #ccc;font-size: 12px;">
									{{$lang.TRADE_DAY_CREATE_TIME}}
								</view>
								<view style="font-size: 28rpx;padding-left: 24rpx;color:#fff;">
									{{item.created_at}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				amount: '', // 输入金额
				available: '', // 可用余额
				orderList: [], // 申请列表
				successList: [], // 通过列表
				eurToUsd: 1, // 欧转美
				usdToEur:1,//美转欧
			}
		},
		computed: {
			// 列表数据
			setList() {
				if (this.curTab == 0) return [];
				if (this.curTab > 0) {
					return this.curTab == 1 ? this.orderList : this.successList;
				}
			},
			colors() {
				return ['#FFB044', '#03B467', '#FF2D30'];
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				this.getConfig(); // 每次重新请求汇率
				if (this.curTab == 0) this.getAccountInfo(); // 账户信息
				if (this.curTab == 1) this.getOrderList();
				if (this.curTab == 2) this.getSuccessList();
			},
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			// 购买
			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TRADE_DAY_TIP_INPUT_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				// 弹层
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},

			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					this.changeTab(1);
				}, 1000);
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(result);
				this.available = result.totalZichan || 0;
			},


			// 申请列表
			async getOrderList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				if (!result) return false;
				console.log(result);
				this.orderList = result.length <= 0 ? [] : result;
				this.orderList = this.orderList.map(item=>{
					const newItem = {...item};
					if(newItem.project_type_id !== 6 && newItem.type == 1) {
						newItem.success = newItem.success*this.usdToEur; //如果是美元 则转为欧元
					}
					return newItem;
				})
				console.log(this.orderList,2346)
				
			},

			// 审批结果列表
			async getSuccessList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/order-list`);
				if (!result) return false;
				console.log(result);
				this.successList = result.length <= 0 ? [] : result;
				this.successList = this.successList.map(item=>{
					const newItem = {...item};
					if(newItem.project_type_id !== 6 && newItem.order_id !== null && newItem.order_id > 0) {
						newItem.success = newItem.success*this.usdToEur; //如果是美元 则转为欧元
					}
					return newItem;
				})
				console.log(this.successList,111)
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				// this.eurToUsd = temp.get('usd_eur') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>