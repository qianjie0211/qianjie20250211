<template>
	<view style="background-color: #000;min-height: 100vh;">

		<view>
			<HeaderSecond :title="$lang.TRADE_HOLD_DETAIL_TITLE"></HeaderSecond>
		</view>

		<view class="padding-10 radius10 bg-white margin-10" v-if="order.order_buy">
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Name</view>
				<view style="color:#00AA98;font-size: 28rpx;">{{order.goods_info.name}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Price</view>
				<view style="color:#00AA98;font-size: 28rpx;">{{$util.formatCoin(order.order_buy.price,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Buy Num</view>
				<view style="color:#333333;font-size: 28rpx;">{{order.order_buy.num}}
				</view>
			</view>

			<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Buy Num</view>
				<view style="color:#333333;font-size: 28rpx;">{{order.order_buy.old_num}}
				</view>
			</view> -->

			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Pay Money</view>
				<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(order.order_buy.user_pay,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Profit and Loss</view>
				<view style="font-size: 28rpx;" :style="order.order_buy.yingkui>0?'color:#00AA98;':'color:red;'">
					{{$util.formatCoin(order.order_buy.yingkui,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Overnight Fee</view>
				<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(order.order_buy.gy_fee||0,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				v-if="order.order_buy.zhiying>0">
				<view style="color:#666666;">Take Profit</view>
				<view style="color:#00AA98;font-size: 28rpx;">{{$util.formatCoin(order.order_buy.zhiying||0,3)}}
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				v-if="order.order_buy.zhisun>0">
				<view style="color:#666666;">Stop Loss</view>
				<view style="color:red;font-size: 28rpx;">{{$util.formatCoin(order.order_buy.zhisun||0,3)}}
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
				<view style="color:#333333;font-size: 28rpx;">{{order.order_sn}}</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Time</view>
				<view style="color:#333333;font-size: 28rpx;">{{order.buy_time}}
				</view>
			</view>
			<view>
				<view class="flex" @tap.stop="handleSell(info.id)">
					<view class="flex-1 text-center padding-10 color-white margin-top-10 radius10"
						style="background-color: crimson;">Sell</view>
				</view>

				<!-- <view class="flex" @click="if_yingsun=true" >
					<view class="flex-1 text-center padding-10 color-white margin-top-10 radius10" style="background-color: #00AA98;" >Take Profit and Stop Loss</view>
				</view> -->
			</view>

		</view>
		<view class="text-center margin-top-20 bold font-size-16">Sell ​​History</view>



		<!-- <template v-if="!order.order_sell || order.order_sell.length<=0">
			<EmptyData></EmptyData>
		</template>
		
		<view class="padding-10 radius10 bg-white margin-10" v-if="order.order_buy" v-for="(item,index) in order_sell">
			
			
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Price</view>
				<view style="color:#00AA98;font-size: 28rpx;">{{$util.formatCoin(item.price,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Quantity Available</view>
				<view style="color:#333333;font-size: 28rpx;">{{item.num}}
				</view>
			</view>
			
			
			
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">lump sum</view>
				<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.amount,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Profit and Loss</view>
				<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.yingkui,3)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Fee</view>
				<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.sell_fee||0,3)}}
				</view>
			</view>
		
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
				<view style="color:#666666;">Time</view>
				<view style="color:#333333;font-size: 28rpx;">{{order.created_at}}
				</view>
			</view>
		</view> -->

		<!-- <u-modal :show="if_yingsun"  title="Sell" confirmText="Confirm" cancelText="Cancel" :showCancelButton="true" @cancel="if_yingsun=false" @confirm="confirmYingsun">
			
			<view style="width: 100%;">
				<view>Take Profit Price</view>	
				<u--input class="margin-top-10" placeholder="Please enter Take Profit" border="surround" v-model="zhiying" type="digit"></u--input>
				
				<view>Stop Loss</view>
				<u--input class="margin-top-10" placeholder="Please enter Stop Loss" border="surround" v-model="zhisun" type="digit"></u--input>
				
			</view>
		</u-modal> -->


		<!-- <u-modal :show="show"  title="Sell" confirmText="Confirm" cancelText="Cancel" :showCancelButton="true" @cancel="show=false" @confirm="confirmSell">
			
			<view style="width: 100%;">
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;" class="margin-bottom-10">
					<view style="color:#666666;">Current Price</view>
					<view style="color:#333333;font-size: 28rpx;">{{current}}
					</view>
				</view>
				<u-radio-group v-model="radiovalue1" placement="row" @change="groupChange">
					<u-radio :customStyle="{marginRight: '48rpx'}" v-for="(item, index) in radioList" :key="index"
						:label="item.name" :name="item.name" @change="radioChange" :activeColor="$theme.PRIMARY"
						labelSize="28rpx" :labelColor="item.name==radiovalue1?$theme.PRIMARY:'#CFCFCF' ">
					</u-radio>
				</u-radio-group>
				限价模式，输入金额
				<template v-if="isShowAmountInput">
					
					<u--input
						class="margin-top-10" :placeholder="$lang.COIN_BAY_ENTER_AMOUNT" border="surround" v-model="price"></u--input>
				</template>
				<u--input class="margin-top-10" placeholder="Please enter quantity" border="surround" v-model="num" ></u--input>
			</view>
		</u-modal> -->

	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData
		},
		data() {
			return {
				id: 0, // url传入值
				info: {},
				order: {},
				show: false,
				num: "",
				radiovalue1: 'Market Price',
				price: "",
				current: "",
				if_yingsun: false,
				zhiying: "",
				zhisun: ''
			}
		},
		computed: {
			// 单选项的选项组
			radioList() {
				return [{
					name: 'Market Price',
					disabled: false
				}, {
					name: 'Limit Price',
					disabled: false
				}];
			},
			// 当前交易模式
			isShowAmountInput() {
				return this.radiovalue1 == this.radioList[1].name;
			},
		},
		onLoad(opt) {
			this.id = opt.id || 0;
			// this.connect()
		},
		onShow() {
			this.getData();
		},
		methods: {
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.order.goods_info.code == data.market && data.lastPrice > 0) {
						// console.log('data:', data);
						this.current = data.lastPrice || 0;


					}
				});
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1 = n;
			},

			groupChange(n) {
				console.log('groupChange', n);
				this.radiovalue1 = n;
			},
			// async confirmYingsun(){
			// 	// if(this.zhiying<=0){
			// 	// 	uni.$u.toast('Please enter Take Profit Price');
			// 	// 	return
			// 	// }
			// 	// if(this.zhisun<=0){
			// 	// 	uni.$u.toast('Please enter Stop Loss Price');
			// 	// 	return
			// 	// }
			// 	if(this.zhisun<=0&&this.zhiying<=0){
			// 		// uni.$u.toast('Must set one');
			// 		// return
			// 		this.zhiying="";
			// 		this.zhisun="";
			// 	}
			// 	const result = await this.$http.post(`api/user/yingsun`, {
			// 		id:this.id,
			// 		zhiying:this.zhiying,
			// 		zhisun:this.zhisun,
			// 	});
			// 	if (!result) return false;
			// 	this.if_yingsun=false;
			// 	this.getData();
			// },

			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell();
				}
			},
			// 平仓功能
			async confirmSell() {
				const result = await this.$http.post(`api/user/sell`, {
					id: this.id,
				});
				if (!result) return false;
				// if (result.code == 0) {
				// 	// this.getData()
				// 	uni.$u.toast(result.message);
				// } else {
				// 	uni.$u.toast(result.message);
				// }
				uni.showToast({
					title: '',
					icon: 'success'
				})
				setTimeout(() => {
					this.actionEvent()
				}, 1000)
			},

			// // 平仓功能
			// async confirmSell() {
			// 	console.log(this.num);

			// 	if(this.num<=0||!this.num){
			// 		uni.$u.toast('Please enter quantity');
			// 		return
			// 	}

			// 	if (this.isShowAmountInput) {
			// 		if (this.price == '' || this.price <= 0) {
			// 			uni.$u.toast(this.$lang.COIN_BAY_ENTER_AMOUNT);
			// 			return false;
			// 		}
			// 	}

			// 	const result = await this.$http.post(`api/user/sell`, {
			// 		id:this.id,
			// 		num:this.num,
			// 		fx: this.isShowAmountInput ? 2 : 1,
			// 		price:this.price
			// 	});
			// 	if (!result) return false;
			// 	this.getData();
			// },
			async getData() {
				const result = await this.$http.get(`api/user/order_info`, {
					id: this.id
				});
				console.log(1111, result);

				this.order = result
				this.order_sell = result.order_sell
				this.price = result.goods_info.current_price

				this.current = result.goods_info.current_price
				this.show = false
				this.zhiying = result.order_buy.zhiying;
				this.zhisun = result.order_buy.zhisun;
				console.log(`result:`, result);
			}
		}
	}
</script>

<style>

</style>