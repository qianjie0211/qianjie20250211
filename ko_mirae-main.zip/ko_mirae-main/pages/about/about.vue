<!-- 关于我们 -->
<template>
	<view class="common_page_bg2" style="min-height: 100vh;">
		<CustomHeader :title="about.title" @action="handleBack()"></CustomHeader>

		<view class="common_block" style="background-color: rgba(255,255,255,0.35);margin:30rpx;padding: 30rpx;">
			<view style="color: #181945;line-height: 1.6;" v-html="about.content"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				about: ''
			};
		},
		mounted() {
			this.about_us()
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/about-us', {});
				this.about = list.data.data
			},
		},
	}
</script>