<template>
	<view style="min-height: 100vh;padding:0rpx 36rpx;">
		<view style="padding: 20px 0px;">
			<view class="flex" >
				<image src="/static/zuofanhui.png" mode="aspectFit" :style="$theme.setImageSize(40)" @click="linkBack()"></image>
				
				<text class="flex-1 text-center" style="color: #FFFFFF;font-size: 20px;">{{$lang.GENDAN}}</text>
			</view>
		</view>
		
		<header class="header_bg">
			<view style="padding:20rpx 40rpx;">
				<view style="font-size: 36rpx;color: #FFFFFF;padding: 16rpx 0;">
					{{$lang.FOF_TITLE.toUpperCase()}}
				</view>
				<view
					style="color:#FFFFFF;font-size: 20rpx;background-color: #03b874;border-radius: 26rpx;padding:6rpx 16rpx;width: max-content;"
					@tap="linkFOF()">{{$lang.FOF_BTN_VIEW}}</view>
			</view>
		</header>
		<!-- search -->
		<view style=" background-color: #25262A;border-radius: 32rpx;padding:12rpx 24rpx;margin-top: 40rpx;">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<input v-model="keyword" type="text" :placeholder="$lang.TRADE_COPY_SEARCH_TIP"
					:placeholder-style="$util.setPlaceholder()"></input>
				<view style="" @tap="handleSearch()">
					<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				</view>
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 40rpx;">
			<block v-for="(item,index) in tabs" :key="index">
				<view :style="setStyle(curTab==index)" @tap="changeTab(index)">
					<view>
						<view style="display: flex;align-items: center;justify-content: space-around;">
							<view>{{item}}</view>
							<image :src="`/static/arrow_${curTab==index?curSort==1?`down_1`:`up_1`:`down_0` }.png`"
								mode="aspectFit" style="padding-left: 12rpx;" :style="$theme.setImageSize(14,20)">
							</image>
						</view>
					</view>
				</view>
			</block>
		</view>
		<view style="padding:40rpx 0;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view
						style="border: 1px solid #3F3F40;padding:32rpx 26rpx;margin-bottom: 20rpx;border-radius: 8rpx;">
						<view style="display: flex;align-items: center;">
							<view style="flex:0 0 6%">
								<image src="/static/logo.jpg" mode="aspectFit" :style="$theme.setImageSize(80)">
								</image>
							</view>
							<view style="flex:0 0 88%;">
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-left: 20rpx;">
									<view style="font-size: 26rpx;" :style="{color:$theme.WHITE}">{{item.name}}
									</view>
									<view style="margin-left: auto;padding:2rpx 8rpx;border-radius: 4rpx;"
										:style="{backgroundColor:$theme.RGBConvertToRGBA($theme.SECOND,20)}">
										<text style="font-size: 24rpx;"
											:style="{color:$theme.SECOND}">{{item.pingfen.split('/')[0]}}</text>
										<text
											style="color:#C9C9C9;font-size: 20rpx;">/{{item.pingfen.split('/')[1]}}</text>
									</view>
								</view>
								<view style="display: flex;align-items: center;padding-left: 20rpx;padding-top: 12rpx;">
									<image :src="`/static/flags/${item.guojia}.svg`" mode="scaleToFill"
										style="border-radius: 8rpx;" :style="$theme.setImageSize(56,48)">
									</image>
									<view style="padding-left: 10rpx;color:#8E8D92;font-size: 24rpx;">
										{{item.tip}}
									</view>
								</view>
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view>
								<view style="font-size: 24rpx;line-height: 1.8;">
									<text
										style="color:#8E8D92;padding-right: 20rpx;">{{$lang.TRADE_COPY_FOLLOWERS}}</text>
									<text style="color:#FFFFFF;">{{item.gentoushu}}</text>
								</view>
								<view style="font-size: 24rpx;line-height: 1.8;">
									<text style="color:#8E8D92;padding-right: 20rpx;">{{$lang.TRADE_COPY_RATE}}</text>
									<text :style="{color:item.zongshouyilv*1>0?$theme.RISE:$theme.FALL}">
										{{`${item.zongshouyilv>0?'+':'-'}`+  item.zongshouyilv+` %`}}
									</text>
								</view>
								<view style="font-size: 24rpx;line-height: 1.8;">
									<text style="color:#8E8D92;padding-right: 20rpx;">{{$lang.TRADE_COPY_TOTAL}}</text>
									<text style="color:#FFFFFF;">{{item.zongshouyi*1}}</text>
								</view>
							</view>
							<view style="margin-left: auto;">
								<image :src="`/static/line_${item.zongshouyilv>0?'rise':'fall'}.png`" mode="scaleToFill"
									:style="$theme.setImageSize(280,100)"></image>
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="font-size: 24rpx;">
								<text
									style="color:#8E8D92;padding-right: 20rpx;">{{$lang.TRADE_COPY_TOTAL_AMOUNT}}</text>
								<text style="color:#FFFFFF;">{{item.gentouzong+` USD`}}</text>
							</view>
							<view style="margin-left: auto;" @tap="linkDetail(item.id)">
								<view
									style="border-radius:50rpx;background-color: #03b874;color:#FFFFFF;padding:6rpx 24rpx;font-size: 24rpx;text-align: center;">
									{{$lang.TRADE_COPY_BTN_COPY}}
								</view>
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData
		},
		data() {
			return {
				keyword: '', // search value
				curTab: 0, // current tab
				list: [], // 列表数据
				curSort: 1, // 当前排序模式
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_COPY_FOLLOWERS,
					this.$lang.TRADE_COPY_RATE,
					this.$lang.TRADE_COPY_WIN
				]
			},
		},
		onShow() {
			this.getList();
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				if (this.curTab == val) {
					// 如果点击同一个，就改变排序状态
					this.curSort = this.curSort == 1 ? 0 : 1
				} else {
					this.curTab = val;
					this.curSort = 1; // 如果切换tab，默认降序
				}
				this.getList();
			},
			// 跳转到详情
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.TRADE_COPY_DETAIL + `?id=${val}`
				});
			},
			// 跳转到FOF
			linkFOF() {
				uni.switchTab({
					url: '/pages/trade/copy/fof',
				})
			},
			linkBack() {
				// 默认回退一级
				uni.switchTab({
					url:'/pages/home'
				})
			},

			// 搜索
			handleSearch() {
				this.getList();
			},

			async getList() {
				const result = await this.$http.post(`api/gentouea/gentoulist`, {
					type: this.curTab + 1,
					name: this.keyword,
					paixu: this.curSort == 1 ? 'desc' : 'asc'
				});
				if (!result) return false;
				// console.log(`result:`, result);
				this.list = result;
				this.list.forEach(item => {
					// 处理 +123% -123%
					item.zongshouyilv = item.zongshouyilv.split('%')[0] * 1
				})
			},

			// tabs style
			setStyle(val) {
				return {
					fontSize: `24rpx`,
					textAlign: `center`,
					borderRadius: `32rpx`,
					padding: `8rpx 16rpx`,
					color: val ? this.$theme.SECOND : this.$theme.WHITE,
					border: `1px solid ${val ? this.$theme.SECOND : '#3B3B3D'}`,
					backgroundColor: val ? this.$theme.RGBConvertToRGBA(this.$theme.SECOND, 14) : this.$theme.TRANSPARENT,
					minWidth: `180rpx`,
				}
			},
		}
	}
</script>

<style>
	.header_bg {
		background-image: url(/static/trade_copy_header.png);
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: 100%;
		width: 100%;
		height: 160rpx;
	}
</style>