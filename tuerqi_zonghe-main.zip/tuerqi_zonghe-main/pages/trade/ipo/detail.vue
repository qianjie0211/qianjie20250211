<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="type==2?$lang.TRADE_IPO_TITLE:$lang.X_G_S_G" :color="$theme.SECOND"></HeaderSecond>
		</view>
		<view style="padding-top: 20rpx;padding-bottom: 200rpx;">
			<view class="common_block" style="border-radius: 24rpx;">
				<template v-if="!info">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<view style="display: flex;align-items: center;">
						<CustomLogo :logo="info.goods.logo" :name="info.goods.name"></CustomLogo>
						<view style="padding-left: 20rpx;font-size: 32rpx;" :style="{color:$theme.SECOND}">
							{{info.goods.name}}
						</view>
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;margin-top: 40rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_TOTAL}}</view>
						<view :style="{color:$theme.SECOND}">{{info.fa_amount}}</view>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IEO_LIST_TOTAL}}</view>
						<view :style="{color:$theme.SECOND}">{{info.total}}</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_PRICE}}</view>
						<view :style="{color:$theme.SECOND}">{{info.price}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_CT}}</view>
						<view :style="{color:$theme.SECOND}">{{info.gb_date}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_DETAIL_URL}}</view>
						<view>
							<view style="display: flex;align-items: center;">
								<view style="color:#018ef8;padding-left: 20rpx;" @tap="openURL(info.baipishu)">
									{{info.goods.name.split('/')[0]}}
								</view>
							</view>
						</view>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_DETAIL_WEBSITE}}</view>
						<view>
							<view style="display: flex;align-items: center;">
								<view :style="{color:$theme.SECOND}">{{info.guanwang}}</view>
								<view style="color:#018ef8;padding-left: 20rpx;" @tap="handleCopy(item.guanwang)">
									{{$lang.COMMON_COPY}}
								</view>
							</view>
						</view>
					</view> -->

					<!-- <view style="font-size: 28rpx;font-weight: 700;margin-top: 40rpx;" :style="{color:$theme.SECOND}">
						{{$lang.TRADE_IPO_DETAIL_COIN_DESC}}
					</view> -->
					<view style="margin-top: 40rpx;border-top: 1px solid #F5F6FB;padding-top: 20rpx;">
						<view v-html="info.jianjie"></view>
					</view>
					<!-- <view style="line-height: 1.6;word-wrap: break-word;">
						{{$lang.API_EMPTY_CONTENT}}
					</view> -->
				</template>
			</view>
		</view>

		<view style="position: fixed;bottom:0;left: 0;right: 0;background-color: #FFFFFF;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleBuy()">
				{{$lang.COMMON_BUY}}
			</view>
		</view>

		<!-- 购买的弹层 -->
		<template v-if="isShow">
			<BuyModal :info="buyInfo" @action="handleClose"></BuyModal>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	
	import BuyModal from './components/BuyModal.vue';
	export default {
		components: {
			HeaderSecond,

			BuyModal,
		},
		data() {
			return {
				id: '',
				info: null,
				isShow: false, //显示购买设置
				buyInfo: {}, // buy modal 所需
			}
		},
		computed: {
			setTitle() {
				return !this.info ? this.$lang.TRADE_IPO_DETAIL_TITLE : this.info.goods.name;
			}
		},
		onLoad(opt) {
			console.log(`opt`, opt);
			this.id = opt.id || '';
		},
		onShow() {
			this.isAnimat = true;
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getData();
			uni.stopPullDownRefresh();
		},
		methods: {
			handleClose(val) {
				this.isShow = false;
				this.getData();
			},
			openURL(val) {
				window.open(val)
			},
			// async handleCopy(val) {
			// 	const result = await uni.setClipboardData({
			// 		data: val, //要被复制的内容
			// 	});
			// 	if (result[1].confirm) {
			// 		uni.showToast({
			// 			title: this.$lang.COMMON_COPY_SUCCESS,
			// 			duration: 2000,
			// 			icon: 'success'
			// 		})
			// 	}
			// },

			async handleBuy() {
				this.isShow = true;
				this.buyInfo = {
					id: this.info.id,
					name: this.info.goods.name,
					price: this.info.price,
				}
			},

			async getData() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/goods-shengou/detail`, {
					id: this.id
				});
				if (!result) return false;
				console.log(`result`, result);
				this.info = result;
			}
		}
	}
</script>

<style>
</style>