<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #FFFFFF; padding:20rpx 30rpx;border-radius: 28rpx;margin:0 20rpx 20rpx 20rpx;">
				
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>{{$lang.LOG_TRADE_AMOUNT_AFTER}}</view>
					<view :style="{color:$theme.RISE}">{{$util.formatMoney(item.after)}} {{$lang.CURRENCY_UNIT}}</view>
				</view>
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>{{$lang.LOG_TRADE_AMOUNT_BEFORE}}</view>
					<view :style="{color:$theme.RISE}">{{$util.formatMoney(item.before)}} {{$lang.CURRENCY_UNIT}}</view>
				</view>
				
				<view class="flex flex-b" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>{{$lang.LOG_TRADE_DW}}</view>
					<view :style="{color:$theme.RISE}" >{{$util.formatMoney(item.money)}} {{$lang.CURRENCY_UNIT}}</view>
				</view>
				<view class="hui1" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>논평 :</view>
					<view class="text-right" style="">{{item.desc}}</view>
				</view>
				<view class="flex flex-b hui1" style="border-bottom: 1px #f5f5f5 solid;line-height: 2.5">
					<view>{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view>{{item.created_at}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		computed: {},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.get(`api/user/finance`);
				this.list = result || [];
			},
		}
	}
</script>

<style>

</style>