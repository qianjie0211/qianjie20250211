<template>
	<view style="">
		
		<!-- <view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-image: url(/static/chicang_top.png);">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view> -->
		<view style="padding: 0px 10px;">
		<view style="border: 1px #e9b069 solid;border-radius: 5px; padding: 10px;background-color: #fff;">
			<view class="flex flex-b">
				<view style="line-height: 1.6;">
					<view class="flex">
						<view class="hui1 ">총자산</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
							@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
						</image>
					</view>
					
					<view class="bold " style="font-size: 18px;color: #e9b069;">{{showAmount?$util.formatMoney(userInfo.totalZichan):hideAmount}}</view>
				</view>
				<view style="line-height: 1.6;">
					<view class="text-right hui1">운용 자금</view>
					<view class="bold " style="font-size: 18px;">{{showAmount?$util.formatMoney(userInfo.money):hideAmount}}</view>
				</view>
			</view>
			
			<view class="flex flex-b margin-top-15">
				<view style="line-height: 1.6;"> 
					<view class="hui1 ">평가수익금</view>
					<view>{{showAmount?$util.formatMoney(userInfo.holdYingli):hideAmount}}</view>
				</view>
				<view class="text-center" style="line-height: 1.6;">
					<view class="hui1">매입금액</view>
					<view style="color: #e9b069;">{{showAmount?$util.formatMoney(userInfo.frozen):hideAmount}}</view>
				</view>
				<view style="line-height: 1.6;">
					<view class=" hui1 text-right">실현손익</view>
					<view style="color: #e9b069;">{{showAmount?$util.formatMoney(userInfo.totalYingli):hideAmount}}</view>
				</view>
			</view>
		</view>
		</view>

		

		
			</view>
		</view>
	</view>
</template>

<script>
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'AccountTradeInfo',
		components: {
			CardItemThird,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				cardData: {}, // 资产相关数据
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT
				];
			},
			// 是否显示饼图
			isPieChart() {
				return this.cardData && Object.keys(this.cardData).length > 0;
			}
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			// 入金 提款 按钮样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#F8F8F8' : this.$theme.SECOND,
					borderRadius: `24rpx`,
					padding: `24rpx 0`,
					width: `280rpx`,
				}
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan * 1, // 
					value2: this.userInfo.money, // 
					value3: this.userInfo.freeze, // 
				};
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>