import http from '@/common/http.js';

const POST = 'POST';

// 登录
export const postSignIn = (data, title) => http(`app/login`, {
	method: POST,
	data,
	title
});
// 注册 创建账户
export const postSignUp = (data, title) => http(`app/register`, {
	method: POST,
	data,
	title
});
// 登出 
export const signOut = () => http(`app/logout`);

// 获取APP config
export const getAPPConfig = () => http(`app/config`);
// 用户信息
export const accountInfo = () => http(`api/user/bindBankCard`);
// 可用金额
export const userFastInfo = () => http(`user/fastInfo`);
// 变更登入密码
export const putSignInPwd = (data) => http(`user/updateLoginPassword`, {
	method: POST,
	data
});

// 绑定银行卡
export const bindBankCard = (data) => http(`user/bindBankCard`, {
	method: POST,
	data
});
// 提款
export const postWithdarw = (data) => http(`app/withdraw`, {
	method: POST,
	data
});
// 入金
export const postDeposit = (data) => http(`app/recharge`, {
	method: POST,
	data
});

// 资金明细
export const getAccountFinance = () => http(`user/finance`);
// 充值记录
export const getAccountDeposit = () => http(`user/recharge`);
// 提现记录
export const getAccountWithdraw = () => http(`user/withdraw`);
// 取消 提现记录中使用
export const postCancelWithdraw = () => http('app/qx', {
	method: POST,
	data
});
// 持股和卖出 的订单
export const getTradeList = (data) => http(`user/order`, {
	data,
	hide: true,
});
// 卖出
export const postStockSell = (data, title) => http(`user/sell`, {
	method: POST,
	data,
	title
});

// 获取股票列表
export const getStockList = (data) => http(`goods/list`, {
	data,
	hide: true,
});
// 获取关注的股票列表
export const getFollowList = () => http(`user/collect_list`, {
	hide: true,
});
// 取消关注
export const updateFollow = (data) => http(`user/collect_edit`, {
	method: POST,
	data
});

// 股票详情
export const getStockInfo = (data) => http(`product/info`, {
	data,
	hide: true
});

// 单股 K线数据
export const getKLineData = (data) => http(`product/lishi`, {
	data,
	hide: true
});
// 单股购买
export const postStockBuy = (data) => http(`product/purchase`, {
	method: POST,
	data
});

// 查询页面 根据股票名称或代码查询
export const postSearchList = (data) => http(`product/list`, {
	data
});

// IPO交易 列表
export const getIPOList = (data) => http(`goods-shengou/calendar`, {
	data
});
// IPO 交易 申购
export const postBuyIPO = (data) => http(`goods-shengou/doOrder`, {
	method: POST,
	data
});
// IPO交易，交易记录
export const getIPOOrderLog = () => http(`goods-shengou/user-order-log`);
// IPO交易 成功列表
export const getIPOSuccessList = (data) => http(`goods-shengou/user-success-log`, {
	data
});
// IPO 交易 支付
export const postIPOPay = (data) => http(`goods-shengou/pay`, {
	method: POST,
	data
});

// 隐私
export const getPactInfo = () => http(`article/privacy`);
// 用户协议
export const getAgreeInfo = () => http(`article/user-agree`);