<template>
	<view class="launch" style="background-color: #202328;">
		<view>
			<image src='/static/logo.png' :style="$util.setImageSize(360)" style="margin-bottom: 50px;" mode="widthFix">
			</image>
		</view>
		
		<view style="color: #fff;font-size: 18px;margin-top: -20px;">TFG Asset Managemen</view>
		
		<view class="launch_progress">
			<u-line-progress :percentage="percentage" height="15" activeColor="#16e2e2"
				:showText="false"></u-line-progress>
		</view>

		<view class="launch_tip">
			{{`${$lang.STATUS_LOADING} `}}
			(<u-count-to :startVal="1" :endVal="percentage" :duration="1500" :useEasing="true" fontSize="16"
				:color="$theme.PRIMARY"></u-count-to> {{` % `}})
		</view>

		
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 1, // 进度条初始值
			}
		},
		onLoad() {
			uni.$u.sleep(1800).then(() => {
				this.percentage = 100;
				//跳转到首页 缓一秒，否则看不到进度条加满效果
				uni.$u.sleep(1500).then(() => {
					uni.switchTab({
						url: HOME,
					})
				})
			})
		},
	}
</script>
