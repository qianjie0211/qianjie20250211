<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.TRADE_ISSUANCE_TITLE}}</text>
			</view>
		</header>

		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#1C1C1C`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<TradeIssuanceList :list="list" @action="showBuy"></TradeIssuanceList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIssuanceRecord :list="record"></TradeIssuanceRecord>
		</template>
		<template v-else>
			<TradeIssuanceSuccess :list="successList"></TradeIssuanceSuccess>
		</template>

		<template v-if="isShow">
			<TradeIssuanceBuy :info="itemInfo" @action="handleClose"></TradeIssuanceBuy>
		</template>
	</view>
</template>

<script>
	import TradeIssuanceList from './components/TradeIssuanceList.vue';
	import TradeIssuanceRecord from './components/TradeIssuanceRecord.vue';
	import TradeIssuanceSuccess from './components/TradeIssuanceSuccess.vue';
	import TradeIssuanceBuy from './components/TradeIssuanceBuy.vue';
	export default {
		components: {
			TradeIssuanceList,
			TradeIssuanceRecord,
			TradeIssuanceSuccess,
			TradeIssuanceBuy,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				list: [],
				record: [],
				successList: [],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		computed: {
			tabs() {
				return [`공모주청약`, `신청 내용`, `거래 내역`]
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getList();
				if (this.curTab == 1) this.getRecordList();
				if (this.curTab == 2) this.getSuccessList();
			},
			// 显示购买弹层
			showBuy(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				this.changeTab(val);
			},


			async getSuccessList() {
				const result = await this.$http.get(`api/goodsscramble/userSuccessLog`);
				if (!result) return false;
				console.log(result);
				this.successList = result;
			},

			async getRecordList() {
				const result = await this.$http.get(`api/goodsscramble/userApplyLog`);
				if (!result) return false;
				console.log(result);
				this.record = result;
			},

			async getList() {
				this.list = []; // 请求前清除数据。
				const result = await this.$http.get(`api/goods-scramble/calendar`)
				if (!result) return false;
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
						zhekou: item.zhekou,
					}
				});
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>