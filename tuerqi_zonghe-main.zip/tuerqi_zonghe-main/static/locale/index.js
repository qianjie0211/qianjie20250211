import enUS from './en-US.js';
import zhHK from './zh-hant.js';
// import zhCN from './zh-hans.js';
import jaJP from './ja-JP.js';
// import koKR from './ko-KR.js';
import Arabic from './Arabic.js';
import French from './French.js';
import Portuguese from './Portuguese.js';
import Spanish from './Spanish.js';
import Russian from './Russian.js';
import Türkçe from './Türkçe.js';
import itIT from './it-IT.js';

// 到处前，根据项目需求，注释不需要的语言包。
// 注意：此处需与`Translate`中定义的数组对应。
export default {
	'en-US': enUS, // 英语
	'zh-hant': zhHK, // 繁中
	// 'zh-CN': zhCN, // 简中
	// 'ko-KR': koKR, // 韩语
	'ja-JP': jaJP, // 日语
	'fr-FR': French, // 法语
	'ar-IL': Arabic, // 阿拉伯语
	'pt-BR': Portuguese, // 葡萄牙语
	'es-ES': Spanish, // 西班牙语
	'ru-RU': Russian, // 俄语
	'tu-TK': Türkçe, // 土耳其语
	'it-IT': itIT, // 意大利
};