<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<HeaderSecond :title="$lang.FORGOT_TITLE" :color="$theme.SECOND"></HeaderSecond>

		<view style="margin: 20px;">
			<TitlePrimary :title="$lang.FORGOT_ACCOUNT"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px Solid #E8EAF3;border-radius: 16rpx;padding-left: 30rpx;background-color: transparent;">
				<input v-model="account" type="text" :placeholder="$lang.FORGOT_ACCOUNT"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.PASSWORD_NEW"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px Solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<template v-if="isShow">
					<input v-model="pwd" type="text" :placeholder="$lang.PASSWORD_ENTER_NEW"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="pwd" type="password" :placeholder="$lang.PASSWORD_ENTER_NEW"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitlePrimary :title="$lang.PASSWORD_VERIFY"> </TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px Solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<template v-if="isShow">
					<input v-model="pwd2" type="text" :placeholder="$lang.PASSWORD_ENTER_VERIFY"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="pwd2" type="password" :placeholder="$lang.PASSWORD_ENTER_VERIFY"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitlePrimary :title="$lang.FORGOT_VERIFY_CODE"></TitlePrimary>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px Solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: transparent;">
				<input v-model="vetifyCode" type="text" :placeholder="$lang.FORGOT_VERIFY_CODE" maxlength="11"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;">

				<view class="radius10 color-white" style="background-color: #3180ff;padding: 2px 10px;" @tap="getCode">
					{{tips}}
				</view>
				<u-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange" startText="Send"
					changeText="X" endText='Send'></u-code>
				</input>
			</view>
		</view>
		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		components: {
			HeaderSecond,
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false,
				account: '', // 账户
				pwd: '', // 新密码
				pwd2: '', // 确认密码
				vetifyCode: '', // 验证码
				isShow: false, // 密码显隐
				seconds: 60,
				tips: 'Send',
			};
		},
		computed: {},
		onLoad() {

		},
		onShow() {
			this.isAnimat = true;
			this.isShow = uni.getStorageSync('show'); // 密码显隐
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				return !emailPattern.test(val)
			},
			codeChange(text) {
				this.tips = text;
			},
			async getCode() {
				if (this.checkEmail(this.account)) {
					uni.$u.toast(this.$lang.TIP_ENTER_EMAIL);
					return false;
				}
				if (!this.account || this.account == '') {
					uni.$u.toast(this.$lang.TIP_ENTER_EMAIL);
					return false;
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: this.$lang.GET_SEND_CODE
					})
					const result = await this.$http.post(`api/app/sendSmsCode`, {
						mobile: this.account,
					})
					uni.hideLoading()
					console.log('result:', result);
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
				} else {
					uni.$u.toast('Send after the countdown ends');
				}
			},
			end() {
				// uni.$u.toast('倒计时结束');
			},
			start() {
				// uni.$u.toast('倒计时开始');
			},

			checkForm() {
				if (this.account == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_EMAIL,
						icon: 'none',
					});
					return false;
				}
				if (this.pwd == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (this.pwd2 == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (this.pwd2 != this.pwd) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (this.vetifyCode == '') {
					uni.showToast({
						title: this.$lang.FORGOT_VERIFY_CODE,
						icon: 'none'
					});
					return false;
				}
				return true;
			},

			// 提交
			async handleSubmit() {
				if (this.checkForm()) {
					const result = await this.$http.post(`api/app/forget`, {
						mobile: this.account,
						password: this.pwd,
						code: this.vetifyCode,
					});
					if (!result) return false;
					setTimeout(() => {
						uni.navigateTo({
							url: this.$paths.ACCOUNT_ACCESS
						})
					}, 1000)
				}
			},
		}
	}
</script>

<style>
</style>