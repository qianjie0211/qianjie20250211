<!-- 股票详情 -->
<template>
	<view>
		<view>
			<!-- <HeaderSecond :title="!info?'': info.name"></HeaderSecond>  -->
			<view class="flex padding-20">
				<view @click="chongzhi()">
					<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.MAIRU_XIANGQING}}</view>
			</view>
		</view>
		<view style="padding-top: 1vh;padding-bottom: 20px;">
			<template v-if="info">
				<StockInfo :info="info"></StockInfo>

				<view style="padding:10px;">

					<view :style="{display:curTab==0?'block':'none' }">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
							<block v-for="(item,index) in tabs" :key="index">
								<view style="text-align: center;font-size: 32rpx;border-radius: 10px;"
									:style="{color:curKLine==index? '#FFFFFF':'#666666'}"
									@click="handleShowKLine(index)">
									{{item}}
								</view>
							</block>
						</view>
						<view class="chart" id="kline-stock" style="width: 100%;height: 1000rpx;">
						</view>
					</view>

					<!-- 8和9是指标 指标是不能购买 -->
					<template v-if="info.project_type_id<8">
						<view class="padding-10 text-center"
							style="margin:20px auto; width:90%;background-color: #02b975;border-radius: 10px;color: #fff;"
							@click="purchase()">
							{{$lang.BTN_BUY}}
						</view>
					</template>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import StockInfo from './components/StockInfo.vue';

	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea,
		klineCandle
	} from '@/common/klineConfig.js';

	export default {
		components: {
			HeaderSecond,
			StockInfo,
		},
		data() {
			return {
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				gid: "",
				info: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				timer: null,
				curType: 0, // 当前弹层模式[0买|1卖]
				indicator: null, // 技术指标
			};
		},
		computed: {
			// header title
			setTitle() {
				if (this.info) {
					return this.info.name || 'XAU';
				}
			},
			// 时间
			tabs() {
				return ['1m', "5m", "15m", "30m", "1D", "1W", "1M"]
			}
		},

		onLoad(option) {

			this.gid = option.gid || '';


		},
		onShow() {

			console.log('stock onShow:', this.curTab)
			// if (this.curTab == 0) {
			// 	this.onSetTimeout()
			// }

			this.getData();

		},
		onHide() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		methods: {
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.genKLineData();
				}, 60000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				if (this.timer) this.clearTimer();
				this.curKLine = val;
				this.getData();
			},
			chongzhi() {
				uni.navigateBack({
					delta: 1,
				})
			},
			connect() {
				var that = this;
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Dandu_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);

					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
						uni.sendSocketMessage({
							data: that.info.pid,
						});

					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);



						if (this.info.pid == data.pid && data.last > 0) {
							console.log(`pid:`, this.info, data);
							this.info.current_price = data.last;
							this.info.rate = data.pcp || 0;
							this.info.rate_num = data.pc || 0;
							this.info.high = data.high || 0;
							this.info.low = data.low || 0;

							// this.info.info = data;
							// // console.log('data.type:', data.type);

							// 	当前k线在分钟走势图，且当前回执数据type='kline'时， 执行以下逻辑		
							// 				if (this.curKLine == 0 && data.type == "kline") {
							// 					// 创建一个Date对象，使用该时间戳创建
							// 					let date = new Date(data.time);
							// 					// 获取当前分钟的起始毫秒时间戳
							// 					let currentMinuteStart = new Date(date.getFullYear(), date.getMonth(), date
							// 						.getDate(),
							// 						date.getHours(), date.getMinutes(), 0, 0).getTime();
							// 					// console.log(currentMinuteStart);

							// 					const temp = {
							// 						close: data.last,
							// 						high: data.high,
							// 						low: data.low,
							// 						// open: data.open,
							// 					};
							// 					this.temp = temp;
							// 					this.kLineChart.updateData(temp);
							// 				} else {
							// 					this.temp.close = data.last;
							// 					this.kLineChart.updateData(this.temp);
							// 				}
						}
					});
				}
			},

			// kLineInit() {
			// 	if (!this.klineChart) {
			// 		this.klineChart = init('kline-stock');
			// 	}
			// 	// // 显示技术指标
			// 	// if (!this.indicator) {
			// 	// 	this.indicator = this.klineChart.createIndicator('MA', false);
			// 	// }

			// 	this.klineChart.setStyles({
			// 		grid: klineGird,
			// 		// 第一个用面积图 后面用蜡烛图
			// 		candle: this.active == 0 ? klineArea : klineCandle,
			// 	});
			// 	// 只有 curKLine==0 显示技术指标
			// 	// if (this.active !== 0) {
			// 	// 	if (this.indicator) {
			// 	// 		this.klineChart.removeIndicator(this.indicator);
			// 	// 		this.indicator = null;
			// 	// 	}
			// 	// }
			// 	this.klineChart.applyNewData(this.chartData, 0)
			// 	// this.kLineChart.setStyles({
			// 	// 	"candle": {
			// 	// 		"type": "candle_solid",
			// 	// 		"tooltip": {
			// 	// 			"showRule": "none",
			// 	// 		},
			// 	// 		area: {
			// 	// 			lineSize: 2,
			// 	// 			lineColor: this.$theme.PRIMARY,
			// 	// 			value: 'close',
			// 	// 			backgroundColor: [{
			// 	// 				offset: 0,
			// 	// 				color: '#ffbfb9'
			// 	// 			}, {
			// 	// 				offset: 1,
			// 	// 				color: this.$theme.PRIMARY,
			// 	// 			}]
			// 	// 		},
			// 	// 		bar: {
			// 	// 			upColor: '#00aa99',
			// 	// 			downColor: '#F92855',
			// 	// 			noChangeColor: '#888888',
			// 	// 			upBorderColor: '#00aa99',
			// 	// 			downBorderColor: '#F92855',
			// 	// 			noChangeBorderColor: '#888888',
			// 	// 			upWickColor: '#00aa99',
			// 	// 			downWickColor: '#F92855',
			// 	// 			noChangeWickColor: '#888888'
			// 	// 		},
			// 	// 	},
			// 	// });
			// 	// this.kLineChart.createIndicator('MA', false);
			// },

			// 买入
			purchase(val) {
				console.log(`val:`, val);
				this.curType = val;
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?gid=${this.gid}&type=${this.info.project_type_id}`
				});
			},

			// 产品详情
			async getData() {
				console.log("getData", this.gid);
				if (this.timer) this.clearTimer();
				const result = await this.$http.get(`api/product/info`, {
					gid: this.gid,
					time_index: this.curKLine
				});
				console.log(result);
				if (!result) return false;
				this.info = result[0];

				console.log(`info:`, this.info);
				console.log(this.info.project_type_id);

				// 当前实时更新模式
				this.onSetTimeout();

				// // 延时,等DOM渲染
				// uni.$u.sleep(50).then(() => {
				// 	if (!this.kLineChart) {
				// 		this.kLineChart = init('chart-type-k-line');
				// 		this.kLineInit(); // 初始化Kline
				// 	}
				this.genKLineData(); // 获取并生成KLine数据				
				// })
				this.connect()
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					code: this.info.code,
					ac_time: this.curKLine,
					project_type_id: this.info.project_type_id,

				})
				console.log('k data:', result);
				if (!result) return false;

				if (!this.klineChart) {
					this.klineChart = init('kline-stock');
				}
				// 显示技术指标
				if (!this.indicator) {
					this.indicator = this.klineChart.createIndicator('MA', false);
				}

				this.klineChart.setStyles({
					grid: klineGird,
					// 第一个用面积图 后面用蜡烛图
					// candle: this.active == 0 ? klineArea : klineCandle,
					candle: klineCandle,
				});
				// 只有 curKLine==0 显示技术指标
				// if (this.active !== 0) {
				// 	if (this.indicator) {
				// 		this.klineChart.removeIndicator(this.indicator);
				// 		this.indicator = null;
				// 	}
				// }
				// this.klineChart.setPriceVolumePrecision(this.info.shudian, 0)
				this.klineChart.applyNewData(result, 0)

				// this.kLineChart.setStyles({
				// 	"candle": {
				// 		"type": this.curKLine == 0 ? "candle_solid" : "candle_solid",
				// 	},
				// });
				// this.kLineChart.setPriceVolumePrecision(this.info.shudian, 0)
				// this.kLineChart.applyNewData(result)
			},
		},
	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #489ce5;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #489ce5;
			}
		}

		.list1 {
			background-color: #0332783b;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}
</style>