<template>
	<header class="common_header">
		<!-- <view class="header_title" :style="{color:color}">{{title}}</view> -->
		<!-- <view class="header_search" @click="linkSearch()">
			
		</view> -->

		<!-- <image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)" @click="linkNotifiy()" style="padding-right: 8rpx;"></image> -->
		<view style="flex: 0 10%">
			<image src="/static/logo.png" mode="widthFix" :style="$theme.setImageSize(128)"></image>
		</view>
		<!-- <view style="flex:1 0 50%; font-size: 18px;color: #fff;">Diversity Hall</view> -->

		<view style="margin-left:auto;">
			<view style="display: flex;align-items: center;">
				<template v-if="isSearch">
					<!-- <image mode="aspectFit" src="/static/search.png" :style="$util.setImageSize(40)"  @click="linkSearch()">
					</image> -->
					<image mode="aspectFit" src="/static/bottom/test7.svg" :style="$util.setImageSize(60)"
						@click="$util.linkService()" style="margin-left: 10px;"></image>
				</template>
			</view>
		</view>
	</header>
</template>

<script>
	import {
		NOTIFICATION,
		SERVICE,
		SEARCH
	} from '@/common/paths.js';
	export default {
		name: 'HeaderPrimary',
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#FFFFFF'
			},
			isSearch: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {};
		},
		methods: {
			// 跳转到通知页面
			linkNotifiy() {
				uni.navigateTo({
					url: NOTIFICATION
				})
			},

			// // 跳转到客服
			linkService() {
				uni.navigateTo({
					url: SERVICE
				})
			},
			linkService5() {
				uni.navigateTo({
					url: '/pages/Introduction/personaldata'
				})
			},
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: SEARCH
				})
			}
		}
	}
</script>