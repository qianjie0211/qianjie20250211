<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="display: flex;align-items: center;line-height: 3;" @click="actionEvent(item)">
				<!-- <image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(40)"></image> -->
				<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">{{item.name}}</view>
				<image src="/static/arrow_right.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(20)"></image>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'ServiceList',

		computed: {
			list() {
				return [{
					name: this.$lang.PROFILE_QA,
					// icon: `profile_5`,
					url: this.$paths.QA,
				}, {
					name: this.$lang.PROFILE_PACT,
					// icon: `profile_6`,
					url: this.$paths.PRVITE_PACT,
				}, {
					name: this.$lang.PROFILE_SHARE,
					// icon: `profile_7`,
					url: this.$paths.SHARE,
				}, {
					name: this.$lang.PROFILE_SERVICE,
					// icon: `profile_8`,
					url: this.$paths.SERVICE,
				}, {
					name: this.$lang.PROFILE_ABOUT,
					// icon: `profile_9`,
					url: this.$paths.ABOUT_US,
				}]
			}
		},
		methods: {
			actionEvent(item) {
				let url=item.url
				if (url.includes('service')) {
					this.$util.linkCustomerService();
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
					this.$emit(`action`, 1);
				} 
				
			},
		}
	}
</script>

<style>
</style>