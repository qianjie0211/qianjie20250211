<template>
	<view>
		<view class="mask" @click="handleClose()"></view>
		<view class="modal_wrapper" style="overflow-y: scroll;">
			<view style="background-color: #010101;min-height: 100vh;width: 100%;">
				<view style="padding:100rpx 40rpx;">
					<template v-if="info">
						<view style="display: flex;align-items: center;">
							<!-- info.avatar -->
							<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(64)"></image>
							<view style="padding-left: 40rpx;">
								<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{info.real_name}}</view>
								<view style="color:#FFFFFF;">{{info.p_mobile}}</view>
								<view style="color:#FFFFFF;">{{$lang.JIGOU_ZHANGHU}}</view>
							</view>
							<view style="margin-left: auto;">
								<view class="common_tag" :style="setStyle()">{{curAuth}}</view>
							</view>
						</view>

					</template>
					<view style="background-color: #222222; border-radius: 6px; padding: 0  16px 16px  16px;" >
						<view style="font-size: 32rpx;font-weight: 700; line-height: 2.4;margin-top: 80rpx;"
							:style="{color:$theme.SECOND}">
							{{$lang.PROFILE_SETTING_TITLE}}
						</view>
						<view
							style="display: flex;align-items: center;line-height: 3;background-color: #424242;border-radius: 6px;margin: 6px 0;padding-right: 6px;"
							@tap="linkAddress()">
							<!-- <image src="/static/profile_0.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image> -->
							<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">
								{{$lang.PROFILE_ADDRESS}}
							</view>
							<image src="/static/arrow_right.png" mode="aspectFit" style="margin-left: auto;"
								:style="$theme.setImageSize(20)"></image>
						</view>

						<view
							style="display: flex;align-items: center;line-height: 3;background-color: #424242;border-radius: 6px;margin: 6px 0;padding-right: 6px;"
							@tap="linkPassword()">
							<!-- <image src="/static/profile_2.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image> -->
							<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">
								{{$lang.PROFILE_SIGN_IN_PASSWORD}}
							</view>
							<image src="/static/arrow_right.png" mode="aspectFit" style="margin-left: auto;"
								:style="$theme.setImageSize(20)"></image>
						</view>
						<!-- 修改支付密码 需要时打开注释 -->
						<!-- <view style="display: flex;align-items: center;line-height: 3;" @tap="linkPassword(`pay`)">
						<image src="/static/profile_2.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
						<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">
							{{$lang.PROFILE_SIGN_IN_PASSWORD}}
						</view>
						<image src="/static/arrow_right.png" mode="aspectFit" style="margin-left: auto;"
							:style="$theme.setImageSize(20)"></image>
					</view> -->

						<!-- <view style="display: flex;align-items: center;line-height: 3;">
						<image src="/static/profile_3.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
						<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">
							{{$lang.PROFILE_DEFAULT_COIN}}
						</view>
						<view style="margin-left: auto;">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 40rpx;color:#666;">
									USDT
								</view>
								<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(20)">
								</image>
							</view>
						</view>
					</view> -->


						<!-- @tap="chooseLang()" -->
						<view
							style="display: flex;align-items: center;line-height: 3;background-color: #424242;border-radius: 6px;margin: 6px 0;padding-right: 6px;"
							@click="isShowList=true">
							<!-- <image src="/static/profile_4.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image> -->
							<view style="font-size: 26rpx;padding-left: 20rpx;" :style="{color:$theme.SECOND}">
								{{$lang.PROFILE_LANGUAGE}}
							</view>
							<view style="margin-left: auto;">
								<view style="display: flex;align-items: center;">
									<view style="color:#FFFFFF;">
										{{setLang}}
									</view>
									<image src="/static/arrow_right.png" mode="aspectFit"
										:style="$theme.setImageSize(20)">
									</image>
								</view>
							</view>
						</view>
					</view>

					<view style="background-color: #222222;border-radius: 6px;padding: 0  16px 16px  16px;">
						<view style="font-size: 32rpx;font-weight: 700; line-height: 2.4;margin-top: 80rpx; "
							:style="{color:$theme.SECOND}">
							{{$lang.PROFILE_SERVICE_TITLE}}
						</view>

						<ServiceList @action="handleClose"></ServiceList>
					</view>
					<view style="margin-top: 80rpx;">
						<SignOut style="background-color:#018ef8;"></SignOut>
					</view>
				</view>
			</view>
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="isShowList" :columns="[$util.LANGUAGE_LIST]" @change="changeLang" @cancel="isShowList=false"
			@confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="name"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import ServiceList from './ServiceList.vue';
	import SignOut from '@/components/SignOut.vue';
	export default {
		// 用于弹出式的账户
		name: 'ProfileModal',
		components: {
			ServiceList,
			SignOut
		},
		data() {
			return {
				isShow: false,
				info: null,
				isShowList: false, // 多语言备选
			}
		},
		computed: {
			curAuth() {
				if (this.info) {
					return this.info.is_check == 1 ?
						this.$lang.PROFILE_AUTH_VERIFIED : this.$lang.PROFILE_AUTH_UNVERIFIED
				}
			},
			// 当前语言
			setLang() {
				const temp = uni.getStorageSync('lang') || this.$LANGCODE;
				console.log(1111, temp);

				const tempName = this.$util.LANGUAGE_LIST.filter(item => item.lang == temp)[0].name;
				return tempName;
			}
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			handleClose() {
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar
				this.$emit('action', this.isShow);
			},

			linkAddress() {
				this.handleClose();
				uni.navigateTo({
					url: this.$CONSTANTS.ADDRESS_INDEX
				});
			},

			linkPassword(val = '') {
				this.handleClose();
				const temp = val.length > 0 ? `?role=${val}` : '';
				uni.navigateTo({
					url: this.$CONSTANTS.ACCOUNT_PASSWORD + temp
				});
			},

			// 選擇一種 lang
			chooseLang() {
				this.isShowList = true;
			},
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				// this.curLang = e.value[0].name;
				this.isShowList = false;
				uni.setStorageSync('lang', e.value[0].lang);
				uni.reLaunch({
					url: this.$CONSTANTS.LAUNCH,
				})
			},

			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
			},
			setStyle() {
				const temp = this.info.is_check == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.u-popup {
		view {
			z-index: 99999 !important;
		}
	}

	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 11113;
		width: 90%;
		background-color: transparent;
		animation: leftIn 300ms forwards;
	}
</style>