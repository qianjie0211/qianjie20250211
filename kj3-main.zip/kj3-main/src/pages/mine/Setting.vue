<template>
  <div class="container page" style="background-color: #1b1b1b; min-height: 100vh;">
    <van-nav-bar :title="curLang.setting" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
    </van-nav-bar>
    <div class="items" style="background-color: #1b1b1b;">
      <div class="item van-hairline--bottom" @click="toInfomation()">
        <div class="left">{{curLang.Set_basic_information}}</div>
        <van-icon name="arrow" />
      </div>
      <div class="item van-hairline--bottom" @click="toLoginPassword()">
        <div class="left">{{curLang.Login_Password}}</div>
        <van-icon name="arrow" />
      </div>
      <div class="item van-hairline--bottom" @click="toPayPassword()">
        <div class="left">{{curLang.Fund_Password}}</div>
        <div class="right">
          <span class="desc">{{ this.userInfo.paypassword }}</span>
          <van-icon name="arrow" />
        </div>
      </div>
    </div>
    <div style="display: flex;align-items: center;justify-content: center;margin-top: 80px;">
      <van-button class="button c_btn" style="border-radius: 6px;" type="primary" size="normal"
        @click="loginout()">{{curLang.log_out}}</van-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {

      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器

      userInfo: {}
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    back() {
      return window.history.back();
    },
    toPayPassword() {
      if (this.userInfo.paypassword !== "Not set") {
        this.$toast(this.curLang.Your_password_has);
      } else {
        this.$router.push({ path: '/SetPayPassword' });
      }
    },
    toLoginPassword() {
      this.$router.push({ path: '/SetLoginPassword' });
    },
    toInfomation() {
      this.$router.push({ path: '/Infomation' });
    },
    loginout() {
      localStorage.clear()
      this.$router.push({ path: '/Mine' });
    },
    toServicePage() {
      this.$router.push("ServicePage");
    },
    getUserInfo() {
      this.$http({
        method: 'get',
        url: 'user_info'
      }).then(res => {
        if (res.code === 200) {
          this.userInfo = res.data;
          if (res.data.paypassword) {
            this.userInfo.paypassword = "curLang.Be_prepared";
          } else {
            this.userInfo.paypassword = "curLang.Not_set";
          }
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      })
    }
  },
  created() {
    if (!localStorage.getItem('token')) {
      this.$router.push({ path: '/Login' })
    } else {
      this.getUserInfo();
    }

    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    this.curCode = this.curLang.loginCode;
    const temp = this.$locales.filter((item) => item.value == this.curLocale);
    console.log(temp);
    this.langName = temp[0].text;
  }
};
</script>

<style lang='less' scoped>
@import "../../assets/css/base.css";

.container .items {
  background-color: #1b1b1b !important;
  font-size: 30px;
  color: #FFF;
  padding: 0 25px;
}

.container .items .item {
  padding: 30px 0;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  border-bottom-width: 10px;
}

.container .items .van-hairline--bottom::after {
  border-bottom-width: 3px;
}

.container .sign-out {
  margin: 500px 20px 0;
  height: 100px;
  line-height: 100px;
  border-radius: 50px;
  color: #fff;
  font-size: 40px;
  font-weight: bolder;
  border: none;
  background: linear-gradient(90deg, #775fd9, #FFCC99)
}

.container .item .desc {
  font-size: 30px;
  font-weight: 700;
  color: #979799;
}

.container .item .right {
  display: flex;
  flex-direction: row;
  align-items: center;
}
</style>
