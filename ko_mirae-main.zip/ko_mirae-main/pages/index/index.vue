<!-- 主页 -->
<template>
	<view class="common_page_bg2">
		<Header :title="$lang.HOME"></Header>
		
		<view style="width: 100%;justify-content: center;display: flex;">
			<image src="../../static/sy_tu.jpg" mode="aspectFill" style="width: 95%;border-radius: 10px;height: 180px;"></image>
		</view>

		<view style="">
			<ButtonGroup :btns="$util.businessBtnsConfig()" col="30"></ButtonGroup>
		</view>
		
		<view  style="padding: 100px 10px; justify-content: space-between; ">
			<view class="flex" style="padding: 5px 10px;">
				<view>
					<image src="/static/sc_ss.png" mode="widthFix" style="width: 20px;"></image>
				</view>
				<view class="margin-left-10 font-size-18">국내종목</view>
			</view>
				<view style="margin:5px 0px;" class="padding-5 flex text-center">
					<view :style="klineindex==index?'background-color: #e7d7ca;':'background-color:#ffe1de;'" class="flex-1"
						style="border-radius: 16rpx;margin: 3px;" v-for="(item,index) in top1"
						@click='qiehuan111(index)'>
			
						<view style="padding: 8px 0px;">
							<view class="container gap5">
								<view style="width: 7px;height: 7px;background-color: #18BFB4;" class="left-element"
									:style="klineindex==index?'background-color: #f58017;':'background-color: #18BFB4;'">
								</view>
								<view class="right-text">
									{{top111[index]}}
								</view>
							</view>
							<view class="t num-font" :style="{color:item.rate>0?'#f58017':'#18BFB4' }">{{item.close}}</view>
							<view class="t1 " :style="{color:item.rate>0?'#f58017':'#18BFB4' }">{{(item.rate)}}%</view>
						</view>
			
					</view>
				</view>
				<view style="margin: 10px;">
					<view class="chart" id="chart-type-k-line" style="width: 100%;height: 300rpx;">
					</view>
				</view>
			
			
			<!-- <block v-for="(item,index) in goodsList.slice(0, 1)" :key="index">
			<view class="sy_gupiao" style="padding: 20px 10px;width: 43%;">
				<view style="">
				<view class="font-size-16 bold">{{item.ko_name}}</view>
				<view style="padding: 5px 0px;color: #999;">{{item.code}}</view>
				<view class="flex margin-top-5">
					<view class="font-size-16" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatNumber(item.close*1)}}</view>
					<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.setImageSize(20)" style="margin-left: 15px;"></image>
					<view style="font-size: 15px;margin-left: 5px;" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatMathABS(1*item.returns).toFixed(2)}}%</view>
				</view>
				</view>
			</view>
			</block>
			<block v-for="(item,index) in goodsList.slice(1, 2)" :key="index">
			<view class="sy_gupiao2" style="padding:20px 10px;width: 43%;">
				<view class="font-size-16 bold">{{item.ko_name}}</view>
				<view style="padding: 5px 0px;color: #999;">{{item.code}}</view>
				<view class="flex margin-top-5">
					<view class="font-size-17" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatNumber(item.close*1)}}</view>
					<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.setImageSize(20)" style="margin-left: 15px;"></image>
					<view style="font-size: 15px;margin-left: 5px;" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatMathABS(1*item.returns).toFixed(2)}}%</view>
				</view>
			</view>
			</block> -->
		</view>
		<view style="margin-top: -70px;">
			<view class="flex" style="padding: 10px 15px;">
				<view class="font-size-18 flex-1">인기 주식</view>
				<view class="flex" @click="gupiao()">
					<view>인기 주식</view>
					<image src="../../static/jiantou.png" mode="widthFix" style="width: 10px;margin-left: 5px;"></image>
				</view>
			</view>
			<GoodsList :list="goodsList"></GoodsList>
		</view>
		
		
		

		<!-- <NotifyPrimary></NotifyPrimary> -->

		<!-- <Favorites :list="freeList"></Favorites> -->
		
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import NotifyPrimary from '@/components/notify/NotifyPrimary.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		components: {
			Header,
			ButtonGroup,
			NotifyPrimary,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				userinfo: [],
				// show_money: true,
				page: 1,
				goodsList: [],
				gp_index: 0,
				freeList: [],
				top1: [],
				top11: ["국내", "해외", "가상화폐"],
				top22: ["상승률", "하락률", "신고가", "거래량", '거래대금'],
				top111: {
					17470: "코스피 200",
					255: "코스피",
					141: "코스닥",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: [],
				klineindex: 141
			}
		},
		
		mounted() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.free()
			this.startTimer()
			this.top_one()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		},
		mounted() {
		
		
			this.kLineChart = init('chart-type-k-line')
		
			this.kLineChart.setStyles({
				"candle": {
					"type": "area",
					"tooltip": {
						"showRule": "none",
					}
				},
		
			});
			this.top_one()
			this.top_two()
			this.top_three()
			this.startTimer()
		
		
		},
		methods: {
			
			// 银转证
			silver(money, bank_card_info, idno) {
				uni.$u.toast('고객 서비스 매니저에 연락해주세요.');
				return
				// if (bank_card_info && idno !== null) {
				// uni.navigateTo({
				// 	//保留当前页面，跳转到应用内的某个页面
				// 	url: '/pages/service/service'
				// });
			},
			gupiao(){
				uni.reLaunch({
					url:'/pages/free/free'
				})
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
					this.top_one()
					this.top_two()
					this.top_three()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let result = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = result.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = result.data.data
			},
			
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/signin/signin'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let result = await this.$http.get('api/user/collect_list', {})
				this.freeList = result.data.data.list
			},
			open(url) {
					window.open(url)
				},
				//删除
				async handleClickDelProduct(e) {
					let list = await this.$http.post('api/user/collect_edit', {
						gid: e,
					})
					if (list.data.code == 0) {
						uni.$u.toast(list.data.message);
						this.top_two()
						this.top_three()
					} else {
						this.show = false
						uni.$u.toast(list.data.message);
					}
				},
				async top_one() {
					// uni.showLoading({
			
					// })
					let list = await this.$http.post('api/goods/top1', {
						current1: this.current1,
						stockid: this.klineindex
					})
			
					this.top1 = list.data.data.top1
					this.kline = list.data.data.kline
					this.article = list.data.data.article
					this.bottom = list.data.data.bottom
					// console.log();
					// this.klineindex=Object.keys(list.data.data.top1)[0]
					this.kLineChart.applyNewData(list.data.data.kline)
					// uni.hideLoading()
					this.$forceUpdate()
				},
			
				async top_two() {
					// uni.showLoading({
			
					// })
					let list = await this.$http.post('api/goods/top2', {
						current: this.current2
					})
					this.top2 = list.data.data
					uni.hideLoading()
				},
				async top_three() {
					// uni.showLoading({
			
					// })
					let list = await this.$http.post('api/goods/top3', {
						current: this.current3,
						current33: this.current33
					})
					this.top3 = list.data.data
					// uni.hideLoading()
				},
			
				//定时器
				startTimer() {
					const storedTimerId = uni.getStorageSync('timerId');
					if (storedTimerId) {
						clearInterval(storedTimerId);
					}
					this.timerId = setInterval(() => {
						this.top_one()
						this.top_two()
						this.top_three()
						// this.dataUpdate()
					}, 5000);
					uni.setStorageSync('timerId', this.timerId);
			
			
				},
			
		},
	}
</script>

<style lang="scss">
	

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	


	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		
	}
</style>