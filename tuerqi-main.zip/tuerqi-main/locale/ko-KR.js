export default {

	LAUNCH_TITLE: "Çevrimiçi Hisse Senedi İşlem Uygulaması", // 在线股票交易应用程序
	LAUNCH_PROGRESS_TITLE: "Yükleniyor", // 正在加载
	TRANSLATE_TITLE: "Lütfen Dilinizi Seçin", // 请选择您的语言
	HELLO: "Merhaba", // 你好

	// 网络控制和网络状态
	TIP_NETWORK_TYPE_NONE: "Şu anda ağ yok veya ağ bağlantısı zayıf.", // 当前没有网络或网络连接较弱。

	// 与API相关的通知
	API_TOKEN_EXPIRES: "Giriş durumu hatalı. Lütfen yeniden giriş yapın.", // 登录状态错误。请重新登录。
	API_HTTP_ERROR: "İstek hatası. Lütfen ağı kontrol edin.", // 请求错误。请检查网络。
	REQUEST_DATA: "Veri talebi", // 数据请求
	API_EMPTY_DATA: "Veri yok", // 没有数据
	API_EMPTY_CONTENT: "İçerik yok", // 暂无内容
	API_SEND_CODE: "Doğrulama kodu gönderiliyor", // 正在发送验证码
	API_SEND_CODE_SUCCESS: "验证码发送成功", // 验证码发送成功
	API_SIGN_IN_NOW: "Giriş yapılıyor", // 正在登录
	API_SIGN_UP_NOW: "Kayıt olunuyor", // 正在注册
	API_DATA_SUBMIT: "Veriler gönderiliyor", // 数据正在提交
	API_POST_SUCCESS: "Başarılı", // 成功
	API_GET_ACCOUNT_INFO: "Hesap bilgileri alınıyor", // 正在获取账户信息

	// 底部菜单
	TABBAR_HOME: "Anasayfa", // 首页
	TABBAR_FOLLOW: "Piyasa", // 市场
	TABBAR_MARKET: "Favoriler", // 收藏
	TABBAR_TRADE: "İşlem", // 交易
	TABBAR_ACCOUNT: "Daha Fazla", // 更多

	// 登录，注册
	SIGN_IN_TITLE: "Giriş", // 登录
	SIGN_UP_TITLE: "Kayıt", // 注册
	BTN_SIGN_IN: "Giriş Yap", // 登录
	BTN_SIGN_UP: "Kaydol", // 注册
	BTN_SIMGN_OUT: "Çıkış Yap", // 退出
	GO_TO_SIGN_IN: "Giriş sayfasına git", // 转到登录页
	ACCOUNT_NAME: "Telefon Numarası", // 手机号
	ACCOUNT_EMAIL: "E-posta", // 邮箱
	ACCOUNT_PASSWORD: "Şifre", // 密码
	VERIFY_ACCOUNT_PASSWORD: "Şifreyi Yeniden Girin", // 重新输入密码
	INVITATION_CODE: "Davet Kodu", // 邀请码


	TIP_REMEMBER_PWD: "Giriş durumunu hatırla", // 记住登录状态
	TIP_AGREE: "Okudum ve kabul ediyorum", // 阅读并同意
	TIP_PRVITE_PACT: "Gizlilik Sözleşmesi", // 隐私协议
	TIP_VERIFY_CODE: "Doğrulama Kodu", // 验证码
	TIP_ENTER_EMAIL: "Geçerli bir e-posta adresi girin", // 请输入有效的邮箱
	TIP_ENTER_EMAIL_CODE: "E-posta doğrulama kodu hatalı", // 邮箱验证码错误
	TIP_ENTER_ACCOUNT_NAME: "Telefon numarasını girin", // 请输入手机号
	TIP_ENTER_ACCOUNT_PASSWORD: "Şifreyi girin", // 请输入密码
	TIP_ENTER_VERIFY_ACCOUNT_PASSWORD: "Şifreyi tekrar girin", // 再次输入密码
	TIP_ENTER_INVITATION_CODE: "Davet kodu Girin", // 请输入邀请码
	TIP_PWD_NOEQUAL: "İki şifre aynı değil", // 两次密码不一致
	TIP_CHECK_AGREE: "Lütfen Gizlilik Sözleşmesi'ni kabul edin.", // 请勾选同意用户隐私协议。
	TIP_SUCCESS_SIGNIN: "Başarıyla giriş yapıldı", // 登录成功
	TIP_SUCCESS_REGISTER: "Kayıt tamamlandı. Lütfen giriş yapın.", // 注册完成。请登录。
	TIP_SIGN_OUT_SUCCESS: "Çıkış başarılı", // 退出成功
	PRVITE_PACT_TITLE: "Gizlilik Sözleşmesi", // 隐私协议


	CARD_ASSETS_TOTAL: "Toplam Varlık", // 总资产
	CARD_ASSETS_AVAIL: "Kullanılabilir Bakiye", // 可用余额
	CARD_ASSETS_FREEZE: "Dondurulmuş Miktar", // 冻结金额
	CARD_BTN_TREAD_LOG: "İşlem Geçmişi", // 交易记录


	SEARCH_TITLE: "Arama", // 搜索
	TIP_SEARCH: "Hisse Adı/Kodu Girin", // 请输入股票名称/代码
	SEARCH_HISTORY: "Arama Geçmişi", // 搜索历史
	SEARCH_CLEAR: "Geçmişi Temizle", // 清除历史
	LOADING_SEATCH: "Veri aranıyor...", // 数据查询中...
	SEATCH_RESULT_COUNT: "sonuç", // 条结果


	MARKET_INDEX_TAB_TRACK: "Takip", // 关注
	MARKET_INDEX_TAB_MARKET: "Piyasa", // 市场
	MARKET_INDEX_TAB_HOP: "Popüler Hisseler", // 热门股票
	MARKET_INDEX_TAB_KPI: "Endeksler", // 市场指标
	MARKET_INDEX_TIP_GO_STOCK: "Hisse Senedi Piyasasına Git", // 进入股票市场


	ACCOUNT_CENTER_TITLE: "Hesabım", // 我的账户
	ABOUT_US_TITLE: "Hakkımızda", // 关于我们
	SIGNIN_PASSWORD_TITLE: "Giriş Şifresini Değiştir", // 修改登录密码
	PAY_PASSWORD_TITLE: "Ödeme Şifresini Değiştir", // 修改支付密码
	ENTER_OLD_PASSWORD: "Eski Şifreyi Girin", // 输入旧密码
	ENTER_NEW_PASSWORD: "Yeni Şifreyi Girin", // 输入新密码
	ENTER_VERIFY_NEW_PASSWORD: "Yeni Şifreyi Yeniden Girin", // 重新输入新密码
	ENTER_VERIFY_FAIL: "Lütfen şifreyi tekrar girin", // 请重新输入密码
	BIND_BANK_CARD_TITLE: "Banka Hesabı Bağla", // 绑定银行账户
	BIND_BANK_CARD_REAL_NAME: "Hesap Adı", // 账户名
	BIND_BANK_CARD_BANK_NAME: "Banka Adı", // 银行名称
	BIND_BANK_CARD_ID: "Banka IBAN Numarası", // 银行 IBAN 号码
	TIP_BIND_BANK_CARD_REAL_NAME: "Adınızı girin", // 请输入您的姓名
	TIP_BANK_NAME: "Banka adını girin veya seçin", // 输入或选择银行名称
	TIP_BANK_CARD: "Kart numarasını girin", // 请输入银行卡号
	BTN_CHANGE_BANK_CARD: "Onayla", // 确认
	BTN_BANK_SELECTED: "Banka Seç", // 选择银行
	ACCOUNT_TRADE_LOG_TITLE: "Hesap Detayları", // 账户详情
	///==============================================


	ACCOUNT_AUTH_STATUS: ['Doğrulandı [Doğrulanmadı]', 'Doğrulandı [İnceleniyor]', 'Doğrulandı [Onaylandı]',
		'Doğrulandı [Reddedildi]'
	], // 已认证 [未验证], 已认证 [审核中], 已认证 [已通过], 已认证 [审核失败]
	ACCOUNT_CHANGE_PWD: "Giriş Şifresini Değiştir", // 修改登录密码
	ACCOUNT_CHANGE_PAY_PWD: "İşlem Şifresini Değiştir", // 修改交易密码
	ACCOUNT_CARD_MANAGEMENT: "Banka Hesabı Bağla", // 绑定银行账户
	ACCOUNT_TRADE_LOG: "Hesap Detayları", // 账户详情
	ACCOUNT_SERVICE: "Müşteri Hizmetleri", // 客服
	ACCOUNT_AMOUNT_TOTAL: "Toplam Varlık", // 总资产
	ACCOUNT_AMOUNT_AVAILABLE: "Kullanılabilir Fon", // 可用资金
	ACCOUNT_MORE_FEATURES: "Daha Fazla Özellik", // 更多功能
	ACCOUNT_COLD_AMOUNT: "Dondurulmuş Fon", // 冻结资金
	ACCOUNT_REPAY: "Geri Ödeme", // 还款
	ACCOUNT_TOTAL_PROFIT: "Toplam Getiri", // 总收益
	PAGE_TITLE_AVATAR: "Ayarlar", // 设置
	AVATAR_TIP_NICK_NAME: "Adınızı girin", // 请输入您的姓名


	WITHDRAW_TITLE: "Para Çekme", // 提现
	WITHDRAW_AMOUNT: "Varlıklarım", // 我的资产
	TIP_AMOUNT_AVAIL: "Kullanılabilir Bakiye", // 可用余额
	WITHDRAW_WITH_AMOUNT: "Çekilecek Tutar", // 提现金额
	TIP_AMOUNT_WITHDRAW: "Lütfen çekmek istediğiniz tutarı girin", // 请输入提现金额
	WITHDRAW_PAY_PWD: "Para Çekme Şifresi", // 提现密码
	TIP_WITHDRAW_PWD: "Hesap Şifresi", // 账户密码
	WITHDRAWING_POST_TIP: "İşleniyor...", // 处理中...
	WITHDRAW_TIP_TEXT: [
		'1. Satılmayan hisse senetleri çekilemez', // 未卖出的股票无法提现。
		'2. Kimlik doğrulaması ve hesap doğrulaması yapıldıktan sonra para çekme işlemi yapılabilir', // 需进行身份验证和账户验证方可提现。
		'3. Para çekme işlemleri iş günlerinde 09:00-18:00 arasında yapılabilir (hafta sonları ve tatillerde para çekme işlemi desteklenmez)', // 提现时间为工作日09:00-15:00（周末及节假日不支持提现）。
		'4. Minimum 100 birimlik başvuru sonrasında, fonlar en kısa sürede belirtilen hesaba aktarılacaktır', // 最低金额500提交申请后，资金会尽快转入指定账户。
		'5. Para çekme başvurusu sonrası fonlar aynı gün içinde belirtilen hesaba aktarılacaktır', // 提交提现申请后，资金会在当天内转入指定账户。
		'※ En fazla 2 iş günü (48 saat) içinde tamamlanır' // 最多在2个工作日（48小时）内完成。
	],


	DEPOSIT_TITLE: "Para Yatırma", // 存款
	DEPOSIT_TIP_DEPOSIT_AMOUNT: "Lütfen yatırmak istediğiniz tutarı girin", // 请输入存款金额
	DEPOSIT_TIP_LOW_AMOUNT: "Minimum depozito tutarı 10,000 TL’dir.", // 最低存款金额为1,000,000
	DEPOSIT_POST_TIP: "İşleniyor...", // 处理中...
	DEPOSIT_TIP_TITLE: "Bilgilendirme", // 温馨提示
	DEPOSIT_TIP_TEXT: [
		'1. 09:00-22:00 saatleri arasında ve tatil günlerinde para yatırma işlemi yapılabilir', // 1.9；00-  22；00   节假日正常转入资金。
		'2. Güvenli fon transferi için lütfen her para yatırma işlemi öncesinde müşteri hizmetleriyle iletişime geçin ve hesap bilgilerini doğrulayın.Yanlış hesaba yapılan transferler sonucu oluşabilecek zararlar kullanıcıya aittir' // 感谢你的选择，为保证您的资金安全到账，请联系在线客服领取实时账户，请在每次转入资金时与工作人员确认。因转账至非实时账户造成的损失，由您自行承担。
	],


	AUTH_TITLE: "Kimlik Doğrulama", // 身份验证
	AUTH_TIP_ID_CARD: "Geçerli bir kimlik numarası girin", // 请输入有效的身份证号
	AUTH_TIP_CARD_F: "Ön yüzü eklemek için tıklayın", // 点击添加正面
	AUTH_TIP_CARD_B: "Arka yüzü eklemek için tıklayın", // 点击添加背面
	AUTH_ID_CARD: "Kimlik Kartı", // 身份证
	AUTH_CARD_F: "Kimlik Kartı Ön Yüzü", // 身份证正面
	AUTH_CARD_B: "Kimlik Kartı Arka Yüzü", // 身份证背面
	AUTH_TIP_TEXT: "※ Kimlik doğrulama tamamlanmadan hizmetten yararlanamayabilirsiniz", // ※ 未完成身份验证，您可能无法享受服务。
	AUTH_RESULT_PASS: "Kimlik doğrulama başarılı", // 身份验证成功
	AUTH_RESULT_REVIEW: "İnceleniyor", // 审核中
	AUTH_RESULT_REPOST: "Yeniden gönderin", // 重新提交审核


	TRADE_LOG_TRADE: "Kayıt", // 记录
	TRADE_LOG_DEPOSIT: "Para Yatırma", // 存款
	TRADE_LOG_WITHDRAW: "Para Çekme", // 提现
	TRADE_LOG_TIP_MODAL_TITLE: "Para çekme başvurusunu iptal etmek istiyor musunuz?", // 是否取消提现申请？
	TRADE_LOG_WITHDRAW_STATUS: ["İnceleniyor", "Para Çekme Başarılı", "Başarısız",
		"İptal Edildi"
	], // 审核中, 提现成功, 失败, 已取消
	LOG_TRADE_AMOUNT_AFTER: "İşlem Sonrası Bakiye", // 交易后余额
	LOG_TRADE_AMOUNT_BEFORE: "İşlem Öncesi Bakiye", // 交易前余额
	LOG_TRADE_DW: "Para Yatırma", // 存款
	LOG_TRADE_CREATE_TIME: "Tarih ve Saat", // 日期时间
	LOG_TRADE_DESC: "Açıklama", // 说明
	LOG_TRADE_ORDER_SN: "Sipariş Numarası", // 订单编号
	LOG_TRADE_DW_DESC: "Reddedilme Nedeni", // 拒绝原因
	LOG_WITHDRAW_AMOUNT: "Para Çekme Miktarı", // 提现金额
	LOG_STATUS: "Durum", // 状态


	TRADE_TITLE: "Yatırım Sonuçları", // 投资结果
	TRADE_HOLD_LOG: "Mevcut", // 持有
	TRADE_SELL_LOG: "Geçmiş", // 历史
	TRADE_TOTAL_BUY_AMOUNT: "Toplam Alış Tutarı", // 总购买金额
	TRADE_VALUATION_GAIN_LOSS: "Kazanç ve Kayıp", // 收益和亏损
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: "Toplam Kazanç", // 总收益
	TRADE_RATE_RESPONSE: "Kazanç Oranı", // 盈利率
	TRADE_TOTAL_GAIN: "Toplam Kazanç", // 总收益
	TRADE_HOLD_LABEL_PROFIT_RATE: "Kazanç Oranı", // 盈利率
	TRADE_HOLD_LABEL_PROFIT_AMOUNT: "Gerçekleşmiş Kazanç ve Kayıp", // 已实现盈亏
	TRADE_HOLD_LABEL_BUY_AMOUNT: "Alış Tutarı", // 购买金额
	TRADE_HOLD_LABEL_TOTAL_PRICE: "Toplam Alış Fiyatı", // 总购买价格
	TRADE_HOLD_LABEL_BUY_PRICE: "Alış Fiyatı", // 购买价格
	TRADE_HOLD_LABEL_CUR_PRICE: "Güncel Fiyat", // 当前价格
	TRADE_SELL_LABEL_PROFIT_RATE: "Kazanç Oranı", // 盈利率
	TRADE_SELL_LABEL_PROFIT_AMOUNT: "Gerçekleşmiş Kazanç ve Kayıp", // 已实现盈亏
	TRADE_SELL_LABEL_BUY_AMOUNT: "Alış Tutarı", // 购买金额
	TRADE_SELL_LABEL_TOTAL_PRICE: "Toplam Alış Fiyatı", // 总购买价格
	TRADE_SELL_LABEL_BUY_PRICE: "Alış Fiyatı", // 购买价格
	TRADE_SELL_LABEL_SELL_PRICE: "Satış Fiyatı", // 卖出价格
	TRADE_MODAL_BUY_TIME: "Alış Zamanı", // 购买时间
	TRADE_MODAL_SELL_TIME: "Satış Zamanı", // 卖出时间
	TRADE_MODAL_FLOAT_PROFIT: "Mevcut Kazanç ve Kayıp", // 当前盈亏
	TRADE_MODAL_PROFIT: "Toplam Kazanç ve Kayıp", // 总盈亏
	TRADE_MODAL_BUY_PRICE: "Alış Fiyatı", // 购买价格
	TRADE_MODAL_BUY_QTY: "Miktar", // 数量
	TRADE_MODAL_LEVER: "Kaldıraç", // 杠杆
	TRADE_MODAL_FEE: "Ücret", // 手续费
	TRADE_MODAL_YINGKUI: "Kazanç ve Kayıp", // 盈亏
	TRADE_MODAL_BUY_AMOUNT: "Toplam Alış Tutarı", // 总购买金额
	TRADE_MODAL_STOCK_CODE: "Hisse Kodu", // 股票代码
	SELL_TIP: "Satışı Onaylıyor Musunuz?", // 确认卖出？
	USYF_FJAIF: "Popüler Hisseler", // 热门股票

	// 日内交易
	TRADE_DAY_TITLE: 'günlük ticaret', // AI交易
	TRADE_DAY_TABS: ['İşlem', 'Başvuru Durumu', 'Kayıt'], // 交易, 申请状态, 记录
	TRADE_DAY_BUY: 'Başvur', // 申请
	TRADE_DAY_TIP: 'İpucu', // 提示
	TRADE_DAY_TIP_TEXT: [
		'Bir işlem tekniği olarak, yatırımcılar aynı gün içerisinde hızlı yükselen hisseleri alıp satarak kazanç elde ederler', // 一种交易技巧，投资者在同一天买入和卖出快速上涨的股票，获取收益。
		'Yatırımcılar hisse fiyatına göre adil işlem yapar ve karar verir', // 投资者按股票价格公平交易和决定。
		'Alış yaptıktan sonra kazanç sağlanırsa, “günlük ticaret” sekmesinde görüntüleyebilir ve karla satmayı seçebilirsiniz', // 购买后若产生收益，可在“AI交易”中查看并选择卖出获利。
		'Hızla yükselen hisselerin kar ve gizliliğini korumak için alış süresi boyunca hisse kodu ve detaylar paylaşılmaz' // 为保护快速上涨的股票的利润和隐私，购买期内不提供股票代码和详情。
	],
	TRADE_DAY_BUY_AMOUNT: 'Miktar', // 金额
	TRADE_DAY_SUCCESS_AMOUNT: 'Onaylanan Miktar', // 确认金额
	TRADE_DAY_BUY_PRICE: 'Alış Fiyatı', // 购买价格
	TRADE_DAY_ORDER_SN: 'Sipariş Numarası', // 订单编号
	TRADE_DAY_CREATE_TIME: 'Tarih ve Saat', // 日期时间
	TRADE_DAY_ORDER_STATUS: 'Sipariş Durumu', // 订单状态
	TRADE_DAY_MODAL_CONTENT: 'Sipariş vermek istiyor musunuz?', // 是否提交订单？
	TRADE_DAY_TIP_INPUT_AMOUNT: 'Lütfen tutarı girin', // 请输入金额
	TRADE_LARGE_TITLE: 'Toplu İşlem', // 大宗交易
	TRADE_LARGE_TABS: ['Ürün Listesi', 'İşlem Kayıtları'], // 产品列表, 交易记录
	TRADE_LARGE_TAB1_TITLES: ['Alış Detayları', 'Dağıtım Miktarı'], // 购买详情, 分配数量
	TRADE_LARGE_PRICE: 'Fiyat', // 价格
	TRADE_LARGE_RATE: 'Büyüme Oranı', // 增长率
	TEADE_LARGE_RATE_AMOUNT: 'Büyüme Miktarı', // 增长金额
	TRADE_LARGE_MIN_QTY: 'En düşük alım adedi', // 最低购买量
	TRADE_LARGE_MAX_QTY: 'En yüksek alım adedi', // 最高购买金额
	TRADE_LARGE_MIN_DAY: 'Minimum Tutma Süresi', // 最短持有天数
	TRADE_LARGE_ITEM_LABELS: ['Fiyat', 'Büyüme Oranı'], // 价格, 增长率
	TRADE_LARGE_ORDER_TITLE: 'Abonelik Başvuru Siparişi', // 订阅申请订单
	TRADE_LARGE_BUY_AMOUNT: 'Alış Fiyatı', // 购买价格
	TRADE_LARGE_TIP_BUY_COUNT: 'Alınacak hisse adedi', // 请输入购买数量
	TRADE_LARGE_ORDER_AMOUNT: 'Alış Tutarı', // 购买金额
	TRADE_LARGE_TIP_BUY_PWD: 'Lütfen 6 haneli işlem şifresini girin', // 请输入6位交易密码
	TRADE_LARGE_LOG_FINISH: 'Alış Tamamlandı', // 购买完成
	TRADE_LARGE_LOG_PRICE: 'Alış Fiyatı', // 购买价格
	TRADE_LARGE_LOG_NUM: 'Hisse adedi', // 购买数量
	TRADE_LARGE_LOG_AMOUNT: 'Alış Tutarı', // 购买金额
	TRADE_LARGE_LOG_LEVER: 'Kaldıraç', // 杠杆
	TRADE_LARGE_LOG_CREATE_TIME: 'Alış Zamanı', // 购买时间
	TRADE_LARGE_BUY_TOTAL_AMOUNT: 'Toplam Alış Tutarı', // 总购买金额
	TRADE_LARGE_LOOK_PASSWORD: 'Şifrenizi girin', // 请输入您的密码
	TRADE_LARGE_GET_PASSWORD: 'Asistandan şifre talep edin', // 请求助理提供密码
	TRADE_LARGE_LOOK_PASSWORD_ERROR: 'Girilen şifre yanlış', // 输入的密码错误


	TRADE_IPO_TITLE: 'Özgün hisse senedi işlemi', // 新股申购
	TRADE_IPO_TABS: ['Ürün Listesi', 'İşlem Kayıtları', 'Başvuru Başarılı'], // 产品列表, 交易记录, 申购成功
	TRADE_IPO_MODAL_TITLE: 'Özgün hisse senedi işlemi', // 首次公开募股申请
	TRADE_IPO_MODAL_CONTENT: 'Başvurmak istiyorsanız, lütfen onaylayın', // 如果想申购，请点击确定
	TADE_IPO_SUB_PRICE: 'Başvuru Fiyatı', // 申购价格
	TRADE_IPO_PE_RATE: 'Fiyat-Kazanç Oranı', // 市盈率
	TRADE_IPO_SUB_CT: 'Başvuru Tarihi', // 申购日期
	TRADE_IPO_POST_QTY: 'İhraç Miktarı', // 发行量
	TRADE_IPO_RAISE_MONEY: 'Toplanan Fonlar', // 筹集资金
	TRADE_IPO_RECORD_PRICE: 'İhraç Fiyatı', // 发行价
	TRADE_IPO_RECORD_APPLY_AMOUNT: 'İhraç Miktarı', // 发行数量
	TRADE_IPO_RECORD_CREATETIME: 'İşlem Tarihi', // 交易日期


	TRADE_IPO_SUCCESS_SUB: 'Başvuru', // 申购
	TRADE_IPO_SUCCESS_PRICE: 'İhraç Fiyatı', // 发行价格
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: 'İhraç Miktarı', // 发行数量
	TRADE_IPO_SUCCESS_QUANTITY: 'Tahsis Edilen Miktar', // 中签数量
	TRADE_IPO_SUCCESS_AMOUNT: 'Tahsis Edilen Tutar', // 中签金额
	TRADE_IPO_SUCCESS_FREEZE: 'Ödeme Tutarı', // 支付金额
	TRADE_IPO_SUCCESS_CT: 'İşlem Tarihi', // 交易日期
	TRADE_IPO_SUCCESS_ORDER_SN: 'İşlem Numarası', // 交易编号
	TRADE_IPO_SUCCESS_UNPAY_AMOUNT: 'Ödenmemiş Tutar', // 未支付金额
	TRADE_IPO_PUBLIC_PRICE: 'Fiyat',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: 'Miktar',

	TRADE_VIP_TITLE: 'AI İşlem', // VIP
	TRADE_VIP_TABS: ['Ürün Listesi', 'İşlem Kayıtları'], // 产品列表, 交易记录


	TRADE_ISSUANCE_TITLE: 'Fiyatlandırma ve Dağıtım', // 询价配售
	TRADE_ISSUANCE_TABS: ['Ürün Listesi', 'İşlem Kayıtları'], // 产品列表, 交易记录
	TRADE_ISSUANCE_MODAL_0: 'Fiyat', // 价格
	TRADE_ISSUANCE_MODAL_1: 'Toplu Fiyat', // 批量价格
	TRADE_ISSUANCE_MODAL_2: 'Likidite', // 流通量
	TRADE_ISSUANCE_MODAL_3: 'Başvuru Tarihi', // 申购日期
	TRADE_ISSUANCE_MODAL_4: 'Duyuru Tarihi', // 公告日期
	TRADE_ISSUANCE_MODAL_5: 'Vade Tarihi', // 到期日期
	TRADE_ISSUANCE_MODAL_6: 'İhraç Tarihi', // 发行日期
	TRADE_ISSUANCE_MODAL_NULL_DATE: 'Henüz Yayınlanmadı', // 尚未发布
	TRADE_ISSUANCE_LOG_PRICE: 'Fiyat', // 价格
	TRADE_ISSUANCE_LOG_SUCCESS: 'Başarılı Miktar', // 成功数量
	TRADE_ISSUANCE_LOG_AMOUNT: 'Başvuru Tutarı', // 申购金额
	TRADE_ISSUANCE_LOG_DATE: 'Başvuru Tarihi', // 申购日期
	TRADE_ISSUANCE_LOG_SN: 'Seri Numarası', // 序列号
	STOCK_BUY_QUANTITY: 'Adet',


	STOCK_OVERVIEW_TITLE: 'Hisse Detayları', // 股票详情
	STOCK_INFO_TITLES: ['Açılış Fiyatı', 'Önceki Kapanış Fiyatı', 'En Yüksek Fiyat', 'En Düşük Fiyat', 'İşlem Hacmi',
		'İşlem Tutarı'
	], // 开盘价, 前一日收盘价, 最高价, 最低价, 成交量, 成交额
	STOCK_OVERVIEW_TABS: ['Grafik', 'Hisse Analizi', 'Haberler'], // 图表, 股票分析, 新闻
	STOCK_OVERVIEW_KLINE_TABS: ['Dakika', 'Gün', 'Hafta', 'Ay'], // 分钟, 日, 周, 月


	STOK_BUY_QUANTITY: 'Miktar', // 数量
	STOCK_BUY_TIP_QUANTITY: 'Lütfen miktarı girin', // 请输入数量
	STOCK_BUY_AMOUNT: 'Ödeme Tutarı', // 支付金额
	STOCK_BUY_FEE: 'Ücret', // 费用
	STOCK_BUY_CONFIRM: 'Satın Almayı Onayla', // 确认购买


	STOCK_BASE_INFO: ['Şirket Sıralaması', 'Değerlendirme Tutarı', 'Hisse Miktarı', 'Yabancı Yatırımcı Oranı',
		'Sektör Grubu', 'Detaylı Sektör Grubu', '52 Haftanın En Yükseği', '52 Haftanın En Düşüğü'
	], // 公司排名, 评估金额, 股票数量, 外资比例, 行业集团, 详细行业集团, 52周最高, 52周最低
	STOK_KOSDAQ: 'KOSDAQ', // KOSDAQ
	STOCK_COMPANY: 'Şirket Bilgisi', // 公司概况


	STOK_SALES: 'Satış Geliri', // 销售额
	STOCK_SALES_TABS: ['Çeyrek Satış', 'Yıllık Satış'], // 季度销售, 年度销售
	STOCK_SALES_LAST_SALES_AMOUNT: 'Son Satış Tutarı', // 最新销售金额
	STOCK_SALES_LAST_SALES_PROFIT: 'Son Faaliyet Karı', // 最新营业利润
	STOCK_SALES_LAST_SALES_INCOME: 'Son Net Kar', // 最新净利润
	STOCK_SALES_KLINE_TABS: ['Satış Geliri', 'Faaliyet Karı', 'Net Kar'], // 销售额, 营业利润, 净利润


	STOCK_TRADE_TREND_TITLE: 'Yatırımcıların İşlem Eğilimi', // 按投资者的交易趋势
	STOCK_TRADE_TREND_BUY_AMOUNT: ['Net Alış Miktarı', 'Kümülatif Net Alış Miktarı'], // 净购买量, 累计净购买量
	STOCK_TRADE_TREND_INFO_TITLE: ['Bireysel', 'Kurum', 'Yabancı'], // 个人, 机构, 外资
	STOCK_TRADE_TREND_RECENT_TITLE: 'Son İşlem Eğilimi', // 最近交易趋势
	STOCK_TRADE_TREND_RECENT_LABELS: ['Tarih', 'Bireysel', 'Kurum', 'Yabancı'], // 日期, 个人, 机构, 外资
	STOCK_TRADE_TREND_PIE_TITLE: 'İşlem Eğilimi', // 交易趋势


	STOCK_TRADE_SELL_EMPTY_TITLE: 'Açığa Satış Hacmi', // 空头销售量
	STOCK_TRADE_SELL_EMPTY_TITLE_BALANCE: 'Açığa Satış Bakiyesi', // 空头销售余额
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_1ST: 'Toplam İşlem Hacmine Göre', // 相对于总成交量
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC_2ND: 'Piyasa Değerine Göre', // 按市值计算


	STOCK_INDUSTRY_TITLE: 'Sektörde Karşılaştırma', // 行业内比较
	STOCK_INDUSTRY_DESC: 'Otomotiv Parçaları', // 汽车零件
	STOCK_INDUSTRY_DESC_SUFFIX: 'Kamu', // 公开
	STOCK_INDUSTRY_DATA_TITLES: ['Güncel Hisse', 'Sektör Ortalaması'], // 当前股票, 行业平均值
	STOCK_INDUSTRY_DATA_LABELS: ['Değerlendirme Tutarı', 'Net Kar Büyüme Oranı', 'Borç Oranı', 'Fiyat-Kazanç Oranı',
		'Piyasa Değeri', 'Özsermaye Getiri Oranı'
	], // 评估金额, 净利润增长率, 负债率, 市盈率, 市净率, 股东权益回报率


	MARKET_TABS: ['Genel Bakış', 'Popüler Projeler', 'Piyasa Göstergeleri', 'Piyasa Sorunları'], // 概览, 热门项目, 市场指标, 市场问题
	MARKET_OVERVIEW_SELF_TITLE: 'Yerel Ürünler', // 本地产品
	MARKET_OVERVIEW_SELF_TABS: ["Yurtiçi", "Yurtdışı", "Kripto Para"], // 国内, 海外, 虚拟货币
	MARKET_MORE_HOT_TITLE: 'Daha Fazla Popüler Proje', // 更多热门项目
	MARKET_NEWS_TITLE: 'Piyasa Sorunları', // 市场问题


	MARKET_OVERVIEW_THEAD: ["Artış Oranı", "Düşüş Oranı", "En Son Fiyat", "İşlem Hacmi",
		'İşlem Tutarı'
	], // 上涨率, 下跌率, 最新价格, 成交量, 成交金额
	MARKET_HOT_TABS: ['Artış Oranı', 'Düşüş Oranı', 'Fiyat Bildirimi', 'Yüksek ve Düşük Hacimler',
		'Yüksek ve Düşük Tutarlar', 'Yabancı Net Alış', 'Kurum Net Alış', 'Yeni Liste', 'Açığa Satış Oranı'
	], // 上涨率, 下跌率, 价格通知, 成交量高低, 成交金额高低, 外资净买入, 机构净买入, 新上市, 空头比例
	MARKET_HOT_FILTER: ['Bugün', '1 Hafta', '1 Ay', '3 Ay', '6 Ay'], // 当日, 1周, 1月, 3月, 6月
	MARKET_HOT_THEAD: ['Hisse Adı', 'Güncel Fiyat', 'Dalgalanma Oranı', 'Güncel Endeks'], // 股票名称, 当前价格, 波动率, 当前指数
	MARKET_INDEX_TABS: ['Endeks', 'Döviz Kuru', 'Hammadde', 'Kripto Para'], // 指数, 汇率, 原材料, 虚拟货币


	MARKET_NEWS_TABS: ['Haberler', 'Piyasa', 'Ekonomi', 'Sektör', 'Tahvil', 'Türev Ürünler', 'Şirket',
		'Yatırım'
	], // 新闻, 市场, 经济, 行业, 债券, 衍生品, 公司, 投资
	MARKET_NEWS_TIP: 'Sadece ilk 100 popüler proje sunulmaktadır', // 仅提供前100排名的热门项目。


	DIALOG_IPO_SUCCESS_TIP_TITLE: 'Tebrikler', // 恭喜
	DIALOG_IPO_SUCCESS_TIP_TEXT: 'Başvuru başarılı oldu', // 您已成功申购。
	DIALOG_IPO_SUCCESS_LABEL_QTY: 'Tahsis Edilen Miktar', // 配额数量
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: 'Toplam Tahsis', // 配额总量

	KOL: 'Kaldıraç', // 杠杆
	STOCK_ALL: 'Popüler Hisseler', // 热门股票
	STOCK_FOLLOW: 'Takip', // 关注
	STOK_THEAD: ['Hisse', 'Güncel Fiyat', 'Dalgalanma Oranı'], // 股票, 最新价格, 波动率


	PAGE_TITLE_NOTIFICATION: 'İndirim Fırsatları', // 折扣机会
	PAGE_TITLE_TRADE_DISCOUNT: 'Avantajlı İşlem', // 优惠交易
	TIP_POST_SUCCESS: 'İşlem başarılı', // 交易成功


	HAKKIMIZDA: 'Hakkımızda', // 关于我们


	// CURRENCY_UNIT: 'Birimi', // 元
	// QUANTITY_UNIT: 'Miktar', // 数量
	CURRENCY_UNIT: '',
	QUANTITY_UNIT: '', // 数量
	UNIT_BILION: 'Milyar', // 十亿
	UNIT_POS: 'Artış', // 上涨
	UNIT_DAY: 'Gün', // 天


	DAHA_FAZLA: 'Daha Fazla', // 更多
	KISA: 'Özet', // 简要
	EMPTY_NOTIFIY: 'Bildirim Yok', // 无消息
	EMPTY_DATA: 'Kayıt Yok', // 无记录
	BTN_CONFIRM: 'Onayla', // 提交
	BTN_CANCEL: 'İptal', // 取消
	BTN_SEND_SERVICE: 'Müşteri Hizmetlerine Ulaş', // 联系客服
	BTN_SERVICE: 'Müşteri Hizmetleri', // 客户服务
	BTN_DETAIL: 'Detay', // 详情
	BTN_BUY: 'Satın Al', // 购买
	BTN_SELL: 'Sat', // 卖出
	BTN_DETAIL_NOW: 'Şimdi Görüntüle', // 立即查看


	STATUS_LOADING: "Yükleniyor", // 加载中
	STATUS_SUBMIT: 'Veriler Gönderiliyor', // 数据提交中
	STATUS_REQUEST: 'Veriler Alınıyor', // 数据获取中
	STATUS_HTTP_ERROR: 'Tekrar Deneniyor', // 重试中
	STATUS_UPLOAD: 'Yükleniyor', // 上传中


	API_HTTP_ERROR: 'Ağ Hatası', // 网络错误


	API_YFHN_FKSDF: 'Giriş Yap', // 登录
	API_UFAS_FSGM: 'Hesap', // 账户
	API_HDMFGL: 'Şifre', // 密码
	API_UJGTIR: 'Güncel Haberler', // 最新资讯
	API_UGREHTR: 'Başlık', // 标题
	API_UFAS_FGERH: 'Lütfen hisse adı/kodu girin', // 请输入股票名称/代码
	API_UFAS_CVDSVSD: 'Piyasa İşlemi', // 市场交易
	API_UFBFDBG: 'Lütfen hisse işleminden önce doğrulama yapın', // 交易前请确认交易股票
	API_UFBGTTBNNY: 'İşlem Hacmi', // 成交量
	API_UFBERBTYB: 'Artış Oranı', // 涨幅
	API_UFMYUMYU: 'Düşüş Oranı', // 跌幅
	API_UHGNGHNYT: 'Hisse Fiyatı', // 股价


	API_UFBFGBGRT: 'Kimlik Doğrulama ve Güvenlik', // 身份验证和安全
	API_UFBDFBR: 'Güvenli kullanıcı işlemi, hesap koruma ve olağandışı erişim önleme', // 安全用户交易、账户保护和异常访问预防


	API_UFXCVRVR: 'İsim', // 姓名
	API_UFXZVXVR: 'Hesap Numarası', // 户口号码
	API_UFXVDEFRGT: 'Kimlik Kartı veya Sürücü Belgenizi Yükleyin', // 上传您的身份证件或驾照原件
	API_UFANYNU: 'Kimlik Yükleme Notları', // 上传证件注意事项
	API_UFCXVCB: '1. Kimlik bilgileriniz doğru değilse, kimlik doğrulama reddedilebilir. Çözüm yollarına dikkat edin', // 1、如果您的凭据不正确，可能会导致实名验证被拒绝，请关注解决方法及解决办法。
	API_UMBNMBN: '2. Kimlik belgelerinde ışık yansıması ve gölgelerden kaçının', // 2. 应避免上传证件光反射和阴影。
	API_UFYTJTY: '3. Kayıttan önce kimlik bilgilerinizin doğruluğunu ve geçerliliğini kontrol edin', // 3. 注册前，您必须检查您的凭据的准确性和有效期。


	API_UFWETREM: 'Banka Hesap Bilgilerini Doğrulayın', // 验证银行账户信息
	API_UFGFDBFD: 'İşlem tamamlamak için hesabınızı bağlayın', // 关联您的账号以完成交易


	API_UFEWVTG: 'Şifre', // 密码
	API_UXCBVRTBT: 'Şifreyi Doğrula', // 确认密码
	API_UFXCVXRG: 'Davet Kodu', // 邀请码


	API_UFGFDGG: 'Ürün Listesi', // 产品列表
	API_UFXFHDFHRG: 'Başvuru Kayıtları', // 申请记录
	API_UFXCVXGDSD: 'Fiyat', // 价格
	API_UFXFDGG: 'Tutma Süresi', // 持仓天数
	API_UFXFDGRG: 'Minimum Alış Miktarı', // 最少购买量
	API_UFDFHVXRG: 'Maksimum Alış Miktarı', // 最大购买量
	API_UFBDFBVXRG: 'Alış Fiyatı', // 购买价格
	API_UFXCBRHG: 'Toplam Alış Tutarı', // 总购买金额
	API_UWETVXRG: 'Gönder', // 提交


	API_UFXGDSGRRG: 'Alış Miktarı', // 购买数量
	API_UFXEYJRG: 'Ücret', // 手续费
	API_UFXKJKXRG: 'Sipariş Numarası', // 订单号
	API_UFXCVXRG: 'Alış Z0amanı', // 购买时间
	API_UFGHRG: 'Yayınlanma tarihi', // 上市日期
	API_UFXCFFRG: 'Başvuru Miktarı', // 申购数量
	API_UFXCEEG: 'Tahsis Edilen Tutar', // 中签金额
	TRADE_EA_ORDER_PERIOD: 'Dönem',
	TRADE_EA_ORDER_POD: 'Verim',
	TRADE_EA_ORDER_PD: 'Başlangıç ​​Tarihi',
	TRADE_EA_ORR_POD: 'Son Tarih',
	TRADE_EA_OIFJ: 'Teklif indeksi',
	TRADE_EA_YBFIFJ: 'Şirket Adı ve Kod',
	TRADE_EA_ODGVRFJ: 'Fiyat',
	TRADE_EA_OOLKDMJ: 'Değişim',
}