<!-- 펀드 비밀번호 -->
<template>
	<view>
		<CustomHeader title="決済パスワードの変更" @action="handleBack()"></CustomHeader>

		<view class="common_block" style="padding-top: 10px;">
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="古いパスワードを入力してください" type="password" v-model="value"></input>
			</view>
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="新しいパスワードを入力してください" type="password" v-model="value2"></input>
			</view>
			<view style="padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;">
				<input placeholder="新しいパスワードをもう一度入力してください" type="password" v-model="value3"></input>
			</view>
			<view @click="transactionPassword()" style="background-color:#4b5fcc;
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;">
				確認
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//修改交易密码
			async transactionPassword() {
				let list = await this.$http.post('api/user/updatePayPassword', {
					// oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('修正されました.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		}
	}
</script>

<style lang="scss">
	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}
</style>