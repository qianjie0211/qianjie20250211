<template>
	<view class="common_btn"
		style="margin:40rpx auto; width: 80%;background-color: #f7be65;border-radius: 24rpx;border:none;color:#fff;"
		@click="handleSignOut()">
		{{$lang.BTN_SIMGN_OUT}}
	</view>
</template>

<script>
	export default {
		name: 'SignOut',
		methods: {
			// 登出
			handleSignOut() {
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version);
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>
</style>