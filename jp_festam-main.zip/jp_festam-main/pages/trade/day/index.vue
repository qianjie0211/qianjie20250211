<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderThird :title="$lang.TRADE_DAY_TITLE" color="#000">
			<view style="color:#000;width: 60px;" @click="linkRecord()">{{$lang.TRADE_DAY_RECORD}}</view>
		</HeaderThird>

		<view style="min-height: 90vh;padding:40rpx;width: 85%;border-radius: 10px;margin-left: 10px;">
			<view style="width: 100%;justify-content: center;display: flex;">
				<image src="/static/trade_day.png" mode="widthFix" style="width: 150px;padding: 40px 0px;"></image>
			</view>
			<TradeDayBuy></TradeDayBuy>
		</view>
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeDayBuy from './components/TradeDayBuy.vue';
	export default {
		components: {
			HeaderThird,
			TradeDayBuy,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_DAY_RECORD
				})
			}
		},
	}
</script>