<template>
	<view>
		<header class="header_bg">
			<view style="padding:20rpx 40rpx;">
				<view class="flex">
					<view @click="fanhui()">
						<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;"></image>
					</view>
					<view class="flex-1 text-center" style="font-size: 46rpx;color: #FFFFFF;padding: 16rpx 0;">
						{{$lang.FOF}}
					</view>
				</view>
				
				<!-- <view
					style="color:#FFFFFF;font-size: 20rpx;background-color: #EEAB44;border-radius: 26rpx;padding:6rpx 16rpx;width: max-content;"
					@tap="linkFOF()">{{$lang.FOF_BTN_VIEW}}</view> -->
			</view>
		</header>
		<!-- <header class="common_header">
			<view class="left" @click="linkBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text style="color: #FFFFFF;">{{$lang.FOF_TITLE}}</text>
			</view>
		</header> -->

		<view style="padding:36rpx;">
			<template v-if="topList && topList.length>=0">
				<block v-for="(item,index) in topList" :key="index">
					<view style="border-bottom: 1px solid #3B3B3D;padding-bottom: 36rpx;margin-bottom: 36rpx;">
						<view style="display: flex;align-items: center;">
							<image src="/static/icon_fof.png" mode="aspectFit" :style="$theme.setImageSize(64)"></image>
							<view style="padding-left: 20rpx;">
								<view style="font-size: 26rpx;" :style="{color:$theme.WHITE}">{{item.name}}
								</view>
								<view style="font-size: 22rpx;color:#8E8D92;">{{item.fudu}}
								</view>
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding-top: 32rpx;">
							<view>
								<view style="color:#8E8D92;">{{$lang.FOF_RUN_DT}}</view>
								<view style="color:#FFFFFF;">{{item.days}}</view>
							</view>
							<view>
								<view style="color:#8E8D92;text-align: right;">{{$lang.FOF_COPY_AMOUNT}}</view>
								<view style="color:#FFFFFF;text-align: right;">
									{{item.amount}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding-top: 24rpx;">
							<view>
								<view style="color:#8E8D92;">{{$lang.FOF_AVERAGE_PROFIT}}</view>
								<view style="color:#FFFFFF;">{{item.fudu}}</view>
							</view>
							<view>
								<view style="color:#8E8D92;text-align: right;">{{$lang.FOF_COPY_FOLLOWS}}</view>
								<view style="color:#FFFFFF;text-align: right;">
									{{item.people}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding-top: 24rpx;">
							<view>
								<view style="color:#8E8D92;">{{$lang.FOF_GAIN}}</view>
								<view :style="{color:$theme.RISE}">{{!item.shouyi?'':item.shouyi}}</view>
							</view>
							<view>
								<view style="color:#8E8D92;text-align: right;">{{$lang.FOF_MIN_DAY}}</view>
								<view style="color:#FFFFFF;text-align: right;">
									{{item.min_day+` `+$lang.FOF_DAYS}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding-top: 24rpx;">
							<view style="flex:1 0 auto;">
								<view
									style="background-color: #25262A;border-radius: 16rpx;padding:8rpx 24rpx;width: 60%;color:#FFFFFF;text-align: center;">
									<view style="display: flex;align-items: center;justify-content: space-between;">
										<image src="/static/icon_sub.png" mode="aspectFit"
											:style="$theme.setImageSize(48)" @tap="handleSub(index)"></image>
										<view>{{item.curDays +` `+$lang.FOF_DAYS}}</view>
										<image src="/static/icon_add.png" mode="aspectFit"
											:style="$theme.setImageSize(48)" @tap="handleAdd(index)"></image>
									</view>
								</view>
							</view>

							<view style="margin-left: auto;" @tap="handleModal(item)">
								<view
									style="border-radius:44rpx;background-color: #16E2E2;color:#FFFFFF;padding:12rpx 24rpx;font-size: 24rpx;text-align: center;">
									{{$lang.TRADE_COPY_BTN_COPY}}
								</view>
							</view>
						</view>
					</view>
				</block>
			</template>

			<view style="display: flex;align-items: center;padding:36rpx 0;">
				<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
				<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
					{{$lang.FOF_LIST_TITLE}}
				</view>
			</view>

			<view style="display: flex;align-items: center;color:#8E8D92;font-size: 22rpx;">
				<view style="width: 80rpx;">{{$lang.FOF_LIST_THEAD_INDEX}}</view>
				<view style="width: 80%;text-align: center;">{{$lang.FOF_LIST_THEAD_TRADER}}</view>
				<view style="margin-left: auto;">{{$lang.FOF_LIST_THEAD_PER}}</view>
			</view>
			<template v-if="!list ||list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="`a`+index">
					<view style="display: flex;align-items: center;color:#8E8D92;font-size: 22rpx;padding-top: 20rpx;">
						<view style="width: 80rpx;text-align: center;" :style="{color:index<3?$theme.RISE:'#8E8D92'}">
							{{index+1}}
						</view>
						<view style="flex:1 0 auto;">
							<view style="display: flex;align-items: center;padding-left: 20rpx;">
								<image :src="item.userinfo.avatar" mode="scaleToFill" style="border-radius: 100%;"
									:style="$theme.setImageSize(56)">
								</image>
								<view style="flex:1 0 auto;">
									<view style="color:#FFFFFF;padding-left: 40rpx;">{{item.userinfo.nick_name}}</view>
								</view>
							</view>
						</view>
						<view style="margin-left: auto;" :style="{color:$theme.RISE}">
							{{item.percentage}}
						</view>
					</view>
				</block>
			</template>
		</view>

		<!-- 弹层 -->
		<template v-if="isShow">
			<view class="mask" @tap="handleClose()"></view>
			<view class="modal_wrapper">
				<view
					style="background-color:#151517;border-radius: 24rpx 24rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
					<view
						style="text-align: center;font-size: 32rpx;font-weight: 700;position: relative;color: #F3F3F3;">
						{{$lang.FOF_MODAL_TITLE}}
						<view style="position: absolute;top: -20rpx; right: 32rpx;" @click="handleClose()">
							<image src="/static/close.svg" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
						</view>
					</view>

					<view style="color:#FFFFFF;text-align: center;font-size: 28rpx;line-height: 2;padding-top: 40rpx;">
						{{$lang.FOF_MODAL_TIP}}
					</view>

					<view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding:36rpx;">
							<view style="color:#8E8D92;">{{$lang.FOF_MODAL_CYCLE}}</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.RISE}">
								{{itemInfo.curDays+` `+$lang.FOF_DAYS}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding:0 36rpx;">
							<view style="color:#8E8D92;">{{$lang.COPY_MODAL_NET_VALUE}}</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.RISE}">{{itemInfo.fudu}}</view>
						</view>

						<view style="font-size: 28rpx;color:#FFFFFF;padding-left: 36rpx;padding-top: 40rpx;">
							{{$lang.FOF_MODAL_TIP_AMOUNT}}
						</view>

						<view style="margin:36rpx;background-color: #25262A;border-radius: 16rpx;padding:24rpx 40rpx;">
							<input v-model="amount" type="digit" :placeholder="$lang.FOF_MODAL_ENTER_AMOUNT"
								:placeholder-style="$util.setPlaceholder()"></input>
						</view>

						<view
							style="margin:48rpx auto;width: 90%;border-radius:50rpx;background-color: #16E2E2;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
							@tap="handleSubmit()">
							{{$lang.FOF_MODAL_BTN_CONFIRM}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	
	export default {
		components: {
		
		},
		data() {
			return {
				isShow: false, // 弹层
				amount: '',
				topList: [], // 产品列表
				list: [], // 基金成员列表
				itemInfo: null, // 选中数据
			}
		},

		onShow() {
			this.getTopData();
			this.getMember();
		},
		onPullDownRefresh() {
			this.getTopData();
			this.getMember();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkBack() {
				// 默认回退一级
				uni.navigateBack({
					delta: 1,
				})
			},
			handleSub(index) {
				if (this.topList[index].curDays <= this.topList[index].min_day) {
					uni.showToast({
						title: this.$lang.FOF_SUB_TIP,
						icon: 'none'
					})
					return false;
				}
				this.$set(this.topList, index, {
					...this.topList[index],
					curDays: this.topList[index].curDays - this.topList[index].min_day
				})
			},
			handleAdd(index) {
				console.log(`index`, index, this.topList[index]);
				this.$set(this.topList, index, {
					...this.topList[index],
					curDays: this.topList[index].curDays + this.topList[index].min_day
				})
			},

			handleModal(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			handleClose() {
				this.isShow = false;
			},
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount.length <= 0) {
					uni.showToast({
						title: this.$lang.FOF_MODAL_TIP_AMOUNT,
						icon: 'none'
					})
					return false;
				}
				if (!this.$util.checkInputNumber(this.amount)) return false;
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.itemInfo.id,
					price: this.amount,
					day: this.itemInfo.curDays,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: this.$lang.COMMON_SUCCESS,
					icon: 'success'
				});
				this.handleClose();
				setTimeout(() => {
					this.getTopData();
					this.getMember();
				}, 1000);
			},

			// 会员列表
			async getMember() {
				const result = await this.$http.post(`api/jijin/member`);
				if (!result) return false;
				this.list = result.filter(item => item.userinfo);
				this.list.forEach(item => {
					if (!item.userinfo.avatar || item.userinfo.avatar.length <= 0) {
						item.userinfo.avatar = `/static/logo.png`;
					}
					if (!item.userinfo.nick_name || item.userinfo.nick_name.length <= 0) {
						item.userinfo.nick_name = item.userinfo.p_mobile;
					}
				})
			},

			// 产品列表
			async getTopData() {
				const result = await this.$http.post(`api/jijin/list`);
				if (!result) return false;
				console.log(`result:`, result);
				this.topList = result;
				this.topList.forEach(item => {
					item.curDays = item.min_day;
				})
			},


		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 0 40rpx;
		display: flex;
		align-items: center;
		padding-top: 48rpx;
		padding-bottom: 20rpx;
		border-bottom: 1px solid #3B3B3D;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}

	.mask {
		position: fixed;
		top: 0;
		left: 0;
		bottom: -1;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>