<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderThird :title="$lang.TRADE_IPO_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;width: 70px;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
		</HeaderThird>

		<view class="flex" style="width: 90%;margin-left: auto;">
				  <view class="flex-1 bold" style="font-size: 23px;color: #FFFFFF;">新株申し込み</view>
				  <image src="/static/ipo.png" mode="widthFix" style="width: 120px;"></image>
		</view>

		<view style="background-color: #FFFFFF;min-height: 80vh;padding:40rpx;width: 85%;border-radius: 10px;margin-left: 10px;">
			<TradeIPOList ref="list"></TradeIPOList>
		</view>
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	export default {
		components: {
			HeaderThird,
			TradeIPOList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			};
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO_RECORD
				})
			}
		}
	}
</script>