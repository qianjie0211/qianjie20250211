<!-- 个人交易 交易信息 -->
<template>
	<view class="common_block" style="padding:20px;">
		<view style="display: flex;align-items: center;padding:4px;">
			<image src="/static/kr.png" mode="aspectFit" :style="$util.setImageSize(60)"
				style="border-radius: 100px;background-color:#bdd8ffa1;padding:6px;"></image>
			<view style="padding-left: 10px;" :style="{color:$theme.TITLE}">KRW</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;">
			<view style="font-size: 36rpx;" :style="{color:$theme.TITLE}">국내주식잔고/손익</view>
			<view class="common_btn btn_secondary" style="width: 20%;transform: scale(0.85);margin-left:40px;"
				@click="handleDeposit"> {{$lang.DEPOSIT}} </view>
			<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
				:style="$util.setImageSize(40)" style="margin-left: auto;">
			</image>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
			<view>예수금</view>
			<view style="font-size: 48rpx;font-weight: 700;padding-left: 40px;" :style="{color:$theme.PRIMARY}">
				<!-- {{$util.formatNumber(info.money)}}
				<text style="padding:0 4px">원</text> -->
				{{showAmount?$util.formatNumber(info.money)+'원':hideAmount}} 
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		props: ['info'],
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			};
		},
		created() {},
		methods: {
			// 资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
		}
	}
</script>