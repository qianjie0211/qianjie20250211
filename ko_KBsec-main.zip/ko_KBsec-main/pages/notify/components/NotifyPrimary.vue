<template>
	<view
		style="margin:20rpx 30rpx;border-radius: 4px;display: flex;align-items: center;background-color: #F8F8F8;padding:0 20px;">
		<image src="/static/horn.png" mode="aspectFit" :style="$theme.setImageSize(30)"></image>
		<template v-if="title">
			<u-notice-bar :text="$lang.LAUNCH_TITLE" speed="80" :url="linkNotify" :color="$theme.PRIMARY"
				:bgColor="$theme.TRANSPARENT" icon=""></u-notice-bar>
		</template>
		<!-- <image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(30)" @click="actionEvent()"></image> -->
	</view>
</template>

<script>
	export default {
		name: 'NotifyPrimary',
		data() {
			return {
				info: null,
			}
		},
		computed: {
			linkNotify() {
				if (this.info) {
					const val = this.info.id;
					return this.$CONSTANTS.NOTIFY_DETAIL + `?id=${val}`
				} else {
					uni.navigateTo({
						url: this.$CONSTANTS.NOTIFIY_INDEX
					})
				}
			},
			title() {
				return !this.info ? this.$lang.LAUNCH_TITLE : this.info.biaoti;
			}
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/app/gglist`);
				console.log(`result:`, result);
				if (!result) return false;
				const temp = result.length > 0 ? result : null;
				if (temp && temp.length > 0) {
					// 排序 獲取當前最新公告
					const tempSort = temp.sort((a, b) => new Date(b.updated_at).getTime() -
						new Date(a.updated_at).getTime());
					this.info = !tempSort || tempSort.length <= 0 ? null : tempSort[0];
					console.log(this.info);
				}
			}
		}
	}
</script>

<style>
</style>