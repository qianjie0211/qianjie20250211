<!-- 登录 -->
<template>
	<view style="height:100vh;width: 100%;background-image: url(/static/shouye_bg.webp);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat">
		<view class="" style="display: flex;justify-content: center;">
			<view style="margin-top: 50px;">
				
				<image mode="widthFix" src="/static/logo.png"  style="width: 300px;"></image>
			</view>
		</view>
		<!-- <view class="text-center margin-top-15 font-size-16" style="color: #666666;">골드만삭스증권</view> -->

       <view class="padding-20">
		   <view style="background-color: #fff;border-radius: 10px;">
		   	<view class="flex" style=" justify-content: space-between;padding: 20px;">
		   		<view>에 오신 걸 환영합니다.</view>
		   		<view @tap="register()">
		   			<view class="font-size-10" style="background-color: #d1defb;border-radius: 5px;padding: 5px 10px;">회원가입</view>
		   		</view>
		   	</view>
				
		   <view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">	
		   <view style="width: 85%;line-height: 20px;height: 10px;position: relative;">계정</view>
			<input shape="" :placeholder="$lang.USER_NAME" color='#121212'
				placeholderStyle="font-size: 13px;color: #999999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value1" type="number"
				maxlength="11" style="margin-top:20px;background-color: rgba(255,255,255,0.75);width: 85%;border-bottom: 1px #EEEEEE solid;"></input>
				
		 <view style="width: 85%;line-height: 20px;height: 0px;position: relative;margin-top: 20px;">비밀 번호</view>
			<input shape="" :placeholder="$lang.PASSWORD" prefixIcon="lock-fill" color='#121212'
				placeholderStyle="font-size: 13px;color: #999999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value2" type="password"
				style="margin-top:60rpx;background-color: rgba(255,255,255,0.75);width: 85%;border-bottom: 1px #EEEEEE solid;"></input>
				
			<view class="" style="padding: 20px;width: 100%;justify-content: center;align-items: center;flex-direction: column;display: flex;">
				<view class="text-center color-white" style="width: 70%;margin-top:20rpx;background-color: #0b03bc;padding: 10px;border-radius: 10px;" @click="gain_login">{{$lang.SIGN_IN}}</view>
			</view>
			
		</view>
		</view>
		<view style="width: 70%;margin-top:60rpx;line-height: 20px;height: 20px;position: relative;">
			<u-checkbox-group>
				<u-checkbox activeColor="#0b03bc" label="로그인 상태 유지" v-model="checked" labelColor="#38AA9A"
					labelSize="12px" :checked="checked"></u-checkbox>
			</u-checkbox-group>
			<!-- <view
				style="font-size: 14px;color: #38AA9A;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
				@tap="register()">
				{{$lang.SIGN_UP}}
				<u-icon name="arrow-right" color="#38AA9A" size="14" :bold="true"
					style="display: inline-block;"></u-icon>
			</view> -->
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				checked: true,
			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput') || '';
			let passinput = uni.getStorageSync('passinput') || '';

			if (userinput) {
				this.value1 = userinput
			}
			if (passinput) {
				this.value2 = passinput
			}

		},
		onHide() {
			uni.setStorageSync('userinput', this.value1);
			uni.setStorageSync('passinput', this.value2);
		},
		methods: {
			register() {
				console.log(22222)
				uni.navigateTo({
					url: '/pages/register/register'
				});
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.setStorageSync('userinput', this.value1);
					uni.setStorageSync('passinput', this.value2);
					uni.$u.toast('성공적 로그인');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
	}
</script>