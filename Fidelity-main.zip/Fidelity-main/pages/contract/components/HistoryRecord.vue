<template>
	<view style="padding-bottom: 40px;">
		<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
			<u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" :label="$lang.COIN_RECORD_TIP_CUR_COIN"
					v-model="isShowCurCoin" labelColor="#999" labelSize="24rpx" @change="filterCoin"
					:checked="isShowCurCoin" iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color: transparent;padding:8px 16px 16px 16px; border-bottom: 1px solid #F3F3F31A;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 10rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
							{{item.name}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:$theme.FALL}">
							{{item.lever+` X`}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 30rpx"
							:style="{color:item.fx==1?'#6D41FF':$theme.SECOND}">
							{{item.fxText}}
						</view>
						<view  style="margin-left: auto;">
							<view :style="setStyle(item.direct)">
								{{item.directText}}
							</view>
						</view>
						<!-- <view style="margin-left: auto;" :style="{color:item.status==1? $theme.FALL:'#B8B8B8'}">
							{{item.status==1?$lang.COIN_HISTORY_TIP_CANCEL:$lang.COIN_HISTORY_TIP_TRADE}}
						</view> -->
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_BUY_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.buy_price}}</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_CURRENT_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.price}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_CURRENT_QTY}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.quantity}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_CURRENT_TOTAL}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.total}}</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_FEE_buy}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.buy_fee}}</view>
					</view>

					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_FEE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.fee}}</view>
					</view> -->


					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HOLD_BUY_PL}}</view>
						<view style="font-size: 28rpx;" :style="{color:item.yingkui*1>0?$theme.RISE:$theme.FALL}">
							{{(item.yingkui*1)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_RATE}}</view>
						<view style="font-size: 28rpx;" :style="{color:item.rate*1>0?$theme.RISE:$theme.FALL}">
							{{(item.rate*1).toFixed(2)}}%
						</view>
					</view>

					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">0.1358</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_QTY}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">0.55</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.sn}}
						</view>
						<view style="font-size: 26rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'HistoryRecord',
		components: {
			EmptyData
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				isShowCurCoin: false, // 是否僅顯示當前coin
			}
		},
		created() {},

		methods: {
			// 過濾出當前coin的數據
			filterCoin(e) {
				this.isShowCurCoin = e;
				// this.getList(); // 重新請求數據
				this.$emit('action', this.isShowCurCoin);
			},

			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>

<style>
</style>