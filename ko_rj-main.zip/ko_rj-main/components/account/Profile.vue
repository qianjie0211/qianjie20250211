<!-- 用户基本信息 -->
<template>
	<view style="padding:0 20rpx;margin-top: 10px;">
		<view class="flex flex-b">
			<view style="text-align: center;">
				<view style="font-size: 22px;color: #fff;">Hi，환영합니다</view>
				<view style="background-color: #fff;border-radius: 20px;padding: 5px 15px;color: #DE834E;margin-top: 5px;">계좌 자금 안전 보호중</view>
			</view>
			<view>
				<image src="/static/dun.png" mode="widthFix" style="width: 100px;height: 100px;"></image>
			</view>
		</view>

		<view style="align-items: center;background-image: url(/static/user_top.png);padding: 10px;background-size: cover;margin-top: -25px;">
			<view class="flex">
				<view style="background-color: transparent;">
					<image style="border-radius: 100px;" mode="scaleToFill" :src="avatar" :style="$theme.setImageSize(120)">
					</image>
				</view>
				<view>
					<view style="display: flex;align-items: center;justify-content: center; padding:0 20rpx;">
						<view style="font-size: 32rpx;text-align: left;color:#121212;padding-right: 30rpx;">
							{{info.p_mobile}}
						</view>
					</view>
				</view>
			</view>
			
			
			<view style="display: flex;align-items: center;">
				<view class="flex flex-b" style="width: 100%; background-color: #CEB494;padding: 5px;border-radius: 10px;opacity: 0.7;">
					<view style="display: flex;align-items: center;line-height: 1.6;">
						<view style="color:#000;font-size: 32rpx;font-weight: 700;">
							총 자산
						</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
							@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
						</image>
					</view>
					<view style="font-size: 36rpx;font-weight: 700;line-height: 1.6;color: #be844f;">
						{{showAmount?$util.formatMoney(info.totalZichan):hideAmount}}
					</view>
				</view>
			</view>
		
			<view style="display: flex;align-items: center;font-size: 28rpx;padding: 5px;margin-top: 5px;">
				<view style="flex:1 0 50%;">
					<view style="color:#666666;">사용 가능한 금액</view>
					<view :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.money):hideAmount}}</view>
				</view>
				<!-- <view style="flex:1 0 50%;text-align: right;">
					<view style="color:#666666;">꼭 매달리게 하다</view>
					<view :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.freeze):hideAmount}}</view>
				</view> -->
			</view>	
		</view>
		
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: {
			info: {
				type: Object,
				default: {}
			},
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			}
		},
		computed: {
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 处理显示姓名或昵称
			showName() {
				return this.info.real_name ?
					this.info.real_name : this.info.nick_name ?
					this.info.nick_name : ''
			},
			// 处理显示头像
			avatar() {
				return this.info.avatar ? this.info.avatar : '/static/app_logo.png';
			},
		},

		methods: {
			// 进入信息修改页面
			handleLink() {
				// uni.navigateTo({
				// 	url: this.$paths.ACCOUNT_AVATAR,
				// })
			},
		}
	}
</script>

<style>

</style>