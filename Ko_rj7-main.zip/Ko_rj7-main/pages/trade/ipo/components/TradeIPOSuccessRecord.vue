<template>
	<view style="margin-top: 90px;background-color: #fff;min-height: 100vh;">
		<view class="flex" style="border-bottom: 1px #ccc solid;padding: 10px 15px;">
			<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
			<view style="color:#000; margin-left: 5px;">세부정보</view>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px #ccc solid; padding: 10px;">
					<view style="padding: 5px;">
						<view class="flex bold" style="border: 1px #ccc solid;padding: 10px;border-radius: 5px;">
							<view>{{item.goods.name}}</view>
							<view class="margin-left-5 flex-1">({{item.goods.code}})</view>
							<!-- <view :style="{color:transStatus2(item.status)}">{{transStatus(item.status)}}</view> -->
						</view>
					</view>
					<view class="flex" style="padding: 0px 10px;gap: 10px;">
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_RECORD_PRICE}}</view>
							<view>{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}</view>
							<view>{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}</view>
						</view>
					</view>
					<view class="flex" style="padding: 10px 10px;gap: 10px;">
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_SUCCESS_QUANTITY}}</view>
							<view>{{$util.formatNumber(item.success)+` ${$lang.QUANTITY_UNIT}`}}</view>
						</view>
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}</view>
							<view>{{$util.formatMoney(item.success_num_amount)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
					</view>


					<view class="flex" style="padding: 0px 10px;gap: 10px;">
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_SUCCESS_FREEZE}}</view>
							<view>{{$util.formatMoney(item.freeze)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_SUCCESS_UNPAY_AMOUNT}}</view>
							<view>
								{{$util.formatMoney(item.success*item.price-item.freeze)+' '+ `${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
					</view>

					<view class="flex padding-10">
						<view class="hui1 flex-1">거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
					<view class="flex" style="padding: 0px 10px;">
						<view class="hui1 flex-1">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeIPOSuccessRecord',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		created(option) {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				console.log(result);
				this.list = result || [];
			},

			async subscription(item) {
				const result = await this.$http.post(`api/goods-shengou/pay`, {
					id: item.id
				});
				console.log('result:', result);
				// if (result.code == 0) {
				// 	uni.$u.toast(result.message);
				// 	if (result.success == 0) {
				// 		setTimeout(() => {
				// 			this.$util.linkCustomerService();
				// 		}, 500)
				// 	} else {
				// 		uni.redirectTo({
				// 			url: TRADE_IPO_SUCCESS,
				// 		});
				// 		this.$router.go(0)
				// 	}
				// } else {
				// 	uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				// }
			},
		},
	}
</script>