<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond style="background-color: #F8C351;" :title="$lang.ACCOUNT_TRADE_LOG_TITLE" :color="$theme.SECOND"></HeaderSecond>

		<TabsPrimary :tabs="tabLabels" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<view style="padding: 20rpx 0;">
			<template v-if="curTab == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="curTab == 1">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="curTab == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		computed: {
			// tabs的明文
			tabLabels() {
				return [
					this.$lang.TRADE_LOG_TRADE,
					this.$lang.TRADE_LOG_DEPOSIT,
					this.$lang.TRADE_LOG_WITHDRAW
				];
			}
		},
		onLoad(opt) {
			console.log(opt);
			const temp = opt.tag == 'recharge' ? 1 : opt.tag == 'withdraw' ? 2 : 0;
			this.curTab = temp || 0;
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>