<template>
	<view style="min-height: 100vh;background-color: #010101;">
		<header class="header" style="background-color: #010101;" v-if="!top_show">
			<view class="flex" @click="$util.goBack()">
				<view class="flex-1">
					<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				</view>

			</view>
			<view class="flex-1 text-center font-size-18" style="padding-left: 0;text-align: center;">
				<text style="color:#FFFFFF;">{{type==1?$lang.TRADE_DAY_TITLE:$lang.H_Y_J_Y}}</text>
			</view>
			<view class="" style="padding-left: 0;" @click="Record()">
				<text style="color:#FFFFFF;font-size: 12px;">{{$lang.SHENQING_JILV}}</text>
			</view>
		</header>

		<header style="padding-top: 60rpx;" v-if="top_show">
			<view class="left" @click="$u.route({type:'switchTab',url:'/pages/home/index'});"
				style="position: absolute;top: 75rpx;left: 5px;">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view style="margin-left: 30px;">
				<scroll-view :scroll-x="true" style="white-space: nowrap;" :scroll-left="type==1?0:600" @touchmove.stop
					:scroll-with-animation="true">
					<view style="display: flex;margin:0 10rpx;" class="align-center">

						<block v-for="(item,index) in $util.TABS()" :key='index'>
							<view :style="$util.setStyle1((type==1?0:6) ==index)" @click="$util.changeTab1(item.url)">
								{{item.value}}
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</header>

		<view style="background-color: #424242;margin: 16px 20px;border-radius: 12px;">
			<view
				style="margin-bottom: 28rpx;border-radius: 10rpx;display: flex;align-items: center;justify-content: space-between;"
				v-if="type==1">
				<block v-for="(item,index) in $lang.TRADE_DAY_TABS.slice(0,2)" :key='index'>
					<view :style="setStyle(curTab==index)" @click="changeTab(index)" class="flex-1">
						{{item}}
					</view>
				</block>
			</view>
			<view
				style="margin-bottom: 28rpx;border-radius: 10rpx;display: flex;align-items: center;justify-content: space-between;"
				v-if="type==2">
				<block v-for="(item,index) in $lang.TRADE_DBS.slice(0,2)" :key='index'>
					<view :style="setStyle(curTab==index)" @click="changeTab(index)" class="flex-1">
						{{item}}
					</view>
				</block>
			</view>
		</view>

		<template v-if="curTab==0">
			<TradeDayBuy @action="changeTab" @record_click="Record()" :code='type' v-if="isUpdate"></TradeDayBuy>
		</template>

		<template v-else-if="curTab==1">
			<TradeDaySuccessList :list="successList" :code='type' @chicang_list="getSuccessList" v-if="isUpdate">
			</TradeDaySuccessList>

		</template>
		<!-- <template v-else>
			<TradeDayOrderList :list="orderList" :type='type' v-if="isUpdate"></TradeDayOrderList>
		</template> -->

		<view style="height: 160rpx;"></view>
		<FooterSmall code="stock" />
	</view>
</template>

<script>
	import TradeDayBuy from './components/TradeDayBuy.vue';
	// import TradeDayOrderList from './components/TradeDayOrderList.vue';
	import TradeDaySuccessList from './components/TradeDaySuccessList.vue';
	export default {
		components: {
			TradeDayBuy,
			// TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				orderList: [], // 申请列表
				successList: [], // 通过列表
				isUpdate: true, // 页面子组件强刷
				type: 1,
				top_show: false
			}
		},
		onLoad(op) {
			if (op.type) {
				this.type = op.type
			}

			if (op.top1 == 1) {
				this.top_show = true
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.refreshChild();
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {

			// 此为驱动子组件强刷的方案。
			refreshChild() {
				this.isUpdate = false;
				this.$nextTick(() => {
					this.isUpdate = true;
				})
			},

			Record() {
				uni.navigateTo({
					url: '/pages/trade/day/Record?type=' + this.type
				})
			},
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 1) this.getSuccessList();
				if (this.curTab == 2) this.getOrderList();
			},

			async getOrderList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/Rinei/rineiorder`, {
					status: this.curTab + 0,
					type: this.type
				});
				if (!result) return false;
				console.log(result);
				this.orderList = result.length <= 0 ? [] : result.map((item, index) => {
					return {
						...item,
						// 状态值明文、icon
						...this.$theme.setStatusPrimary(item.status),
						// 状态值 样式:字号、字色、背景等
						style: this.$theme.setStatusPrimary(item.status),
					}
				});
			},

			async getSuccessList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/Rinei/rineiorder`, {
					status: 1,
					type: this.type
				});
				if (!result) return false;
				console.log(result);
				this.successList = result.length <= 0 ? [] : result;
			},
			setStyle(val) {
				return {
					// minWidth: `120rpx`,
					margin: '8rpx',
					padding: `12rpx 20rpx`,
					textAlign: 'center',
					backgroundColor: val ? '#018ef8' : '#424242',
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `16rpx`,
				}
			}
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>