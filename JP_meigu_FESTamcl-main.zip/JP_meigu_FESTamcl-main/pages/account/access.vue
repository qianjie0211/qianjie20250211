<template>
	<view class="access_bg" :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`500rpx`,`bg_1`)">
		<view style="position: fixed;right:3vw;top:3vh;z-index: 11115;">
			<!-- <Translate></Translate> -->
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding: 7vh 0 3vh 0;">
			<image src='/static/logo.png' mode="widthFix" style="width: 200px;">
			</image>
		</view>

		<view
			style="display: flex;align-items: center;justify-content: center;line-height: 2.6;font-size: 36rpx;font-weight: 700;color: #FFFFFF;padding-bottom: 30rpx;">
			<!-- {{$APPNAME}} -->
		</view>
       <view style="margin-top: 20px;">
		   <TabsSeventh :tabs="setTabs" @action="changeTab" :acitve="curTab"> </TabsSeventh>
	   </view>
		

		<view :class="isSignIn?'right_in':'left_in'" style="margin:0 20rpx;padding:30rpx;background-color: #fff;">

			<!-- 手机号登录及注册 -->
			<view style="font-size: 32rpx;font-weight: 700;">{{$lang.ACCOUNT_NAME}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 40rpx;border-radius: 20px;">
				<image src="/static/account_name.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				<input v-model="user" type="number" :placeholder="$lang.TIP_ENTER_ACCOUNT_NAME" maxlength="11"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<!-- 邮箱登入注册及邮箱验证码 印度项目会使用 -->
			<!-- <view class="common_input_wrapper" style="margin-bottom: 40rpx;" :style="$theme.setDirection()">
				<image src="/static/account_name.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				<input v-model="user" type="text" :placeholder="$lang.ACCOUNT_EMAIL"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>
			<template v-if="!isSignIn">
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;" :style="$theme.setDirection()">
					<image src="/static/account_name.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
					<input v-model="emailCode" type="text" :placeholder="$lang.ACCOUNT_EMAIL"
						:placeholder-style="$theme.setPlaceholder()" style="width: 56%;"></input>
					<VerifyCode :info="user" ref="verifyCode"></VerifyCode>
				</view>
			</template> -->

			<!-- 通用的输入密码 -->
			<view style="font-size: 32rpx;font-weight: 700;">{{$lang.ACCOUNT_PASSWORD}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 40rpx;border-radius: 20px;">
				<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.TIP_ENTER_ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="password" type="password" :placeholder="$lang.TIP_ENTER_ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>

				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<!-- 注册所需 -->
			<template v-if="!isSignIn">
				<view style="font-size: 32rpx;font-weight: 700;">{{$lang.VERIFY_ACCOUNT_PASSWORD}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;border-radius: 20px;">
					<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
					<template v-if="isShow">
						<input v-model="verifyPassword" type="text" :placeholder="$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>
					<template v-else>
						<input v-model="verifyPassword" type="password" :placeholder="$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>

					<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
						:style="$theme.setImageSize(32)" @click="toggleShow">
					</image>
				</view>
				<view style="font-size: 32rpx;font-weight: 700;">{{$lang.INVITATION_CODE}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;border-radius: 20px;">
					<image src="/static/account_code.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
					<input v-model="code" type="text" :placeholder="$lang.TIP_ENTER_INVITATION_CODE" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</view>
			</template>

			<!-- 记住密码，以及登入注册的切换 -->
			<view style="display: flex;align-items: center;margin-bottom: 40rpx;">
				<template v-if="isSignIn">
					<u-checkbox-group>
						<!-- circle -->
						<u-checkbox shape=""  :label="$lang.TIP_REMEMBER_PWD"
							v-model="isRemember" labelColor="#666666" labelSize="24rpx" @change="changeRemember"
							:checked="isRemember" iconColor="#FFFFFF"></u-checkbox>
					</u-checkbox-group>
				</template>
			</view>
			<!-- 隐私协议 -->
			<view style="display: flex;align-items: center;justify-content: center;margin: 80rpx 0;">
				<view>
					<u-checkbox-group>
						<u-checkbox shape=""  :label="$lang.TIP_AGREE" v-model="isAgree"
							labelColor="#ffffff" labelSize="24rpx" @change="changeAgree" :checked="isAgree"
							iconColor="#FFFFFF"></u-checkbox>
					</u-checkbox-group>
				</view>
				<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
					{{$lang.TIP_PRVITE_PACT}}
				</view>
			</view>

			<!-- 通用按钮 已包含相关逻辑判断 -->
			<view class="text-center"  @click="handleConfirm()" style="margin:60rpx auto;background-color: #f45642;padding: 15px;color: #FFFFFF;font-size: 16px;border-radius: 30px;">
				{{isSignIn?$lang.BTN_SIGN_IN:$lang.BTN_SIGN_UP}}
			</view>

		</view>
	</view>
</template>

<script>
	// import Translate from '@/components/Translate.vue';
	import TabsSeventh from '@/components/tabs/TabsSeventh.vue';
	export default {
		components: {
			// Translate,
			TabsSeventh,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				user: "", // 账户
				password: '', // 密码
				verifyPassword: '', // 确认密码
				emailCode: '', // 邮箱验证码（印度）
				code: '', // 邀请码
				curTab: 0,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		computed: {
			// current is signin
			isSignIn() {
				return this.curTab < 1;
			},
			setTabs() {
				return [this.$lang.SIGN_IN_TITLE, this.$lang.SIGN_UP_TITLE]
			}
		},

		onShow() {
			this.isAnimat = true;
			// 读取缓存中的页面信息
			this.getStorageData();
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			this.isAnimat = false;
			// 缓存页面信息
			this.setStorageData();
		},
		methods: {
			// 切换当前 登录或注册
			changeTab(val) {
				// this.isSignIn = !this.isSignIn;
				this.curTab = val;
				this.setStorageData();
				this.getStorageData();
			},
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('pwd1', this.verifyPassword);
				uni.setStorageSync('code', this.code);
				uni.setStorageSync('remember', this.isRemember);
				uni.setStorageSync('agree', this.isAgree);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
				this.verifyPassword = uni.getStorageSync('pwd1') || '';
				this.code = uni.getStorageSync('code') || '';
				this.isRemember = uni.getStorageSync('remember') || false;
				this.isAgree = uni.getStorageSync('agree') || false;
			},
			// 设置 激活样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : '#A8A8A8',
					padding: `16rpx 32rpx`,
					borderRadius: `44rpx`,
					minWidth: `120rpx`,
					textAlign: `center`,
				}
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 勾选记住密码
			changeRemember(e) {
				console.log(e);
				this.isRemember = e;
				uni.setStorageSync('remember', this.isRemember);
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				console.log(e);
				this.isAgree = e;
				uni.setStorageSync('agree', this.isAgree);
			},

			// 用户隐私协议
			linkPact() {
				this.setStorageData();
				uni.navigateTo({
					url: this.$paths.PRVITE_PACT,
				})
			},

			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				// 以下通用
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}
				if (this.isAgree != true) {
					uni.showToast({
						title: this.$lang.TIP_CHECK_AGREE,
						icon: 'none',
					});
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				this.setStorageData();
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				this.setStorageData();
				this.signIn();
			},
		}
	}
</script>

<style lang="scss">
	// /deep/.u-checkbox__icon-wrap {
	// 	background-color: transparent !important;
	// }

	.access_bg {
		width: 100%;
		min-height: 100vh;
		background-color: #FFFFFF;
	}
</style>