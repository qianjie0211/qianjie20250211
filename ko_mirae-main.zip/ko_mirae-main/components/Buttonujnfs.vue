<template>
	<view style="padding: 0px 5px;">
	<view class="btns_wrapper" style="height: 85px;">
		<view v-for="(item,index) in btns" :key="index" class="item" :style="{flex:`${col}%`}">
			<!-- <view @click="actionEvent(item.url,index,item.name)" class="icon margin-top-20">
				<image mode="aspectFit" :src="`/static/top${index+1}.png`" :style="$util.calcImageSize(40)"></image>
			</view> -->
			<view @click="actionEvent(item.url,index,item.name)" class="icon margin-top-15">
				<image mode="aspectFit" :src="`/static/top${index+2}.png`" :style="$util.calcImageSize(35)"></image>
			</view>
			<text class="btn_name " :style="{color:current==index?'#f3862b':'#121212'}" style="margin-top: -10px;">{{item.name}}</text>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		name: "Buttonujnfs",
		props: ['btns','col'],
		data() {
			return {
				current: -1
			};
		},
		methods: {
			actionEvent(url, index, name) {
				// if(url.includes("/pages/service/service")){
				// 	uni.$u.toast('고객 서비스 매니저에 연락해주세요.');
				// 	return 
				// }
				this.current = index;
				console.log(111,url);

				if (url.includes('pages')) {
					uni.navigateTo({
						url: `${url}?tag=${name}`,
						fail() {
							uni.switchTab({
								url:`${url}?tag=${name}`
							})
						}
					})
					
				} else {
					this.$emit('action', index);
				}
			},
			
		}
	}
</script>