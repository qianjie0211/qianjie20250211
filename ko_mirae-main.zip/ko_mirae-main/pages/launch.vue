<template>
	<view class="sc_kxbg" style="min-height: 100vh;">

		<view style="display: flex;align-items: center;justify-content: center;padding:0 0;">
			<view style="margin-top: 180px;">
				<image src='/static/logo.jpg' :style="$util.setImageSize(500,250)">
				</image>
			</view>
		</view>
		<!-- <view class="font-size-19 text-center" style="color: #999999;margin-top: 10px;">골드만삭스증권</view> -->

		<view style="display: flex;align-items: center;justify-content: center;">
			<!-- <image src="/static/launch_img.png" mode="aspectFit" :style="$util.setImageSize(512)"></image> -->

		</view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<!-- <view style="margin-top: 20px;text-align: center;font-size: 32rpx;font-family: 700;color:#FFFFFF;">
				온라인 주식 거래 어플리케이션
			</view> -->
		</view>

		<ProgressThird></ProgressThird>

	</view>
</template>

<script>
	import ProgressThird from '@/components/ProgressThird.vue';
	export default {
		components: {
			ProgressThird
		},
	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		background-image: url('/static/lanuch_sc.webp');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>