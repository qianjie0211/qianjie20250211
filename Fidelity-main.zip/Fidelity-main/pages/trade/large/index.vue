<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex padding-15 margin-top-15">
			<view class="" @click="dazong()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-1 text-center font-size-18" style="color: #fff;">{{$lang.DAZONG_JIAOYI}}</view>
			<view style="color:#FFFFFF;font-size: 12px;" @click="linkRecord()">{{$lang.LISHI_JILV}}</view>
		</view>
		<!-- <HeaderThird :title="$lang.TRADE_LARGE_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;width: 70px;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
		</HeaderThird> -->
		
			<TradeLargeList ref="list"></TradeLargeList>
	
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeLargeList from './components/TradeLargeList.vue';

	export default {
		components: {
			HeaderThird,
			TradeLargeList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: '/pages/trade/large/record'
				})
			},
			dazong(){
				uni.navigateBack({
					delta:1,
				})
			},
		},
	}
</script>