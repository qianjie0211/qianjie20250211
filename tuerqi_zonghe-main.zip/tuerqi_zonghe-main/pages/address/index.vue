<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color:#010101;">
			<HeaderSecond :title="$lang.ADDRESS_INDEX_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="margin: 40rpx 20rpx;padding-bottom: 100rpx;min-height: 100vh;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="border-radius: 24rpx;">
						<view style="display: flex;align-items: center;">
							<!-- <CustomLogo :logo="'/static/bank/'+item.name+'.png'" :name="item.name"></CustomLogo> -->
							<image :src="'/static/bank/'+item.name+'.png'" mode="widthFix" style="width: 40px;height: 40px;"></image>
							<view style="padding-left: 10rpx;flex:1 1 auto;">
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view style="font-size: 32rpx;color: #fff;" >
										{{item.name}}
									</view>
									<view>
										<view style="display: flex;align-items: center;">
											<image mode="aspectFit" :src="`/static/${isShow?'show':'hide'}.png`"
												@click.stop="toggleShow()" style="padding-right: 40rpx;"
												:style="$theme.setImageSize(32)">
											</image>
											<view class="common_tag" :style="setStyle" @tap="handleCopy(item.address)">
												{{$lang.COMMON_COPY}}
											</view>
										</view>
									</view>
								</view>
								<view :style="{color:$theme.LOG_LABEL}">{{isShow?item.address:hideAddress}}</view>
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<view style="position: fixed;bottom: 60px;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="linkAdd()">
				{{$lang.ADDRESS_ADD_TITLE}}
			</view>
		</view>
		<view style="height: 160rpx;"></view>
		<FooterSmall code="assets" />
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		components: {
			HeaderSecond,
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 地址显隐
				hideAddress: '******', // 隐藏金额
				list: [], // 提现地址列表
			};
		},
		computed: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20),
					color: this.$theme.RISE,
				}
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.isShow = uni.getStorageSync('show');
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换地址显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			linkAdd() {
				uni.redirectTo({
					url: this.$CONSTANTS.ADDRESS_ADD
				})
			},
			// link(id) {
			// 	uni.redirectTo({
			// 		url: this.$CONSTANTS.ADDRESS_ADD + "?id=" + id
			// 	})
			// },
			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/fastinfo`);
				if (!result) return false;
				console.log(`result:`, result);
				if (result.bank_card_info) {
					this.list = result.bank_card_info
				}

			}
		}
	}
</script>

<style>
</style>