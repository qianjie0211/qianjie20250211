<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="page">
			<view class="block">
				<view class="head">
					<img :src="$icon.laba" class="head-ring" @click="$u.route({url:'/pages/notification'});">
					<view class="head-search" @click="$u.route({url:'/pages/search/index'});">
						<img :src="$icon.sousuo">
					</view>
					<img :src="$icon.chilun" class="head-setting" @click="$u.route({url:'/pages/account/center'});">
				</view>
			</view>
			<view class="page-card">
				<view class="top">
					<view class="top-left">
						<view class="top-left-top">残高
							<img :src="showAmount?$icon.yanjing:$icon.biyan" @click="showAmount=!showAmount">
						</view>
						<view class="top-left-foot">{{showAmount?$util.formatMoney(userInfo.totalZichan):hideAmount}}
						</view>
					</view>
					<view class="top-right">
						<view class="top-chart" v-if="curTab==1">
							<qiun-data-charts type="pie" :opts="$icon.opts" :chartData="chartData" />
						</view>
						<view class="top-chart" v-if="curTab==2">
							<qiun-data-charts type="pie" :opts="$icon.opts" :chartData="chartData1" />
						</view>
						<view class="top-mask"></view>
					</view>
				</view>
				<view class="foot">
					<view class="foot-item" v-if="curTab==1">
						<view class="foot-left"><span class="foot-ball color1"></span>損益総額</view>
						<view class="foot-right">{{showAmount?$util.formatMoney(userInfo.holdYingli):hideAmount}}
						</view>
					</view>
					<view class="foot-item" v-if="curTab==1">
						<view class="foot-left"><span class="foot-ball color2"></span>時価総額</view>
						<view class="foot-right">{{showAmount?$util.formatMoney(userInfo.frozen):hideAmount}}</view>
					</view>

					<view class="foot-item" v-if="curTab==2">
						<view class="foot-left"><span class="foot-ball color1"></span>売却損益</view>
						<view class="foot-right">{{showAmount?$util.formatMoney(userInfo.totalYingli):hideAmount}}
						</view>
					</view>
					<view class="foot-item" v-if="curTab==2">
						<view class="foot-left"><span class="foot-ball color2"></span>売り市場価格</view>
						<view class="foot-right">{{showAmount?$util.formatMoney(userInfo.Sellamount):hideAmount}}
						</view>
					</view>


					<view class="foot-item">
						<view class="foot-left"><span class="foot-ball color3"></span>買付余力</view>
						<view class="foot-right">
							{{showAmount?$util.formatMoney(userInfo.money):hideAmount}}
						</view>
					</view>
				</view>
			</view>

			<TabsThird :tabs="tabs" @action="changeTab" :acitve="curTab"> </TabsThird>

			<view class="abox">
				<view class="abox-list" v-for="(item,index) in list" :key="index">
					<view class="abox-title gap5">
						<view class="abox-name">{{item.name}}<span>{{item.code}}</span></view>
						<view class="abox-have" v-if="item.status==1">保有中</view>
						<view class="abox-not" v-if="item.status==2">決済済み</view>
					</view>
					<view class="abox-foot">
						<view class="foot-item">
							<view class="abox-foot-title">購入履歴</view>
							<view class="abox-foot-list">
								購入株数<span>{{$util.formatNumber(item.buyQTY)+` 株`}}</span></view>
							<view class="abox-foot-list">購入価格<span>{{$util.formatMoney(item.buyPrice)}}</span></view>
							<view class="abox-foot-list">手数料<span>{{item.status==2?item.sellFee:item.buyFee}}</span>
							</view>
							<view class="abox-foot-list" v-if="item.status==1">最近の変動率<span>{{$util.formatMoney(item.buyProfitRate,2)}}%</span></view>
							<view class="abox-foot-list" v-if="item.status==1">
								最新の市場価格<span>{{$util.formatMoney(item.currentPrice*1*item.buyQTY,2)}}</span>
							</view>
							<view class="abox-foot-list" v-if="item.status==2">
								購入総額<span>{{$util.formatMoney(item.total)}}</span>
							</view>
							<view class="abox-foot-list" v-if="item.status==2">
								{{item.status==2?'約定時間':'購入時間'}}<span>{{item.status==2?item.sellCT:item.buyCT}}</span>
							</view>
						</view>
						<view class="foot-item" v-if="item.status==1">
							<view class="abox-foot-title">最新の記録</view>
							<view class="abox-foot-list">
								ロット数<span class="red">{{$util.formatNumber(item.buyQTY/100)}}</span>
							</view>
							<view class="abox-foot-list">最新価格<span
									class="red">{{$util.formatMoney(item.currentPrice,2)}}</span></view>
							<view class="abox-foot-list">レバレッジ<span
									class="red">{{item.lever}}</span></view>
							<view class="abox-foot-list">購入総額<span
									class="red">{{$util.formatMoney(item.total)}}</span></view>
							<view class="abox-foot-list">最新の利益<span
									class="red">{{$util.formatMoney(item.buyProfit*1)}}</span></view>
						</view>

						<view class="foot-item" v-if="item.status==2">
							<view class="abox-foot-title">売却履歴</view>
							<view class="abox-foot-list">
								ロット数<span class="red">{{$util.formatNumber(item.num)}}</span>
							</view>
							<view class="abox-foot-list">売却価格<span
									class="red">{{$util.formatMoney(item.sellPrice)}}</span></view>
							<view class="abox-foot-list">売却時の損益率<span
									class="red">{{$util.formatMoney(item.sellProfitRate,2)}}%</span></view>
							<view class="abox-foot-list">売却時価総額<span
									class="red">{{$util.formatMoney(item.sellAmont)}}</span></view>
							<view class="abox-foot-list">売却利益<span
									class="red">{{$util.formatMoney(item.sellProfit*1)}}</span></view>
						</view>
					</view>
					<view class="flex flex-b" v-if="item.status==1">
						<view class="abox-foot-list font-size-11">{{item.status==2?'約定時間':'購入時間'}}</view>
						<view style="font-size: 11px;">{{item.status==2?item.sellCT:item.buyCT}}</view>
					</view>
					<view class="abox-bottom" style="padding-top: 10px;">
						<view class="btn1" @click="info_link(item)" v-if="item.status==1">保有詳細</view>
						<view class="btn2" @tap="handleSell(item.id)" v-if="item.status==1">売却</view>
					</view>
					<view class=" flex margin-top-10" v-if="item.source == 'goods' || item.source == 'guadna' ">
						<view class="flex-1"></view>
						<view class=" text-right"
							style="background-color: #013f9c;color: #fff;font-size: 12px;padding: 8px 30px;border-radius: 5px;"
							@click="showzs(item)" v-if="item.status==1">
							利確、損切り
						</view>
					</view>
				</view>
			</view>
		</view>
		<template>
			<u-popup :show="show" mode="center" :round="10" @close="close" @open="open">
				<view style="margin-left: auto;padding: 20px;" @click="closePopup">
					<image src="/static/failed.png" mode="widthFix" style="width: 25px;"></image>
				</view>
				<view style="padding: 0px 20px;">
					<view class="flex" style="width: 96%;">
						<view>損切り価格：</view>
						<input placeholder="入力してください" type="number" v-model="zhikui"
							style="border: 1px #000 solid; border-radius: 5px; padding: 5px;width: 60%;" />
					</view>
					<view class="flex margin-top-20" style="width: 100%;">
						<view>利確価格：</view>
						<input placeholder="入力してください" type="number" v-model="zhiying"
							style="border: 1px #000 solid; border-radius: 5px; padding: 5px;width: 58%;margin-left: 15px;" />
					</view>

					<view style="padding: 30px 20px;" @click="pingcang()">
						<view class="text-center"
							style="background-color: #e4013e; padding: 8px 0px; border-radius: 5px; color: #fff;">確定
						</view>
					</view>
				</view>
			</u-popup>
		</template>



	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsThird from '@/components/tabs/TabsThird.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import AccountTradeInfo from './components/AccountTradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsThird,
			TitlePrimary,
			AccountTradeInfo,
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 1, // 
				showAmount: false, // 显示金额
				hideAmount: '******', // 隐藏金额
				usd: '',
				show: false,
				available: '', // 可用額
				userInfo: null,
				list: [], // 
				source: '',
				zhikui: '', // 止损价格
				zhiying: '', // 止盈价格
				id: '',

				curPage: 1, // 当前页码
				maxPage: 1, // 最大页码
				isShow: false, // 是否显示弹层
				detail: null, // 单条数据详情
				chartData: "",
				chartData1: "",
				// isClose:false, // 
			}
		},

		computed: {
			tabs() {
				return [
					'購入申込',
					'進行中',
					'終了',

				]
			},
			open() {
				this.show = true;
			},
			close() {
				this.show = false;
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad() {

		},
		onShow() {
			this.getAccountInfo();
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		// 觸底加載
		onReachBottom() {
			console.log(`onReachBottom`)
			if (this.curPage < this.maxPage) {
				this.curPage++;
				this.getList();
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo();
			this.curPage = 1;
			this.list = [];
			this.getList();
			uni.stopPullDownRefresh();
		},

		methods: {
			showzs(item) {
				this.show = true
				console.log(5496459, item);
				this.id = item.id
			},
			open() {
				console.log('Popup opened');
			},
			closePopup() {
				this.show = false; // 设置 show 为 false，关闭弹出层
			},
			pingcang() {
				console.log('Pingcang 確定 clicked');
				this.closePopup(); // 点击 "確定" 后关闭弹出层
			},
			fanhui() {
				this.closePopup(); // 点击图片后关闭弹出层
			},

			info_link(val) {

				let arrayString = JSON.stringify(val);
				uni.navigateTo({
					url: "/pages/position/info?data=" + encodeURIComponent(arrayString)
				})
			},
			fanhui() {
				uni.navigateBack({
					delta: 1
				})
			},
			// tab切换
			changeTab(val) {
				console.log(val)

				this.curTab = val;
				this.curPage = 1;
				this.list = [];
				if (val == 0) {
					return
				}
				this.getList();
			},
			handleShowModal(item) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.detail = item;
				console.log(this.detail);

			},
			// 关闭弹层
			handleClose() {
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	
				// this.curPage = 1;
				// this.list = [];
				// this.getList();
			},
			// 跳转到股票详情
			linkStockInfo(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			async pingcang() {
				try {
					// 确保传递的参数格式正确
					const result = await this.$http.post(`api/user/zhikui`, {
						id: this.id,
						zhikui: this.zhikui,
						zhiying: this.zhiying,
					});
					if (!result) {
						this.show = false;
						return
					}
					console.log('接口数据', result)
					if (result && result.data.success) {
						// 如果请求成功，处理后续逻辑
						uni.showToast({
							title: 'セットアップ成功',
							icon: 'success',
						});
						this.close(); // 关闭弹窗
					} else {
						// 处理错误提示
						uni.showToast({
							title: result.data.message || '操作失败',
							icon: 'none',
						});
					}
				} catch (error) {
					console.error("接口请求失败:", error);
					uni.showToast({
						title: 'セットアップ成功',
						icon: 'none',
					});
				}
				this.show = false;
			},


			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id
				});
				console.log(result);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar	
				this.curPage = 1;
				this.list = [];
				this.curTab = 2;
				this.changeTab(this.curTab);
			},

			// 获取持有及历史数据
			async getList() {
				console.log(`curPage:`, this.curPage);
				const result = await this.$http.post(`api/user/order`, {
					page: this.curPage,
					status: this.curTab, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				console.log(`sell result:`, result);
				this.maxPage = result.last_page; // 記錄最大頁碼
				let filterData = [];
				if (this.curTab == 1) {
					filterData = result.filter(item => item.goods_info && item.order_buy);
				} else if (this.curTab == 2) {
					filterData = result.filter(item => item.goods_info && item.order_buy && item.order_sell);
				}
				console.log(`filterData`, filterData);
				const temp = filterData.map(item => {
					return {
						id: item.id,
						source: item.source,
						order_sn: item.order_sn,
						typeId: item.goods_info.project_type_id,
						code: item.goods_info.number_code,
						status: item.status, // 1买 2卖
						name: item.goods_info.name, // 名称
						// 持仓盈利率 =（最终价 - 买入价） / 买入价 *100%
						buyProfitRate: (item.goods_info.current_price * 1 - item.order_buy.price * 1) /
							(item.order_buy.price * 1) * 100,
						// 卖出盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% 
						sellProfitRate: item.status == 2 ? (item.order_sell.price * 1 - item.order_buy
							.price * 1) / item.order_buy.price * 100 : '',
						buyPrice: item.order_buy.price, // 买入价
						sellPrice: item.status == 2 ? item.order_sell.price : '', // 卖出价
						num: item.status == 2 ? item.order_sell.num : '',
						currentPrice: item.goods_info.current_price, // 最新价
						buyQTY: item.order_buy.num, // 买入数量
						sellQTY: item.status == 2 ? item.order_sell.num : '', // 卖出数量
						buyProfit: item.order_buy.yingkui, // 买入盈亏额
						sellProfit: item.status == 2 ? item.order_sell.yingkui : '', // 卖出盈亏额
						buyAmont: item.order_buy.amount,
						sellAmont: item.status == 2 ? item.order_sell.amount : '', // 卖出盈亏额,
						lastPrice: item.goods_info.last_price,
						total: item.order_buy.num * 1 * (item.order_buy.price * 1), // 个股买入总金额 
						buyFee: item.order_buy.buy_fee, // 买入手续费
						sellFee: item.status == 2 ? item.order_sell.sell_fee : '', // 卖出手续费
						lever: item.order_buy.double, // 杠杆
						buyCT: item.order_buy.created_at, // 买入时间
						sellCT: item.status == 2 ? item.order_sell.created_at : '', // 卖出时间
						buyFloatProfit: item.order_buy.float_yingkui * 1, // 买入浮动盈亏
						// 卖出浮动盈亏
						sellFloatProfit: item.status == 2 ? item.order_sell.float_yingkui * 1 : '',
					}
				});
				if (this.list.length > 0) {
					this.list.push(...temp);
				} else {
					this.list = temp;
				}
				console.log(this.list, this.list.length);
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},
			linkService() {
				this.$util.linkCustomerService();
			},

			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},

			// available
			async getAccountInfo() {
				// uni.showLoading({
				// 	title: this.$lang.API_GET_ACCOUNT_INFO,
				// })
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(`result info:`, result);
				this.userInfo = result;
				this.available = !result.money ? 0 : result.money * 1; // 可提

				console.log(333, Math.abs(result.Sellamount * 1));

				let res = {
					series: [{
						data: [{
							"name": "損益総額",
							"value": Math.abs(result.holdYingli),
							"color": "#adc1bb"
						}, {
							"name": "時価総額",
							"value": Math.abs(result.frozen),
							"color": "#c3a9ee"
						}, {
							"name": "評価損益",
							"value": Math.abs(result.money),
							"color": "#f4b4b7"
						}]
					}]
				};
				this.chartData = JSON.parse(JSON.stringify(res));


				let res1 = {
					series: [{
						data: [{
							"name": "売却損益",
							"value": Math.abs(result.totalYingli),
							"color": "#adc1bb"
						}, {
							"name": "売り市場価格",
							"value": Math.abs(result.Sellamount),
							"color": "#c3a9ee"
						}, {
							"name": "評価損益",
							"value": Math.abs(result.money),
							"color": "#f4b4b7"
						}]
					}]
				};
				this.chartData1 = JSON.parse(JSON.stringify(res1));

			},
		},
	}
</script>


<style lang="scss" scoped>
	@charset "UTF-8";

	.page {
		background: #f7f9f8;
		min-height: 100vh;
		box-sizing: border-box;
		padding-bottom: 67px
	}

	.page-card {
		height: 173px;
		background: #fff;
		padding: 7px 15px 0 15px;
		box-sizing: border-box;
		margin-top: 10px
	}

	.page-card .top {
		height: 83px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.page-card .top .top-left {
		height: 83px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-webkit-flex-direction: column;
		flex-direction: column;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.page-card .top .top-left .top-left-top {
		height: 16px;
		font-weight: 500;
		font-size: 11px;
		color: #333;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		padding: 0 3px
	}

	.page-card .top .top-left .top-left-top img {
		width: 19px;
		height: 14px;
		margin-left: 5px
	}

	.page-card .top .top-left .top-left-foot {
		height: 36px;
		font-weight: 400;
		font-size: 26px;
		color: #e4013e;
		line-height: 36px;
		margin-top: 4px
	}

	.page-card .top .top-right {
		width: 83px;
		height: 83px;
		position: relative
	}

	.page-card .top .top-right .top-chart {
		width: 100px;
		height: 100px
	}

	.page-card .top .top-right .top-mask {
		width: 83px;
		height: 83px;
		position: absolute;
		left: 0;
		top: 0;
		z-index: 10
	}

	.page-card .foot {
		height: 88px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-webkit-flex-direction: column;
		flex-direction: column;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.page-card .foot .foot-item {
		height: 21px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.page-card .foot .foot-left {
		height: 21px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-weight: 400;
		font-size: 11px;
		color: #333
	}

	.page-card .foot .foot-right {
		font-weight: 600;
		font-size: 13px;
		color: #333
	}

	.page-card .foot .foot-ball {
		width: 13px;
		height: 13px;
		margin-right: 3px;
		border-radius: 50%;
		display: block
	}

	.page-card .foot .color1 {
		background: #adc1bb
	}

	.page-card .foot .color2 {
		background: #c3a9ee
	}

	.page-card .foot .color3 {
		background: #f4b4b7
	}

	.page-card .page-box {
		height: 28px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.page-card .page-box .btn1 {
		width: 105px;
		height: 28px;
		background: #e4013e;
		border-radius: 5px;
		font-weight: 400;
		font-size: 11px;
		color: #fff;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.page-card .page-box .btn2 {
		width: 105px;
		height: 28px;
		border-radius: 5px;
		border: 1px solid #e4013e;
		font-weight: 500;
		font-size: 11px;
		color: #e4013e;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.pageNav {
		height: 49px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
		background: #f7f9f8;
		margin: 0 11px
	}

	.pageNav .nav-item {
		width: 32%;
		height: 28px;
		background: #fff;
		border-radius: 5px;
		border: 1px solid #e4013e;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 500;
		font-size: 10px;
		color: #e4013e;
		box-sizing: border-box
	}

	.pageNav .active {
		background: #e4013e;
		color: #fff
	}

	.abox .abox-list {
		background: #fff;
		box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .36);
		margin-bottom: 8px;
		padding: 0 10px 9px 10px
	}

	.abox .abox-title {
		height: 41px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.abox .abox-name {
		font-weight: 600;
		font-size: 12px;
		color: #333;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center
	}

	.abox .abox-name span {
		height: 24px;
		background: #ec4d78;
		border-radius: 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		padding: 0 11px;
		font-weight: 400;
		font-size: 11px;
		color: #fff;
		margin-left: 14px
	}

	.abox .abox-have {
		min-width: 126px;
		height: 24px;
		background: #e4013e;
		border-radius: 5px;
		font-weight: 100;
		font-size: 11px;
		color: #fff;
		padding: 0 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.abox .abox-not {
		min-width: 126px;
		height: 24px;
		background: #fabec5;
		border-radius: 5px;
		font-weight: 100;
		font-size: 11px;
		color: #fff;
		padding: 0 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.abox .abox-foot {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.abox .abox-foot .foot-item {
		width: calc(50% - 7px)
	}

	.abox .abox-foot .abox-foot-title {
		height: 31px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-weight: 500;
		font-size: 13px;
		color: #333
	}

	.abox .abox-foot .abox-foot-list {
		width: 100%;
		height: 29px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
		font-weight: 300;
		font-size: 12px;
		color: #666
	}

	.abox .abox-foot .abox-foot-list span {
		font-weight: 500;
		font-size: 12px;
		color: #333
	}

	.abox .abox-foot .abox-foot-list .red {
		color: #e04e50
	}

	.abox .abox-foot .abox-foot-list .green {
		color: #37927d
	}

	.abox .abox-bottom {
		height: 28px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.abox .abox-bottom .btn1 {
		width: 105px;
		height: 28px;
		background: #e4013e;
		border-radius: 5px;
		font-weight: 400;
		font-size: 11px;
		color: #fff;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.abox .abox-bottom .btn2 {
		width: 105px;
		height: 28px;
		background: #fff;
		border-radius: 5px;
		border: 1px solid #e4013e;
		font-weight: 400;
		font-size: 11px;
		color: #e4013e;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.fbox .fbox-item {
		background: #fff;
		box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .36);
		margin-top: 10px;
		padding: 0 10px
	}

	.fbox .fbox-item .fbox-item-top {
		height: 45px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.fbox .fbox-item .fbox-item-name {
		height: 45px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-weight: 600;
		font-size: 12px;
		color: #333
	}

	.fbox .fbox-item .fbox-item-name span {
		height: 24px;
		background: #adc1bb;
		border-radius: 5px;
		margin-left: 14px;
		padding: 0 5px;
		white-space: nowrap;
		font-weight: 400;
		font-size: 11px;
		color: #fff;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center
	}

	.fbox .fbox-item .fobx-item-type {
		height: 24px;
		background: #e4013e;
		border-radius: 5px;
		padding: 0 5px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-weight: 100;
		font-size: 11px;
		color: #fff
	}

	.fbox .fbox-item .fbox-item-middle {
		padding: 0 8px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-flex-wrap: wrap;
		flex-wrap: wrap;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between
	}

	.fbox .fbox-item .fbox-item-list {
		width: calc(50% - 7px);
		padding: 6px 0;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
		font-weight: 300;
		font-size: 12px;
		color: #666
	}

	.fbox .fbox-item .fbox-item-list span {
		font-weight: 500;
		font-size: 12px;
		color: #333;
		padding-left: 5px
	}

	.fbox .fbox-item .fbox-item-list .red {
		color: #e04e50
	}

	.fbox .fbox-item .fbox-item-full {
		padding: 6px 8px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-weight: 300;
		font-size: 12px;
		color: #666
	}

	.fbox .fbox-item .fbox-item-full span {
		font-weight: 500;
		font-size: 12px;
		color: #333;
		padding-left: 11px
	}
</style>