<template>
	<view class="common_page_bg2">
		<CustomHeader :title="$lang.SEARCH" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view style="margin:30rpx 30rpx;">
			<u-search  placeholder="종목코드검색" v-model="keyword" :showAction="false" height="40px"
				searchIconColor="#18BFB4" searchIconSize="30" bgColor="#FFFFFF"  @clear="keyword=''" actionText="검색"
				@search="searchButton" @custom="searchButton"></u-search>
		</view>

		<view class="common_block" style="background-color: #fff;">
			<!-- <view class="flex padding-top-10 padding-bottom-10">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #283480;">
					</view>
				<view class="margin-left-10">검색기록</view>
			</view> -->

			<view class="box" style="border-radius: 10px;padding: 0px 15px; " v-if="searchList">
				<view class="top flex flex-b padding-10">
					<view class="flex-2  font-size-16">주식/코드</view>
					<view class="flex-1 t-r  font-size-16">등락률</view>
					<view class="flex-1 t-r font-size-16" style="margin-left: 10px;">최신</view>
				</view>

				<u-gap height="1" bgColor="#EEEEEE"></u-gap>
                <view style="padding: 15px 0px;">
				<view class=" box-item flex flex-b padding-10" v-for="(item,index) in searchList"
					@click="detailed(item.code)" style="background-color: #F8F7FC;border-radius: 10px;">
					<view class="list-name flex-2 font-size-16">
						<view class="list-name-txt ">
							{{item.name}}
						</view>
						<view style="color: #999;padding: 3px;">{{item.number_code}}</view>
					</view>
					<view class="flex-1 t-c num-font" :style="{color:item.rate>0?'#ff3636':'#18BFB4'}">
						{{$util.formatNumber(item.current_price)}}
					</view>
					<view class="per flex-1 t-r color-white" :style="{color:item.rate>0?'#ff3636':'#18BFB4'}">
						{{item.rate>0?'+':''}}{{item.rate}}%
					</view>
				</view>
			</view>
			</view>

			<template v-if="searchList.length<=0">
				<view style="display: flex;flex-direction: column;align-items: center;justify-content: center;">
					<image src="/static/market/no.png" mode="aspectFit" :style="$util.setImageSize(480)"></image>
					<view class="text-center padding-bottom-30" style="color: #999;font-size: 32rpx;">기록 없음</view>
				</view>
			</template>
		</view>
	</view>
</template>
<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				searchList: [],
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords: [],
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}],
				gp_index: 0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
			console.log(this.keywords)
		},
		methods: {
			gp_select_click(e) {
				this.storehouse = ""
				this.gp_index = e.index
			},
			dianji(keyword) {
				this.keyword = keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(code) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/productDetails/productDetails' + `?code=${code}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('검색어는 비워둘 수 없습니다. 다시 검색해 주세요');

				} else {
					uni.showLoading({
						title: "검색...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index: this.gp_index
					})
					this.searchList = list.data.data
					console.log(8888, list.data.data)
					uni.hideLoading();
					if (list.data.data.length > 0) {
						if (this.keywords.indexOf(this.keyword) < 0) {
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords", this.keywords)
						}
					}
				}
			},
		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}
</style>