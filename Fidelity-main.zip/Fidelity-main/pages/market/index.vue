<template>
	<view :style="$theme.setBGSize(`360rpx`)">
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx;">
			<block v-for="(item,index) in tabs" :key="index">
				<view :style="setStyle(curTab==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
			<view style="margin-left: auto;" @click="linkSearch()">
				<image mode="aspectFit" src="/static/search.png" :style="$util.setImageSize(40)"></image>
			</view>
		</view>

		<view style="padding-bottom: 20px;">
			<template v-if="curTab==0">
				<MarketCoin ref="coin"></MarketCoin>
			</template>
			<template v-else>
				<MarketTrack ref="track"></MarketTrack>
			</template>
		</view>
	</view>
</template>

<script>
	import MarketCoin from './components/MarketCoin.vue';
	import MarketTrack from './components/MarketTrack.vue';
	export default {
		components: {
			MarketCoin,
			MarketTrack,
		},
		data() {
			return {
				curTab: 0,
			}
		},
		computed: {
			tabs() {
				return [this.$lang.MARKET_TAB_COIN, this.$lang.MARKET_TAB_TRACK];
			}
		},
		methods: {
			// 设置tab样式
			setStyle(val) {
				return {
					margin: `10rpx 40rpx`,
					borderBottom: `3px solid ${val?'#FFFFFF':'transparent'}`,
					fontSize: val ? `36rpx` : `32rpx`,
					fontWeight: val ? '700' : '100',
					color: '#FFFFFF',
				}
			},
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
			// 跳转到查询页面
			linkSearch() {
				uni.switchTab({
					url: this.$paths.MARKET
				})
			}
		}
	}
</script>

<style>
</style>