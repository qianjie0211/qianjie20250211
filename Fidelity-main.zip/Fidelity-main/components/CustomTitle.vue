<template>
	<view style="margin:0 10px;display: flex;flex-wrap: nowrap;align-items: center;line-height: 2;">
		<template v-if="img!=''">
			<image mode="aspectFit" :src="`/static/${img}.png`" :style="$util.setImageSize(40)"
				style="padding-right: 10px;"></image>
		</template>
		<view style="font-size: 32rpx;color:#FFFFFF;font-weight: 800;">
			{{title}}
		</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: 'CustomTitle',
		props: {
			title: {
				type: String,
				default: 'TITLE'
			},
			// 左边图标url。有值视为需要
			img: {
				type: String,
				default: '',
			}
		},
	}
</script>

<style>
</style>