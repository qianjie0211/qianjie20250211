<template>
	<view>
		<view class="flex padding-10">
			<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
			<view class="bold margin-left-5">{{$lang.MARKET_INDEX_TAB_KPI}}</view>
		</view>

		<TabsFifth :tabs="$lang.MARKET_INDEX_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		<view class="flex " style="padding: 0px 15px;">
			<view style="flex: 50%;align-items: center;font-size: 12px;color: #999;">종목명/코드</view>
			<view style="flex: 20%;align-items: center;font-size: 12px;color: #999;">현재가</view>
			<view style="font-size: 12px;color: #999;">등락률</view>
		</view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="flex " style="padding: 10px;border-bottom:1px solid #F3F3F3;" @click="link(item.code)">
					<view style="align-items: center;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex: 25%;align-items: center;margin-left: 10px;">
						<view style="font-size: 26rpx;line-height: 1.6;color: #000;">
							{{item.name}}
						</view>
						<view style="font-size: 25rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.code}}
						</view>
					</view>
					<view style="flex:30%; font-size: 32rpx;text-align: center;font-weight: 700;"
						:style="$theme.setStockRiseFall(item.rate*1>0)">
						{{$util.formatMoney(item.price)}}
					</view>
					<view style=" color:#FFFFFF;" :style="setStyle(item.rate*1>0)">
						<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(16)" style="padding-right: 12rpx;"></image>
						{{$util.formatNumber($util.formatMathABS(item.rate),2)}}%
					</view>
				</view>
			</block>
		</template>

		<view style="text-align: center;color: #999;line-height: 3.8;">{{$lang.MARKET_NEWS_TIP}}</view>
		<!-- <view style="margin-top: 80px;">.</view> -->
	</view>
</template>

<script>
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketKPI',
		components: {
			TabsFifth,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					borderRadius: `10rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			// // 跳转到股票详情
			// link(code) {
			// 	if (!code || code == '') return false;
			// 	uni.navigateTo({
			// 		url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
			// 	});
			// },
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/zhibiao`, {
					current: this.curTab
				})
				// console.log('result, result);
				if (!result) return false;
				this.list = Object.values(result).map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		}
	}
</script>

<style>
</style>