<template>

	<view :class="isAnimat?'fade_in':'fade_out'" style="">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<view class="flex " style="padding: 25px 20px;background-color: #4543d1;">
			<view class="color-white"> 관심 종목 </view>
			<view class="flex flex-1" @click="sousuo()"
				style="background-color: #a2a1e8;border-radius: 30px;padding: 6px 10px;margin-left: 20px;">
				<image src="/static/sousuo.png" mode="widthFix"
					style="width: 15px;height: 30px;display: block;float: left;"></image>
				<view class="text-center" style="font-size: 10px;color: #fff;margin-left: 5px;">검색</view>
			</view>

			<view class="margin-left-10">
				<!-- <image src="/static/fangdajing.png" mode="widthFix" style="width: 20px;height: 20px;margin-right: 10px;"
					@click="sousuo()"></image> -->
				<image src="/static/notification.png" mode="widthFix" style="width: 20px;height: 20px;"
					@click="xinxi()">
				</image>
			</view>
		</view>
		<!-- <view style="position: relative;">
					<image src="/static/sc_bgt.png" mode="widthFix" style="width: 100%;height: 80px;"></image>
				</view> -->
		<header style="padding: 20rpx 20rpx 0 20rpx;background-color: #fff;">
			<view style="display: flex;text-align: center; padding: 5px;">
				<block v-for="(item,index) in tabs" :key='index'>
					<view style="flex:1;" :style="setStyle2(curTab ==index)" @click="changeTab(index)">
						{{item}}
					</view>
				</block>
			</view>
		</header>

		<view :class="setClass" style="">
			<template v-if="curTab==0">
				<MarketStockList></MarketStockList>
			</template>
			<template v-if="curTab==1">
				<!-- <MarketChart /> -->
				<TabOne></TabOne>
			</template>
			<template v-if="curTab==2">
				<MarketTrack ref="track" @action="linkStock"></MarketTrack>
				
			</template>
			<template v-if="curTab==3">
				<!-- <MarketHot></MarketHot> -->
				<MarketKPI></MarketKPI>
			</template>
			<!-- <template v-if="curTab==4">
				<MarketKPI></MarketKPI>
			</template> -->
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import TabOne from './components/TabOne.vue'
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	// import MarketChart from './components/MarketChart.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TabOne,
			MarketTrack,
			MarketStockList,
			MarketHot,
			MarketKPI,
			// MarketChart,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 3, // 当前默认放在Coin
				tabs: [
					// this.$lang.MARKET_INDEX_TAB_CHART,
					'시세',
					'특징종목',
					'관심종목',
					this.$lang.MARKET_INDEX_TAB_KPI
				],
				text1: ['투자자 여러분 주의하세요! 📢 Stock X가 새로운 최고가를 기록하며 주요 저항 수준을 돌파했습니다! 새로운 상승의 물결을 기대하세요!',
					'시장 업데이트! 📈 인기 주식 Y가 오늘 엄청난 유입으로 급등하고 있습니다! 이 좋은 기회를 놓치지 마세요!',
					'공지 알림📢 – 큰 소식입니다! Leading Bank Z가 예상보다 높은 분기 실적을 보고했습니다. 잠재적인 가격 변동을 주시하세요!',
					'투자 기회! 📢 제약 주식이 강력한 상승세를 보이고 있습니다! 새로운 랠리의 시작이 될 수 있습니다. 투자자 여러분, 이 분야의 주요 주식을 주시하세요!',
					'빠른 알림 📢 – W 회사가 방금 중요한 발표를 했고 주가가 흔들리고 있습니다! 현재 보유자 여러분, 위험을 관리하고 일중 움직임을 면밀히 모니터링하세요!',
					'Hot Off the Press! 🔥 IT 부문 주식이 예외적으로 좋은 성과를 보이고 있습니다! 여러 회사가 새로운 계약을 발표하여 기회를 창출하고 있습니다. 계속 지켜봐 주세요!',
				],
			}
		},

		computed: {
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			sousuo() {
				uni.navigateTo({
					url: '/pages/search/index'
				})
			},
			xinxi() {
				uni.navigateTo({
					url: '/pages/notification'
				})
			},
			// 设置样式
			setStyle2(val) {
				return {
					padding: `12rpx 0`,
					color: val ? '#000' : '#ccc',
					// borderTop: val ? '#eecda5' : '',
					textAlign: 'center',
					fontSize: `32rpx`,
					fontWeight: val ? '700' : '100',
					// borderBottom: val ? '6rpx solid #eecda5' : 'none', // 添加自定义下划线
					//   paddingBottom: '5rpx', // 增加与下划线的间距

				}
			},
			linkStock() {
				this.changeTab(2);
			},
		},
	}
</script>