<template>

	<view>
		<view class="block">
			<view class="head">
				<img @click="$u.route({type:'navigateBack'});" :src="$icon.zjt" class="back">
				<view class="title left_in" style="margin-left: 0px;">口座開設</view>
				<view class="back"></view>
			</view>
		</view>
		<view class="box"><img src="/static/img/2.2d13f31b.png" class="box-top">
			<view class="box-info" style="margin-left: 0px;">
				<view class="box-title">新しいアカウントを作成する</view>
				<view class="box-name">電話番号</view>
				<view class="box-input">
					<input v-model="user" type="number" placeholder="携帯電話番号を入力してください" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view>
				<view class="box-name">パスワードを設定</view>
				<view class="box-input">
					<template v-if="isShow">
						<input v-model="password" type="text" placeholder="パスワードを入力してください"></input>
					</template>
					<template v-else>
						<input v-model="password" type="password" placeholder="パスワードを入力してください"></input>
					</template>

					<img @click="isShow=!isShow"
						:src="isShow?'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAwCAMAAACWlYwtAAAAAXNSR0IArs4c6QAAAM9QTFRFAAAA/wAA/wAAzAAz1QAq2wBJ4wA56AA64wBC5ABA5QA+5gA85gBC5gBA5QA+5ABA5AA/5QA+5gBA5QA/5AA+5AA+5AA95QA+5QA+4wA/5AA/5QA/5QA+4wA/4wA+5AA95AA/5AI+5QI+5QI94wI+5QI+4wI95AI+5QE95QE+5AE+5AE+4wE+5AE+5AE+5QE+4wE/5AE+5AE+5AE+5AE+5AE95AE+5AE+5QE+5AE+5AE+5AE+4wE+5AE+5AE+5AE+5AE+5AE+5AE+5AE+5AE+Z2e5ngAAAER0Uk5TAAECBQYHCRYbHB0eHygxODk6PEVeX2BiY2Vpamtub3ByjJGanaWmqbe4vsDCx8jLzM3Oz9rg4ebn6u3w8fX3+Pr8/f74Bir+AAABwUlEQVRIx7VW2XaCMBCN1tZdxBUXKrjgglqxKO6K8v/f1BOwRzNhs6Hzxs3cIZkluQh5Wa7SGy/Wx+N6Me5VcuhF4/ori7BVnwvP/qhrlotp9Y9Q9JiwtTxsK8SC+YWZ5WOzQgA90b1avmZ2E3781NwKtHnKm1/aWCFsU/LiNy5WKLs03PltyvOqq4qi6nRaWm78FvQaCUlnJSmMQkRo3kiXKdF53JRcvTUhv0ryTRE6iCYZoUIuF8/E8r5Mb7G8J1zOxefFNFk/886P85IsS3z8HoHcwyb9ND0L8oTO/hOi4XwaotN9Iun19ZitAcifDWaWD2SZsSGQycEvvwZqZOc/YzxDhh2BA441h589gPrb+/8mwaV9CtAPh6w9/xMQV3A57z0vAgAn+H7owP7F/RenxsrAtUjCru4glD8BTMe/4ukR4jGuA/CUR0PoqGJHiQ4gYVyF6BDtIKRgR5kOIGNcgeiOPQDzEZiT6FFGI1wZP6NopJCt/ObZygzDVI1qnNkvlL9daakoL1X2a539YWF/2l56XNv/87yzCwx2iYPQe5DIuvqLLHaZF4HQZJe6zmzQYrv4qmDHcl/Dcl/zlfs/8PzWmiS5IY0AAAAASUVORK5CYII=':'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAwCAYAAAChS3wfAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF6mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIyLjIgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNC0xMC0wMlQxMjowNDowNSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6YmM2MjhmN2YtMmE5YS00YmVkLThjOWEtOWM2ZTVmMWIxODk4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQxRjU5ODk3RDBFQzExRUU5RjI4OUZEM0QxRDlDNjc2IiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6RDFGNTk4OTdEMEVDMTFFRTlGMjg5RkQzRDFEOUM2NzYiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEMUY1OTg5NEQwRUMxMUVFOUYyODlGRDNEMUQ5QzY3NiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEMUY1OTg5NUQwRUMxMUVFOUYyODlGRDNEMUQ5QzY3NiIvPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpiYzYyOGY3Zi0yYTlhLTRiZWQtOGM5YS05YzZlNWYxYjE4OTgiIHN0RXZ0OndoZW49IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4wIChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhBFAqgAAAVGSURBVGiB1dpZrJ1TFMDx3zmVqgf1YqyqxBwPtFLcNtQsSIQHHgyJqTW09CYilESaamKMhzaG0JKaJWYeSAwNiopqeaMiocpFSQwxtdrrYX03/Xrud849Z+9zLv7Jyc3d37fX2mt9e1h77V1bX5thFNgbx+AoTMLO2KX4Cz9gQ/F3HVbgTXzZ5XbciJvKBbUeOqAPs3CCcEAKX+J1LMHKjLYcXMiY3vig2w7YAedgDg7rpmCsxt14An90UO8a3NHsYbccUMPFuEV07V6yAdfjQQy2eG8/8dWPbSWs3oUGTcG7WKr3xit0LC10Tmnyzhx8agTjyXPAWCzCKjHeR5s+fFC0YWxRNhEv4y5t2pY6BPbEMzgypXIPeB9PYyHGtVlnHS5LccBReAq7d1rxP8QSXImNnQ6BWXjD/9f473AmLsVG2K6DynPE2MplCz7HN8UPJhS/fXVnYq7iUczGr+XCdh0wW77xr4hx+hK+b/LOrjgdZ+GUTH1D/IQr8GTVw3bmgCtEAFJLbMDbuFbnkVwfbsfRiXphDU4WIXYlI3W3C6Qbvxn9mCEtjF1Z1O0XwyaFyTit1QutHDAN90kz/mecisUJdcuMwUHS54Ua7he2VNJsDpiIZ7F9gtLNOBuvNnleF927T0x8xGS4svgNfe3jxXK1T0IbymwvbDkc6xsfVjlgBzwvfam7WrXxY3E55mGPJnUHcKswuj9RfxW74zkxpLbZSFVNgo/h3ERFbxdKGtkLL2geu48Wj+O8ckHj2LpQuvHEbN/IXiJU/beNJ2y7sFxQdsAksbFI5RXDZ/uxeFHzLp/K2oy6i4St2OqAGpZhfIbgpyvKLhdLUbdYJXrS7Rkyxgtba2x1QD+OyxC6RUR4ZeoicdEtFoqZ/KNCV2psQNjaT0yCB4mIqd1tZBWf4YCGsul4J0NmmVkiCVJmLfbPkPknptSxQJ7xbN3UlOlmkqRqaFbp7IRxWFDHiZmCmjVmQkVZKlWych0AJ/Zq6/m/oY7XuiCn6gtNqihLpVc97LU65osJIYdyY3YTofTZmTLLVO0mcx3wJ+bX8Yn85Wpfkcw4X6wIZ2TKKzNguAN2LXTmMA+fDM0Bi7A8Q1hdrM2PYMfMhjVyq+Fr/unyUmfLFVv1ISGDIkb+JUPoERl1m7EG91aUn5Uh8xdh6yDbenGd7m5BcxkQQ2lTQ3mfvHzhXGErhnejZWLL2G1+19lR9xpx6PJVxbOcfcDjeKhcUDWOZuLDDCWNvCQOKg8QPWygxbsDxTt9qo2fKz1JukrYtg3NssITxblbzgHIJlwl8opl2k2JNXKSOPcbk9CWbzEVXzc+aJUWnyZmy5S84N+4SBxGdIOTxHHcTgl1/xK7v/eqHrZaSt7DnQkKiVzjMtFlc5krvnyK8YPiGKzSeFo74GbckKB0iDEivnhL2s6wr6i7SFq3HxTHeQ+3eqlqCEwV6ejJCUpbMdpHY3Nwz0gvNTpg2C2qHjAah6NXihOtERk6FzhEzNajcdOjLjI5OdmcZmwSX35JJ425Dh9r3/jP8WPHTes939p6mtQ2dbHZaJfbRFBzqMj1/1d4X8xdKzqt2O54Wytues4r/v+6+H+xvOxsLluKNsxQEeS0QzsOWIwDxZJU5i8Rtk6Vd4szlZWF7n7FdZcUWjngCxGBjbRDXCNS4DPFJcZes6HQNb3QnUUzB9wnNi/t5gsH8YC4E3yJuNbabVYXsvcudLW6Jdo2tfW1GWVBA7jM8FOeFKaJL9WNy9JLtQhncyg74GFxGeq3HuhpvC4/dFW+fF1+6Mp8L6/LD+Mf0PkcU9upbK4AAAAASUVORK5CYII='">
				</view>
				<view class="box-name">設定パスワードを再度入力してください</view>
				<view class="box-input">
					<template v-if="isShow">
						<input v-model="verifyPassword" type="text" placeholder="パスワードを入力してください"></input>
					</template>
					<template v-else>
						<input v-model="verifyPassword" type="password" placeholder="パスワードを入力してください"></input>
					</template>

					<img @click="isShow=!isShow"
						:src="isShow?'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAwCAMAAACWlYwtAAAAAXNSR0IArs4c6QAAAM9QTFRFAAAA/wAA/wAAzAAz1QAq2wBJ4wA56AA64wBC5ABA5QA+5gA85gBC5gBA5QA+5ABA5AA/5QA+5gBA5QA/5AA+5AA+5AA95QA+5QA+4wA/5AA/5QA/5QA+4wA/4wA+5AA95AA/5AI+5QI+5QI94wI+5QI+4wI95AI+5QE95QE+5AE+5AE+4wE+5AE+5AE+5QE+4wE/5AE+5AE+5AE+5AE+5AE95AE+5AE+5QE+5AE+5AE+5AE+4wE+5AE+5AE+5AE+5AE+5AE+5AE+5AE+5AE+Z2e5ngAAAER0Uk5TAAECBQYHCRYbHB0eHygxODk6PEVeX2BiY2Vpamtub3ByjJGanaWmqbe4vsDCx8jLzM3Oz9rg4ebn6u3w8fX3+Pr8/f74Bir+AAABwUlEQVRIx7VW2XaCMBCN1tZdxBUXKrjgglqxKO6K8v/f1BOwRzNhs6Hzxs3cIZkluQh5Wa7SGy/Wx+N6Me5VcuhF4/ori7BVnwvP/qhrlotp9Y9Q9JiwtTxsK8SC+YWZ5WOzQgA90b1avmZ2E3781NwKtHnKm1/aWCFsU/LiNy5WKLs03PltyvOqq4qi6nRaWm78FvQaCUlnJSmMQkRo3kiXKdF53JRcvTUhv0ryTRE6iCYZoUIuF8/E8r5Mb7G8J1zOxefFNFk/886P85IsS3z8HoHcwyb9ND0L8oTO/hOi4XwaotN9Iun19ZitAcifDWaWD2SZsSGQycEvvwZqZOc/YzxDhh2BA441h589gPrb+/8mwaV9CtAPh6w9/xMQV3A57z0vAgAn+H7owP7F/RenxsrAtUjCru4glD8BTMe/4ukR4jGuA/CUR0PoqGJHiQ4gYVyF6BDtIKRgR5kOIGNcgeiOPQDzEZiT6FFGI1wZP6NopJCt/ObZygzDVI1qnNkvlL9daakoL1X2a539YWF/2l56XNv/87yzCwx2iYPQe5DIuvqLLHaZF4HQZJe6zmzQYrv4qmDHcl/Dcl/zlfs/8PzWmiS5IY0AAAAASUVORK5CYII=':'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAwCAYAAAChS3wfAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF6mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIyLjIgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNC0xMC0wMlQxMjowNDowNSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6YmM2MjhmN2YtMmE5YS00YmVkLThjOWEtOWM2ZTVmMWIxODk4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQxRjU5ODk3RDBFQzExRUU5RjI4OUZEM0QxRDlDNjc2IiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6RDFGNTk4OTdEMEVDMTFFRTlGMjg5RkQzRDFEOUM2NzYiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEMUY1OTg5NEQwRUMxMUVFOUYyODlGRDNEMUQ5QzY3NiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEMUY1OTg5NUQwRUMxMUVFOUYyODlGRDNEMUQ5QzY3NiIvPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpiYzYyOGY3Zi0yYTlhLTRiZWQtOGM5YS05YzZlNWYxYjE4OTgiIHN0RXZ0OndoZW49IjIwMjQtMTAtMDJUMTI6NDI6NTErMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMS4wIChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PhBFAqgAAAVGSURBVGiB1dpZrJ1TFMDx3zmVqgf1YqyqxBwPtFLcNtQsSIQHHgyJqTW09CYilESaamKMhzaG0JKaJWYeSAwNiopqeaMiocpFSQwxtdrrYX03/Xrud849Z+9zLv7Jyc3d37fX2mt9e1h77V1bX5thFNgbx+AoTMLO2KX4Cz9gQ/F3HVbgTXzZ5XbciJvKBbUeOqAPs3CCcEAKX+J1LMHKjLYcXMiY3vig2w7YAedgDg7rpmCsxt14An90UO8a3NHsYbccUMPFuEV07V6yAdfjQQy2eG8/8dWPbSWs3oUGTcG7WKr3xit0LC10Tmnyzhx8agTjyXPAWCzCKjHeR5s+fFC0YWxRNhEv4y5t2pY6BPbEMzgypXIPeB9PYyHGtVlnHS5LccBReAq7d1rxP8QSXImNnQ6BWXjD/9f473AmLsVG2K6DynPE2MplCz7HN8UPJhS/fXVnYq7iUczGr+XCdh0wW77xr4hx+hK+b/LOrjgdZ+GUTH1D/IQr8GTVw3bmgCtEAFJLbMDbuFbnkVwfbsfRiXphDU4WIXYlI3W3C6Qbvxn9mCEtjF1Z1O0XwyaFyTit1QutHDAN90kz/mecisUJdcuMwUHS54Ua7he2VNJsDpiIZ7F9gtLNOBuvNnleF927T0x8xGS4svgNfe3jxXK1T0IbymwvbDkc6xsfVjlgBzwvfam7WrXxY3E55mGPJnUHcKswuj9RfxW74zkxpLbZSFVNgo/h3ERFbxdKGtkLL2geu48Wj+O8ckHj2LpQuvHEbN/IXiJU/beNJ2y7sFxQdsAksbFI5RXDZ/uxeFHzLp/K2oy6i4St2OqAGpZhfIbgpyvKLhdLUbdYJXrS7Rkyxgtba2x1QD+OyxC6RUR4ZeoicdEtFoqZ/KNCV2psQNjaT0yCB4mIqd1tZBWf4YCGsul4J0NmmVkiCVJmLfbPkPknptSxQJ7xbN3UlOlmkqRqaFbp7IRxWFDHiZmCmjVmQkVZKlWych0AJ/Zq6/m/oY7XuiCn6gtNqihLpVc97LU65osJIYdyY3YTofTZmTLLVO0mcx3wJ+bX8Yn85Wpfkcw4X6wIZ2TKKzNguAN2LXTmMA+fDM0Bi7A8Q1hdrM2PYMfMhjVyq+Fr/unyUmfLFVv1ISGDIkb+JUPoERl1m7EG91aUn5Uh8xdh6yDbenGd7m5BcxkQQ2lTQ3mfvHzhXGErhnejZWLL2G1+19lR9xpx6PJVxbOcfcDjeKhcUDWOZuLDDCWNvCQOKg8QPWygxbsDxTt9qo2fKz1JukrYtg3NssITxblbzgHIJlwl8opl2k2JNXKSOPcbk9CWbzEVXzc+aJUWnyZmy5S84N+4SBxGdIOTxHHcTgl1/xK7v/eqHrZaSt7DnQkKiVzjMtFlc5krvnyK8YPiGKzSeFo74GbckKB0iDEivnhL2s6wr6i7SFq3HxTHeQ+3eqlqCEwV6ejJCUpbMdpHY3Nwz0gvNTpg2C2qHjAah6NXihOtERk6FzhEzNajcdOjLjI5OdmcZmwSX35JJ425Dh9r3/jP8WPHTes939p6mtQ2dbHZaJfbRFBzqMj1/1d4X8xdKzqt2O54Wytues4r/v+6+H+xvOxsLluKNsxQEeS0QzsOWIwDxZJU5i8Rtk6Vd4szlZWF7n7FdZcUWjngCxGBjbRDXCNS4DPFJcZes6HQNb3QnUUzB9wnNi/t5gsH8YC4E3yJuNbabVYXsvcudLW6Jdo2tfW1GWVBA7jM8FOeFKaJL9WNy9JLtQhncyg74GFxGeq3HuhpvC4/dFW+fF1+6Mp8L6/LD+Mf0PkcU9upbK4AAAAASUVORK5CYII='">
				</view>
				<view class="box-name">招待コード</view>
				<view class="box-input">
					<input v-model="code" type="text" placeholder="招待コードを入力してください" maxlength="11"></input>
				</view>
				<view class="box-btn" @click="handleConfirm()">登録する</view>
				<view class="box-foot" @click="$u.route({url:'/pages/account/login'});">口座お持ち方 こちら<img
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFGmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjEuMCAoTWFjaW50b3NoKSIgeG1wOkNyZWF0ZURhdGU9IjIwMjQtMTAtMDJUMTI6MDQ6MDUrMDg6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDI0LTEwLTAyVDEyOjQwOjMxKzA4OjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDI0LTEwLTAyVDEyOjQwOjMxKzA4OjAwIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgcGhvdG9zaG9wOkNvbG9yTW9kZT0iMyIgcGhvdG9zaG9wOklDQ1Byb2ZpbGU9InNSR0IgSUVDNjE5NjYtMi4xIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjI5OTMyYjRkLTlkYzEtNGJmMS05YmJhLWZmZjkzZWY1NTZiMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyOTkzMmI0ZC05ZGMxLTRiZjEtOWJiYS1mZmY5M2VmNTU2YjIiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoyOTkzMmI0ZC05ZGMxLTRiZjEtOWJiYS1mZmY5M2VmNTU2YjIiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjI5OTMyYjRkLTlkYzEtNGJmMS05YmJhLWZmZjkzZWY1NTZiMiIgc3RFdnQ6d2hlbj0iMjAyNC0xMC0wMlQxMjowNDowNSswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIxLjAgKE1hY2ludG9zaCkiLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+tOBA/gAAAsNJREFUaIHt2k9olEccxvHPuyTRGkQRRPFQpGpbKKGHgoYEgq2xIEJAi9CDlELTSw+l9NBTa1DxICK5eFFoRVoVERRUsLT0Dx7ioQcpEVvahsaS0qUimFCqQW08jNTNuO5us++7+6bs97TvM7O/mWdn3pnfvO8mE0kfdGMPurBSekziAPZVqbcIJ7EF7TXG/hOj2IWRZCLp68YIkrn1tSZewLUK5e/j4Bxjz6C3IIxEliags0r5kjpiJ9hdEKZTlhzHd1XqHMF4HW10JRNJ30wkDuCXOoKWcgt/1Fh3AZ5HR5myp3FMhZFtK6ON4YcaG0+TaXxfRl+FE6pMz0IWPUqRFfgaayN9PK6YZyPL8RWei/Sr2B5XLje18sAyfCks26X8iE3C/TSLPI7IUnyBFyP9Z7wibISPkTcji/E5Xor0XwUTT1wB82SkExexIdJ/w8uYqPTlvBh5ChfQG+m/CyNxvVqAPBhZiHPYGOlFwcRYLUGabaQDZ9Af6TeE1emnWgM100g7Tgupeyk3BROVsuVJIev997pZRtqE88dApN/CZuGcUYkpHC25Hm7GhljAp3gt0qfwKq7UGOctfIzbuNJoIwXhl3w90v8Spli1dD9mpDRwo0hwGG9E+t/YWtqpudBII4cwGGl3hPvkUr3BG2VkGO9E2jS2CRlu3TTCyH68F2l3sUPIq1IhayN78UGk3RNu9vNpNpTlqvUuPoy0+9gp7Ob1svphG1My3kc+iq7/wZs4lULsNnwjmIH1WU6tyZLPM3gbn6UUe41HJqA/SyODwoGoKOwdn6QYO36s2p7l1PoWz2QYfxbNTuNTo2Ukb7SM5I2WkbzRMpI3WkbyRstI3mgZyRv/GyPlDlbPyr/BdbHQJhxFS/8RdLZh3UmPYkH1R/jzgdEChsx+aTLfmMFQAZfRI7ygLza1S/+NotDnHlx+AIHkdV95ad2hAAAAAElFTkSuQmCC">
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	// import Translate from '@/components/Translate.vue';
	import TabsSeventh from '@/components/tabs/TabsSeventh.vue';
	export default {
		components: {
			// Translate,
			TabsSeventh,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				user: "", // 账户
				password: '', // 密码
				verifyPassword: '', // 确认密码
				emailCode: '', // 邮箱验证码（印度）
				code: '', // 邀请码
				curTab: 1,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
				inv: 0
			};
		},

		onShow() {
			this.isAnimat = true;
			// 读取缓存中的页面信息
			this.getStorageData();
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			this.isAnimat = false;
			// 缓存页面信息
			this.setStorageData();
		},
		methods: {
			bian(num) {
				this.inv += num
				if (this.inv < 0) {
					this.inv = 4;
				} else if (this.inv > 4) {
					this.inv = 0;
				}
			},
			// 切换当前 登录或注册
			changeTab(val) {
				// this.isSignIn = !this.isSignIn;
				this.curTab = val;
				this.setStorageData();
				this.getStorageData();
			},
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('pwd1', this.verifyPassword);
				uni.setStorageSync('code', this.code);
				uni.setStorageSync('remember', this.isRemember);
				uni.setStorageSync('agree', this.isAgree);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
				this.verifyPassword = uni.getStorageSync('pwd1') || '';
				this.code = uni.getStorageSync('code') || '';
				this.isRemember = uni.getStorageSync('remember') || false;
				this.isAgree = uni.getStorageSync('agree') || false;
			},
			// 设置 激活样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : '#A8A8A8',
					padding: `16rpx 32rpx`,
					borderRadius: `44rpx`,
					minWidth: `120rpx`,
					textAlign: `center`,
				}
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 勾选记住密码
			changeRemember(e) {
				console.log(e);
				this.isRemember = e;
				uni.setStorageSync('remember', this.isRemember);
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				console.log(e);
				this.isAgree = e;
				uni.setStorageSync('agree', this.isAgree);
			},

			// 用户隐私协议
			linkPact() {
				this.setStorageData();
				uni.navigateTo({
					url: this.$paths.PRVITE_PACT,
				})
			},

			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				// 以下通用
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}

				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				this.setStorageData();
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				this.setStorageData();
				this.signIn();
			},
		}
	}
</script>

<style type="text/css">
	@charset "UTF-8";

	/* uni.scss */
	.block {
		padding-top: 45px
	}

	.head {
		height: 45px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
		padding: 0 21px;
		width: 100%;
		position: fixed;
		left: 0;
		top: 0;
		box-sizing: border-box;
		z-index: 10;
		background: #fff
	}

	.head .back {
		width: 20px;
		height: 15px;
		display: block
	}

	.head .title {
		font-size: 13px;
		font-weight: 600;
		color: #111;
		letter-spacing: 0.5px;
		-webkit-transition-duration: 1s;
		-moz-transition-duration: 1s;
		-o-transition-duration: 1s;
		margin-left: -208px
	}

	.short {
		width: 100%;
		height: 1px;
		background: #ebebeb
	}

	@charset "UTF-8";

	/* uni.scss */
	.box {
		padding: 1px 20px 0 20px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-webkit-flex-direction: column;
		flex-direction: column;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center
	}

	.box .box-info {
		width: 100%;
		margin-left: -400%;
		-webkit-transition-duration: 1s;
		-moz-transition-duration: 1s;
		-o-transition-duration: 1s
	}

	.box .box-top {
		width: 227px
	}

	.box .box-title {
		width: 100%;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-size: 17px;
		font-weight: 600;
		color: #2a2a2a;
		line-height: 24px;
		margin-top: 1px
	}

	.box .box-tip {
		width: 100%;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		font-size: 11px;
		font-weight: 400;
		color: #080827;
		line-height: 15px;
		letter-spacing: 0.5px;
		margin-top: 11px
	}

	.box .box-name {
		width: 100%;
		height: 37px;
		padding: 0 3px;
		font-size: 12px;
		font-weight: 600;
		color: #080827;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center
	}

	.box .box-input {
		width: 100%;
		height: 35px;
		border-radius: 3px;
		border: 1px solid #bcbcbc;
		padding: 0 9px;
		box-sizing: border-box;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center
	}

	.box .box-input uni-input {
		width: 100%;
		height: 33px;
		line-height: 33px;
		background: transparent;
		border: 0;
		font-size: 12px;
		font-weight: 400;
		color: #333
	}

	.box .box-input img {
		width: 16px;
		height: 12px;
		margin-left: 7px
	}

	.box .box-btn {
		width: 100%;
		height: 39px;
		background: #e4013e;
		border-radius: 6px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-size: 13px;
		font-weight: 500;
		color: #fff;
		margin-top: 21px
	}

	.box .box-foot {
		height: 57px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		font-size: 11px;
		font-weight: 400;
		color: #000020
	}

	.box .box-foot span {
		font-size: 11px;
		font-weight: 400;
		color: #195546;
		margin-left: 9px
	}

	.box .box-foot img {
		width: 13px;
		height: 13px;
		margin-left: 5px
	}

	.uni-input-input {
		font-size: 12px;
		font-weight: 400;
		color: #333
	}
</style>