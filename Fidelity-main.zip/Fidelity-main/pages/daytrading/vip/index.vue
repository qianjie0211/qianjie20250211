<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/zuofanhui.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.QIANGGOU}}</text>
			</view>
			<view style="color:#FFFFFF;font-size: 12px;" @click="linkRecord()">{{$lang.LISHI_JILV}}</view>
		</header>

		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="padding:16px 20rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;display: flex;align-items: center;border: 1px #ccc solid;border-radius: 10px;background-color: #1a1e2a;">
					<!-- <view style="flex:0 0 6%">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view> -->
					<view style="flex:94%;">
						<view style="display: flex;align-items: center;">
							<view style="padding-left: 20rpx;font-size: 32rpx;font-weight: 700;color:#fff;">
								{{item.goods.name}}
							</view>
							
						</view>
						<view style="display: flex;align-items: center;padding:0 20rpx;">
							<view style="font-size: 28rpx;padding-right:80rpx;" :style="{color:$theme.LOG_LABEL}">
								{{item.goods.code}}
							</view>
							<view style="font-size: 28rpx;padding-right:80rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(item.price)}}
							</view>
							<view style="font-size: 28rpx;text-align: center;"
								:style="$theme.setStockRiseFall(item.rate_num>0)">
								{{item.goods.rate>0?'+':'-'}} {{($util.formatNumber(Math.abs(item.goods.rate),2))}}%
							</view>

						</view>
					</view>
					<view :style="setStyle()" @click="handleDetail(item)">
						{{$lang.BTN_BUY}}
					</view>
				</view>
			</block>
			<template v-if="isShow">
				<TradevipBuy :info="itemInfo" @action="handleClose"></TradevipBuy>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	import TradevipBuy from './components/TradevipBuy.vue';
	export default {
		components: {
			TradevipBuy,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 是否显示弹层
				list: [], // 持有列表
			}
		},
		onShow() {
			this.getList();
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkStockInfo(val) {
				uni.navigateTo({
					url: this.$CONSTANTS.STOCK_OVERVIEW + `?gid=${val.gid}&type=${val.project_type_id}`
				});
			},
			linkRecord() {
				uni.navigateTo({
					url: '/pages/daytrading/vip/recording'
				})
			},
			handleDetail(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				const result = await this.$http.get('api/goods/goodsvipscramble');
				if (!result) return false;
				console.log(result);
				this.list = result;
			},
			setStyle() {
				return {
					backgroundColor: '#03b774',
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `8px 10px`,
					fontSize: `22rpx`,
					textAlign: `center`,
					width:'50px'
				}
			},
		},
	}
</script>
<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>