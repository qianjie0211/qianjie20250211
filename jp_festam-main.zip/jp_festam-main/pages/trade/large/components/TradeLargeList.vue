<template>
	<view style="border-radius: 10px;padding: 10px;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			
			<view style="border: 1px #f2bc8f solid;border-radius: 10px;margin-top: 10px;">
				<view class="flex" style="padding: 10px 5px;border-radius: 10px;">
					<view class="bold" style="font-size: 16px; width: 120px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{item.name}}</view>
					<view class="flex-1" style="color: #a3a4a4;font-size: 10px;">({{item.code}})</view>
					<view class="flex-1" style="font-size: 18px;color: #f65d43;">{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
					<view style="background-color: #f2bd8f;padding: 5px 20px;border-radius: 30px;color: #FFFFFF;" @click="handleDetail(item)">{{$lang.BTN_BUY}}</view>
				</view>
				<view class="flex" style="justify-content: space-between;padding: 10px 10px;">
					<view class="flex-1">
						<view style="color: #999;">価格</view>
						<view class="bold font-size-18 margin-top-10">{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
					</view>
					<view class="flex-1">
						<view style="color: #999;">最低購入額</view>
						<view class="bold font-size-18 margin-top-10">{{$util.formatMoney(item.min_num)+` ${$lang.CURRENCY_UNIT}`}}</view>
					</view>
				</view>
			</view>
			
		</block>
		
		<template v-if="isShow">
			<TradeLargeBuy :info="itemInfo" @action="handleClose"></TradeLargeBuy>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeLargeBuy from './TradeLargeBuy.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeLargeList',
		components: {
			CustomTitle,
			EmptyData,
			TradeLargeBuy,
			CustomLogo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		computed: {},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					// backgroundColor: this.$theme.PRIMARY,
					...this.$theme.LG_PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `8rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},

			handleDetail(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				});
			},
		},
	}
</script>