<template>
	<view>
		<!-- <web-view src="/#/pages/trade/day/index?type=1&top1=1" @message="handleMessage"></web-view> -->
	</view>
</template>


<script>
	
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	export default {
		components: {
			HeaderPrimary,
		},
		data() {
			return {}
		},
		
		onLoad() {
			
		},
		onShow() {
			uni.reLaunch({
				url:"/pages/trade/day/index?type=1&top1=1"
			})
		},
		computed: {
			//如果是页面初始化调用时，需要延时一下 
		},

		methods: {
			
			handleMessage(event) {
				const data = event.detail.data[0]; // 获取消息内容
				console.log(111111111111, data);

				if (data.action === 'navigateTo') {
					// 使用 uni.navigateTo 跳转到指定页面
					uni.navigateTo({
						url: data.page
					});
				}
			}
		},
	}
</script>