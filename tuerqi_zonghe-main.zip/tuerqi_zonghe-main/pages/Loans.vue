<template>
	<view style="min-height: 100vh;background-color: #010101;">
		<header class="flex padding-20" style="background-color: #010101;justify-content: space-between;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}" class="font-size-16">
					{{$lang.DAI_KUAN}}
				</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view class="padding-15 color-red ">
			{{$lang.JINGPING_SHENHE}}
		</view>

		<view class="flex justify-center margin-top-20">
			<view class="">
				{{$lang.LOANS_ZXDJE}}
			</view>
		</view>

		<view class="flex justify-center ">
			<view class="font-size-30">{{userinfo.keshenq}}</view>
			<view style="padding: 0px 5px;color: #FFFFFF;margin-top: 6px;">USDT</view>
		</view>



		<view class="flex" style="padding: 0px 15px;margin-top: 30px;">
			<view>
				{{$lang.LOANS_JDJE}}
			</view>
			<view style="padding: 0px 5px;color: #FFFFFF;">(USDT)</view>
		</view>

		<view style="padding: 10px 15px;">
			<input :placeholder="$lang.LOANS_QSRJDJE" v-model="money"
				style="border: 1px #999 solid;padding: 10px;border-radius: 10px;" />
		</view>

		<view style="margin-top: 10px;">
			<view class="flex" style="justify-content: flex-end;padding: 0px 20px;">
				<view>
					{{$lang.LOANS_JDJE}}:
				</view>
				<view>{{userinfo.keshenq}}</view>
				<view class="font-size-11 margin-left-5">USDT</view>
			</view>
			<view class="flex" style="justify-content: flex-end;padding: 0px 20px;">
				<view>
					{{$lang.LOANS_YJDJE}}:
				</view>
				<view>{{userinfo.daik}}</view>
				<view class="font-size-11 margin-left-5">USDT</view>
			</view>
		</view>


		<view style="padding: 30px 10px;" @click="getAccountInfo()">
			<view class="text-center" style="background-color: #458ae7;padding: 10px;color: #FFFFFF;border-radius: 10px;">
				{{$lang.LOANS_QR}}
			</view>
		</view>
		
		<view style="height: 160rpx;"></view>
		<FooterSmall code="assets" />
	</view>
</template>

<script>
	export default {
		components: {

		},
		data() {
			return {
				info: null,
				money: "",
				userinfo: "",
			};
		},

		computed: {

		},
		onLoad() {},
		onShow() {
			this.getAccountInfo();
			this.getAccountuserinfo();
		},
		onReady() {},
		onHide() {},
		methods: {
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/app/daikuan`, {
					money: this.money
				});
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				uni.showToast({
					title: result.data,
					duration: 1000,
					icon: 'success'
				})
			},
			async getAccountuserinfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('userinfo result：', result);
				if (!result) return false;
				this.userinfo = result;
			},
			linkRecord() {
				uni.navigateTo({
					url: '/pages/Loansjiju'
				})
			},
		}
	}
</script>

<style>
</style>