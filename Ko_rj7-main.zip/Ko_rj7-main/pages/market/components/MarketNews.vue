<template>
	<view style="background-color: #ecebf4;">
		<view class="padding-10">
			<!-- <TabsFifth :tabs="$lang.MARKET_NEWS_TABS" @action="changeTab" :acitve="curTab"></TabsFifth> -->
			<image src="/static/xinwen_bg.png" mode="widthFix" style="width: 100%;"></image>
			<view style="margin-top: -10px;">
				<view class="flex" style="line-height: 1.8;background-color: #fff;border-radius: 5px;padding: 20px 0px;">
					<view style="flex: 30%;text-align: center;" @click="$util.linkCustomerService()">
						<image src="/static/kefu-dd.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
						<view class="font-size-11">고객 서비스</view>
					</view>
					<view style="flex: 30%;text-align: center;" @click="xingu()">
						<image src="/static/sc_rr.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
						<view class="font-size-11">IPO</view>
					</view>
					<view style="flex: 30%;text-align: center;" @click="rinei()">
						<image src="/static/sc_ee.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
						<view class="font-size-11">AI거래</view>
					</view>
					<view style="flex: 30%;text-align: center;" @click="dazong()">
						<image src="/static/sc_ww.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
						<view class="font-size-11">블록딜</view>
					</view>
					<view style="flex: 30%;text-align: center;" @click="tikuan()">
						<image src="/static/sc_qq.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
						<view class="font-size-11">입금</view>
					</view>
				</view>
			</view>
		</view>
		
		<view style="background-color: #fff;padding: 10px;">
			<view class="flex">
				<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
				<view class="bold margin-left-5">뉴스 내용</view>
			</view>
			<view class="flex gap10" style="padding: 5px 5px;">
				<image src="../../../static/xinwen_q.png" mode="widthFix" style="width: 110px;"></image>
				<image src="../../../static/xinwen_w.png" mode="widthFix" style="width: 110px;"></image>
				<image src="../../../static/xinwen_e.png" mode="widthFix" style="width: 110px;"></image>
			</view>
			<view class="padding-5">
			<block v-for="(item,index) in list.slice(10,16)" :key="index" >
				<view @click="open(item.url)" class="gap10"
					style="display: flex;align-items: center;margin-bottom: 10px;">
					<template v-if="curTab==0">
						<view style="border: 3px #f20206 solid;border-radius: 50px;"></view>
						<view style="color: #121212;">
							<view style="width: 80%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{item.title}}</view>
							
						</view>
					</template>
				</view>
			</block>
			</view>
		</view>
		

		<view style="padding: 10px 10px;background-color: #fff;margin-top: 10px;">
			<block v-for="(item,index) in list" :key="index">
				<view @click="open(item.url)" class="gap10"
					style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;border-bottom: 1px #ccc solid;">
					<template v-if="curTab==0">
						<view style="flex: 20%;">
							<image :src="item.pic" :style="$theme.setImageSize(200,150)" mode="scaleToFill"
								style="border-radius: 10px;"></image>
						</view>
						
						<view style="flex:80%;padding-top: 10px;color: #121212;">
							<view>{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;"><text style="padding: 4px 0;"
									:style="{color:$theme.LOG_VALUE}">{{$util.formatDate(item.updated_at)}}</text>
							</view>
						</view>
					</template>
					<template v-else>
						<view style="flex:100%">
							<view style="color: #121212;">{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;text-align: right;"
								:style="{color:$theme.LOG_VALUE}">
								{{$util.formatDate(item.updated_at)}}
							</view>
						</view>
					</template>
				</view>
			</block>
		</view>
		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}} </view>
	</view>
</template>

<script>
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	export default {
		name: 'MarketNews',
		components: {
			TabsFifth,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			open(url) {
				window.open(url)
			},
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			rinei(){
				uni.navigateTo({
					url:'/pages/aiBank/aiBank'
				})
			},
			dazong(){
				uni.navigateTo({
					url:'/pages/trade/large/index'
				})
			},
			xingu(){
				uni.navigateTo({
					url:'/pages/trade/ipo/index'
				})
			},
			tikuan(){
				uni.navigateTo({
					url:'/pages/deposit/index'
				})
			},
			
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/get_news`, {
					current: this.curTab
				})
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						title: item.title,
						url: item.url,
						updated_at: item.updated_at,
						pic: item.pic,
					}
				});
			},
		}
	}
</script>