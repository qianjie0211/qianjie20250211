<template>
	<view style="padding:18px;padding-bottom: 200rpx;padding-top: 0;">
		<!-- background-color: #34393e;border-radius: 32rpx; -->
		<view style="font-size: 20px;font-weight: 700;color: #10DF95;width: 50%;margin-top: 20px;margin-left: 20px;">
			IMPORTO DELLA PARTECIPAZIONE
		</view>
		<view
			style="box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(255, 255, 255, 0.25) 0px 0px 0px 1px;padding: 10px;border-radius: 10px;background-color: #1a1e2a;margin-top: 20px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.TRADE_DAY_TIP_INPUT_AMOUNT}}
			</view>
			<view style="padding:24rpx;">
				<u-radio-group v-model="radiovalue1" placement="column" @change="groupChange">
					<u-radio :customStyle="{marginBottom: '8px'}" v-for="(item, index) in radiolist1" :key="index"
						:label="item.name" :name="item.bi" @change="radioChange" activeColor="#03b673"
						labelColor="#efefef">
					</u-radio>
				</u-radio-group>
				<view class="access_input_wrapper"
					style="background-color: transparent;padding:12rpx;border:1px solid #666;">

					<view style="padding-right: 12rpx;" :style="{color:$theme.PRIMARY}">{{biname}}</view>
					<input v-model="amount" type="digit" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					<!-- <view style="color:#fff">{{$lang.CURRENCY_UNIT}}</view> -->
				</view>
				<template v-if="amount>0">
					<view style="padding-left: 12rpx;color:#AAA;"> USD {{$util.formatUSD(`${amount*eurToUsd}`,4)}}
					</view>
				</template>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx;"
				:style="{color:$theme.LOG_LABEL}">
				<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
				<view :style="{color:$theme.LOG_VALUE}">
					<template v-if="available && available>0">
						<view class="margin-top-10 color-white" style="text-align: right;">
							{{` € `+$util.formatMoney(`${available}`,4)}}
						</view>
						<view style="color:#AAA;text-align: right;">
							{{` $ `+$util.formatUSD(`${available*eurToUsd}`,4)}}
						</view>
					</template>
					<view style="text-align: right;" :style="{color:$theme.PRIMARY}" @click="linkDeposit">
						{{$lang.DEPOSIT_TITLE}}
					</view>
				</view>

			</view>
		</view>

		<view style="padding-bottom: 24rpx;margin-top: 20px;">
			<view class="common_btn"
				style="margin:0 auto;background-color: #03b774;color:#FFF;border-radius: 30px;width: 90%;"
				@click="handleBuy()">
				{{$lang.TRADE_DAY_BUY}}
			</view>
		</view>

		<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;" :style="{color:$theme.LOG_VALUE}">
			<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
			<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;font-size: 13px;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeDayBuy',
		data() {
			return {
				radiolist1: [{
						name: 'Trading intraday azioni italiane',
						bi:1,
						disabled: true
					},
					{
						name: 'Trading intraday azioni\namericane',
						bi:2,
						disabled: false
					},
					{
						name: 'Alleanza dei trader',
						bi:3,
						disabled: false
					}
				],
				// u-radio-group的v-model绑定的值如果设置为某个radio的name，就会被默认选中
				radiovalue1: 1,
				amount: '',
				available: '',
				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
				biname:"EUR"
			}
		},
		created() {
			this.getconfig();
			this.getAccountInfo();
		},
		methods: {
			groupChange(n) {
				console.log('groupChange', n);
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1=n
				if(n==1||n==3){
					this.biname="EUR"
				}else{
					this.biname="EUR"
				}
			},
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},

			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},

			// 购买
			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TRADE_DAY_TIP_INPUT_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				// 弹层
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},

			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
					radiovalue1:this.radiovalue1,
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					// 1 为驱动父组件，实现切换Tab效果
					this.$emit('action', 1);
				}, 1000);
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(result);
				this.available = result.totalZichan || 0;
			},
		}
	}
</script>