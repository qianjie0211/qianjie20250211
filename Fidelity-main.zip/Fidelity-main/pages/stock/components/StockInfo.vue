<template>
	<view style="padding-bottom: 10px;">
		<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
			<template v-if="info.logo">
				<!-- <view style="width: 80rpx;margin:auto 0;">
					<image :src="info.logo" mode="aspectFit" :style="$theme.setImageSize(80)"
						style="border-radius:100%;"></image>
				</view> -->
			</template>
			<view style="flex:72%">
				<view style="margin-bottom: 2px;padding:1px 6px;">
					<text
						style="font-weight: 700;font-size: 40rpx;border-radius: 4px;color: #FFFFFF;">{{info.name}}</text>
					<!-- <view class="hui"> {{info.ct_name}}</view> -->
				</view>
			</view>
		</view>

		<view
			style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;justify-content:space-between;"
			:style="$util.setStockRiseFall(info.rate>0)">
			<view style="font-size: 20px; font-weight: 700;">
				<template v-if="$util.isEur(info.project_type_id)">
					{{`€ `+$util.formatMoney(`${info.current_price}`)}}
				</template>
				<template v-else>
					{{`$ `+$util.formatUSD(`${info.current_price}`)}}
				</template>
			</view>
			<view style="text-align: right; font-size: 20px; font-weight: 700;">
				<template v-if="$util.isEur(info.project_type_id)">
					{{`€ `+$util.formatMoney(`${info.rate_num}`)}}
				</template>
				<template v-else>
					{{`$ `+$util.formatUSD(`${info.rate_num}`)}}
				</template>
			</view>
			<view style="text-align: right; font-size: 20px; font-weight: 700;">
				<image :src="`/static/arrow_${info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
					:style="$util.setImageSize(32)" style="margin-right: 10px;"></image>
				{{info.rate}}%
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'StockInfo',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {

		},
		created() {
			console.log(`stock info:`, this.info);
			console.log(`stock info:`, this.info.current_price);
		},
		methods: {}
	}
</script>

<style>
</style>