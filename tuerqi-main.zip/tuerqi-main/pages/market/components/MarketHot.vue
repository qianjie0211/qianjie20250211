<template>
	<view style="background-color: #FFFFFF;border-radius: 15px;">
		<view class="flex" style="padding: 0px 40px;">
			<block v-for="(item,index) in MARKET_HOT_TABS" :key='index'>
				<view class="btn_common flex-1" :style="setStyleTab(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>



		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view class="flex flex-b"
				style="color: #999;background-color: #fffaf3;border-radius: 30px;padding: 5px 0px;">
				<view class="text-center" style="flex: 3%;">{{$lang.TRADE_EA_YBFIFJ}}</view>
				<view class="text-center" style="flex: 30%;">{{$lang.TRADE_EA_ODGVRFJ}}</view>
				<view class="text-center" style="flex: 10%;">{{$lang.TRADE_EA_OOLKDMJ}}</view>
			</view>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding:10px;display: flex;align-items: center;border-bottom:1px solid #F3F3F3;"
					@click="link(item.code)">


					<view style="flex:1 0 86%;">
						<view style="display: flex;align-items: center;">
							<view style="flex: 26%;">
								<view class="color-black bold" style="font-size: 28rpx;line-height: 1.6;">
									{{item.name}}
								</view>
								<view style=" font-size: 25rpx;" :style="{color:$theme.LOG_LABEL}">
									{{item.code}}
								</view>
							</view>

							<view style="flex:15%; font-size: 32rpx;font-weight: 700;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{$util.formatMoney(item.current_price)}}
							</view>
							<view style="flex: 10%; color:#FFFFFF;" :style="setStyle(item.rate*1>0)">
								<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
									:style="$theme.setImageSize(16)" style="padding-right: 12rpx;"></image>
								%{{$util.formatMoney(item.rate,2)}}
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>

		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketHot',
		components: {
			TabsFifth,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				curTab: 0,
				MARKET_HOT_TABS: ['BIST 100', 'BIST 30', 'Banks'],
				timer: null,
			}
		},
		created() {
			this.getList();
		},
		

		methods: {
		
			// 设置样式
			setStyleTab(val, w = 80) {
				return {
					minWidth: `${w}rpx`,
					margin: '10rpx',
					padding: `12rpx 24rpx`,
					textAlign: 'center',
					backgroundColor: val ? '#f7be64' : this.$theme.TRANSPARENT,
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `44rpx`,
				}
			},
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					borderRadius: `10rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			async getList() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/paihang`, {
					current: this.curTab
				})
				console.log(result);
				this.list = result
			},
		}
	}
</script>

<style lang="scss" scoped>
	.btn_common {
		padding: 6rpx 12rpx;
		font-size: 28rpx;
		text-align: center;
		margin-right: 12rpx;
		display: inline-block;

	}
</style>