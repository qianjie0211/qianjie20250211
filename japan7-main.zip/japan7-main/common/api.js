// http.js
// 通常可以吧 baseUrl 单独放在一个 js 文件了
// const BaseUrl = 'http://47.242.30.5/'
import md5 from 'js-md5';
import UTIL from '@/common/util.js';

const BaseUrl = 'https://api.jpanstock.xyz'

const WssUrl = 'wss://api.jpanstock.xyz/ws'


const Request = "Qwd3N5yp"
const API_URL = {
	SIGN_IN: `api/app/login`, // 登入
	SIGN_UP: `api/app/register`, // 创建账户
	SIGN_OUT: 'api/app/logout', // 登出
	APP_CONFIG: 'api/app/config', // 获取一些配置信息
	APP_WITHDRAW: 'api/app/withdraw', // 提款
	USER_INFO: `api/user/info`, // 用户信息
	USER_BIND_CARD: `api/user/bindBankCard`, // 换绑银行卡
	GOODS_LIST: `api/goods/list`, // 产品列表
	COLLECT_LIST: `api/user/collect_list`, // 关注的产品
	COLLECT_EDIT: `api/user/collect_edit`, // 删除收藏
	GOODS_ZHIBIAO: `api/goods/zhibiao`, // 指标
	GOODS_PAIHANG: `api/goods/paihang`, // 市场排行
	GOODS_NEWS: `api/goods/get_news`, // 市场新闻
	GOODS_TOP1: `api/goods/top1`, // 市场概况 折线数据、最近新闻
	GOODS_TOP2: `api/goods/top2`, // 市场排行top1-5

	TRADE_SHORT_LIST: `api/goods-duanda/list`, // 短打交易 列表
	TRADE_SHORT_DETAIL: `api/goods-duanda/detail`, // 短打交易 单数据详情
	TRADE_SHORT_ORDER: `api/goods-duanda/doOrder`, // 短打交易 下单
	TRADE_LARGE_LIST: `api/goods-bigbill/list`, // 大宗交易 列表
	TRADE_LARGE_DETAIL: `api/goods-bigbill/detail`, // 大宗交易 单数据详情
	TRADE_LARGE_ORDER: `api/goods-bigbill/doOrder`, // 大宗交易 下单
	TRADE_DISCOUNT_LIST: `api/goods-discount/list`, // 大宗交易 列表
	TRADE_DISCOUNT_DETAIL: `api/goods-discount/detail`, // 大宗交易 单数据详情
	TRADE_DISCOUNT_ORDER: `api/goods-discount/doOrder`, // 大宗交易 下单
	TRADE_IPO_LIST: `api/goods-shengou/calendar`, // IPO交易 列表


	PRODUCT_INFO: `api/product/info`, // 产品详情
	PRODUCT_LISHI: 'api/product/lishi', // 
	PRODUCT_NEWS: `api/product/news`, // 股市新闻
	PRODUCT_INFO_TOW: `api/product/info_two`, // 
	ABOUT_US: 'api/article/about-us', // 关于我们
	SIGNIN_PASSWORD: 'api/user/updateLoginPassword', // 变更登入密码
	PAY_PASSWORD: 'api/user/updatePayPassword', // 变更支付密码
	BIND_BANK_CARD: 'api/user/bindBankCard', // 绑卡
	USER_FASTINFO: 'api/user/fastInfo', // 可用金额
	USER_WITHDRAW: 'api/user/withdraw', // 提现记录
	USER_DEPOSIT: 'api/user/recharge', // 充值记录
	USER_FINANCE: 'api/user/finance', // 资金明细
	APP_QX: 'api/app/qx', // 取消 提现记录中使用
	USER_ORDER: 'api/user/order', // 持股和卖出
	USER_SELL: 'api/user/sell', // 卖出
};

/* 一些未用到的API
// 新股持仓
let list = await this.$http.post('api/user/sg-order', { gp_index: 0 })

let list = await this.$http.post('api/goods-shengou/user-all-apply-log', { gp_index: 0 })
*/

const baseUrl = async () => {
	if (!BaseUrl) {
		const res = await uni.request({
			url: BaseUrl,
			method: 'GET',
		})
		BaseUrl = res[1].data
		const str = BaseUrl.substring(0, BaseUrl.length - 1);
		uni.setStorageSync("url", str)
	}
}
const request = async (options = {}) => {

	// 在这里可以对请求头进行一些设置
	let token;
	let is_if = uni.getStorageSync("token") || ''
	if (is_if) {
		token = "Bearer " + uni.getStorageSync("token")
	} else {
		token = ''
	}
	options.header = {
		"Content-Type": "application/x-www-form-urlencoded",
		"Authorization": token,
		"language": 'zh-Hans',
	}
	if (!BaseUrl) await baseUrl()

	const setHearderIndex = (data) => {
		options.header = data
	}
	return new Promise((resolve, reject) => {


		let time = parseInt(new Date().getTime() / 1000)
		let str_url = ("/" + options.url).toLowerCase()


		let mdd = md5("XPFXMedS" + Request + str_url + time)
		// console.log(mdd+"=="+options.url+"=="+str_url+"=="+time);


		uni.request({
			url: BaseUrl + "/" + options.url + "?sign=" + mdd + "&t=" + time,
			method: options.type || 'GET',
			data: options.data || {},
			header: options.header || {},

		}).then(data => {
			let [err, res] = data;
			if (err) {
				reject(err)
			} else {
				console.log(`res:`, res);
				if (res.data.code === 999 || !uni.getStorageSync('token') || uni.getStorageSync(
						'token') == '') {
					try {
						try {
							uni.clearStorageSync();
						} catch (e) {
							// error
						}
						uni.$u.toast("ログイン状態が正しくありません。 もう一度ログインしてください。");
						setTimeout(() => {
							uni.navigateTo({
								url: UTIL.PAGE_URL
									.ACCOUNT_SIGNIN // '/pages/account/sigin'
							});
						}, 1000)

					} catch (e) {
						//TODO handle the exception
					}
				}
				resolve(res);
			}

		}).catch(error => {
			// console.log(error)
			reject(error)

		})
	});
}

const get = (url, data, options = {}) => {
	options.type = 'GET';
	options.data = data;
	options.url = url;
	return request(options)
}

const post = (url, data, options = {}) => {
	options.type = 'POST';
	options.data = data;
	options.url = url;
	return request(options)
}


export default {
	API_URL,
	request,
	get,
	post,
	BaseUrl: BaseUrl,
	WssUrl
}