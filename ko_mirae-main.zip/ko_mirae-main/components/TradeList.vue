<template>
	<view>
		<view class="sc_bg" v-for="(item,index) in list" :key="index" style="padding:10rpx 30rpx;border-radius: 10px;margin-top: 10px;">
			<view style="margin: 10px 0;display: flex;align-items: center;">
				<view>
					<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
				</view>
				<view class="margin-left-10 flex-1">
					<view class="bold" style="color:#121212;font-size: 16px;">{{item.name}}</view>
					<view style="color:#777;font-size: 16px;">{{item.code}}</view>
				</view>
				
				<view @click="handleDetail(item.id)"
					style="background-color: #ff8f33;color: #fff;border-radius: 8rpx;padding: 6rpx 40rpx;font-size: 26rpx">
					{{$lang.DETAIL}}
				</view>
			</view>
			<view class="flex" style=" justify-content: space-between;">
				<view>
					<view style="color: #777;">단가</view>
					<view class="font-size-18 text-center margin-top-10">{{item.price}} 원</view>
				</view>
				<view>
					<view style="color: #777;">최소 구매</view>
					<view class="font-size-18 text-center margin-top-10">{{item.min_num}} 주</view>
				</view>
				<view>
					<view class="text-center" style="color: #777;">최대 구매</view>
					<view class="font-size-18 text-center margin-top-10">{{item.max_num}} 주</view>
				</view>
			</view>
		</view>
		<EmptyData v-if="list.length<=0"></EmptyData>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeList",
		props: ['type', 'height'],
		components: {
			EmptyData
		},
		data() {
			return {
				list: [],
			};
		},
		computed: {
			heightVal() {
				return this.height > 0 ? this.height : 85;
			},
		},
		mounted() {
			this.getList();
		},
		methods: {
			// 查看详情
			handleDetail(id) {
				this.$emit('action', id);
			},
			async getList() {
				const result = await this.$http.get(`api/goods-${this.type}/list`, {});
				this.list = result.data.data.map(item => {
					return {
						id: item.id,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				})
			},
		}
	}
</script>

<style>

</style>