<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.TRADE_IPO_TITLE}}</text>
			</view>
		</header>

		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in $lang.TRADE_IPO_TABS" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#1C1C1C`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab ==0">
			<TradeIPOList :list="ipoList" @action="handleBuy"></TradeIPOList>
		</template>

		<template v-if="curTab==1">
			<TradeIPORecord :list="ipoRecord"></TradeIPORecord>
		</template>
		<template v-if="curTab==2">
			<TradeIPOSuccessRecord :list="successList"></TradeIPOSuccessRecord>
		</template>

	</view>
</template>

<script>
	import TradeIPOList from './components/TradeIPOList.vue';
	import TradeIPORecord from './components/TradeIPORecord.vue';
	import TradeIPOSuccessRecord from './components/TradeIPOSuccessRecord.vue';

	export default {
		components: {
			TradeIPOList,
			TradeIPORecord,
			TradeIPOSuccessRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				ipoList: [],
				ipoRecord: [],
				successList: [],
			};
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getList();
				if (this.curTab == 1) this.getRecordList();
				if (this.curTab == 2) this.getSuccessList();
			},

			handleBuy(val) {
				this.changeTab(val);
			},

			async getSuccessList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				if (!result) return false;
				console.log(result);
				this.successList = result;
			},

			// record
			async getRecordList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-apply-log`);
				if (!result) return false;
				console.log(result);
				this.ipoRecord = result;
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				});
				if (!result) return false;
				console.log(result);
				this.ipoList = result.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				})
			},

			// 设置样式
			setStyle(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>