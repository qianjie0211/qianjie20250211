<template>
	<view :class="isAnimat ? 'fade_in' : 'fade_out'">
		<HeaderSecond :title="$lang.TRADE_VIP_TITLE" :color="$theme.SECOND"></HeaderSecond>
		
		<view class="flex flex-b" style="padding: 10px 60px;">
			<view style="background-color: #ff8502;border-radius: 30px;padding: 5px 20px;color: #FFFFFF;">{{$lang.API_UFGFDGG}}</view>
			<view class="bold" @click="jilv()">{{$lang.API_UFXFHDFHRG}}</view>
		</view>

		<view style="padding: 10px;">
			<block v-for="(item, index) in list" :key="index">
				<view
					style="margin: 0rpx 10rpx; padding: 20rpx; background-color: #FFFFFF; border-radius: 8rpx; box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;">
					<view style="display: flex; align-items: center;">
						<view style="flex: 6%;">
							<CustomLogo :logo="item.logo" :name="item.goods.name"></CustomLogo>
						</view>
						<view style="flex: 94%;">
							<view style="padding-left: 10px; font-size: 36rpx; font-weight: 700;"
								:style="{color:$theme.SECOND}">
								{{ item.goods.ct_name }}
							</view>
							<view style="display: flex; align-items: center;">
								<text style="font-size: 28rpx; padding-left: 10px; flex: 70%;"
									:style="{color:$theme.LOG_LABEL}">
									{{ item.goods.code }}
								</text>
							</view>
						</view>
						<view :style="setStyle()" @click="openPopup(item)"
							style="padding: 4rpx 6rpx; border-radius: 12rpx;">
							{{$lang.BTN_BUY}}
						</view>
					</view>
					
					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;padding:5px 10px;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFXCVXGDSD}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFXFDGG}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{ item.day }}
							</view>
						</view>
					</view>
					
					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;padding: 0px 10px;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFXFDGRG}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
								{{item.min_num}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view >
								{{$lang.API_UFDFHVXRG}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{ item.max_num }}
							</view>
						</view>
					</view>
					
					
					
					
					
					
				</view>
			</block>
		</view>

		<!-- u-popup 弹出框 -->
		<u-popup :show="show" @close="close" :round="10" mode="bottom">
			<view>
				<view class="text-center padding-10 bold"
					style="background-color: #ff8501; border-radius: 10px 10px 0px 0px; color: #fff;">
					{{ itemInfo.goods ? itemInfo.goods.ct_name : '' }}
				</view>
				<view class="flex flex-b" style="padding: 10px 40px;">
					<view>{{$lang.API_UFBDFBVXRG}}</view>
					<view>{{ itemInfo.price || 0 }}</view>
				</view>
				<view style="padding: 0px 30px;">
					<input v-model="quantity" placeholder="请输入数量" type="number"
						style="background-color: #f4f4f4; padding: 10px; border-radius: 10px; font-size: 12px;" />
				</view>
				<view class="flex flex-b" style="padding: 10px 30px;">
					<view>{{$lang.API_UFXCBRHG}}</view>
					<view>{{ totalPrice }}</view>
				</view>
				<!-- <view class="flex-1 text-right" style="padding: 0px 30px;">可用资金：5000052.51</view> -->
				<view style="padding: 30px 20px;">
					<view class="text-center padding-10"
						style="background-color: #ff8501; border-radius: 10px; color: #fff;" @click="submit">
						{{$lang.API_UWETVXRG}}
					</view>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import HeaderSecond from "@/components/header/HeaderSecond.vue";
	import CustomLogo from "@/components/CustomLogo.vue";

	export default {
		components: {
			HeaderSecond,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				show: false, // 控制弹出框显示
				list: [], // 列表数据
				itemInfo: {}, // 弹出框中显示的单条数据详情
				quantity: '', // 用户输入的购买数量
				
			};
		},
		computed: {
			// 计算总购买金额
			totalPrice() {
				return (this.itemInfo.price || 0) * this.quantity;
			},
		},
		async mounted() {
			this.fetchList();
			this.isAnimat = true;
		},
		methods: {
			// 打开弹出框并加载数据
			openPopup(item) {
				this.itemInfo = item;
				this.show = true;
			},
			close() {
				this.show = false;
			},
			jilv(){
				uni.navigateTo({
					url:"/pages/trade/vip/viplog"
				})
			},
			// 样式设置
			setStyle() {
				return {
					backgroundColor: "#ff8501",
					color: "#fff",
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `10rpx 20rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				};
			},
			// 获取接口数据
			async fetchList() {
				try {
					let response = await this.$http.post("api/goods/goodsvipscramble", {});
					this.list = response; // 存储接口返回的数据
				} catch (error) {
					console.error("Failed to fetch data:", error);
				}
			},
			// 提交操作
			async submit(id) {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				
				const result = await this.$http.post(`api/Product/buy_scramble`, {
					id: this.itemInfo.id,
					num: this.quantity,
				});
				uni.showToast({
					title: result.message,
					icon:"none"
					});
				
				this.close(); // 关闭弹出框
				setTimeout(function(){
					uni.navigateTo({
						url:"/pages/trade/vip/viplog"
					})
				},2000)
			},
		},
	};
</script>