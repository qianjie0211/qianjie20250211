<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;padding-bottom: 10px;margin:0 40rpx;" @click="personal()">
			<view style="text-align: center;margin-right: 10px;">
					
				<u-avatar :src="info.avatar" default-url='/static/logo.jpg' size="60"></u-avatar>
					
			</view>
			<view style="flex:60%;" v-if="info" >
				<view class="flex" v-if="info.real_name">
					<view style="font-size: 30rpx;text-align: left;color:#fff;">
						{{info.real_name}}
					</view>
					<image src="/static/baijiantou.png" mode="widthFix" style="width: 5px;margin-left: 15px;"></image>
				</view>
				
				<view style="font-size:26rpx;text-align: left;color:#adb1bd;">
					{{info.mobile}}
					<!-- {{info.p_mobile}} -->
				</view>
				<view class="flex">
					<view style="font-size:26rpx;text-align: left;color:#484c62;">
					  UID:{{info.uid}}
					</view>
					<view style="font-size: 12px;color: #15a4a5;margin-left: 10px;">{{$lang.FUZHI}}</view>
				</view>
				
			</view>
			<!-- <view @click="linkLevel()">
				<image :src="`/static/level${info.level}.png`" mode="aspectFit" style="width: 200rpx;height: 60rpx;">
				</image>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入等级页面
			linkLevel() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_LEVEL,
				})
			},
			personal() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_GERENXINXI,
				})
			},
		}
	}
</script>

<style>

</style>