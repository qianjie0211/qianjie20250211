export const ysc = `/static/base64/1.png`; 


export const sc = `/static/base64/2.png`;


export const laba = `/static/base64/3.png`;

export const chilun =`/static/base64/4.png`;


export const sousuo = `/static/base64/5.png`;


export const up =`/static/base64/6.png`;

export const down =`/static/base64/7.png`;


export const yanjing =`/static/base64/8.png`;

export const biyan =`/static/base64/9.png`;



export const zjt =`/static/base64/10.png`;


export const yjt =`/static/base64/11.png`;


export const yjt1 =`/static/base64/12.png`;


export const cha =`/static/base64/13.png`;

export const avatar =`/static/base64/14.png`;


export const dazong =`/static/base64/15.png`;



export const ipo =`/static/base64/16.png`;




export const ipo1 =`/static/base64/17.png`;



export const ipo2 =`/static/base64/18.png`;


export const panqian =`/static/base64/19.png`;



export const hangqing =`/static/base64/20.png`;

export const  opts={
	timing: "easeOut",
	duration: 1000,
	rotate: false,
	rotateLock: false,
	color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4", "#ea7ccc"],
	padding: [5, 5, 5, 5],
	fontSize: 13,
	fontColor: "#666666",
	dataLabel: false,
	dataPointShape: true,
	dataPointShapeType: "solid",
	touchMoveLimit: 60,
	enableScroll: false,
	enableMarkLine: false,
	legend: {
		show: false,
		position: "bottom",
		float: "center",
		padding: 5,
		margin: 5,
		backgroundColor: "rgba(0,0,0,0)",
		borderColor: "rgba(0,0,0,0)",
		borderWidth: 0,
		fontSize: 13,
		fontColor: "#666666",
		lineHeight: 11,
		hiddenColor: "#CECECE",
		itemGap: 10
	},
	extra: {
		pie: {
			activeOpacity: 0.5,
			activeRadius: 10,
			offsetAngle: 0,
			labelWidth: 15,
			border: true,
			borderWidth: 3,
			borderColor: "#FFFFFF",
			customRadius: 0,
			linearType: "none"
		},
		tooltip: {
			showBox: true,
			showArrow: true,
			showCategory: false,
			borderWidth: 0,
			borderRadius: 0,
			borderColor: "#000000",
			borderOpacity: 0.7,
			bgColor: "#000000",
			bgOpacity: 0.7,
			gridType: "solid",
			dashLength: 4,
			gridColor: "#CCCCCC",
			boxPadding: 3,
			fontSize: 13,
			lineHeight: 20,
			fontColor: "#FFFFFF",
			legendShow: true,
			legendShape: "auto",
			splitLine: true,
			horizentalLine: false,
			xAxisLabel: false,
			yAxisLabel: false,
			labelBgColor: "#FFFFFF",
			labelBgOpacity: 0.7,
			labelFontColor: "#666666"
		}
	}

}