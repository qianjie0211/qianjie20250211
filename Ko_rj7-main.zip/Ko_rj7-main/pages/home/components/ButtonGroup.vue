<template>
	<view class="btns " style="">
		<block v-for="(item,index) in btnConfig" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(70)"></image>
				<text style="padding-top: 6px;font-size: 12px;color: #666666;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		computed: {
			btnConfig() {
				// 根据客户需求，调整位置，注释不需要要显示的项
				const temp = [
					
					{
						name: '주식주문', // 新股配售
						url: this.$paths.MARKET_INDEX +`?type=0`,
					},
					{
						name: 'AI거래', // 日内交易
						url: '/pages/aiBank/aiBank',
					},
					{
						name: this.$lang.TRADE_LARGE_TITLE, // 大宗交易
						url: this.$paths.TRADE_LARGE,
					},
					{
						name: 'IPO', // IPO
						url: this.$paths.TRADE_IPO,
					},
					{
						name: '세계증시', // 新闻
						url: this.$paths.MARKET_INDEX +`?type=3`,
					},
					{
						name: this.$lang.AUTH_TITLE, // 实名认证
						url: this.$paths.ACCOUNT_AUTH,
					}, 
					
					{
						name: this.$lang.DEPOSIT_TITLE, // 入金/充值
						url: '/pages/service',
					}, 
					// {
					// 	name: '출금', // 
					// 	url: '/pages/account/withdraw',
					// },
					{
						name: '기관배정', // 新股配售
						url: this.$paths.TRADE_ISSUANCE,
					},
					
					
					
					// {
					// 	name: this.$lang.ACCOUNT_SERVICE, // 客服
					// 	url: this.$paths.SERVICE,
					// },
				].map((item, index) => {
					return {
						name: item.name,
						icon: `top${index}`,
						url: item.url
					}
				});
				return temp;
			}
		},

		methods: {
			actionEvent(url, index) {
				if(url=="/pages/service"){
					// uni.navigateTo({
					// 	url: "/pages/service"
					// });
					// return 
					this.$util.linkCustomerService();
				}
				if (url.includes('pages')) {
					uni.reLaunch({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
			
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px 0;

		.item {
			width: 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #CBCBCF;
			padding: 4px 0;
		}
	}
</style>