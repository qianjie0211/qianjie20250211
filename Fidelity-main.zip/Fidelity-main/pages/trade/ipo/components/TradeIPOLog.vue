<template>
	<view>
		<template v-if="!list || list.length<=0">
			<view class="" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view :class="index==list.length-1?'':'line' "
					style="margin: 10rpx; word-wrap:break-word;padding: 10px;border: 1px #00aa98 solid;border-radius: 10px;margin-top: 10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}" >{{item.goods.name}}</view>
						<view><text
								style="color:#fff;padding:2px 4px;border: 1px #00aa98 solid;border-radius: 5px;">{{item.message}}</text>
						</view>
					</view>
					<view style="font-size: 30rpx;color: #ccc;">{{item.goods.code}} </view>


					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view style="color: #ccc;">{{$lang.TRADE_IPO_LOG_LABELS[0]}}</view>
						<view style="color: #fff;">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view style="color: #ccc;">{{$lang.SHENGOU_SHULIANG}}</view>
						<view style="color: #fff;">{{$util.formatNumber(item.apply_amount)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view style="color: #ccc;">{{$lang.ZHONGQAIN_SHULIANG}}</view>
						<view style="color: #fff;">{{$util.formatNumber(item.success)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view style="color: #ccc;">{{$lang.SHENGOU_RIQI}}</view>
						<view style="color: #fff;">{{item.goods.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view style="color: #ccc;">{{$lang.DINGDAN_HAO}}</view>
						<view style="color: #fff;">{{item.order_sn}}</view>
					</view>
					
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPOLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/goods-shengou/user-order-log`);
				if (!result) return false;
				this.list = result;
			},
		},
	}
</script>