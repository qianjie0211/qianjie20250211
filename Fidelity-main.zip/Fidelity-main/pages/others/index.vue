<template>
	<view :class="isAnimat?'fade_in':'fade_out' " style="min-height: 100vh;">
		<header class="common_header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center">
				<image src="/static/coin_choose.png" mode="aspectFit" style="padding-left: 20rpx;"
					:style="$theme.setImageSize(24)" @tap="chooseCoin()"></image>
				<template v-if="info">
					<text style="padding:0 30rpx;" :style="{color:$theme.SECOND}">{{info.name}}</text>
				</template>
			</view>
			<view class="right">
				<view @tap="showDesc()">
					<image src="/static/contract_desc.png" mode="aspectFit" style="padding-right: 30rpx;"
						:style="$theme.setImageSize(32)">
					</image>
				</view>
			</view>
			<view class="right">
				<view @click="handleUnFollow(info.gid)">
					<image :src="`/static/${info && info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
						:style="$theme.setImageSize(32)"></image>
				</view>
			</view>
		</header>
		<template v-if="info">
			<view style="margin:20rpx 60rpx;display: flex;align-items: center;justify-content: space-between;">
				<text style="font-size: 32rpx;"
					:style="$theme.setStockRiseFall(info.rate>0)">{{$util.formatNumber(info.current_price)}}</text>
				<text style="font-size: 24rpx;padding:0 40rpx;"
					:style="$theme.setStockRiseFall(info.rate>0)">{{info.rate}}%</text>
			</view>
		</template>

		<!-- display: flex;align-items: center;justify-content: space-between; -->
		<view style="padding:0 20rpx 20rpx 0;">
			<!-- <view style="flex:0 1 50%;"> -->
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<block v-for="(item,index) in actionTabs" :key="index">
					<view :style="setStyle(curAction ==index)" @click="changeAction(index)">
						{{item}}
					</view>
				</block>
			</view>
			<view style="padding:20rpx;">
				<u-radio-group v-model=" radiovalue1" placement="row" @change="groupChange">
					<u-radio :customStyle="{marginRight: '48rpx'}" v-for="(item, index) in radioList" :key="index"
						:label="item.name" :name="item.name" @change="radioChange"
						:activeColor="curAction==0?$theme.RISE:$theme.FALL" labelSize="28rpx"
						:labelColor="item.name==radiovalue1?curAction==0?$theme.RISE:$theme.FALL:'#CFCFCF' ">
					</u-radio>
				</u-radio-group>
			</view>

			<!-- 限价模式，输入金额 -->
			<template v-if="isShowAmountInput">
				<view style="margin:20rpx;  display: flex;align-items: center;">
					<view style="flex:0 0 40%;color:#999999;">
						{{this.radiovalue1+` `+$lang.OTHERS_INDEX_PRICE}}
					</view>
					<view style="flex:0 0 60%;">
						<view style="background-color: #25262A;border-radius: 16rpx;padding:12rpx 24rpx;">
							<input v-model="amount" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_PRICE"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</view>
				</view>
			</template>
			<template v-else>
				<view style="margin:20rpx;  display: flex;align-items: center;">
					<view style="flex:0 0 40%;color:#999999;">
						{{this.radiovalue1+` `+$lang.OTHERS_INDEX_PRICE}}
					</view>
					<view style="flex:0 0 60%;">
						<view style="background-color: #25262A;border-radius: 16rpx;padding:12rpx 24rpx;"
							:style="{color:$theme.LOG_LABEL}">
							{{!info?'': info.current_price}}
						</view>
					</view>
				</view>
			</template>
			<view style="margin:20rpx;  display: flex;align-items: center;">
				<view style="flex:0 0 40%;color:#999999;">
					{{$lang.OTHERS_INDEX_LEVER}}
				</view>
				<view style="flex:0 0 60%;">
					<view @tap="handleChooseLever()"
						style="background-color:#25262A;border-radius: 16rpx;display: flex;align-items: center;padding:12rpx 24rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{curLever+` X`}}</view>
						<image src="/static/arrow_down_solid.png" mode="aspectFit"
							style="margin-left: auto;padding-right: 40rpx;" :style="$theme.setImageSize(16)">
						</image>
					</view>
				</view>
			</view>
			<view style="margin:20rpx; display: flex;align-items: center;">
				<view style="flex:0 0 40%;color:#999999;">
					{{$lang.OTHERS_INDEX_QUANTITY}}
				</view>
				<view style="flex:0 0 60%;">
					<view style="background-color: #25262A;border-radius: 16rpx;padding:12rpx 24rpx;">
						<input v-model="quantity" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_QTY"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
				</view>
			</view>
			<template v-if="userInfo && info">
				<view style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.6;"
					:style="{color:$theme.LOG_LABEL}">
					{{$lang.COIN_BUY_BALANCE}}{{`: ${userInfo.money} USDT`}}
				</view>
			</template>
			<template v-if="info">
				<view style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.6;"
					:style="{color:$theme.LOG_LABEL}">
					{{$lang.COIN_BUY_MAX_QTY}}
					{{`: ${$util.formatNumber(curMaxQTY,4)} ${info.number_code.toUpperCase()}`}}
				</view>
			</template>

			<view style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.6;"
				:style="{color:$theme.LOG_LABEL}">
				{{$lang.COIN_BUY_TOTAL_AMOUNT}} {{`: ${totalAmount} USDT`}}
			</view>

			<view
				style="margin:28rpx auto;width: 80%;border-radius:50rpx;color:#FFFFFF;padding:8rpx 0;font-size: 28rpx;text-align: center;"
				:style="{backgroundColor:curAction==0?$theme.RISE:$theme.FALL}" @click="placeOrder()">
				{{actionTabs[curAction]}}
			</view>
			<!-- </view>
			<view style="flex:0 1 50%;">
				<template v-if="asks && asks.length>0">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_BUY_TITLE_PRICE}}
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_BUY_TITLE_QTY}}
						</view>
					</view>

					<AskList :list="asks" :max="asksMax"></AskList>
					<BidList :list="bids" :max="bidsMax" dir="right"></BidList>
				</template>
			</view> -->
		</view>

		<!-- 當前委托 持有倉位 历史记录 -->
		<ContractTabs :tabs="setTabs" @action="changeTab" :active="curTab1"></ContractTabs>

		<template v-if="curTab1==0">
			<CurrentRecord :code="code" ref="current"></CurrentRecord>
		</template>
		<template v-else-if="curTab1==1">
			<HoldRecord :list="holdList" @action="handleHoldList"></HoldRecord>
		</template>
		<template v-else>
			<HistoryRecord :code="code" ref="history"></HistoryRecord>
		</template>

		<!-- 顯示合約説明 -->
		<template v-if="isShowDesc">
			<ContractDesc @action="handleClose"></ContractDesc>
		</template>

		<!-- 杠桿選擇器 -->
		<u-picker :show="isShowLever" :columns="[leverList]" @change="changeLever" @cancel="isShowLever=false"
			@confirm="confirmLever" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"></u-picker>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import ContractTabs from './components/ContractTabs.vue';
	import CurrentRecord from './components/CurrentRecord.vue';
	import HistoryRecord from './components/HistoryRecord.vue';
	// import AskList from './components/AskList.vue';
	// import BidList from './components/BidList.vue';
	import HoldRecord from './components/HoldRecord.vue';
	import ContractDesc from './components/ContractDesc.vue';
	export default {
		components: {
			ContractTabs,
			CurrentRecord,
			HistoryRecord,
			HoldRecord,
			// AskList,
			// BidList,
			ContractDesc,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				code: '', // url ?code=
				gpIndex: '', // url type=
				curAction: 0, // buy or sell
				curTab1: 1,
				// asks: [],
				// bids: [],
				// asksMax: 0, // asks 當前最大數量
				// bidsMax: 0, // bids 當前最大數量
				socket: null,
				quantity: '', // 数量输入框 
				show: false,
				info: null,
				userInfo: null,
				radiovalue1: this.$lang.COIN_PRICE_TYPE_MARKET,
				amount: '', // 限价模式 输入金额

				isShowCoinList: false, // 是否顯示 coin選擇器
				coinList: null, // coin 選項組

				isShowLever: false, // 是否顯示杠桿選擇器
				curLever: 1, // 当前选中杠杆值
				leverList: null, // 杠桿選項組	

				holdList: [], // 持有列表
				isShowCurCoin: true, // 是否仅显示当前coin
				
				isShowDesc: false, // 是否顯示合約説明
			};
		},
		computed: {
			// header title
			setTitle() {
				if (this.info) {
					return this.info.name || '';
				}
			},
			actionTabs() {
				return [this.$lang.COIN_VIEW_BTN_BUY, this.$lang.COIN_VIEW_BTN_SELL]
			},
			setTabs() {
				return [this.$lang.CONTRACT_RECORD_CURRENT,
					this.$lang.CONTRACT_RECORD_HOLD,
					this.$lang.CONTRACT_RECORD_HISTORY
				]
			},
			// 单选项的选项组
			radioList() {
				return [{
					name: this.$lang.COIN_PRICE_TYPE_MARKET,
					disabled: false
				}, {
					name: this.$lang.COIN_PRICE_TYPE_LIMIT,
					disabled: false
				}];
			},
			// 当前交易模式
			isShowAmountInput() {
				return this.radiovalue1 == this.radioList[1].name;
			},
			// 當前最大可買或可買數量
			curMaxQTY() {
				// 市價模式： 餘額/單價。 限價模式：餘額/輸入值
				if (this.info && this.userInfo) {
					// 市價或限價模式下的單價
					const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
					// console.log(`curMaxQty:`, temp);
					return temp * 1 > 0 ? this.$util.formatNumber(this.userInfo.money * this.curLever / temp, 4) : '';
				}
			},
			// 计算总价
			totalAmount() {
				if (!this.info) return 0;
				// console.log(this.info.current_price);
				const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
				// 價格*數量/杠桿
				const temmTotal = temp * 1 * this.quantity * 1 / this.curLever;
				// console.log(`total amount:`, temmTotal);
				// const result = temmTotal.toString().split('.')[1]?.length || 0;
				// return result < 3 ? temmTotal : Number(temmTotal.toFixed(4));
				return this.$util.formatNumber(temmTotal, 4);
			},
		},
		onLoad(opt) {
			console.log(opt);
			this.code = opt.code || ''; // 默認 btcusdt
			this.gpIndex = opt.type || '';
			this.curAction = opt.tag || 0;
		},
		onShow() {
			this.isAnimat = true;
			if (this.socket) this.disconnect();
			this.getData();
			this.getAccountInfo();
			if (this.curTab1 == 0 && this.$refs.current) this.$refs.current.getList();
			if (this.curTab1 == 1) this.getHoldList();
			if (this.curTab1 == 2 && this.$refs.history) this.$refs.history.getList();
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			changeAction(val) {
				this.curAction = val;
				this.getAccountAssets();
				// if (this.socket) this.disconnect();
				// this.getData();
			},

			// 選擇杠桿 Lever
			handleChooseLever() {
				this.isShowLever = true;
			},
			changeLever(e) {
				console.log(`changeMode e:`, e);
			},
			confirmLever(e) {
				console.log(`confirmMode e:`, e);
				this.curLever = e.value[0];
				this.isShowLever = false;
			},
			// 合約交易説明
			showDesc() {
				this.isShowDesc = true;
				uni.hideTabBar(); // 隐藏tabBar
			},
			handleClose(val) {
				console.log('val:', val);
				this.isShowDesc = false;
				uni.showTabBar(); // 显示tabBar
			},
			// 選擇一種coin
			chooseCoin() {
				// 請求數據。
				this.getCoinList();
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.code = e.value[0].code;
				this.isShowCoinList = false;
				// 重置一些值
				this.quantity = '';
				this.curLever = 1;
				this.getData();
			},

			// 在切換coin時，需請求列表，製作coin選擇器數組
			async getCoinList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`, {
					gp_index: this.gpIndex,
				});
				if (!result) return false;
				console.log(result);
				this.coinList = Object.values(result).map(item => {
					return {
						label: item.name,
						code: item.code
					}
				});
				// 獲取數據之後，顯示選擇器
				this.isShowCoinList = true;
			},

			// 跳轉到 詳情頁面
			linkCoinInfo() {
				uni.navigateTo({
					url: this.$paths.COIN_DETAIL + `?code=${this.code}&type=${this.gpIndex}`
				});
			},
			// 设置样式
			setStyle(val) {
				const temp = this.curAction == 0 ? this.$theme.RISE : this.$theme.FALL;
				return {
					minWidth: `120rpx`,
					margin: '0 16rpx',
					padding: `8rpx 16rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? temp : '#25262A',
					color: val ? '#FFFFFF' : '#C9C9C9',
					borderRadius: `44rpx`,
					fontSize: `24rpx`,
				}
			},


			changeTab(val) {
				this.curTab1 = val;
				if (this.curTab1 == 1) this.getHoldList();
			},

			// linkRecord() {
			// 	uni.navigateTo({
			// 		url: this.$paths.CION_RECORD + `?code=${this.code}`
			// 	})
			// },
			groupChange(n) {
				console.log('groupChange', n);
				this.radiovalue1 = n;
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1 = n;
			},

			// 产品详情
			async getData() {
				if (this.socket) this.disconnect();
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/product/info`, {
					code: this.code,
				});
				if (!result) return false;
				console.log(`info:`, result);
				this.info = result[0];
				// if (this.info) this.getDepthList();
				this.getAccountAssets();
				this.connect();
				this.amount = this.info.current_price;
			},

			checkFrom() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.$u.toast(this.$lang.COIN_BUY_TIP_ENTER_QTY);
					return false;
				}
				if (!this.$util.checkInputNumber(this.quantity)) return false;

				if (this.isShowAmountInput) {
					if (this.amount == '' || this.amount <= 0) {
						uni.$u.toast(this.$lang.COIN_BUY_TIP_ENTER_PRICE);
						return false;
					}
				}
				return true;
			},

			// 買賣
			async placeOrder() {
				if (this.checkFrom()) {
					const result = await uni.showModal({
						title: '',
						content: `${this.info.name} Quantity ${this.quantity}`,
						cancelText: this.$lang.COIN_MODAL_CANCEL,
						confirmText: this.$lang.COIN_MODAL_COMFIRM,
						showCancel: true, // 是否显示取消按钮，默认为 true
						confirmColor: this.$theme.SECOND,
						cancelColor: this.$theme.MODAL_CANCEL,
					});
					if (result[1].confirm) {
						if (this.curAction == 0) {
							this.buy();
						} else if (this.curAction == 1) {
							this.sell();
						}
					}
				}
			},
			async buy() {
				let formData = {
					num: this.quantity,
					gid: this.info.gid,
					fx: this.isShowAmountInput ? 2 : 1, // 1市价 2限价
					direct: 1, // direct   1买多    2卖少
					ganggan: this.curLever, // 杠桿
				}
				if (this.isShowAmountInput) {
					formData.price = this.amount;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/purchase`, formData);
				if (!result) return false;
				console.log(`buy result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				// 刷新当前激活的列表
				if (this.curTab1 == 0 && this.$refs.current) {
					this.$refs.current.getList();
				}
				if (this.curTab1 == 1) {
					this.getHoldList();
				}
				if (this.curTab1 == 2 && this.$refs.history) {
					this.$refs.history.getList();
				}
			},

			async sell() {
				let formData = {
					num: this.quantity,
					gid: this.info.gid,
					fx: this.isShowAmountInput ? 2 : 1, // 1市价 2限价
					direct: 2, // direct   1买多    2卖少
					ganggan: this.curLever, // 杠桿
				}
				if (this.isShowAmountInput) {
					formData.price = this.amount;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/purchase`, formData);
				if (!result) return false;
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				// 刷新当前激活的列表
				if (this.curTab1 == 0 && this.$refs.current) {
					this.$refs.current.getList();
				}
				if (this.curTab1 == 1) {
					this.getHoldList();
				}
				if (this.curTab1 == 2 && this.$refs.history) {
					this.$refs.history.getList();
				}
			},

			// 获取账户 資產 信息 (每次切換買賣時，都調用一次該函數)
			async getAccountAssets() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 2, // 資產賬戶
					name: 'USDT',
				});
				if (!result) return false;
				console.log(`assets:`, result);
				this.userInfo = result;
			},

			// async getDepthList() {
			// 	const response = await uni.request({
			// 		url: `https://api.huobi.pro/market/depth`,
			// 		method: 'GET',
			// 		data: {
			// 			symbol: this.code,
			// 			depth: 5,
			// 			type: 'step0'
			// 		},
			// 	});
			// 	const [err, res] = response;
			// 	console.log('err:', err, 'res:', res);
			// 	if (res && res.data.status == 'ok') {
			// 		const temp = res.data;
			// 		this.asks = res.data.tick.asks;
			// 		this.bids = res.data.tick.bids;
			// 		// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
			// 		this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
			// 		// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
			// 		this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
			// 	}
			// 	console.log('asks:', this.asks);
			// 	console.log('bids:', this.bids);
			// },
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.info.pid == data.pid && data.last > 0) {
							// console.log(`pid:`, this.info, data);
							this.info.current_price = data.last;
							this.info.rate = data.pcp || 0;
							this.info.rate_num = data.pc || 0;
							this.info.high = data.high || 0;
							this.info.low = data.low || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},

			// 子组件改变checkbox的状态
			handleHoldList(val) {
				console.log(`val:`, val);
				this.isShowCurCoin = val;
				this.getHoldList();
			},
			async getHoldList() {
				let formData = {
					status: 1, // 1持仓，2历史
				}
				if (this.isShowCurCoin) {
					formData.code = this.code;
				}
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/order`, formData);
				if (!result) return false;
				console.log(`hold result:`, result);
				const temp = !Array.isArray(result) || result.length < 0 ? [] :
					result.filter(item => item.goods_info && item.goods_info.gid > 0 && item.order_buy && item
						.order_buy.gid > 0);
				this.holdList = temp.length <= 0 ? [] : temp.map(item => {
					return {
						id: item.id,
						code: item.goods_info.code,
						name: item.goods_info.name,
						// fx   1市价 2限价
						fx: item.order_buy.fx,
						fxText: item.order_buy.fx == 1 ? this.$lang.COIN_PRICE_TYPE_MARKET : this.$lang
							.COIN_PRICE_TYPE_LIMIT,
						direct: item.order_buy.direct,
						// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
						directText: item.order_buy.direct == 1 ? this.$lang.CONTRACT_DETAIL_BTN_BUY : this
							.$lang
							.CONTRACT_DETAIL_BTN_SELL,
						price: item.order_buy.price,
						quantity: item.order_buy.num,
						total: item.order_buy.user_pay,
						sn: item.order_sn,
						ct: item.order_buy.updated_at,
						lever: item.order_buy.double,
						profit: item.order_buy.zhiying || '--',
						loss: item.order_buy.zhisun || '--',
						curPrice: item.goods_info.current_price, // 最新价
						fee: item.order_buy.buy_fee,
						profitLossBuy: item.order_buy.yingkui, // 1买多 盈亏
						profitLossSell: item.order_buy.yingkui, // 2 卖少 盈亏
						floatPLBuy: item.order_buy.float_yingkui, // 1买多 浮动盈亏
						floatPLSell: item.order_buy.float_yingkui, // 2 卖少 浮动盈亏
					}
				});
				console.log(this.holdList)
			},
		},
	}
</script>

<style lang="scss" scoped>
	//  u-picker 样式覆盖
	/deep/.u-popup__content {
		background-color: #151517 !important;

		.uni-picker-view-mask {
			background: none !important;
		}

		.u-picker__view__column__item {
			color: #C9C9C9 !important;
		}
	}

	.common_header {
		padding: 56rpx 36rpx 20rpx 36rpx;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #3B3B3D;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>