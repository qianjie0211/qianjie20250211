<template>
	<view style="background: #0f1316;">
		<!-- <image src="/static/home_banner.png" mode="widthFix" style="width: 100%;"></image> -->
		<view class="">
			<HeaderPrimary :title="$lang.TABBAR_HOME" isSearch></HeaderPrimary>
		</view>

		<view class="home_header_bg" style="border-radius: 12rpx;margin:10px 24rpx;"></view>

		<view style="margin-top: -50px;padding:20px;">
			<view class="flex" style="background-color: #34393e;border-radius: 10px;">
				<block v-for="(item,index) in listinfo" :key="index" v-if="index==0||index==15||index==7">
					<view class="" style="padding: 15px;border-radius: 10px;">
						<view class="font-size-15 color-white">{{item.name}}</view>
						<view style="color: #02B975;" :style="$util.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
						<view style="color: #02B975;font-size: 18px;" :style="$util.setStockRiseFall(item.rate>0)">
							{{item.current_price}}
						</view>
					</view>
				</block>
			</view>

		</view>

		
		<view class="flex" style=" justify-content: space-between;padding: 10px;">
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradejiaoyi()">
				<image src="/static/top3.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.GUPIAO}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradegendan()">
				<image src="/static/top2.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.WAIHUI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTrabibi()">
				<image src="/static/top9.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.BIBI_JIAOYI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradaikuan()">
				<image src="/static/top10.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.DAIKUAN}}</view>
			</view> -->

		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;">
			<view style="flex:0 0 25%;" @tap="linkrinei()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top1.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.RINEI_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeipo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top2.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.IPO}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekeieo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top3.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.LIANGHUA_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeotc()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top5.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.DAZONG_JIAOYI}}</view>
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;margin-top: 0;">
			<view style="flex:0 0 25%;" @tap="linkqianggou()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top6.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.QIANGGOU}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top4.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.AUTH_TITLE}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkMarket()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top7.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.MARKET_STOCK_EU}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekefu()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/top8.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					<view class="zi">{{$lang.KEFU}}
					</view>
				</view>
			</view>
		</view>
		
		<view class="padding-10">
			<view style="background-image: url(/static/tongzhi_bg.png);background-position: center;background-repeat: no-repeat;" class="flex padding-10 gap10">
				<view style="width: 10px;background: #10DF95;height: 10px;border-radius: 50%;"></view>
				<view class="color-white" style="display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp:1;overflow: hidden;text-overflow: ellipsis;white-space: normal;">Annuncio: Si prega di verificare il vostro vero nome</view>
			</view>
			
		</view>
		
		<view class="flex text-center justify-center"  style="padding:  20px;">
			<view style="background-color: #424445;border-radius: 20px;" class="flex ">
				<view style="color: #fff;border-radius: 20px;padding:5px 20px;"
					@click="inv=0;getList()" :style="inv==0?'background-color: #10df95;':''">{{$lang.MARKET_STOCK_EU}}</view>
				<view style="color: #fff;border-radius: 20px;padding: 5px;margin-left: 10px;padding:5px 20px;"
					@click="inv=1;getList()" :style="inv==1?'background-color: #10df95;':''">{{$lang.MARKET_STOCK_US}}</view>
			</view>
		</view>
		<view style="background-color: #0e1215;margin: 10px;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(255, 255, 255, 0.25) 0px 0px 0px 1px;padding: 5px;background-color: #1a1e2a;">
			<view>
				<view>
					<scroll-view class="scroll-view_H " scroll-x="false" @scroll="scroll()">
						<view class="flex" style="color: #00AA98;justify-content: space-between;padding: 10px;">
							<view class="flex-2">{{$lang.MINGCHEN}}</view>
							<view class="text-center flex-2">{{$lang.ZUIXIN_JIA}}</view>
							<view class="flex-1" style="text-align: right;">{{$lang.ZAHNGDIE_FU}}</view>
						</view>
						<view>
							<template v-if="listinfo && listinfo.length<=0">
								<view style="padding: 40rpx;text-align: center;">
									<image src="/static/empty_data.png" mode="aspectFit" :style="$theme.setImageSize(400)">
									</image>
									<view style="font-size: 32rpx;color:#CBCBCF">{{$lang.EMPTY_DATA}}</view>
								</view>
							</template>
							<template v-else>
								<view v-for="(item,key,index) in listinfo" :key="key" :class="index%2!=0?'bg':''">
									<view class="flex"
										style="justify-content: space-between;padding: 10px;"
										@tap="linkDetail(item)">
										<view class="flex-2" style="color: #fff;">
											<view>{{item.name}}</view>
											<view style="color: #566872;">{{item.number_code}}</view>
										</view>
										<view class="text-center flex-2" style="color: #fff;">
											<view>{{item.current_price}}</view>
											<view style="color: #566872;">{{item.rate_num}}</view>
										</view>
										<view class="flex-1" style="color: #fff;">
											<view :style="$util.setStockRiseFall(item.rate>0)" style="text-align: right;">
												{{item.rate}}%
											</view>
										</view>
			
									</view>
								</view>
							</template>
						</view>
					</scroll-view>
				</view>
			</view>
		</view>
		

		<view class="flex" style="padding:0px 10px;margin-top: 20px;">
			<view style="background-color: #fff;width: 3px; height: 15px;color: #fff;"></view>
			<view style="margin-left: 5px;font-size: 16px;color: #fff;">{{$lang.XINWEN}}</view>
			<view style="margin-left: 20px;">
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;margin-top: 5px;"></image>
			</view>
		</view>
		
		<u-modal :show="show" :confirmText="$lang.BTN_CONFIRM" @confirm="queren" :cancelText="$lang.BTN_CANCEL" :showCancelButton='true' @cancel="show=false" @close="show=false">
			<u--input
				:placeholder="$lang.MIMA"
				border="surround"
				v-model="password"
				
			  ></u--input>
		</u-modal>
		
		
		<view style="padding:0rpx 5rpx;">
			<view>
				<scroll-view class=" " scroll-x="false" @scroll="scroll()" @click="home()">
					<view>
						<block v-for="(item, index) in levelinfo" :key="index">
							<view @click="open(item.url)"
								style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;padding: 10px;border-bottom: 1px #ccc solid;">
								<template v-if="curTab==0">
									<view style="flex:60%;padding-right: 30px;padding-top: 10px;color: #fff;">
										<view>{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;color: #fff;"><text
												style="padding: 4px 0;">{{item.updated_at}}</text>
										</view>
									</view>
									<image :src="item.pic" :style="$theme.setImageSize(220,150)" mode="scaleToFill"
										style="border-radius: 10px;"></image>
								</template>
								<template v-else>
									<view style="flex:100%">
										<view style="color: #fff;">{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;text-align: right;color: #fff;">
											{{item.updated_at}}
										</view>
									</view>
								</template>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import index from 'uview-ui';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'MarketNews',
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			TabsFifth,
			CustomTitle,
			EmptyData,

		},
		data() {
			return {
				show:false,
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				info: {}, // 基本信息
				scrollTop: 0,
				selectedContent: 0,
				message: [],
				listinfo: [],
				listinfo2: [],
				list: [],
				curTab: 0,
				levelinfo: [],
				AccountInfo: [],
				old: {
					scrollTop: 0
				},
				inv:0,
				password:''
			}
		},

		onShow() {
			this.getLevelInfo();
			this.getList()
			// this.getList2()
			// this.getAccountInfo();

		},
		onLoad() {},

		onHide() {
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},

		methods: {
			async queren(){
				
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				let vip_pass = temp.get('vip_pass') || "VIP123000";
				if(vip_pass!=this.password){
					uni.showToast({
						icon: "none",
						title: "La password non è corretta."
					})
				}else{
					uni.navigateTo({
						url: '/pages/daytrading/vip/index'
					})
				}
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
				
			},
			open(url) {
				window.open(url)
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw',
				})
			},


			// 跳转到交易的股票分栏
			linkTradejiaoyi() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=0`,

				})
			},
			linkAuth() {
				uni.navigateTo({
					url: `/pages/Introduction/auth`
				})
			},
			linkTradegendan() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=1`,

				})
			},
			linkTragensui() {
				uni.navigateTo({
					url: '/pages/trade/copy/index',

				})
			},

			linkTradekeieo() {
				uni.navigateTo({
					url: '/pages/trade/wealth/index'
				})
			},
			linkrinei() {
				uni.navigateTo({
					url: '/pages/daytrading/day/index'
				})
			},
			linkTradaikuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},
			linkTradekefu() {
				// uni.navigateTo({
				// 	url: '/pages/service'
				// })
				this.$util.linkCustomerService()
			},
			// linkTradeheyue() {
			// 	uni.navigateTo({
			// 		url: '/pages/transfer/index'
			// 	})
			// },
			linkTradeipo() {
				uni.navigateTo({
					url: '/pages/trade/ipo/index'
				})
			},
			linkTradeotc() {
				uni.navigateTo({
					url: '/pages/trade/large/index'
				})
			},


			licai() {
				uni.switchTab({
					url: "/pages/trade/wealth/index"
				})
			},
			tongzhi() {
				uni.navigateTo({
					url: "/pages/tongzhi"
				})
			},
			linkqianggou() {
				this.show=true
				
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			// 跳转到市场
			linkMarket() {
				uni.switchTab({
					url: this.$paths.MARKET,
				})
			},

			home() {
				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},

			closeAll() {
				if (this.$refs.goods) this.$refs.goods.disconnect();
			},
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				// uni.showToast({
				// 	icon: "none",
				// 	title: "纵向滚动 scrollTop 值已被修改为 0"
				// })
			},
			// 
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?gid=${val.gid}`
				})
			},

			// async getList() {
			// 	const result = await this.$http.post(`api/goods/zhishu`, {});
			// 	console.log(result);
			// 	if (!result) return false;
			// 	this.listinfo = result;
			// 	console.log(this.listinfo);
			// 	this.connect1()
			// },
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				let tempData = {};
				tempData.gp_index =this.inv==0?'6':'7';;
				tempData.limit=10
				console.log(this.keyword);
				const result = await this.$http.post(`api/goods/list`, tempData);
				console.log(result);
				if (!result) return false;
				this.listinfo = result;
				console.log(7777,this.listinfo);
				// 启动 websocket链接
				if (Object.values(this.listinfo).length > 0)
					this.connect();
			},

			async getList2() {
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: 8
				});
				console.log(result);
				if (!result) return false;
				this.listinfo2 = result;
				console.log(this.listinfo2);
			},


			// websocket链接
			connect() {
				let tempURL = '';
				if (this.curKey == 'coin') {
					tempURL = this.$http.WS_COIN_URL;
				} else {
					tempURL = this.$http.WS_Zonghe_URL;
				}
				console.log('tempURL', tempURL);
				//创建webSocket
				this.socket = uni.connectSocket({
					url: tempURL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('success', res);
					},
					fail: (res) => {
						console.log('fail', res);
					},
					complete: (res) => {
						console.log('complete', res);
					}
				})
				console.log('ws', this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});
			
					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(data);
						// console.log(this.curKey);
			
						if ((this.curKey === 'us' || this.curKey === 'eu' || this.curKey === 'forex') &&
							this.listinfo[data.pid] && this.listinfo[data.pid].pid == data.pid && data.last > 0) {
							// console.log(this.curKey);
							// console.log(`pid:`, this.list[data.pid].pid);
							this.listinfo[data.pid].current_price = data.last;
							this.listinfo[data.pid].rate = data.pcp || 0;
						}
					});
				}
			},
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			
			async getLevelInfo() {
				const result = await this.$http.get(`api/article/list`, {
					type: 11
				});
				if (!result) return false;
				this.levelinfo = result;
			},
		},

	}
</script>

<style>
	.bg{
		background-color: #0e1215;
		border-radius: 10px;
	}
	.scroll-Y {
		height: 300rpx;
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.scroll-view-item_H {
		display: inline-block;
		border-radius: 10px;
		width: 80%;
		/* height: 300rpx; */
		/* line-height: 60rpx; */
		/* text-align: center; */
		font-size: 36rpx;
	}
	.zi{
		color: #fff;margin-top: 5px;text-align: center;
		font-size: 12px;
		font-weight: 100;
	}
</style>