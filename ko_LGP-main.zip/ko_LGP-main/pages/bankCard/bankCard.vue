<!-- 绑定银行卡 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<CustomHeader title="개인 계좌 연동" @action="handleBack()"></CustomHeader>

		<view style="padding:10px 30rpx;margin:0 20rpx;background-color: #fff;border-radius: 10px;">
			<view style="padding: 10px;">
			<view class="bank-name">
				<view class="">성명:</view> <text> {{cardManagement.realname}}</text>
			</view>
			<view class="bank-name">
				<view class="">은행명: </view><text> {{cardManagement.bank_name}}</text>
			</view>
			<view class="bank-name">
				<view class="">계좌번호: </view> <text> {{cardManagement.card_sn}}</text>
			</view>
			

			<view @tap='handleChangeCard()' style="background-color:#190dbf;
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;">
				확인
			</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				cardManagement: {},
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			handleChangeCard() {
				uni.navigateTo({
					url: '/pages/changeCard/changeCard'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.cardManagement = list.data.data.bank_card_info
			},
		},

	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		background-color: #EFF1F8;
		display: flex;
		font-size: 28rpx;
		margin-top: 10px;
		border: 2rpx solid #f4f4f4;
		border-radius: 10px;

		view {
			width: 30%;
		}

		text {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>