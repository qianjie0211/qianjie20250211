<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="background-color:#FFFFFF;">
			<HeaderSecond :title="$lang.NOTIFY_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;padding:34rpx 40rpx;line-height: 1.8;"
					@tap="linkDetail(item.id)">
					<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{item.biaoti}}
					</view>
					<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
						{{$util.formatDate(item.created_at)}}
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: []
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.$util.checkToken();
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.NOTIFY_DETAIL + `?id=${val}`
				})
			},
			async getList() {
				const result = await this.$http.post(`api/app/gglist`, {
					locale: this.$LANGCODE,
				});
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result.length > 0 ? result : [];
			}
		}
	}
</script>

<style>
</style>