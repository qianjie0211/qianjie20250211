<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond style="background-color: #F8C351;" :title="$lang.TRADE_LARGE_TITLE" :color="$theme.SECOND"></HeaderSecond>
		

	<!-- 	<TabsPrimary :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary> -->
	
	<view
		style=" display:flex; text-align: center; justify-content: space-between; margin: 20px  10px 10px  10px;  padding: 0 14px;">
		<view style="flex:1;" @click="changeTab(0)">
			<view>
				<image src="/static/trad_day_buy_1.svg" :style="$theme.setImageSize(80)"></image>
			</view>
			<view :style="{color:curTab==0?`#121212`:$theme.RGBConvertToRGBA(`#0A2448`,50)}">
				{{$lang.TRADE_LARGE_TABS[0]}}</view>
		</view>
		<view style="flex:1;" @click="changeTab(1)">
			<view>
				<image src="/static/trad_day_buy_2.svg" :style="$theme.setImageSize(80)"></image>
			</view>
			<view :style="{color:curTab==1?`#121212`:$theme.RGBConvertToRGBA(`#0A2448`,50)}">
				{{$lang.TRADE_LARGE_TABS[1]}}</view>
		</view>
		
	
	</view>
	

		<template v-if="curTab==0">
			<TradeLargeList></TradeLargeList>
		</template>
		<template v-else>
			<TradeLargeRecord></TradeLargeRecord>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeLargeList from './components/TradeLargeList.vue';
	import TradeLargeRecord from './components/TradeLargeRecord.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeLargeList,
			TradeLargeRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

		},
	}
</script>