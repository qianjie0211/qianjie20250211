<template>
	<view style="margin-top: 90px;background-color: #fff;min-height: 100vh;">
		<view class="flex" style="border-bottom: 1px #ccc solid;padding: 10px 15px;">
			<view style="border-left: 3px solid #4e4cd2;height: 15px;"></view>
			<view style="color:#000; margin-left: 5px;">신청등록</view>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px #ccc solid; padding: 10px;">
					<view style="padding: 5px;">
						<view class="flex bold" style="border: 1px #ccc solid;padding: 10px;border-radius: 5px;">
							<view>{{item.goods.name}}</view>
							<view class="margin-left-5 flex-1">({{item.goods.code}})</view>
							<view :style="{color:transStatus2(item.status)}">{{transStatus(item.status)}}</view>
						</view>
					</view>
					<view class="flex" style="padding: 0px 10px;gap: 10px;">
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_RECORD_PRICE}}</view>
							<view>{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}</view>
						</view>
						<view class="flex flex-b" style="flex: 40%;">
							<view class="hui1">{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}</view>
							<view>{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}</view>
						</view>
					</view>

					<view class="flex padding-10">
						<view class="hui1 flex-1">거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
					<view class="flex" style="padding: 0px 10px;">
						<view class="hui1 flex-1">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPORecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			transStatus(status) {
				if (status == 0) {
					return '실패한'
				} else if (status == 1) {

					return '검토 대기 중'
				} else if (status == 2) {

					return '구독 예정'
				}

			},
			transStatus2(status) {
				if (status == 0) {

					return this.statusColor = '#fc4136'
				} else if (status == 1) {

					return this.statusColor = "#1ba035"
				} else if (status == 2) {

					return this.statusColor = "#4644d1"
				}

			},


			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-apply-log`);
				console.log(result);
				this.list = result || [];
			},
		},
	}
</script>