<!-- 新股申购 -->
<template>
	<view>
		<view
			style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
			<view style="width: 90%;justify-content: flex-end; display: flex; ">
				<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="home()">
				</image>
				<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">ブックビルディング</view>
			</view>
		</view>
		<view>
			<view class="" style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;">
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content:space-around;margin-top: -150px;">
			<view @click="handleChangeTab(0)"
				style="padding:2px 4px;background-color: #38aa9a;padding: 5px 40px;border-radius: 5px;color: #fff;">
				{{$util.BTNS_IPO[1]}}
			</view>
			<view @click="handleChangeTab(1)"
				style="padding:2px 4px;background-color: #38aa9a;padding: 5px 40px;border-radius: 5px;color: #FFF;">
				{{$util.BTNS_IPO[2]}}
			</view>
		</view>

		<!-- <view style="height: 450px;border-radius: 5px;width: 95%;margin: 10px;margin-top: 20px;">
			<EmptyData v-if="list.length<=0" style="color: #38aa9a;"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view class=" bg-white radius20 margin-10 padding-20">
						<view class="flex">
							<view class="flex-1">
								<view class="bold">{{item.goods.name}}</view>
								<view class="hui1 margin-top-5">{{item.goods.code}}</view>
							</view>
							
							<view class="color-white  radius10  text-center" style="background-color: #38aa9a;padding: 3px 30px;font-size: 14px;" @click="buy(item.id)">
								申込
							</view>
						</view>
						
						<view class="flex margin-top-5">
							<view class="flex-1">
								発行価格
							</view>
							<view class="font-size-14 ">
								{{$util.formatNumber(item.price)}}
							</view>
						</view>
						
						<view class="flex margin-top-5">
							<view class="flex-1">
								発行量
							</view>
							<view class="font-size-14 ">
									{{item.fa_amount}}
							</view>
						</view>
						
						<view class="flex margin-top-5">
							<view class="flex-1">
								購読日
							</view>
							<view class="font-size-14 ">
								{{item.shengou_date}}
							</view>
						</view>
						
						<view class="flex margin-top-5">
							<view class="flex-1">
								上場日
							</view>
							<view class="font-size-14 ">
								{{item.online_date}}
							</view>
						</view>
						
					</view>
					
					
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							
							<view class="subscription-times">購読時間<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">購読
								価格<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								株価収益率<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							循環<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>
		</view> -->
		<!-- <view>
				<u-modal :show="show" title="" @cancel="cancel" @confirm="position(buyid)" :showCancelButton='true' content='申請を確認しますか？' cancelText="キャンセル" confirmText="確認する">
				</u-modal>
			</view> -->
		<view class="padding-10">
			<view
				style="box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;background-color: #f5f6f7;"
				v-for="(item,index) in list" :key="item.index">
				<view style="background-color: #fff;" class="padding-10">
					<view class="flex">
						<view class="radius10 color-white font-size-12"
							style="background-color: #dc004c;padding: 2px 5px;">
							IPO
						</view>
						<view class="bold font-size-16 margin-left-10">{{item.goods.name}}</view>
					</view>
					<view class="hui2">{{item.jianjie}}</view>
					<u-button color="#38aa9a" class="margin-top-10" @click="id=item.id;show_mima=true">
						{{'申込'+ '&nbsp;&nbsp;&nbsp;' + '' }}</u-button>
					<view class="margin-top-10">

						<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #fff;">
							<view>発行価格</view>
							<view>仮条件</view>
						</view>
						<view class="flex flex-b padding-bottom-10"
							style="border-bottom: 1px solid #e6e8f0;margin-top: -10px;">
							<view>売出価格</view>
							<view>{{item.price}}円</view>
						</view>
						<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #e6e8f0;">
							<view>申込単位</view>
							<view>100株単位</view>
						</view>
						<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #e6e8f0;">
							<view>上場日</view>
							<view>{{item.online_date}}</view>
						</view>

					</view>
				</view>
				<view class="margin-top-10 padding-10">
					<view class="flex flex-c gap10">
						<view style="border: 1px solid #38aa9a;height: 25px;"
							class="flex-1 padding-10 text-center flex  justify-center" @click="webview(item.baipi)"
							v-if="item.baipi">
							目論見書
							<u-icon
								name="https://sbisec.akamaized.net/sbisec/sp/static/2.3.0/images/pdf_primary.svg"></u-icon>
						</view>
						<view style="border: 1px solid #38aa9a;height: 25px;"
							class="flex-1 padding-10 text-center flex  justify-center" v-if="item.guanwang"
							@click="webview(item.guanwang)">
							ウェブサイト
							<u-icon name="share-square" size="24" color="#092987"></u-icon>
						</view>

					</view>
					<view class="margin-top-10 hui margin-bottom-10">
						<u-parse :content="item.content"></u-parse>
					</view>
				</view>

			</view>

			<view class="" style="color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;">
				もうこれ以上はありません
			</view>

		</view>
		<view>
				<u-modal :show="show_mima" confirm-text="申込" @close="show_mima=false" @confirm="purchase()"
					:closeOnClickOverlay="true">
					<u--input placeholder="申込数量を入力してください" border="surround" type="number"
						v-model="number"></u--input>
				</u-modal>
			</view>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
				confirmation: "",
				show: false,
				id:0,
				number:"",
				show_mima:false,
				buyid: ""
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			buy(id) {
				this.show = true;
				this.buyid = id
			},
			webview(url){
				window.location.href=url
				// uni.navigateTo({
				// 	url:"/pages/webview?url="+encodeURIComponent(url)
				// })
			},
			async position(id) {
				this.purchase(id)
				this.show = false;

				// let list = await this.$http.post('api/goods-shengou/password', {
				// 	password:this.password,
				// 	id: id,
				// 	// price: this.price
				// })

				// if (list.data) {
				// 	this.show_mima = false;
				// 	this.show = true;

				// } else {
				// 	this.show_mima = false;
				// 	uni.$u.toast(list.data.message);
				// }
				// 
				// this.confirmation = id


				// console.log(this.confirmation, '11111111111');
			},
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase(confirmation)
				this.show = false;
			},
			// 点击申购
			// async purchase(confirmation) {
			// 	let list = await this.$http.post('api/goods-shengou/doOrder', {
			// 		num: this.value,
			// 		id: confirmation,
			// 		// price: this.price
			// 	})
			// 	if (list.data.code == 0) {
			// 		uni.showLoading({
			// 			title: "購読が進行中です。 しばらくお待ちください....",
			// 			mask: true, // 显示透明蒙层，防止触摸穿透
			// 		});
			// 		setTimeout(() => {
			// 			uni.navigateTo({
			// 				url: '/pages/trade/ipoLog'
			// 			});
			// 			uni.hideLoading();
			// 		}, 1000)
			// 	} else {
			// 		uni.$u.toast(list.data.message);
			// 	}
			// },
			async purchase() {
				if(this.number<=0){
					return uni.$u.toast('正しい数量を入力してください');
				}
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.number,
					id: this.id,
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: 'サブスクリプションが進行中です、お待ちください',
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/ipoLog'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			handleChangeTab(val) {
				if (val == 0) {
					this.applyPurchase();
				} else if (val == 1) {
					this.luckyNumber();
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.TRADE_IPO_LIST, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			applyPurchase() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO_LOG
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>