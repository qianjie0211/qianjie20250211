<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');

			// 启动监听网络状态变化
			uni.onNetworkStatusChange(res => {
				console.log('res:', res.isConnected);
				console.log('res:', res.networkType);
				if (!res.isConnected || res.networkType === 'none') {
					uni.showToast({
						title: this.$lang.TIP_NETWORK_TYPE_NONE,
						icon: 'none'
					})
				}
			});
		},
		onShow: function() {
			console.log('App Show')
			console.log(this.$u.config.v);
		},
		onHide: function() {
			console.log('App Hide');
			// 停止监听网络状态
			uni.offNetworkStatusChange(res => {
				console.log('res:', res);
			});
		}
	}
</script>

<style lang="scss">
	@import "@/node_modules/uview-ui/index.scss";
	@import url("common/css/rc.css");
	@import url("common/icon.css");
	@import url("common/style.css");
	
	@import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
	
	
	view {
		font-family: "Roboto", sans-serif;
		font-weight: 500;
		font-style: normal;
		font-size: 14px;
	}

	page{
		background-image: url(/static/bg.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		width: 100%;
		min-height: 100vh;
	}




	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	// //公共css 结束


	// 	/deep/.uni-tabbar {
	// 		width: 800rpx !important;
	// 		margin: auto;
	// 	}
	// }

	//版本更新
	.download .upgrade {
		position: relative;
		background: #fff;
		width: 468rpx;
		min-height: 238rpx;
		border-radius: 20rpx;
	}

	.download .logo image {
		width: 208rpx;
		height: 208rpx;
		position: absolute;
		top: -80rpx;
		left: 0;
		right: 0;
		margin: 0 auto;
	}

	.download .content {
		padding-top: 80rpx;
	}

	.download .content .title {
		text-align: center;
		font-size: 30rpx;
		font-weight: bold;
	}

	.download .content .container {
		color: #666;
	}

	.download .content .container .descriptions {
		padding: 0rpx 30rpx;
		text-align: center;
		font-size: 28rpx;
	}

	.download .content .container .details,
	.download .content .prpgroess {
		padding: 16rpx 46rpx;
		box-sizing: border-box;
		font-size: 24rpx;
	}

	.download .content .prpgroess {
		padding: 16rpx 22rpx;
		margin: 20rpx 0;
	}

	.download .content .btn-group {
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 20rpx;
	}

	.download .content .btn-group view {
		width: 200rpx;
		height: 68rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 14rpx;
		font-size: 24rpx;
		border-radius: 16rpx;
		line-height: 1.5;
	}

	.download .content .btn-group .confirm {
		background: #ef5656;
		color: #fff;
	}
</style>