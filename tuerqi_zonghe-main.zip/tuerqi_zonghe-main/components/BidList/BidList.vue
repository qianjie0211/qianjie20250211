<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="line-height: 1.6;margin:10rpx 0;">
				<view :style="$theme.depathBidsBG(item[1],max,to)">
					<view class="item" :style="{flexDirection:dir}">
						<view style="font-size: 26rpx;" :style="$theme.setStockRiseFall(false)">
							{{$util.formatNumber(item[0],4)}}
						</view>
						<view style="font-size: 26rpx;">{{$util.formatNumber(item[1],4)}}</view>
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "BidList",
		props: {
			list: {
				type: Array,
				default: []
			},
			max: {
				type: Number,
				default: 100
			},
			// to 表示 动态背景的to方向。 
			to: {
				type: String,
				default: ''
			},
			// 方向，兼容detail頁面反向顯示
			dir: {
				type: String,
				default: 'row', // row-reverse
			}
		},
	}
</script>

<style lang="scss" scoped>
	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 20rpx;
	}
</style>