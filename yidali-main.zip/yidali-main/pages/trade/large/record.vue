<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex" style="padding: 20px;">
			<view @click="$util.goBack()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-1 text-center font-size-18" style="color: #fff;">{{$lang.LISHI_JILV}}</view>
		</view>
		<view style="padding:10px 16px 100px 16px;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-radius: 12rpx;padding:20rpx;margin-bottom: 12px;border: 1px #00a997 solid;">
						<view class="bold" style="display: flex;align-items: center;justify-content: space-between;">
							<view style="font-size: 32rpx;color: #fff;">{{item.goods.name}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.MAIRU_JIAGE}}</view>
							<view>
								<view style="color: #fff;">
									{{`€ `+$util.formatMoney(`${(item.price||0)*1}`,3)}}
								</view>
								<view style="color: #AAA;font-size: 12px;text-align: right;">
									{{`$ `+$util.formatUSD(`${(item.price||0)*eurToUsd}`,3)}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.ZHIFU_JINE}}</view>
							<view>
								<view style="color: #fff;">
									{{`€ `+$util.formatMoney(`${(item.amount||0)*1}`,3)}}
								</view>
								<view style="color: #AAA;font-size: 12px;text-align: right;">
									{{`$ `+$util.formatUSD(`${(item.amount||0)*eurToUsd}`,3)}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
							<view style="color: #AAA;font-size: 12px;">{{$lang.SHULIANG}}</view>
							<view style="color: #fff;">
								{{$util.formatNumber(`${(item.num||0)*1}`)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
							<view style="color: #ccc;">{{$lang.MAIRU_SHIJIAN}}</view>
							<text style="color: #fff;">{{item.created_at}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				eurToUsd: 1, // 欧转美
			}
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
			this.getList();
			this.getConfig(); // 每次重新请求汇率
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		},
	}
</script>

<style>
</style>