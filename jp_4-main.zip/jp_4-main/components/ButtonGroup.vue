<template>
	<view class="btns_wrapper common_block" >
		<view v-for="(item,index) in btns" :key="index" class="item" :style="{flex:`${col}%`}">
			<view @click="actionEvent(item.url,index,item.name)" class="icon">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(32)"></image>
			</view>
			<text class="btn_name bold" :style="{color:current==index?$util.THEME.SECONDARY_COLOR:$util.THEME.PRIMARY_COLOR}">{{item.name}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns','col'],
		data() {
			return {
				current: -1
			};
		},
		methods: {
			actionEvent(url, index, name) {
				this.current = index;
				if (url.includes('pages')) {
					uni.navigateTo({
						url: `${url}?tag=${name}`,
						fail() {
							uni.switchTab({
								url:`${url}?tag=${name}`
							})
						}
					})
					
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>