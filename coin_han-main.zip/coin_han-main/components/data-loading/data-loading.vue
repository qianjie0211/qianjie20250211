<template>
	<view class="w-100 h-100 d-flex justify-content-center align-items-center">
		<u-loading class="mx-auto" mode="flower" color="rgba(255,255,255,.8)" size="50"></u-loading>
	</view>
</template>

<script>
	export default {
		name:"data-loading",
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
