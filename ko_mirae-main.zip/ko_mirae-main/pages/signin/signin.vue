<!-- 登录 -->
<template>
	<view>
		<view class="" style="display: flex;justify-content: center;">
			<view style="margin-top: 10px;">
				<image mode="aspectFit" src="/static/logo.jpg" :style="$util.setImageSize(400)">
				</image>
			</view>
		</view>
		<!-- <view class="text-center font-size-20" style="color: #f38121;margin-top: -40px;">미래에셋증권</view> -->

       <view class="padding-20" style="margin-top: -20px;">
		   <view style="background-color: #fff;border-radius: 10px;">
		   	<view class="flex" style=" justify-content: space-between;padding: 20px;">
		   		<view class="font-size-17">회원정보입력</view>
		   		<view @tap="register()">
		   			<view class="font-size-10" style="background-color: #f38121;border-radius: 30px;padding: 5px 10px;color: #fff;">회원가입</view>
		   		</view>
		   	</view>
				
		   <view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">	
		   <view style="width: 85%;line-height: 20px;height: 10px;position: relative;font-size: 16px;">아이디</view>
			<input shape="" placeholder="아이디(휴대폰번호'-'없이 입력해주세요)" color='#121212'
				placeholderStyle="font-size: 13px;color: #999999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value1" type="number"
				maxlength="11" style="margin-top:20px;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
				
		 <view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;">비밀번호</view>
			<input shape="" placeholder="비밀번호(필수)" prefixIcon="lock-fill" color='#121212'
				placeholderStyle="font-size: 13px;color: #999999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value2" type="password"
				style="margin-top:60rpx;background-color: #f1f1f1;width: 85%;border: 1px #EEEEEE solid;padding: 10px;"></input>
				
			<view class="" style="padding: 20px;width: 90%;justify-content: center;align-items: center;flex-direction: column;display: flex;">
				<view class="text-center color-white" style="width: 70%;margin-top:20rpx;background-color: #f38121;padding: 10px;border-radius: 10px;" @click="gain_login">로그인(휴대폰번호 간편로그인)</view>
			</view>
			
		</view>
		</view>
		<view style="width: 70%;margin-top:60rpx;line-height: 20px;height: 20px;position: relative;">
			<u-checkbox-group>
				<u-checkbox activeColor="#f38121" label="로그인 상태 유지" v-model="checked" labelColor="#38AA9A"
					labelSize="12px" :checked="checked"></u-checkbox>
			</u-checkbox-group>
			<!-- <view
				style="font-size: 14px;color: #38AA9A;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
				@tap="register()">
				{{$lang.SIGN_UP}}
				<u-icon name="arrow-right" color="#38AA9A" size="14" :bold="true"
					style="display: inline-block;"></u-icon>
			</view> -->
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				checked: true,
			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput') || '';
			let passinput = uni.getStorageSync('passinput') || '';

			if (userinput) {
				this.value1 = userinput
			}
			if (passinput) {
				this.value2 = passinput
			}

		},
		onHide() {
			uni.setStorageSync('userinput', this.value1);
			uni.setStorageSync('passinput', this.value2);
		},
		methods: {
			register() {
				console.log(22222)
				uni.navigateTo({
					url: '/pages/signin/hetong'
				});
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.setStorageSync('userinput', this.value1);
					uni.setStorageSync('passinput', this.value2);
					uni.$u.toast('정상 로그인 되었습니다');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
	}
</script>