<template>
	<view style="margin-top: 70px;">
		<view class="flex hui1" style="padding: 15px 15px;">
			<view class="font-size-12" style="flex: 35%;">주식명</view>
			<view class="font-size-12" style="flex: 30%;">{{$lang.TRADE_DAY_BUY_PRICE}}</view>
			<view class="font-size-12" style="flex: 30%;">{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}</view>
			<view class="font-size-12" style="flex: 15%;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="background-color: #fff;min-height: 80vh;">
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px #ccc solid;">
                   <view class="flex padding-10">
					   <view style="flex: 30%;">{{item.zt}}</view>
					   <view style="flex: 20%;">{{$util.formatMoney(item.price)}}</view>
					   <view style="flex: 20%;">{{$util.formatMoney(item.success)}}</view>
					   <view style="flex: 10%;text-align: center;background-color: #34d66a;border-radius: 5px;padding:4px 0px;color: #fff;">성공</view>
				   </view>
					<!-- <view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;height: 120rpx;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_ORDER_STATUS}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								{{item.zt}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;height: 120rpx;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_BUY_PRICE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.price)}}
							</view>
						</view>
					</view>


					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_BUY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.money)}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.success)}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_ORDER_SN}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.ordersn}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_CREATE_TIME}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
					</view> -->
				</view>
			</block>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDaySuccessList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 申请列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/order-list`);
				this.list = !result || result.length <= 0 ? [] : result;
			},
		}
	}
</script>

<style>
</style>