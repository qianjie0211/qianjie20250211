<template>
  <div class="container page" style="background-color: #1b1b1b">
    <van-nav-bar title="실명" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
      <template #right>
        <span class="nav-right" @click="save()">도움말!</span>
      </template>
    </van-nav-bar>
    <div style="margin: 20px 16px">
      <label
        style="color: #fff; font-size: 16px; font-weight: 700; line-height: 1.8"
        >본명을 입력해 주세요</label
      >
      <div class="custom_input">
        <input v-model="name" placeholder="실명을 입력해 주세요" />
      </div>
    </div>
    <p>
      계좌의 안전을 위하여 귀하의 실명은 기입된 카드명과 일치하여야 합니다
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: "",
      userInfo: {},
    };
  },
  methods: {
    back() {
      return window.history.back();
    },
    save() {
      if (this.userInfo.name) {
        this.$toast("No duplicate installation");
        return true;
      }
      if (this.name === "" || this.name === null || this.name === undefined) {
        this.$toast.fail("Please enter your name!");
        return false;
      }
      this.$http({
        method: "get",
        data: { name: this.name },
        url: "user_set_name",
      }).then((res) => {
        if (res.code === 200) {
          this.getUserInfo();
          this.name = this.userInfo.name;
          this.$toast(res.msg);
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getUserInfo() {
      this.$http({
        method: "get",
        url: "user_info",
      }).then((res) => {
        if (res.code === 200) {
          this.userInfo = res.data;
          console.log("userInfo===🚀===>", this.userInfo);
          this.name = res.data.name;
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
  },
  created() {
    if (!localStorage.getItem("token")) {
      this.$router.push({ path: "/Login" });
    } else {
      this.getUserInfo();
    }
  },
};
</script>

<style lang="less" scoped>
@import "../../assets/css/base.css";
.van-cell {
  font-size: 35px;
  line-height: 80px;
}
.container p {
  padding: 0 15px;
  margin-top: 15px;
  font-size: 30px;
  color: #FFCC99;
}
.custom_input {
  margin-bottom: 20px;
  background-color: transparent;
  border: 1px solid #ffcc99;
  border-radius: 6px;
  height: 68px;
  line-height: 68px;
  padding-left: 24px;
  color: #fff;
}
.custom_input input {
  background-color: transparent;
  border: none;
  outline: none;
}
.custom_input input::placeholder{
  color:#666;
  font-size: 24px;
}
</style>
