<template>
  <div class="container page" style="background-color: #1b1b1b;">
    <van-nav-bar :title="curLang.Gender_Correction" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()"/>
      </template>
    </van-nav-bar>
    <div class="sex">
        <van-radio-group v-model="radio">
          <div class="item van-hairline--bottom" @click="chooesSex(1)">
              <van-radio name="1">{{curLang.man}}</van-radio>
          </div>
          <div class="item van-hairline--bottom" @click="chooesSex(2)">
            <van-radio name="2">{{curLang.female}}</van-radio>
          </div>
        </van-radio-group>

    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器

      radio:"",
      userInfo:{}
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    back(){
      return window.history.back();
    },
    chooesSex(sex){
      this.$http({
        method: 'post',
        data:{sex:sex},
        url: 'user_set_sex'
      }).then(res=>{
        if(res.code === 200){
          this.getUserInfo();
          this.radio = sex;
          this.$toast(res.msg);
        }else if(res.code ===401){
          this.$toast(res.msg);
        }
      })
    },
    getUserInfo(){
      this.$http({
        method: 'get',
        url: 'user_info'
      }).then(res=>{
        if(res.code === 200){
          this.userInfo = res.data;
          this.radio = res.data.sex;
        }else if(res.code ===401){
          this.$toast(res.msg);
        }
      })
    }
  },
  created() {
    if(!localStorage.getItem('token')){
      this.$router.push({path:'/Login'})
    }else {
      this.getUserInfo();
    }

    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    this.curCode = this.curLang.loginCode;
    const temp = this.$locales.filter((item) => item.value == this.curLocale);
    console.log(temp);
    this.langName = temp[0].text;
  }
};
</script>

<style lang='less' scoped>
@import "../../assets/css/base.css";
.container .sex{
  background-color: transparent;
  padding: 0 40px;
}
.container .sex .item{
  font-size: 35px;
  line-height: 50px;
  padding: 30px 0;
}
::v-deep .van-radio__label {
  line-height: 50px;
  margin-left: 30px;
  color:#fff;
}
::v-deep .van-radio__icon {
  font-size: 30px;
}
::v-deep .van-radio__icon--checked .van-icon {
  color: #fff;
  border-color: #FFCC99;
  background-color: #FFCC99;
}
.container .van-hairline--bottom::after {
  border-bottom-width: 3px;
}
</style>
