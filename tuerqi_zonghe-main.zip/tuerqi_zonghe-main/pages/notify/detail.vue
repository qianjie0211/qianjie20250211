<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color:#FFFFFF;min-height: 100vh;">
		<HeaderSecond :title="$lang.NOTIFY_TITLE" :color="$theme.SECOND"></HeaderSecond>
		<template v-if="!info">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding:20rpx 40rpx;line-height: 1.8;">
				<view style="font-size: 32rpx;font-weight: 700; text-align: center;" :style="{color:$theme.SECOND}">
					{{info.biaoti}}
				</view>
				<view style="font-size: 24rpx;text-align: right;" :style="{color:$theme.LOG_LABEL}">
					{{info.created_at}}
				</view>

				<view v-html="info.xiangqing"></view>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	
	export default {
		components: {
			HeaderSecond,
		
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				id: 0,
				info: null,
			}
		},
		onLoad(opt) {
			this.id = opt.id || 0;
		},
		onShow() {
			this.isAnimat = true;
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getData() {
				const result = await this.$http.post(`api/app/gginfo`, {
					id: this.id
				});
				console.log(`result:`, result);
				if (!result) return false;
				this.info = result;
			}
		}
	}
</script>

<style>
</style>