<template>
	<view style="padding: 10px;background-color: #FFFFFF;min-height: 100vh;margin-top: 90px;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="border: 1px #35d66b solid;border-radius: 10px; padding: 10px;">
				<!-- <TradeStockItem :item="item" @action="handleDetail"></TradeStockItem> -->
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
					<view style="flex:80%;">
						<view class="bold" style="font-size: 32rpx;color:#121212;">
							{{item.goodname}}
						</view>
					</view>
					<template v-if="item.status==1">
						<view class="access_btn" @click="handleDetail(item.id)"
							style="padding:6rpx 24rpx;margin:0;font-size: 28rpx;line-height: 1.4;background-color: #34d66a;border-radius: 5px;color: #fff;">
							{{$lang.BTN_SELL}}
						</view>
					</template>
				</view>
				<view class="flex" style="padding: 0px 0px;gap: 10px;">
					<view class="flex flex-b" style="flex: 40%;">
						<view class="hui1">{{$lang.TRADE_EA_ORDER_AMOUNT}}</view>
						<view>{{$util.formatNumber(item.price)}}</view>
					</view>
					<view class="flex flex-b" style="flex: 40%;">
						<view class="hui1">{{$lang.TRADE_EA_ORDER_CYCLE}}</view>
						<view>{{item.fudu+` %`}}</view>
					</view>
				</view>
				
				<view class="flex" style="padding: 10px 0px;gap: 10px;">
					<view class="flex flex-b" style="flex: 40%;">
						<view class="hui1">{{$lang.TRADE_EA_ORDER_RATE}}</view>
						<view>{{item.fudul*1+` %`}}</view>
					</view>
					<view class="flex flex-b" style="flex: 40%;">
						<view class="hui1">{{$lang.TRADE_EA_ORDER_PERIOD}}</view>
						<view>{{item.zhouqi+` Day`}}</view>
					</view>
				</view>
				
				<view class="flex">
					<view class="flex-1 hui1">시작일</view>
					<view>{{item.cretime}}1</view>
				</view>
				<view class="flex " style="padding: 10px 0px;">
					<view class="flex-1 hui1">종료일</view>
					<view>{{item.endtime}}2</view>
				</view>
				<view class="flex">
					<view class="flex-1 hui1">일련번호</view>
					<view>{{item.ordersn}}</view>
				</view>
				</view>	
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'EaOrder',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},

		methods: {
			async handleDetail(id) {
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_EA_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.handleSell(id);
				}
			},
			async handleSell(id) {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/jijin/buy`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				this.getList();
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/jijin/list`);
				console.log(result);
				this.list = result.order || [];
			}
		}
	}
</script>

<style>
</style>