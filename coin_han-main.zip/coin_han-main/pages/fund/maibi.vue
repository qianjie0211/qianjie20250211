<template>
	<view>
		<u-navbar back-icon-size="34" :title="$t('Coins.maibi')"></u-navbar>
		<view class="padding-30 text-center color-white">
			<view class="font-size-48 bold">{{change_balance}}</view>
			<view class="margin-top-10">{{i18n.dangqian}}</view>
		</view>
		<view class="padding-10 color-white">
			<view>{{i18n.chongzhi}}</view>
			<view class="margin-top-5" style="color: #ddd;">{{i18n.zuixiao}}</view>
		</view>
		
		<view class="padding-10">
			<input :placeholder="i18n.shuru" type="number" v-model="quantity" style="border-bottom: 1px #444 solid;padding: 5px;color: #fff;"/>
		</view>
		
		<view class="margin-top-10 text-center" style="padding: 0px 10px;">
			<u-row justify="space-between" gutter="10" >
				<u-col span="2.8" >
					<view :class="quantity==1000?'actity':'noactity'" @click="quantity=1000;quantity1=''">1000USDT</view>
				</u-col>
				<u-col span="2.8" >
					<view :class="quantity==5000?'actity':'noactity'" @click="quantity=5000;quantity1=''">5000USDT
					</view>
				</u-col>
				<u-col span="2.8" >
					<view :class="quantity==10000?'actity':'noactity'" @click="quantity=10000;quantity1=''">10000USDT 
					</view>
				</u-col>
				<u-col span="2.8" >
					<view :class="quantity==30000?'actity':'noactity'" @click="quantity=30000;quantity1=''">30000USDT
					</view>
				</u-col>
		
			</u-row>
		</view>
		
		<view class="padding-10" @click="kefu()">
			<view class="text-center padding-10" style="background-color: #0690e7;color: #fff;border-radius: 5px;">{{i18n.liji}}</view>
		</view>
		
		<view class="padding-10 color-white">
			<view>{{i18n.tishi}}:</view>
			<view>{{i18n.diyi}}</view>
			<view>{{i18n.dier}}</view>
		</view>
		
		
	</view>
</template>

<script>
	// 选择币种
	export default {
		data() {
			return {
				coins: [{
					id: 3,
					text: 'USDT'
				}, {
					id: 1,
					text: 'BTC'
				}, {
					id: 2,
					text: 'ETH'
				}],
				quantity: '',
				selectCoin: {},
				showSelect: false,
				min_number: 0, //最低提现金额
				change_balance: 0, //余额
				rate: 0, //手续费,
				number: null,
				showSelectAddress: false,
				originWalletAddress: [],
				walletAddress: [],
				selectAddress: {},
				type: 1, //0地址，1银行卡,
				card: {},
				card_international: {},
				payPwd: '',
			};
		},
		onLoad() {
			this.selectCoin = this.coins[0]
		},
		onShow() {
			this.getWalletAddressList()
			this.getCard()
			this.getCardInternational()
		},
		methods:{
			jump(item){
				if(!item.status) return
				uni.setStorageSync('selectCoin',item)
				let url = `/pages/fund/${this.url}`
				uni.navigateTo({
					url
				})
			},
			
			
			kefu(){
				uni.navigateTo({
					url:'/pages/kefu/index'
				})
			},
			confirmSelect(index) {
				this.selectCoin = this.coins[index]
			},
			getWalletInfo() {
				const {
					id: currency
				} = this.selectCoin
				this.$u.api.wallet.getWalletInfo(currency).then(res => {
					const {
						message: data
					} = res
					this.change_balance = Number(data.change_balance)
					this.min_number = Number(data.min_number)
					this.rate = Number(data.rate)
			
				})
			},
			checkNumber(e) {
				const {
					i18n,
					min_number,
					selectCoin
				} = this
				const value = Number(e.detail.value)
			
				if (value < min_number && value != 0) {
					// this.number = min_number
					return this.$utils.showToast(i18n.leastNumber + min_number + selectCoin.text)
				}
			},
			getWalletAddressList() {
				this.$u.api.setting.getWalletAddressList(this.page, 99999).then(res => {
					this.originWalletAddress = res.message.data
					this.walletAddress = this.originWalletAddress.filter(item => item.currency == this.selectCoin
						.id)
					this.selectAddress = this.walletAddress[0]
				})
			},
			selectAddressFunc(item) {
				this.selectAddress = item
				setTimeout(() => {
					this.showSelectAddress = false
				}, 300);
			},
			withdraw() {
				const {
					i18n,
					selectAddress,
					number,
					rate,
					selectCoin,
					type,
					card,
					card_international,
					payPwd,
				} = this
				if (selectAddress && !selectAddress.address && type == 0) {
					//没有提币地址
					return this.$utils.showToast(i18n.plsSelectWithdrawAddress)
				}
				if (!card.bank_account && type == 1) {
					//没有银行卡
					return this.$utils.showToast(i18n.plsAddCard)
				}
				if (!card_international.bank_account && type == 2) {
					//没有银行卡
					return this.$utils.showToast(i18n.plsAddCard)
				}
				const address = selectAddress ? selectAddress.address : ''
				if (!number) {
					//没有金额
					return this.$utils.showToast(i18n.plsIptWithdrawNumber)
				}
			
				if (payPwd == '') {
					return this.$utils.showToast(this.$t('payPwd'))
				}
			
				const currency = selectCoin.id
				this.$u.api.wallet.withdraw({
					address,
					currency,
					number,
					rate,
					type,
					pay_password: payPwd,
				}).then(res => {
					this.$utils.showToast(res.message)
					this.number = 0
				})
			
			},
			getCard() {
				this.$u.api.setting.getCard().then(res => {
					this.card = res.message
				})
			},
			getCardInternational() {
				this.$u.api.setting.getCardInternational().then(res => {
					this.card_international = res.message
				})
			}
		},
		computed: {
			i18n() {
				return this.$t("Coins")
			},
			i18ncommon() {
				return this.$t("common")
			},
			canGetNumber() {
				const value = this.number - this.rate
				if (value > 0) return value
				return 0
			}
		},
		watch: {
			'selectCoin.id'() {
				this.getWalletInfo()
				this.walletAddress = this.originWalletAddress.filter(item => item.currency == this.selectCoin.id)
				this.selectAddress = this.walletAddress.length ? this.walletAddress[0] : {}
			},
		},

	}
</script>

<style>
	.actity {
		background-color: #0690e7;
		color: #000;
		font-weight: 700;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 5px;
	}
	
	.noactity {
		background-color: #444;
		color: #fff;
		border: 1px solid #f1f5f9;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 5px;
	}
</style>