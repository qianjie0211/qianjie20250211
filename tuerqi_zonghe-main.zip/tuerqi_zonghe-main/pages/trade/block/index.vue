<template>
	<view style="min-height: 100vh;background-color: #010101;">
		<header class="header" style="background-color: #010101;" v-if="!top_show">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text style="color:#FFFFFF;">{{type==1?$lang.TRADE_BLOCK_TITLE:'OTC'}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<header style="padding-top: 60rpx;" v-if="top_show">
			<view class="left" @click="$u.route({type:'switchTab',url:'/pages/home/index'});"
				style="position: absolute;top: 75rpx;left: 5px;">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view style="margin-left: 30px;">
				<scroll-view :scroll-x="true" style="white-space: nowrap;" :scroll-left="type==1?0:730" @touchmove.stop
					:scroll-with-animation="true">
					<view style="display: flex;margin:0 10rpx;" class="align-center">

						<block v-for="(item,index) in $util.TABS()" :key='index'>
							<view :style="$util.setStyle1((type==1?1:7) ==index)" @click="$util.changeTab1(item.url)">
								{{item.value}}
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</header>


		<view>
			<view class="flex" style=" justify-content: space-between;padding: 20px 20px;">
				<view style="background-color: #018ef8;color: #fff; padding: 8px 20px;border-radius: 10px;">
					{{$lang.PINZHONG}}
				</view>
				<view style="background-color: #018ef8;color: #fff; padding: 8px 20px;border-radius: 10px;"
					@click="chicang()">{{$lang.CONTRACT_RECORD_HOLD}}</view>
				<view style="background-color: #018ef8;color: #fff; padding: 8px 20px;border-radius: 10px;"
					@click="lishi()">{{$lang.CONTRACT_RECORD_HISTORY}}</view>
			</view>
		</view>

		<view style="padding-bottom: 200rpx;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block"
						style="padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
						<view style="display: flex;align-items: center;">
							<view style="flex:0 0 6%" v-if="type==1">
								<CustomLogo :logo="logo.image" :name="item.name"></CustomLogo>
							</view>
							<view style="flex:0 0 6%" v-if="type==2">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
							<view style="flex:94%;">
								<view style="display: flex;align-items: center;">
									<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#FFFFFF;">
										{{item.name}}
										<!-- <text style="font-size: 20rpx;padding:20rpx;color:#999;">
											{{item.code}}</text> -->
									</view>
									<view style="margin-left: auto;">
										<view :style="setStyleBuy()" @click="showModal(item)">
											{{$lang.BTN_BUY}}
										</view>
									</view>
								</view>
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color: #FFFFFF;font-size: 24rpx;">{{$lang.TRADE_BLOCK_PRICE}}</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(item.price)}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.ZHE_JIA_BAIFENB}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatPercentage($util.formatNumber((item.price*1/item.current_price*1)*100,2))}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_MIN_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.min_num}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #FFFFFF;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_MAX_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.max_num}}
							</view>
						</view>
						<view
							style="background-color: #E8E8E8;border-radius: 24rpx;position: relative;height: 20rpx;margin-top: 5px;">
							<view
								style="position: absolute;left: 0;right: 0;top:0;bottom: 0; background-color: #038ef8;border-radius: 24rpx;"
								:style="{width: setWidth(item.cj_num, item.sg_num) + '%'}">
							</view>
						</view>
						<view :style="{color:$theme.SECOND}" style="margin-top: 5px;">{{$lang.TRADE_IPO_LIST_RC+ ` `}}
							{{$util.formatPercentage($util.formatNumber((item.cj_num / item.sg_num)*100, 2)) }}
						</view>
					</view>

				</block>
			</template>
		</view>
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;background-color: #202020;">
				<view class="popup_header" style="background-color: #018ef8;">
					{{detail.name}}
					<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
						@click="handleClose()">
					</image>
				</view>
				<view style="padding-bottom: 30rpx;">
					<view style="background-color: #353739;margin: 20px;border-radius: 12px;padding-bottom: 30rpx;">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding: 20px 20px;">
							<text :style="{color:$theme.LOG_LABEL}"> {{$lang.BLOCK_BUY_STOCK}}</text>
							<text style="font-size: 12px; color: #a1a2a5;">
								{{$lang.COIN_BUY_PRICE}} {{$util.formatNumber(detail.price) }}</text>
						</view>

						<view>
							<view class="common_input_wrapper"
								style="margin:30rpx 38rpx;background-color: transparent;border-bottom: 1px solid #9c9c9c;border-radius: 0;">
								<input v-model="amount" :placeholder="$lang.TRADE_BLOCK_ORDER_AMOUNT" type="number"
									style="flex: 1;color: #fff;" :placeholder-style="$theme.setPlaceholder()"></input>
								<view style="margin-left: auto;">
									<view
										style="display: flex;align-items: center;justify-content: space-between;flex-wrap: nowrap;">
										<view>{{code==1?$lang.BLOCK_QTY:'USDT'}}</view>
										<text style="padding: 0 4px;">|</text>
										<view @click="maxQty()" :style="{color:$theme.PRIMARY}">
											{{$lang.SEARCH_TAB_ALL }}
										</view>
									</view>
								</view>
							</view>
							<view style="margin-top: -10px;margin-left: 19px; font-size: 12px; color: #a1a2a5;">
								{{$lang.COIN_VIEW_AVAILABLE_AMOUNT }}
								{{!userInfo?0: $util.formatCurrency(userInfo.money*1) }}
							</view>
						</view>


						<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
						<!-- <template v-if="leverList.length>1">
						<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
							:style="{color:$theme.LOG_LABEL}">
							{{$lang.LEVER}}
						</view>
			
						<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
							<block v-for="(item,index) in leverList" :key="index">
								<view
									style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
									:style="setStyle(curLever==item)" @click="chgangeLever(item)">
									{{item}}
								</view>
							</block>
						</view>
					</template> -->

						<view style="display: flex;flex-wrap: nowrap;align-items: left;padding:20px 20px;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_BLOCK_BUY_TOTAL_AMOUNT}}</view>
							<view style="padding-left: 6px;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney($util.formatNumber(buyAmount),2) }}
							</view>
						</view>


					</view>
					<view class="common_input_wrapper"
						style="padding-left: 24rpx;margin:0 20px 15px 20px;background-color: #353739;border-radius: 12px;">
						<input v-model="password" :password="isMask" :placeholder="$lang.TRADE_BLOCK_TIP_BUY_PWD"
							:placeholder-style="$theme.setPlaceholder()" style="color: #FFF;"></input>
						<image :src="`/static/${isMask?'hide':'show'}.png`" mode="aspectFit"
							style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
							@click="isMask=!isMask">
						</image>
					</view>

					<view class="common_btn" @tap.stop="handleConfirm()"
						style="margin:20rpx auto;width: 80%;background-color: #7d7d7d;color:#FFF;margin-bottom: 60px;">
						{{$lang.BTN_BUY}}
					</view>
				</view>
			</view>
		</template>

		<view style="height: 200rpx;"></view>
		<FooterSmall code="stock" />
	</view>
</template>

<script>
	export default {

		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				isShow: false, // 是否显示弹层
				detail: {}, // 单条数据详情
				amount: "", // 金额
				password: '', // 支付密码
				isMask: true, //  密码默认掩码状态
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
				type: 1,
				top_show: false,
				logo: {
					image: '../../../static/guoqip.png'
				},
				userInfo: null, // 账号余额
			}
		},
		computed: {
			// 金额计算
			buyAmount() {
				return this.detail.price * this.amount / this.curLever;
			},
		},
		onLoad(op) {
			if (op.type) {
				this.code = op.type
			}
			if (op.top1 == 1) {
				this.top_show = true
			}
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
			this.getAccountInfo();
			this.getConfig();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.isShow = false;
			this.getList();
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 最大可购买股
			maxQty() {
				if (this.code == 1) {
					this.amount = this.$util.formatNumber(this.userInfo.money * 1 / this.detail.price, 4);
				} else {
					this.amount = this.userInfo.money * 1;
				}
			},

			showModal(val) {
				this.isShow = true;
				this.detail = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				// this.changeTab(val);
			},
			chicang() {
				uni.navigateTo({
					url: '/pages/trade/block/chicang?type=' + this.type
				})
			},
			lishi() {
				uni.navigateTo({
					url: '/pages/trade/block/lishi?type=' + this.type
				})
			},
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.TRADE_BLOCK_RECORD + '?type=' + this.type
				})
			},

			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : 'transparent',
					color: val ? '#FFFFFF' : '#A8A8A8',
					borderRadius: `16rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
				}
			},
			setStyleBuy() {
				return {
					backgroundColor: this.$theme.PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`
				}
			},
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},

			handleConfirm() {
				if (!this.checkForm()) return false;
				this.buy();
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_COUNT);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_PWD);
					return false;
				}
				return true;
			},
			setWidth(cj_num, sg_num) {
				const num1 = Number(cj_num);
				const num2 = Number(sg_num);

				// 处理异常情况
				if (!num1 || !num2 || num2 <= 0) {
					return '0'; // 宽度为 0%
				}

				// 计算宽度百分比
				const percentage = (num1 / num2) * 100;
				return Math.min(percentage, 100).toFixed(2); // 限制最大值为 100%
			},
			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.detail.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever,
					type: this.type,
					money: this.amount,
				});
				if (!result) return false;
				this.handleClose();
				setTimeout(() => {
					// this.lishi(); // 1为购买成功，通知父组件刷新
					this.getList();
					this.getAccountInfo();
				}, 1000);
			},

			// 产品列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`, {
					type: this.code,
				});
				if (!result) return false;
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						current_price: item.goods.current_price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
						cj_num: item.cj_num,
						sg_num: item.sg_num,
					}
				});
				console.log(this.list, 555555);
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.post(`api/user/assets`, {
					// type: 2,
					name: `TRY`
				});
				if (!result) return false;
				console.log(`result`, result);
				this.userInfo = result[0];
			},

			// 请求配置参数
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				console.log(`temp`, temp);
				// this.blockPwd = temp.get('password');
			}

		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>