<template>

	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<header style="padding:20px 16px 10px 16px;
		display: flex; background-color: #F8C351;
		align-items: center;justify-content: space-between;">
			<view style="flex: 0 10%">
				<image src="/static/logo.png" mode="widthFix" :style="$theme.setImageSize(60)"></image>
			</view>
			<view style="flex:1; font-size: 36rpx;color: #0A2448;text-align:center; padding-right: 20px;">
				선택 과목
			</view>
			<view style="margin-left:auto;">
				<image src="/static/search.svg" mode="widthFix" style="margin-right: 8px;"
					:style="$theme.setImageSize(40)" @click="$paths.linkSearch()"></image>
				<image src="/static/news.svg" mode="widthFix" :style="$theme.setImageSize(40)"
					@click="$util.linkCustomerService()"></image>
			</view>
		</header>

		<!-- 		<view style="margin: 20px 6px; ">
			<text style="font-size: 18px; text-align: left; margin: 20px 16px;"></text>
			<view
				style="border-radius: 7px; width: 146px; height: 7px;background-color: #F8C351;margin-top: -10px; margin-left: 16px;">
			</view>
		</view> -->

		<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px ;">
			<view>
				<text style="font-size: 18px; text-align: left; margin: 20px 16px;">아이콘) 시장 지수
				</text>
				<view
					style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351;margin-top: -10px;">
				</view>
			</view>
			<view style="margin-left: auto;" @click="$paths.linkMarket(1)">
				<image src="/static/arrow_right.svg" mode="widthFix" :style="$theme.setImageSize(40)">
				</image>
			</view>
		</view>
		
		<CustomTitle title=" 주요지수"></CustomTitle>

		<view class="flex flex-wrap gap10" style="padding:0 12rpx;">
			<block v-for="(item,index) in top1" :key="index">

				<view
					style="flex:20%;padding:10px;border-radius: 6px;background-color: #F6F6F6;line-height: 1.8;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;"
					:style="{backgroundImage: item.rate*1>0 ? `linear-gradient(to bottom, #FFD6D6 ,#FFFFF3  )` :`linear-gradient(to bottom, #E0F0FF,#ECF6FF )`  }"
					@click='handleChangeType(index)'>
					<view class="text-center bold">
						<view class="font-size-16" style="color: #0A2448;">
							{{top111[index]}}
						</view>
						<view style="font-weight: 100;" :style="{color:item.rate*1>0?`#FF0000`:`#1E90FF`}">
							{{item.close}}
						</view>
						<view style="font-weight: 100;" :style="{color:item.rate*1>0?`#FF0000`:`#1E90FF`}">
							{{item.rate}}%
						</view>
					</view>
				</view>
			</block>
		</view>






		<!-- <view
			style="display: flex;flex-direction: row;justify-content:space-between;flex-wrap: nowrap; margin: 20px 16px;">
			<block v-for="(v,k) in topList" :key="k">
				<view style=" background: ;width: 31%;text-align: center; border-radius: 6px;"
					:style="{backgroundImage: v.returns*1>0 ? `linear-gradient(to bottom, #FFD6D6 ,#FFFFF3  )` :`linear-gradient(to bottom, #E0F0FF,#ECF6FF )`  }">
					<view style="padding: 8px 8px 4px 8px;font-size: 16px; color: #0A2448;">{{v.ko_name}} </view>
					<view style="padding: 4px 8px 4px 8px; color: #666;">{{v.code}}</view>
					<view style=" align-items: center;padding: 4px 8px;flex-wrap:wrap;"
						:style="{color:v.returns*1>0?`#FF0000`:`#1E90FF`}">
						<view style="flex:0 0 100%;" :style="{color:v.returns*1>0?`#FF0000`:`#1E90FF`}">
							{{$util.formatMoney(v.close*1,2)}}
						</view>
						<view style=" font-size: 12px;text-align: center;"> {{v.returns*1}}% </view>
					</view>
					<view>
						<image :src="`/static/market_${v.returns*1>0?`red`:`blue`}.png` " style="margin-top: 10px ;"
							mode="widthFix"
							:style="{...$theme.setImageSize(200),transform:`scaleX(${v.returns*1>0?-1:1})`}"></image>
					</view>
				</view>
			</block>
		</view> -->

		<view style="margin: 10px 10px" :style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}">
		</view>

		<!-- <view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px ;">
				<view>
					<text style="font-size: 18px; text-align: left; margin: 20px 16px;">거래 데이터
					</text>
					<view
						style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351;margin-top: -10px;">
					</view>
				</view>
				<view style="margin-left: auto;" @click="$paths.linkMarket(2)">
					<image src="/static/arrow_right.svg" mode="widthFix" :style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>


			<view style="align-items: center;">
				<image src="/static/market_line.png" style="margin: 10px 16px;" mode="widthFix"
					:style="$theme.setImageSize(700)"></image>
			</view>
		</view> -->
		<view style="margin: 10px 10px" :style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}">
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px ;">
			<view>
				<text style="font-size: 18px; text-align: left; margin: 20px 16px;">인기 주식 </text>
				<view
					style="border-radius: 7px; width: 110px; height: 7px;background-color: #F8C351;margin-top: -10px;">
				</view>
			</view>
			<view style="margin-left: auto;" @click="linkstockList">
				<image src="/static/arrow_right.svg" mode="widthFix" :style="$theme.setImageSize(40)"></image>
			</view>
		</view>

		<!-- <view style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); border-radius: 6px; margin: 0 16px;">
			<template v-if="marketList.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<view style="margin:0 24rpx;padding-bottom: 24rpx;">
					<block v-for="(item,index) in marketList" :key="index">
						<view
							style="display: flex;align-items:center; padding:10px;border-radius: 8rpx;box-shadow: none;"
							:style="{borderBottom:`1rpx solid ${$theme.RGBConvertToRGBA(`#0A2448`,10)}`}"
							@click="linkDetail(item)">
							<view style="margin-right: auto;">
								<image :src="`/static/stock_${item.follow?'follow':'unfollow'}.png`" mode="aspectFit"
									:style="$theme.setImageSize(50)" @click.stop="handleUnFollow(item.gid)">
								</image>
							</view>
							<view style="width: 90rpx;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
							<view style="flex:1;padding-left: 6px;">
								<view style="font-size: 28rpx;color: #121212">
									{{item.name}}
									<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
										:style="$theme.setImageSize(28)" style="padding-left: 20rpx;"></image>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="font-size: 24rpx;"
										:style="{color:$theme.RGBConvertToRGBA(`#0A2448`,70)}">
										{{item.code}}
									</view>
									<view style="font-size: 26rpx;font-weight: 700;"
										:style="$theme.setStockRiseFall(item.rate>0)">
										{{$util.formatMoney(item.close)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view
										style="padding: 6rpx 12rpx;border-radius: 10rpx;  min-width: 50px; text-align:center;"
										:style="$theme.setStockRiseFall(item.rate>0,true)">
										{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
									</view>
								</view>
							</view>
						</view>
					</block>
				</view>
			</template>
		</view> -->



		<!-- <view style="height: 200rpx;"></view> -->

<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#F8C351`:`#959CA0`}" @click="changeTab(index)"> 
					
					{{item}}
				</view>
			</block>
		</view>







		<view :class="setClass"
			style="padding-top: 10px; background-color: #FFFFFF;margin:20rpx;border-radius: 28rpx;min-height: 100vh;">
			<template v-if="curTab==0">
				<MarketTrack ref="track" @action="linkStock"></MarketTrack>
			</template>
			<template v-else-if="curTab==1">
				<MarketStockList ref="all"></MarketStockList>
			</template>
			<template v-else-if="curTab==2">
				<MarketHot ref="hot"></MarketHot>
			</template>
			<template v-else>
				<MarketKPI ref="kpi"></MarketKPI>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList,
			CustomTitle,
			MarketHot,
			MarketKPI,
			EmptyData
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
				topList: null, // 指数数组
				marketList: [], // 市场股票
				timer: null,
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				top111: {
					141: "코스닥",
					17470: "코스피 200",
					255: "코스피",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kLineChart: null,
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				industryList: [],
				hotNewList: [],

			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					this.$lang.MARKET_INDEX_TAB_MARKET,
					this.$lang.MARKET_INDEX_TAB_HOP,
					this.$lang.MARKET_INDEX_TAB_KPI



				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		beforeMount() {
			this.getData();
			this.gethotNewList();
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},

		onShow() {

			this.isAnimat = true;
			console.log(this.cardLabels);
			this.getMarketTop();

			// this.getTopList();
		},
		onReady() {
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},

			// 通知父组件切换tab
			handleChangeTab() {
				this.$emit(`action`, 3);
			},


			linkstockList() {
				uni.navigateTo({
					url: this.$paths.MARKET_STOCKLIST
				})
			},

			// 获取市场top数据
			async getMarketTop() {


				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: 0
				});
				if (!result) return false;
				this.marketList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},

			linkDetail(val) {
				console.log(`??`, val);
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?code=${val.code}`
				})
			},
			// 取关
			async handleUnFollow(id) {
				uni.showLoading({
					title: this.$lang.STATUS_SUBMIT,
				});
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				uni.showToast({
					title: this.$lang.TIP_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.getMarketTop();
				}, 1000)
			},

			//获取热点新闻数据
			async gethotNewList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/get_news`);
				if (!result) return false;
				this.hotNewList = result || [];
			},

			setNewsTitleText(val) {
				let temp = '';
				return temp = val.length <= 30 ? val : val.slice(0, 26) + '...'
			},
			setText(val) {
				let temp = '';
				return temp = val.length <= 18 ? val : val.slice(0, 15) + '...'
			},

			setsubText(val) {
				let temp = '';
				return temp = val.length <= 20 ? val : val.slice(0, 16) + '...'
			},
			open(url) {
				window.open(url)
			},

			barStyle(value) {
				value = value * 2 * 10
				let percentage = Math.min(Math.abs(value), 100); // 确保百分比限制在 0 到 100 之间
				if (value > 0) {
					// 正数时，从中间往右显示红色，左边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #fe474f 50%, #fe474f ${50 + (percentage / 2)}%, #e9e9ea ${50 + (percentage / 2)}%)`,
					};
				} else if (value < 0) {
					// 负数时，从中间往左显示绿色，右边保持灰色
					return {
						background: `linear-gradient(to right, #e9e9ea ${50 - (percentage / 2)}%, #1e6be1 ${50 - (percentage / 2)}%, #1e6be1 50%, #e9e9ea 50%)`,
					};
				} else {
					// 值为 0 时，保持全灰色
					return {
						background: `linear-gradient(to right, #e9e9ea 50%, #e9e9ea 50%)`,
					};
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 5000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			changeTab(val) {
				this.current1 = val;
				this.curTab = val;
				this.getData()
			},
			handleChangeTabHot(val) {
				console.log('top:', val);
				this.current2 = val;
				this.top_two()
			},
			handleChangeType(val) {
				this.stockId = val;
				this.getData()
			},

			open(url) {
				window.open(url)
			},

			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`,
				})
			},

			handleHot() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=3`,
				})
			},

			async getData() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/top1`, {
					current1: this.current1,
					stockid: this.stockId
				});
				console.log('getData:', result);
				if (!result) return false;
				this.top1 = result.top1
				this.article = result.article;
				this.industryList = result.bottom;








			},
			
			async getAllList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/list`);
				if (!result) return false;
				console.log('result:', result);
				const temp = result.length <= 0 ? [] : result.filter(item => item.stock_id && item
					.stock_id > 0);
				this.allList = !temp || temp.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code || '',
						price: item.close || 0,
						rate: item.returns || 0,
						type_id: item.project_type_id || 0,
					}
				});
			},
			
			// 热门
			async getHotList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/paihang`, {
					current: this.curHotTab
				})
				if (!result) return false;
				console.log(result);
				this.hotList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code,
						price: item.close || 0,
						rate: item.returns || 0,
						follow: item.sc,
						gid: item.gid,
					}
				});
			},
			// 指标
			async getKpiList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/zhibiao`, {
					current: this.curKpiTab
				})
				// console.log('result, result);
				if (!result) return false;
				this.kpiList = Object.values(result).map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
			
			
			
		},
	}
</script>