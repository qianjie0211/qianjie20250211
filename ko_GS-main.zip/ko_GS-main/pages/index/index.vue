<!-- 主页 -->
<template>
	<view class="common_page_bg" style="min-height: 100vh;">
		<Header :title="$lang.HOME"></Header>
		
		<view style="width: 100%;justify-content: center;display: flex;">
			<image src="../../static/sy_tu.png" mode="widthFix" style="width: 95%;"></image>
		</view>

		<view style="">
			<ButtonGroup :btns="$util.businessBtnsConfig()" col="25"></ButtonGroup>
		</view>
		
		<view class="flex" style="padding: 100px 10px; justify-content: space-between; ">
			<block v-for="(item,index) in goodsList.slice(0, 1)" :key="index">
			<view class="sy_gupiao" style="padding: 20px 10px;width: 43%;">
				<view style="">
				<view class="font-size-16 bold">{{item.ko_name}}</view>
				<view style="padding: 5px 0px;color: #999;">{{item.code}}</view>
				<view class="flex margin-top-5">
					<view class="font-size-16" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatNumber(item.close*1)}}</view>
					<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.setImageSize(20)" style="margin-left: 15px;"></image>
					<view style="font-size: 15px;margin-left: 5px;" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatMathABS(1*item.returns).toFixed(2)}}%</view>
				</view>
				</view>
			</view>
			</block>
			<block v-for="(item,index) in goodsList.slice(1, 2)" :key="index">
			<view class="sy_gupiao2" style="padding:20px 10px;width: 43%;">
				<view class="font-size-16 bold">{{item.ko_name}}</view>
				<view style="padding: 5px 0px;color: #999;">{{item.code}}</view>
				<view class="flex margin-top-5">
					<view class="font-size-17" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatNumber(item.close*1)}}</view>
					<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.setImageSize(20)" style="margin-left: 15px;"></image>
					<view style="font-size: 15px;margin-left: 5px;" :style="{color:`${item.returns>0?'#ff3636':'#18BFB4'}`}">{{$util.formatMathABS(1*item.returns).toFixed(2)}}%</view>
				</view>
			</view>
			</block>
		</view>
		<view style="margin-top: -80px;">
			<view class="flex" style="padding: 10px 15px;">
				<view class="font-size-18 flex-1">인기 주식</view>
				<view class="flex" @click="gupiao()">
					<view>인기 주식</view>
					<image src="../../static/jiantou.png" mode="widthFix" style="width: 10px;margin-left: 5px;"></image>
				</view>
			</view>
			<GoodsList :list="goodsList"></GoodsList>
		</view>
		
		
		

		<!-- <NotifyPrimary></NotifyPrimary> -->

		<!-- <Favorites :list="freeList"></Favorites> -->
		
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import NotifyPrimary from '@/components/notify/NotifyPrimary.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			NotifyPrimary,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				userinfo: [],
				// show_money: true,
				page: 1,
				goodsList: [],
				gp_index: 0,
				freeList: []
			}
		},
		mounted() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.free()
			this.startTimer()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		},
		methods: {
			// 银转证
			silver(money, bank_card_info, idno) {
				uni.$u.toast('고객 서비스 매니저에 연락해주세요.');
				return
				// if (bank_card_info && idno !== null) {
				// uni.navigateTo({
				// 	//保留当前页面，跳转到应用内的某个页面
				// 	url: '/pages/service/service'
				// });
			},
			gupiao(){
				uni.reLaunch({
					url:'/pages/free/free'
				})
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let result = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = result.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = result.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/signin/signin'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let result = await this.$http.get('api/user/collect_list', {})
				this.freeList = result.data.data.list
			},
		},
	}
</script>

<style lang="scss">

</style>