<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;" scroll-left="10" @click="linkMarketNews()" >
		<template v-if="article && article.length>0">
			<block v-for="(item,index) in article" :key="index" v-if="index<=0" >
				<view class="padding-5" >
					<view style="padding: 10px;background-color: #FFFFFF;border-radius: 10px;">
						<view class="flex" style="width: 90%;">
							<view>
								<image :src="item.pic" mode="scaleToFill" style="border-radius:5px;"
									:style="$theme.setImageSize(280,160)">
								</image>
							</view>
							<view style=" padding-left: 10px;" >
								<view style="font-weight: bold; font-size: 14px;word-wrap: break-word; word-break: break-all; white-space: normal;width: 120%; ">{{setText(item.title)}}</view>
								<view style="font-size: 12px;color: #999;margin-top: 10px;">{{item.created_at}}</view>
							</view>
						</view>
					</view>
				</view>
				
			</block>
		</template>
	</scroll-view>
</template>

<script>
	export default {
		name: 'MarketNewsTop',
		data() {
			return {
				article: []
			}
		},
		created() {
			this.getData();
		},
		methods: {
			open(url) {
				window.open(url)
			},
			xinwen(){
				uni.navigateTo({
					url:'/pages/market/overview?type=3'
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=3`,
				})
			},
			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 15 ? val : val.slice(0, 60) + '...'
			},

			async getData() {
				const result = await this.$http.get(`api/goods/top1`);
				this.article = result.article || [];
			},
		}
	}
</script>