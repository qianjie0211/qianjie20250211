<!-- 우승기록 -->
<template>
	<view>
		<view style="font-size: 18px;color: #fff;width: 100%;display: flex;background-color: #1dc0b5;padding: 10px;padding-top: 30px;">
		<view style="width: 90%;justify-content: flex-end; display: flex; " >
		<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;" @click="handleBack()"></image>
		<view class="flex justify-center" style="color: #fff;font-size: 18px;width: 100%;">当選履歴</view>
		</view>
		</view>
		<view>
		<view class=""style="background: linear-gradient(to bottom, #1dc0b5, #8fe0db,#f3f4f8);height: 180px;" >
		</view>
		</view>
		
	
		    
		<view style="width: 100%;border-radius: 10px;margin-top: -160px;">
		
		
		
		<EmptyData v-if="list.length<=0" style="color: #38aa9a;"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="background-color: #FFF;width: 95%;margin: 10px;border-radius: 10px;">
				<view style="justify-content: space-between;padding-bottom: 6px;padding: 10px;">
					<view style="font-size: 18px;">{{item.goods.name}}</view>
					<view style="font-size: 16px;color:seagreen;">
						<view v-if="item.status==2" class="" @click="subscription(item)">購読する</view>
					</view>
				</view>
				<view style="margin-left: 10px;">
					<view style="" :style="{color:$util.THEME.TIP}">銘柄評価額</view>
					<view  style="font-size: 18px;margin-top: 5px;color: #1dc0b5;">
						{{$util.formatNumber(item.price)}}
					</view>
					</view>
				
				<view class="flex margin-10">
					<view class="flex-1" :style="{color:$util.THEME.TIP}">当選数量</view>
					<view >
						{{$util.formatNumber(item.apply_amount)}}
					</view>
				</view>
				
				<view class="flex margin-10">
					<view class="flex-1" :style="{color:$util.THEME.TIP}">公募額</view>
					<view >
						{{$util.formatNumber(item.success_num_amount)}}
					</view>
				</view>
				
				<view class="flex margin-10">
					<view class="flex-1" :style="{color:$util.THEME.TIP}">数量</view>
					<view >
						{{$util.formatNumber(item.success)}}
					</view>
				</view>
				
				<view class="flex margin-10">
					<view class="flex-1" :style="{color:$util.THEME.TIP}">取引日</view>
					<view >
						{{item.created_at}}
					</view>
				</view>
				
				<view class="flex margin-10">
					<view class="flex-1" :style="{color:$util.THEME.TIP}">注文番号</view>
					<view >
						{{item.order_sn}}
					</view>
				</view>
					<view style="padding-top: 10px;"></view>
			</view>
		</block>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			// 우승기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
			async kefu() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							this.kefu()
						}, 500)
					} else {
						uni.redirectTo({
							url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
						});
						this.$router.go(0)

					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},

		},
		onLoad(option) {
			this.shengou()
			// this.gaint_info()
		}
		// mounted() {
		// 	// uni.showLoading({
		// 	// 	title: '加载中'
		// 	// });

		// },
	}
</script>